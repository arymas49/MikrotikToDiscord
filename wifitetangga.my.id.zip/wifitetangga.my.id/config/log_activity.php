<?php
// C:\xampp\htdocs\billing_isp_app\config\log_activity.php

// Pastikan koneksi database sudah ada ($koneksi)
// Dan session sudah dimulai serta $_SESSION['user_id'], $_SESSION['username'], $_SESSION['role'] sudah ada

function logActivity($activity_type, $description) {
    global $koneksi; // Menggunakan koneksi database yang sudah ada

    // Pastikan user sudah login
    if (!isset($_SESSION['user_id']) || !isset($_SESSION['username']) || !isset($_SESSION['role'])) {
        // Jika tidak ada sesi user, log sebagai 'Guest' atau 'System'
        $user_id = 0; // ID 0 untuk user tidak teridentifikasi
        $username = 'System/Guest';
        $role = 'Guest';
    } else {
        $user_id = $_SESSION['user_id'];
        $username = $_SESSION['username'];
        $role = $_SESSION['role'];
    }

    $ip_address = $_SERVER['REMOTE_ADDR'] ?? 'UNKNOWN'; // Mengambil IP address user

    $stmt = $koneksi->prepare("INSERT INTO activity_logs (user_id, username, role, activity_type, description, ip_address) VALUES (?, ?, ?, ?, ?, ?)");
    if ($stmt === false) {
        // Error dalam mempersiapkan statement, mungkin masalah koneksi atau sintaks SQL
        error_log("Error preparing log activity statement: " . $koneksi->error);
        return false;
    }

    $stmt->bind_param("isssss", $user_id, $username, $role, $activity_type, $description, $ip_address);

    if ($stmt->execute()) {
        $stmt->close();
        return true;
    } else {
        // Error saat mengeksekusi statement
        error_log("Error executing log activity statement: " . $stmt->error);
        $stmt->close();
        return false;
    }
}
?>