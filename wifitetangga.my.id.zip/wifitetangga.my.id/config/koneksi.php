<?php
// C:\xampp\htdocs\billing_isp_app\config\koneksi.php

$host = 'localhost'; // Ganti jika database Anda di server lain
$user = 'anjing';      // Username database Anda
$pass = 'Puki49';          // Password database Anda (kosong jika XAMPP default)
$db_name = 'ariradius'; // Nama database Anda

// Buat koneksi mysqli
$koneksi = new mysqli($host, $user, $pass, $db_name);

// Periksa koneksi
if ($koneksi->connect_error) {
    die("Koneksi database gagal: " . $koneksi->connect_error);
}
// Set charset untuk memastikan karakter ditampilkan dengan benar
$koneksi->set_charset("utf8mb4");

?>