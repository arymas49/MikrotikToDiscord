<?php
// xendit_config.php

return [
    'xendit_secret_key' => 'a',
    'xendit_public_key' => 'a',
    'xendit_callback_token' => 'a',
    'base_url' => 'https://wifitetangga.my.id'
];
?>