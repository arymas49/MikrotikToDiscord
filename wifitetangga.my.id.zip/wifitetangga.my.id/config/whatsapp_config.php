<?php

return array (
  'whatsapp_api_url' => 'https://api.fonnte.com/send',
  'whatsapp_api_key' => 'gainL1zxa1ZbgzkAY9zH',
  'instance_id' => 'YOUR_INSTANCE_ID',
  'device_id' => 'tzn_bot_pay',
  'app_base_url' => 'https://wifitetangga.my.id',
  'api_access_token' => 'tzn1426',
);

?>