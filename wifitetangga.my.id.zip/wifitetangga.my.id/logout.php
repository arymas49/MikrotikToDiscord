<?php
// C:\xampp\htdocs\billing_isp_app\logout.php
ini_set('session.use_strict_mode', 1);
ini_set('session.cookie_httponly', 1);
ini_set('session.cookie_samesite', 'Lax');
if (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on') {
    ini_set('session.cookie_secure', 1);
}
session_start();
include 'config/koneksi.php'; // Pastikan koneksi tersedia untuk log
include 'config/log_activity.php'; // Sertakan fungsi log

// Log aktivitas logout sebelum sesi dihancurkan
if (isset($_SESSION['username'])) {
    logActivity('Logout', 'User ' . $_SESSION['username'] . ' berhasil logout.');
}

// Hancurkan semua data sesi
session_destroy();
// Redirect ke halaman login
header('Location: index.php');
exit();
?>