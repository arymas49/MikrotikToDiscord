<?php
// C:\xampp\htdocs\billing_isp_app\includes\sidebar.php

// Ambil data user dari sesi (fungsi ini ada di header.php, jadi sudah tersedia)
$logged_in_username = $_SESSION['username'] ?? 'User';
$logged_in_role = $_SESSION['role'] ?? 'Guest';
$logged_in_id = $_SESSION['user_id'] ?? 'N/A';

// Base path untuk semua halaman di folder pages/
$base_url_pages = '../pages/';

// Fungsi isActive() dan isParentActive() TIDAK DIDEFINISIKAN DI SINI.
// Mereka didefinisikan satu kali di header.php
?>
<aside class="admin-sidebar" id="adminSidebar">
    <nav class="sidebar-nav">
        <div class="nav-section-title"><span class="link-text">Dashboard</span></div>
        <ul>
            <li class="<?php echo isActive('dashboard.php'); ?>">
                <a href="<?php echo htmlspecialchars($base_url_pages, ENT_QUOTES, "UTF-8"); ?>dashboard.php">
                    <i class="fa-solid fa-house"></i> <span class="link-text">Beranda</span>
                </a>
            </li>
        </ul>

        <div class="nav-section-title"><span class="link-text">Pelanggan</span></div>
        <ul>
            <li class="<?php echo isActive('manajemen_paket.php'); ?>">
                <a href="<?php echo htmlspecialchars($base_url_pages, ENT_QUOTES, "UTF-8"); ?>manajemen_paket.php">
                    <i class="fas fa-box-open"></i> <span class="link-text">Manajemen Paket</span>
                </a>
            </li>
            <li class="<?php echo isActive('manajemen_pelanggan.php'); ?>">
                <a href="<?php echo htmlspecialchars($base_url_pages, ENT_QUOTES, "UTF-8"); ?>manajemen_pelanggan.php">
                    <i class="fas fa-users"></i> <span class="link-text">Manajemen Pelanggan</span>
                </a>
            </li>
        </ul>

        <div class="nav-section-title"><span class="link-text">Billing</span></div>
        <ul>
            <li class="<?php echo isActive('pembayaran.php'); ?>">
                <a href="<?php echo htmlspecialchars($base_url_pages, ENT_QUOTES, "UTF-8"); ?>pembayaran.php">
                    <i class="fas fa-file-invoice"></i> <span class="link-text">Pembayaran</span>
                </a>
            </li>
            <li class="<?php echo isActive('pengeluaran.php'); ?>">
                <a href="<?php echo htmlspecialchars($base_url_pages, ENT_QUOTES, "UTF-8"); ?>pengeluaran.php">
                    <i class="fas fa-exchange-alt"></i> <span class="link-text">Pengeluaran</span>
                </a>
                </li>
            <li class="<?php echo isActive('laporan_keuangan.php'); ?>">
                <a href="<?php echo htmlspecialchars($base_url_pages, ENT_QUOTES, "UTF-8"); ?>laporan_keuangan.php">
                    <i class="fa-solid fa-file-invoice-dollar"></i> <span class="link-text">Laporan Pengeluaran</span>
                </a>
            </li>
            <li class="<?php echo isActive('buat_tagihan_manual.php'); ?>">
                <a href="<?php echo htmlspecialchars($base_url_pages, ENT_QUOTES, "UTF-8"); ?>buat_tagihan_manual.php">
                    <i class="fas fa-file-invoice"></i> <span class="link-text">Buat Tagihan Manual</span>
                </a>
            </li>
            <li class="<?php echo isActive('buat_nota_manual_jasa.php'); ?>">
                <a href="<?php echo htmlspecialchars($base_url_pages, ENT_QUOTES, "UTF-8"); ?>buat_nota_manual_jasa.php">
                    <i class="fas fa-receipt"></i> <span class="link-text">Buat Nota Manual</span>
                </a>
            </li>
            <!-- Modifikasi untuk Pembayaran Online (Xendit) dengan submenu -->
            <li class="has-submenu <?php echo isParentActive(['pembayaran_online_xendit.php', 'xendit_api_settings.php']); ?>">
                <a href="javascript:void(0);" class="dropdown-toggle">
                    <i class="fas fa-money-check-alt"></i> <span class="link-text">Pembayaran Online (Xendit)</span> <i class="fas fa-chevron-down dropdown-arrow"></i>
                </a>
                <ul class="submenu">
                    <li class="<?php echo isActive('pembayaran_online_xendit.php'); ?>"><a href="<?php echo htmlspecialchars($base_url_pages, ENT_QUOTES, "UTF-8"); ?>pembayaran_online_xendit.php"><span class="link-text">Manajemen Invoice</span></a></li>
                    <li class="<?php echo isActive('xendit_api_settings.php'); ?>"><a href="<?php echo htmlspecialchars($base_url_pages, ENT_QUOTES, "UTF-8"); ?>xendit_api_settings.php"><span class="link-text">Pengaturan Xendit API</span></a></li>
                </ul>
            </li>
        </ul>

        <div class="nav-section-title"><span class="link-text">Dashboard Karyawan</span></div>
        <ul>
            <li class="<?php echo isActive('dashboard_sales.php'); ?>">
                <a href="<?php echo htmlspecialchars($base_url_pages, ENT_QUOTES, "UTF-8"); ?>dashboard_sales.php">
                    <i class="fas fa-handshake"></i> <span class="link-text">Dashboard Sales</span>
                </a>
            </li>
            <li class="<?php echo isActive('dashboard_penagih.php'); ?>">
                <a href="<?php echo htmlspecialchars($base_url_pages, ENT_QUOTES, "UTF-8"); ?>dashboard_penagih.php">
                    <i class="fas fa-handshake"></i> <span class="link-text">Dashboard Penagih</span>
                </a>
            </li>
            <li class="<?php echo isActive('manajemen_sales.php'); ?>">
                <a href="<?php echo htmlspecialchars($base_url_pages, ENT_QUOTES, "UTF-8"); ?>manajemen_sales.php">
                    <i class="fas fa-user-tie"></i> <span class="link-text">Manajemen Sales</span>
                </a>
            </li>
            <li class="<?php echo isActive('manajemen_penagih.php'); ?>">
                <a href="<?php echo htmlspecialchars($base_url_pages, ENT_QUOTES, "UTF-8"); ?>manajemen_penagih.php">
                    <i class="fas fa-people-carry"></i> <span class="link-text">Manajemen Penagih</span>
                </a>
            </li>
        </ul>
        <?php if (hasRole('superadmin')): ?>
        <div class="nav-section-title"><span class="link-text">Pengaturan</span></div>
        <ul>
            <li class="has-submenu <?php echo isParentActive(['dashboard_mikrotik.php', 'mikrotik_settings.php', 'cetak_voucher.php', 'hotspot_active_users.php', 'hotspot_cookies.php', 'export_hotspot_users.php', 'edit_hotspot_user.php', 'radius_settings.php']); ?>">
                <a href="javascript:void(0);" class="dropdown-toggle">
                    <i class="fa-solid fa-network-wired"></i><span class="link-text">Mikrotik</span> <i class="fas fa-chevron-down dropdown-arrow"></i>
                </a>
                <ul class="submenu">
                    <li class="<?php echo isActive('dashboard_mikrotik.php'); ?>"><a href="<?php echo htmlspecialchars($base_url_pages, ENT_QUOTES, "UTF-8"); ?>dashboard_mikrotik.php"><span class="link-text">Dashboard Mikrotik</span></a></li>
                    <li class="<?php echo isActive('cetak_voucher.php'); ?>"><a href="<?php echo htmlspecialchars($base_url_pages, ENT_QUOTES, "UTF-8"); ?>cetak_voucher.php"><span class="link-text">Cetak Voucher</span></a></li>
                    <li class="<?php echo isActive('hotspot_active_users.php'); ?>"><a href="<?php echo htmlspecialchars($base_url_pages, ENT_QUOTES, "UTF-8"); ?>hotspot_active_users.php"><span class="link-text">Hotspot Aktif</span></a></li>
                    <li class="<?php echo isActive('hotspot_cookies.php'); ?>"><a href="<?php echo htmlspecialchars($base_url_pages, ENT_QUOTES, "UTF-8"); ?>hotspot_cookies.php"><span class="link-text">Hotspot Cookies</span></a></li>
                    <li class="<?php echo isActive('export_hotspot_users.php'); ?>"><a href="<?php echo htmlspecialchars($base_url_pages, ENT_QUOTES, "UTF-8"); ?>export_hotspot_users.php"><span class="link-text">Export Hotspot Users</span></a></li>
                    <li class="<?php echo isActive('mikrotik_settings.php'); ?>"><a href="<?php echo htmlspecialchars($base_url_pages, ENT_QUOTES, "UTF-8"); ?>mikrotik_settings.php"><span class="link-text">Pengaturan API</span></a></li>
                    <!-- Tambahkan link baru untuk pengaturan RADIUS -->
                    <li class="<?php echo isActive('radius_settings.php'); ?>"><a href="<?php echo htmlspecialchars($base_url_pages, ENT_QUOTES, "UTF-8"); ?>radius_settings.php"><span class="link-text">Pengaturan RADIUS</span></a></li>
                </ul>
            </li>
            <li class="has-submenu <?php echo isParentActive(['whatsapp_gateway_settings.php', 'broadcast_message.php', 'sent_messages.php', 'unsent_messages.php']); ?>">
                 <a href="javascript:void(0);" class="dropdown-toggle">
                    <i class="fab fa-whatsapp"></i> <span class="link-text">WhatsApp</span> <i class="fas fa-chevron-down dropdown-arrow"></i>
                </a>
                <ul class="submenu">
                    <li class="<?php echo isActive('whatsapp_gateway_settings.php'); ?>"><a href="<?php echo htmlspecialchars($base_url_pages, ENT_QUOTES, "UTF-8"); ?>whatsapp_gateway_settings.php"><span class="link-text">Gateway Settings</span></a></li>
                    <li class="<?php echo isActive('broadcast_message.php'); ?>"><a href="<?php echo htmlspecialchars($base_url_pages, ENT_QUOTES, "UTF-8"); ?>broadcast_message.php"><span class="link-text">Broadcast Message</span></a></li>
                    <li class="<?php echo isActive('sent_messages.php'); ?>"><a href="<?php echo htmlspecialchars($base_url_pages, ENT_QUOTES, "UTF-8"); ?>sent_messages.php"><span class="link-text">Sent Messages</span></a></li>
                    <li class="<?php echo isActive('unsent_messages.php'); ?>"><a href="<?php echo htmlspecialchars($base_url_pages, ENT_QUOTES, "UTF-8"); ?>unsent_messages.php"><span class="link-text">Unsent Messages</span></a></li>
                </ul>
            </li>
            <li class="<?php echo isActive('user_settings.php'); ?>">
                <a href="<?php echo htmlspecialchars($base_url_pages, ENT_QUOTES, "UTF-8"); ?>user_settings.php">
                    <i class="fas fa-user-cog"></i> <span class="link-text">Pengaturan User</span>
                </a>
            </li>
            <li class="<?php echo isActive('backup_restore.php'); ?>">
                <a href="<?php echo htmlspecialchars($base_url_pages, ENT_QUOTES, "UTF-8"); ?>backup_restore.php">
                    <i class="fas fa-database"></i> <span class="link-text">Backup & Restore DB</span>
                </a>
            </li>
            <li class="<?php echo isActive('activity_logs.php'); ?>">
                <a href="<?php echo htmlspecialchars($base_url_pages, ENT_QUOTES, "UTF-8"); ?>activity_logs.php">
                    <i class="fas fa-history"></i> <span class="link-text">Log Aktivitas</span>
                </a>
            </li>
            <li class="<?php echo isActive('change_password.php'); ?>">
                <a href="<?php echo htmlspecialchars($base_url_pages, ENT_QUOTES, "UTF-8"); ?>change_password.php">
                    <i class="fas fa-key"></i> <span class="link-text">Change Password</span>
                </a>
            </li>
        </ul>
        <?php endif; ?>
    </nav>
</aside>