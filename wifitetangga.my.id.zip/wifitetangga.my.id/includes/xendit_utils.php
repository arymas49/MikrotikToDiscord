<?php
// C:\xampp\htdocs\billing_isp_app\includes\xendit_utils.php

// Impor kelas-kelas yang diperlukan untuk Xendit SDK
use Xendit\Xendit; 
use Xendit\Configuration; 
use Xendit\Invoice\CreateInvoiceRequest; 
use Xendit\Invoice\InvoiceApi; 
use Xendit\Exceptions\ApiException; 

// --- PENTING: Impor kelas-kelas spesifik metode pembayaran dari SDK v3.x ---
// Pastikan nama kelas ini sesuai dengan struktur folder vendor/xendit/xendit-php/src/Invoice/
use Xendit\Invoice\QrCode;
use Xendit\Invoice\QrCodeType;
use Xendit\Invoice\Bank;
use Xendit\Invoice\BankCode; // Memastikan ini di-use untuk konstanta bank
use Xendit\Invoice\Ewallet;
use Xendit\Invoice\EwalletType; // Memastikan ini di-use untuk konstanta e-wallet
use Xendit\Invoice\RetailOutlet;
use Xendit\Invoice\RetailOutletName; // <--- SANGAT PENTING: Menggunakan RetailOutletName
use Xendit\Invoice\Paylater; 
use Xendit\Invoice\PaylaterType; 
// --------------------------------------------------------------------------------------------------

// Fungsi untuk membuat invoice Xendit
function createXenditInvoice($xenditConfig, $local_tagihan_id, $amount, $customer_name, $customer_email, $description, $due_date) {
    try {
        $config = Configuration::getDefaultConfiguration();
        $config->setApiKey($xenditConfig['xendit_secret_key']);

        $apiInstance = new InvoiceApi();

        // --- DEFINISI payment_channel_properties sesuai SDK v3.x ---
        // Ini adalah cara yang benar dan lengkap untuk mengirim metode pembayaran.
        $paymentChannelProperties = [];

        // 1. QRIS
        // Status: Activated (sesuai screenshot dashboard)
        $paymentChannelProperties[] = new QrCode([
            'qr_code_type' => QrCodeType::QRIS, //
        ]);
        $paymentChannelProperties[] = new Bank([
            'bank_code' => BankCode::BJB, // Activated
            'collection_type' => 'VA',
            'account_holder_name' => $customer_name
        ]);
        $paymentChannelProperties[] = new Bank([
            'bank_code' => BankCode::BNI, // Activated
            'collection_type' => 'VA',
            'account_holder_name' => $customer_name
        ]);
        $paymentChannelProperties[] = new Bank([
            'bank_code' => BankCode::BRI, // Activated
            'collection_type' => 'VA',
            'account_holder_name' => $customer_name
        ]);
        $paymentChannelProperties[] = new Bank([
            'bank_code' => BankCode::BSI, // Activated
            'collection_type' => 'VA',
            'account_holder_name' => $customer_name
        ]);
        $paymentChannelProperties[] = new Bank([
            'bank_code' => BankCode::CIMB, // Activated
            'collection_type' => 'VA',
            'account_holder_name' => $customer_name
        ]);
        $paymentChannelProperties[] = new Bank([
            'bank_code' => BankCode::MANDIRI, // Activated
            'collection_type' => 'VA',
            'account_holder_name' => $customer_name
        ]);
        $paymentChannelProperties[] = new Bank([
            'bank_code' => BankCode::PERMATA, // Activated
            'collection_type' => 'VA',
            'account_holder_name' => $customer_name
        ]);
        $paymentChannelProperties[] = new Bank([
            'bank_code' => BankCode::SAHABAT_SAMPOERNA, //
            'collection_type' => 'VA',
            'account_holder_name' => $customer_name
        ]);
        // MUAMALAT, HANA: Ada di BankCode.php, tapi Anda minta dihilangkan/tidak aktif di dashboard
        // Jadi saya akan tetap hilangkan untuk memastikan hanya yang aktif di dashboard.

        // 3. E-Wallets - HANYA YANG AKTIF DI DASHBOARD ANDA
        // Referensi file EwalletType.php:
        $paymentChannelProperties[] = new Ewallet([
            'ewallet_type' => EwalletType::ASTRAPAY, // Activated
        ]);
        
        $paymentChannelProperties[] = new Ewallet([
            'ewallet_type' => EwalletType::SHOPEEPAY, // Activated
        ]);
        // OVO, LinkAja, DANA, ShopeePay, GOPAY: Tidak aktif/tersedia di screenshot (DIHILANGKAN)

        // 4. Retail Outlets - HANYA YANG AKTIF DI DASHBOARD ANDA
        // Referensi file RetailOutletName.php:
        $paymentChannelProperties[] = new RetailOutlet([
            'retail_outlet_name' => RetailOutletName::INDOMARET, // Activated
        ]);

        $paymentChannelProperties[] = new RetailOutlet([
            'retail_outlet_name' => RetailOutletName::ALFAMART, // Activated
        ]);
        // ALFAMART: Not Activated (DIHILANGKAN)

        // 5. PayLater - HANYA YANG AKTIF DI DASHBOARD ANDA
        // Referensi file PaylaterType.php:
        $paymentChannelProperties[] = new Paylater([
            'paylater_type' => PaylaterType::AKULAKU, // Activated
        ]);
        $paymentChannelProperties[] = new Paylater([
            'paylater_type' => PaylaterType::KREDIVO, // Activated
        ]);

        $params = [
            'external_id'       => 'billing-isp-' . $local_tagihan_id,
            'amount'            => $amount,
            'payer_email'       => $customer_email,
            'description'       => $description,
            'invoice_duration'  => 86400, 
            'customer'          => [
                'given_names' => $customer_name,
                'email'       => $customer_email,
            ],
            'payment_channel_properties' => $paymentChannelProperties, 
            
            // Hapus baris 'payment_methods' lama yang hanya array string
            // 'payment_methods' => ['QRIS', 'VA', 'EWALLET', 'ALFAMART', 'INDOMARET'], 

            'callback_url'      => $xenditConfig['base_url'] . '/callbacks/xendit_callback.php',
            'success_redirect_url' => $xenditConfig['base_url'] . '/pages/success_pembayaran.php?tagihan_id=' . $local_tagihan_id,
            'failure_redirect_url' => $xenditConfig['base_url'] . '/pages/failed_pembayaran.php?tagihan_id=' . $local_tagihan_id,
            'currency'          => 'IDR',
            'customer_notification_preference' => [
                'invoice_created' => ['email'],
                'invoice_paid' => ['email'],
            ],
        ];

        // --- Tambahkan parameter 'items' jika PayLater (Akulaku) digunakan ---
        // Parameter 'items' wajib untuk PayLater (ref: dokumentation file 2, 3)
        $is_akulaku_paylater_active = false;
        foreach ($paymentChannelProperties as $channel) {
            if ($channel instanceof Paylater && $channel->getPaylaterType() === PaylaterType::AKULAKU) {
                $is_akulaku_paylater_active = true;
                break;
            }
        }

        if ($is_akulaku_paylater_active) {
            $params['items'] = [
                [
                    'name' => $description, // Menggunakan deskripsi tagihan sebagai nama item
                    'quantity' => 1,
                    'price' => $amount,
                    'category' => 'Internet Service Provider', // Sesuaikan dengan kategori layanan Anda
                    'url' => 'https://www.triplezhinetwork/layanan-internet', // Ganti dengan URL produk yang relevan
                ]
            ];
            // Jika ada lebih dari satu item, Anda bisa menambahkan loop di sini
            // Misalnya jika Anda memiliki detail layanan yang lebih granular.
        }

        error_log("Xendit Invoice Create Request Parameters (SDK v3.x): " . json_encode($params, JSON_PRETTY_PRINT));

        if ($due_date) {
            $expiry_datetime = new DateTime($due_date . ' 23:59:59'); 
            $params['due_at'] = $expiry_datetime->format(DateTime::ATOM); 
        }

        $createInvoiceRequest = new CreateInvoiceRequest($params);

        $apiResponse = $apiInstance->createInvoice($createInvoiceRequest);

        error_log("Xendit Invoice Create Response (Full from API, SDK v3.x): " . json_encode($apiResponse, JSON_PRETTY_PRINT));

        return [
            'success' => true,
            'invoice_id' => $apiResponse['id'],
            'payment_link' => $apiResponse['invoice_url'],
            'message' => 'Invoice created successfully.'
        ];

    } catch (ApiException $e) { 
        error_log("Xendit API Error: " . $e->getMessage() . " - Full Error: " . json_encode($e->getFullError()));
        return ['success' => false, 'message' => $e->getMessage()];
    } catch (Exception $e) {
        error_log("General Error in createXenditInvoice: " . $e->getMessage());
        return ['success' => false, 'message' => 'An unexpected error occurred: ' . $e->getMessage()];
    }
}