<?php
// C:\xampp\htdocs\billing_isp_app\includes\header.php

// Pastikan session dimulai jika belum
if (session_status() == PHP_SESSION_NONE) {
ini_set('session.use_strict_mode', 1);
ini_set('session.cookie_httponly', 1);
ini_set('session.cookie_samesite', 'Lax');
if (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on') {
    ini_set('session.cookie_secure', 1);
}
    session_start();
}

// Fungsi hasRole() - DIBUNGKUS DENGAN if (!function_exists())
if (!function_exists('hasRole')) {
    function hasRole($required_role) {
        if (!isset($_SESSION['role'])) {
            return false;
        }
        $user_role = $_SESSION['role'];

        if ($user_role === 'superadmin') {
            return true;
        }

        if (is_array($required_role)) {
            return in_array($user_role, $required_role);
        }
        else {
            return $user_role === $required_role;
        }
    }
}

// --- DEFINISI FUNGSI isACTIVE() dan isPARENTACTIVE() HANYA DI SINI ---
// Fungsi helper untuk menentukan apakah sebuah link aktif
if (!function_exists('isActive')) {
    function isActive($page_names) {
        $current_page = basename($_SERVER['PHP_SELF']);
        if (is_array($page_names)) {
            return in_array($current_page, $page_names) ? 'active' : '';
        }
        return ($current_page == $page_names) ? 'active' : '';
    }
}

// Fungsi helper untuk menentukan apakah parent menu (dengan submenu) aktif
if (!function_exists('isParentActive')) {
    function isParentActive($page_names_in_submenu) {
        $current_page = basename($_SERVER['PHP_SELF']);
        foreach ($page_names_in_submenu as $page_name) {
            if ($current_page == $page_name) {
                return 'active';
            }
        }
        return '';
    }
}
// --- AKHIR DEFINISI FUNGSI ---

// Cek apakah user sudah login
if (!isset($_SESSION['user_id'])) {
    header('Location: ../index.php');
    exit();
}

// Include log_activity.php jika diperlukan (tetap seperti sebelumnya)
include_once __DIR__ . '/../config/log_activity.php';

// Atur class body untuk layout dashboard
$is_dashboard_page = (basename($_SERVER['PHP_SELF']) == 'dashboard.php');
$body_class = $is_dashboard_page ? 'dashboard-layout' : '';
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Tetangga - Billing</title> <link rel="icon" href="../assets/images/Logo.png" type="image/png">

    <link rel="stylesheet" href="../css/style.css">
    <link rel="stylesheet" href="../css/mikrotik_dashboard_overrides.css"> <link rel="stylesheet" href="../css/loading_styles.css">
    <link rel="stylesheet" href="../css/loading_styles.css">

    <link rel="stylesheet" href="../css/mobile.css" media="screen and (max-width: 768px)">

    <link rel="preconnect" href="https://fonts.gstatic.com">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&family=Poppins:wght@400;500;600;700&family=Roboto:wght@400;500;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
</head>
<body class="<?php echo htmlspecialchars($body_class, ENT_QUOTES, "UTF-8"); ?> ">
    <div id="loadingOverlay" class="loading-overlay">
        <div class="loader"></div>
    </div>
    <div class="menu-toggle" id="menuToggle">
        <i class="fas fa-bars"></i>
    </div>

    <div class="sidebar-overlay" id="sidebarOverlay"></div>

    <?php
    // Pastikan path ini benar relatif terhadap header.php
    // header.php ada di includes/, sidebar.php juga di includes/
    include_once __DIR__ . '/sidebar.php';
    ?>

    <div class="global-app-bar">
        <button class="menu-toggle-desktop" id="menuToggleDesktop" style="z-index: 1003;">
            <i class="fas fa-bars"></i>
        </button>
        <div class="header-search-bar">
            <i class="fas fa-search"></i>
            <input type="text" placeholder="Nomor Invoice">
        </div>
        <div class="header-icons">
            <div class="profile-dropdown-container">
                <div class="user-profile-icon" id="profileDropdownToggle">
                    <img src="../assets/images/Logo.png" alt="Pengguna">
                </div>

                <div class="profile-dropdown-menu" id="profileDropdownMenu">
                    <div class="dropdown-header">
                        <p class="dropdown-name">Hallo, <?php echo htmlspecialchars($_SESSION['username'] ?? 'Pengguna'); ?></p>
                        <p class="dropdown-role"><?php echo htmlspecialchars($_SESSION['role'] ?? 'Tamu'); ?></p>
                    </div>
                    <a href="../logout.php" class="dropdown-item">
                        <i class="fas fa-sign-out-alt"></i> Keluar
                    </a>
                </div>
            </div>
        </div>
    </div>

    <div id="customNotification" class="custom-notification">
        <span class="notification-icon"></span>
        <span class="notification-message"></span>
        <button class="notification-close" onclick="hideNotification()">&times;</button>
    </div>
    <script>
    const sidebar = document.getElementById('adminSidebar');

    // Pulihkan scroll saat halaman dimuat
    window.addEventListener('DOMContentLoaded', () => {
        const savedScroll = localStorage.getItem('sidebarScroll');
        if (savedScroll !== null) {
        sidebar.scrollTop = parseInt(savedScroll, 10);
        }
    });

    // Simpan scroll saat pindah halaman (klik link)
    const links = sidebar.querySelectorAll('a[href]');
    links.forEach(link => {
        link.addEventListener('click', () => {
        localStorage.setItem('sidebarScroll', sidebar.scrollTop);
        });
    });
    </script>
    <script>
    // Global function to show custom notification
    // 'type' can be 'success', 'error', 'warning', 'info'
    window.showNotification = function(message, type = 'info', duration = 3000) {
        const notification = document.getElementById('customNotification');
        const iconSpan = notification.querySelector('.notification-icon');
        const messageSpan = notification.querySelector('.notification-message');

        if (!notification || !iconSpan || !messageSpan) {
            console.error('Notification elements not found.');
            return;
        }

        // Reset classes
        notification.className = 'custom-notification'; // Reset to base class
        iconSpan.className = 'notification-icon'; // Reset icon class

        // Add type class
        notification.classList.add(type);

        // Set icon based on type
        switch(type) {
            case 'success':
                iconSpan.classList.add('fas', 'fa-check-circle');
                break;
            case 'error':
                iconSpan.classList.add('fas', 'fa-times-circle');
                break;
            case 'warning':
                iconSpan.classList.add('fas', 'fa-exclamation-triangle');
                break;
            case 'info':
            default:
                iconSpan.classList.add('fas', 'fa-info-circle');
                break;
        }

        // Set message
        messageSpan.textContent = message;

        // Show notification
        notification.classList.add('show');

        // Auto-hide after duration
        setTimeout(() => {
            notification.classList.remove('show');
        }, duration);
    };

    // Global function to manually hide custom notification
    window.hideNotification = function() {
        const notification = document.getElementById('customNotification');
        if (notification) {
            notification.classList.remove('show');
        }
    };

    // --- DEFINISI FUNGSI showLoadingOverlay dan hideLoadingOverlay ---
    window.showLoadingOverlay = function() {
        // Membuat elemen overlay jika belum ada
        let overlay = document.getElementById('loadingOverlay');
        if (!overlay) {
            overlay = document.createElement('div');
            overlay.id = 'loadingOverlay';
            overlay.style.position = 'fixed';
            overlay.style.top = '0';
            overlay.style.left = '0';
            overlay.style.width = '100%';
            overlay.style.height = '100%';
            overlay.style.background = 'rgba(0, 0, 0, 0.7)';
            overlay.style.display = 'flex';
            overlay.style.justifyContent = 'center';
            overlay.style.alignItems = 'center';
            overlay.style.color = '#fff';
            overlay.style.fontSize = '24px';
            overlay.style.zIndex = '9999';
            overlay.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Memproses...';
            document.body.appendChild(overlay);
        } else {
            overlay.style.display = 'flex';
        }
    };

    window.hideLoadingOverlay = function() {
        let overlay = document.getElementById('loadingOverlay');
        if (overlay) {
            overlay.style.display = 'none';
        }
    };
    // --- AKHIR DEFINISI FUNGSI LOADING ---

    // Global function for custom confirmation modal
    window.showCustomConfirm = function(title, message, callback) {
        const modalId = 'customConfirmModal';
        let modal = document.getElementById(modalId);

        if (!modal) {
            modal = document.createElement('div');
            modal.id = modalId;
            modal.className = 'modal';
            modal.innerHTML = `
                <div class="modal-content">
                    <span class="close-button" id="customConfirmCloseBtn">&times;</span>
                    <h3 id="customConfirmTitle"></h3>
                    <div class="modal-body" id="customConfirmModalBody"></div>
                    <div class="modal-footer">
                        <button class="btn btn-primary" id="customConfirmBtnYes">Ya</button>
                        <button class="btn btn-secondary" id="customConfirmBtnNo">Tidak</button>
                    </div>
                </div>
            `;
            document.body.appendChild(modal);

            modal.querySelector('#customConfirmCloseBtn').onclick = () => {
                modal.style.display = 'none';
                callback(false);
            };
            modal.querySelector('#customConfirmBtnYes').onclick = () => {
                modal.style.display = 'none';
                callback(true);
            };
            modal.querySelector('#customConfirmBtnNo').onclick = () => {
                modal.style.display = 'none';
                callback(false);
            };
            window.addEventListener('click', (event) => {
                if (event.target === modal) {
                    modal.style.display = 'none';
                    callback(false);
                }
            });
        }
        document.getElementById('customConfirmTitle').innerText = title;
        document.getElementById('customConfirmModalBody').innerText = message;
        modal.style.display = 'block';
    };


    // document.addEventListener('DOMContentLoaded', function() {
        // --- LOGIKA TOGGLE SIDEBAR (untuk mobile/responsive) ---
        const menuToggle = document.getElementById('menuToggle');
        const adminSidebar = document.getElementById('adminSidebar');
        const sidebarOverlay = document.getElementById('sidebarOverlay');
        const body = document.body;

        if (menuToggle && adminSidebar && sidebarOverlay) {
            menuToggle.addEventListener('click', function() {
                adminSidebar.classList.toggle('active');
                sidebarOverlay.style.display = adminSidebar.classList.contains('active') ? 'block' : 'none';
            });

            sidebarOverlay.addEventListener('click', function() {
                adminSidebar.classList.remove('active');
                sidebarOverlay.style.display = 'none';
            });
        }

        // --- LOGIKA TOGGLE SIDEBAR UNTUK DESKTOP ---
        const menuToggleDesktop = document.getElementById('menuToggleDesktop');

        if (menuToggleDesktop && adminSidebar && body) {
            menuToggleDesktop.addEventListener('click', function() {
                body.classList.toggle('sidebar-collapsed');
                if (body.classList.contains('sidebar-collapsed')) {
                    localStorage.setItem('sidebarCollapsed', 'true');
                    // Saat collapsed, pastikan semua submenu tertutup dan HAPUS INLINE STYLES
                    closeAllSubmenus(true); // Kirim flag true untuk hapus inline styles
                } else {
                    localStorage.removeItem('sidebarCollapsed');
                    // Jika sidebar diperluas, buka kembali submenu yang aktif (dengan JS)
                    reopenActiveSubmenu();
                }
            });

            // Set state sidebar saat DOMContentLoaded (jika ada di localStorage)
            if (localStorage.getItem('sidebarCollapsed') === 'true') {
                body.classList.add('sidebar-collapsed');
                closeAllSubmenus(true); // HAPUS INLINE STYLES untuk memastikan CSS mengontrol
            }
        }

        // Fungsi helper untuk menutup semua submenu
        // Parameter 'forceClearInline' ditambahkan untuk menghapus inline styles saat collapsed
        function closeAllSubmenus(forceClearInline = false) {
            document.querySelectorAll('.sidebar-nav .has-submenu').forEach(parentLi => {
                parentLi.classList.remove('active', 'active-hover');
                const submenu = parentLi.querySelector('.submenu');
                if (submenu) {
                    // Selalu HAPUS SEMUA INLINE STYLE di sini agar CSS dapat mengontrol transisi
                    // Ini adalah kunci untuk memastikan transisi CSS bekerja
                    submenu.style.removeProperty('max-height');
                    submenu.style.removeProperty('opacity');
                    submenu.style.removeProperty('overflow');
                    submenu.style.removeProperty('visibility');
                    submenu.style.removeProperty('pointer-events');
                    submenu.style.removeProperty('transform');
                    submenu.style.removeProperty('transition');
                }
                const arrow = parentLi.querySelector('.dropdown-arrow');
                if (arrow) arrow.style.transform = 'rotate(0deg)';
            });
        }

        // Fungsi helper untuk membuka kembali submenu yang aktif saat halaman dimuat (jika sidebar tidak collapsed)
        // Fungsi ini akan menggunakan kelas 'active' dan membiarkan CSS yang mengontrol animasinya
        function reopenActiveSubmenu() {
            const currentPath = window.location.pathname.split('/').pop();
            const allNavLinksElements = document.querySelectorAll('.sidebar-nav ul li a');

            allNavLinksElements.forEach(link => {
                const linkPath = link.getAttribute('href') ? link.getAttribute('href').split('/').pop() : '';
                if (linkPath === currentPath) {
                    const currentLi = link.closest('li');
                    if (currentLi) {
                        currentLi.classList.add('active'); // Tandai link aktif

                        const parentSubmenu = currentLi.closest('.submenu');
                        if (parentSubmenu) {
                            const parentLiHasSubmenu = parentSubmenu.closest('li.has-submenu');
                            if (parentLiHasSubmenu) {
                                parentLiHasSubmenu.classList.add('active'); // Tandai parent aktif
                                // DI SINI HANYA TAMBAHKAN KELAS, JANGAN SET STYLE INLINE
                                // CSS akan mengurus semua properti visual dan transisi.
                                const parentToggleArrow = parentLiHasSubmenu.querySelector('.dropdown-arrow');
                                if (parentToggleArrow) {
                                    parentToggleArrow.style.transform = 'rotate(180deg)';
                                }
                            }
                        }
                    }
                }
            });
        }


        // --- LOGIKA DROPDOWN PROFIL PENGGUNA ---
        const profileDropdownToggle = document.getElementById('profileDropdownToggle');
        const profileDropdownMenu = document.getElementById('profileDropdownMenu');

        if (profileDropdownToggle && profileDropdownMenu) {
            profileDropdownToggle.addEventListener('click', function(e) {
                e.stopPropagation();
                profileDropdownMenu.classList.toggle('show');
            });

            document.addEventListener('click', function(e) {
                if (!profileDropdownMenu.contains(e.target) && !profileDropdownToggle.contains(e.target)) {
                    profileDropdownMenu.classList.remove('show');
                }
            });
        }

        // --- LOGIKA DROPDOWN MENU SIDEBAR (submenu) ---
        const hasSubmenuItems = document.querySelectorAll('.sidebar-nav .has-submenu');

        hasSubmenuItems.forEach(item => {
            const submenu = item.querySelector('.submenu');
            let hoverIntentTimeout; // Timeout for closing

            // Fungsi untuk membuka submenu saat hover (hanya jika collapsed)
            const openSubmenu = () => {
                if (body.classList.contains('sidebar-collapsed')) {
                    clearTimeout(hoverIntentTimeout); // Batalkan penutupan yang tertunda
                    // Tutup semua submenu 'active-hover' DAN 'active' lainnya untuk memastikan hanya satu yang terbuka
                    document.querySelectorAll('.sidebar-nav .has-submenu.active-hover, .sidebar-nav .has-submenu.active').forEach(hItem => {
                        if (hItem !== item) {
                            hItem.classList.remove('active-hover', 'active');
                        }
                    });
                    item.classList.add('active-hover'); // Aktifkan submenu ini untuk hover
                }
            };

            // Fungsi untuk menutup submenu setelah penundaan (hanya jika collapsed)
            const closeSubmenu = () => {
                if (body.classList.contains('sidebar-collapsed')) {
                    clearTimeout(hoverIntentTimeout); // Batalkan penutupan sebelumnya jika ada
                    hoverIntentTimeout = setTimeout(() => {
                        // Periksa apakah kursor benar-benar di luar item parent DAN di luar submenu
                        // DAN item tidak sedang aktif (dari klik)
                        if (!item.matches(':hover') && !(submenu && submenu.matches(':hover')) && !item.classList.contains('active')) {
                           item.classList.remove('active-hover');
                        }
                    }, 300); // Waktu penundaan
                }
            };

            // Event listener untuk parent menu item (li.has-submenu)
            item.addEventListener('mouseenter', openSubmenu);
            item.addEventListener('mouseleave', closeSubmenu);

            // Event listener untuk submenu itu sendiri (jika ada)
            if (submenu) {
                submenu.addEventListener('mouseenter', openSubmenu); // Jika mouse masuk submenu, tetap buka
                submenu.addEventListener('mouseleave', closeSubmenu); // Jika mouse keluar submenu, mulai proses penutupan
            }

            // Logika Klik pada dropdown-toggle
            const dropdownToggle = item.querySelector('.dropdown-toggle');
            if (dropdownToggle) {
                dropdownToggle.addEventListener('click', function(e) {
                    // PENTING: Selalu cegah perilaku default link ini agar tidak ada navigasi
                    e.preventDefault();
                    e.stopPropagation(); // Mencegah event bubbling

                    // Jika loading overlay sedang aktif, sembunyikan.
                    const loadingOverlay = document.getElementById('loadingOverlay');
                    if (loadingOverlay && loadingOverlay.classList.contains('show')) {
                        loadingOverlay.classList.remove('show');
                        console.log('Loading overlay disembunyikan karena klik dropdown-toggle.'); // Untuk debugging
                    }

                    console.log('Dropdown toggle diklik. Sidebar collapsed state:', body.classList.contains('sidebar-collapsed')); // Untuk debugging

                    const parentLi = this.closest('li.has-submenu');
                    if (!parentLi) return;

                    // Logika toggle visual submenu
                    if (!body.classList.contains('sidebar-collapsed')) {
                        // Mode sidebar penuh (expanded): Gunakan JS untuk toggle active class dan memutar panah
                        document.querySelectorAll('.sidebar-nav .has-submenu.active').forEach(otherParentLi => {
                            if (otherParentLi !== parentLi) {
                                otherParentLi.classList.remove('active');
                                // HAPUS SEMUA INLINE STYLE PADA SUBMENU LAIN YANG DITUTUP
                                const otherSubmenu = otherParentLi.querySelector('.submenu');
                                if (otherSubmenu) {
                                    // PENTING: Hapus semua properti style yang diatur sebelumnya oleh JS
                                    otherSubmenu.style.removeProperty('max-height');
                                    otherSubmenu.style.removeProperty('opacity');
                                    otherSubmenu.style.removeProperty('overflow');
                                    otherSubmenu.style.removeProperty('visibility');
                                    otherSubmenu.style.removeProperty('pointer-events');
                                    otherSubmenu.style.removeProperty('transform');
                                    otherSubmenu.style.removeProperty('transition');
                                }
                                const otherArrow = otherParentLi.querySelector('.dropdown-arrow');
                                if (otherArrow) otherArrow.style.transform = 'rotate(0deg)';
                            }
                        });

                        // Toggle submenu yang diklik
                        parentLi.classList.toggle('active');
                        const submenu = parentLi.querySelector('.submenu');
                        const arrow = this.querySelector('.dropdown-arrow');

                        if (parentLi.classList.contains('active')) {
                            // SET INLINE STYLE MAX-HEIGHT UNTUK ANIMASI COLLAPSE/EXPAND
                            // properti lain akan diatur oleh CSS karena class 'active'
                            if (submenu) submenu.style.maxHeight = submenu.scrollHeight + 'px';
                            if (arrow) arrow.style.transform = 'rotate(180deg)';
                        } else {
                            // SET INLINE STYLE MAX-HEIGHT UNTUK ANIMASI COLLAPSE
                            if (submenu) submenu.style.maxHeight = '0';
                            if (arrow) arrow.style.transform = 'rotate(0deg)';
                            // Hapus semua inline style setelah transisi selesai untuk membersihkan DOM
                            if (submenu) {
                                submenu.addEventListener('transitionend', function handler() {
                                    if (!parentLi.classList.contains('active')) { // Hanya hapus jika sudah tidak active
                                        submenu.style.removeProperty('max-height');
                                        submenu.style.removeProperty('opacity');
                                        submenu.style.removeProperty('overflow');
                                        submenu.style.removeProperty('visibility');
                                        submenu.style.removeProperty('pointer-events');
                                        submenu.style.removeProperty('transform');
                                        submenu.style.removeProperty('transition');
                                    }
                                    submenu.removeEventListener('transitionend', handler);
                                });
                            }
                        }
                    } else {
                        // Mode sidebar tersembunyi (collapsed):
                        // Saat diklik, kita ingin mengunci submenu agar tetap terbuka.
                        // Kita toggle kelas 'active' pada parentLi. CSS akan mengurus tampilan.
                        parentLi.classList.toggle('active'); // Toggle 'active' class

                        // Tutup semua submenu 'active' lainnya saat ini (untuk mode collapsed)
                        // Pastikan tidak menutup diri sendiri jika sudah aktif dari hover
                        document.querySelectorAll('.sidebar-nav .has-submenu.active').forEach(otherParentLi => {
                            if (otherParentLi !== parentLi) {
                                otherParentLi.classList.remove('active', 'active-hover'); // Hapus keduanya
                            }
                        });

                        // Jika sekarang aktif, tambahkan juga active-hover untuk memastikan CSS aktif
                        // KITA TIDAK AKAN MANIPULASI STYLE DI SINI. CSS AKAN MENANGANI VISIBILITAS.
                        if (parentLi.classList.contains('active')) {
                            parentLi.classList.add('active-hover');
                        } else {
                            parentLi.classList.remove('active-hover');
                            // Tidak perlu panggil closeAllSubmenus(true) di sini, biarkan event mouseleave atau klik di luar yang menutupnya.
                        }
                    }
                });
            }
        });

        // Menutup submenu jika klik di luar sidebar atau di luar tombol toggle desktop
        document.addEventListener('click', function(e) {
            const sidebar = document.getElementById('adminSidebar');
            // Hanya jalankan closeAllSubmenus jika klik di luar sidebar dan bukan toggle desktop
            // DAN bukan bagian dari sidebar itu sendiri (untuk menangani klik di dalam submenu yang terbuka)
            const clickedInsideSidebar = sidebar && sidebar.contains(e.target);
            const isDesktopToggle = e.target.closest('#menuToggleDesktop');
            const isSubmenuItem = e.target.closest('.submenu li a');
            const isDropdownToggle = e.target.closest('.dropdown-toggle'); // Tangani klik pada dropdown toggle sendiri

            // Logika penutupan global yang lebih cerdas
            if (!clickedInsideSidebar && !isDesktopToggle) {
                // Klik di luar sidebar dan bukan toggle desktop: tutup semua submenu
                closeAllSubmenus(body.classList.contains('sidebar-collapsed'));
            } else if (clickedInsideSidebar && body.classList.contains('sidebar-collapsed') && !isSubmenuItem && !isDropdownToggle) {
                // Jika klik di dalam sidebar (collapsed) TAPI bukan item submenu atau dropdown toggle:
                // Tutup submenu yang aktif saat ini, kecuali yang baru saja diklik jika itu adalah parent dropdown.
                document.querySelectorAll('.sidebar-nav .has-submenu.active').forEach(parentLi => {
                    if (parentLi !== e.target.closest('.has-submenu')) { // Jangan tutup yang baru saja diklik jika itu adalah dropdown-toggle
                        parentLi.classList.remove('active', 'active-hover');
                    }
                });
            }
        });


        // --- LOGIKA MENANDAI MENU AKTIF DAN MEMBUKA SUBMENU SAAT HALAMAN DIMUAT ---
        const currentPath = window.location.pathname.split('/').pop();
        const allNavLinksElements = document.querySelectorAll('.sidebar-nav ul li a');

        allNavLinksElements.forEach(link => {
            const linkPath = link.getAttribute('href') ? link.getAttribute('href').split('/').pop() : '';
            if (linkPath === currentPath) {
                const currentLi = link.closest('li');
                if (currentLi) {
                    currentLi.classList.add('active');

                    const parentSubmenu = currentLi.closest('.submenu');
                    if (parentSubmenu) {
                        const parentLiHasSubmenu = parentSubmenu.closest('li.has-submenu');
                        if (parentLiHasSubmenu) {
                            parentLiHasSubmenu.classList.add('active');
                            // DI SINI KITA HANYA TAMBAHKAN KELAS. JANGAN SET STYLE INLINE max-height, opacity, dll.
                            // Biarkan CSS dengan class .active yang mengontrol tampilan dan transisi.
                            const parentToggleArrow = parentLiHasSubmenu.querySelector('.dropdown-arrow');
                            if (parentToggleArrow) {
                                parentToggleArrow.style.transform = 'rotate(180deg)';
                            }
                        }
                    }
                }
            }
        });
    // });
    </script>

</body>
</html>