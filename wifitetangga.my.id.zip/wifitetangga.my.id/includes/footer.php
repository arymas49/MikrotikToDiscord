<?php
// C:\xampp\htdocs\billing_isp_app\includes\footer.php
?>
    </div> </body>
</html>
<?php
// Tutup koneksi database
if (isset($koneksi)) {
    $koneksi->close();
}
?>