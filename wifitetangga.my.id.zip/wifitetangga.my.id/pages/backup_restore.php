<?php
// C:\xampp\htdocs\billing_isp_app\pages\backup_restore.php
ini_set('session.use_strict_mode', 1);
ini_set('session.cookie_httponly', 1);
ini_set('session.cookie_samesite', 'Lax');
if (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on') {
    ini_set('session.cookie_secure', 1);
}
session_start();
include '../config/koneksi.php'; // Untuk koneksi MySQLi
include '../includes/header.php'; // Header akan meng-include sidebar dan fungsi hasRole()

// Batasi akses ke halaman ini: hanya superadmin
if (!hasRole('superadmin')) {
    header('Location: dashboard.php');
    exit();
}

$message = '';
$message_type = ''; // 'success' atau 'danger'

// Cek apakah exec() dinonaktifkan, tampilkan pesan peringatan
if (!function_exists('exec')) {
    $message = 'Peringatan: Fungsi `exec()` dinonaktifkan di server Anda. Fitur backup/restore akan menggunakan metode PHP murni yang mungkin kurang efisien untuk database sangat besar.';
    $message_type = 'warning'; // Ubah menjadi 'warning' agar tidak terlalu menonjol
}

// Fungsi untuk membuat backup database (PHP Murni)
function backupDatabasePurePHP($koneksi_mysqli, $db_name) {
    $tables = array();
    $result = $koneksi_mysqli->query("SHOW TABLES");
    while ($row = $result->fetch_row()) {
        $tables[] = $row[0];
    }

    $sql_dump = "SET NAMES utf8;\n";
    $sql_dump .= "SET foreign_key_checks = 0;\n";
    $sql_dump .= "SET time_zone = '+00:00';\n";
    $sql_dump .= "SET sql_mode = 'NO_AUTO_VALUE_ON_ZERO';\n\n";

    foreach ($tables as $table) {
        $result = $koneksi_mysqli->query("SELECT * FROM `" . $table . "`");
        $num_fields = $result->field_count;
        $num_rows = $result->num_rows;

        // Structure (CREATE TABLE statement)
        $sql_dump .= "DROP TABLE IF EXISTS `" . $table . "`;\n";
        $row2 = $koneksi_mysqli->query("SHOW CREATE TABLE `" . $table . "`")->fetch_row();
        $sql_dump .= $row2[1] . ";\n\n";

        // Data (INSERT statements)
        if ($num_rows > 0) {
            $sql_dump .= "INSERT INTO `" . $table . "` VALUES";
            $row_count = 0;
            while ($row = $result->fetch_row()) {
                $sql_dump .= ($row_count == 0 ? '(' : ',(');
                for ($j = 0; $j < $num_fields; $j++) {
                    if (isset($row[$j])) {
                        $sql_dump .= "'" . $koneksi_mysqli->real_escape_string($row[$j]) . "'";
                    } else {
                        $sql_dump .= 'NULL';
                    }
                    if ($j < ($num_fields - 1)) {
                        $sql_dump .= ',';
                    }
                }
                $sql_dump .= ')';
                $row_count++;
            }
            $sql_dump .= ";\n\n";
        }
    }
    $sql_dump .= "SET foreign_key_checks = 1;\n";
    return $sql_dump;
}

// Fungsi untuk melakukan restore database dari string SQL (PHP Murni)
function restoreDatabasePurePHP($koneksi_mysqli, $sql_content) {
    // Memecah string SQL menjadi perintah-perintah individual
    $sql_array = explode(';', $sql_content);
    $errors = [];

    foreach ($sql_array as $sql_statement) {
        $sql_statement = trim($sql_statement);
        if (!empty($sql_statement)) {
            // Hindari eksekusi query kosong atau komentar
            if (!($koneksi_mysqli->query($sql_statement))) {
                $errors[] = "Error executing query: " . $koneksi_mysqli->error . "\nQuery: " . $sql_statement;
            }
        }
    }
    return $errors;
}


// Logika Backup
if (isset($_POST['action']) && $_POST['action'] == 'backup') {
    // Pastikan koneksi yang digunakan adalah objek MySQLi dari $koneksi
    if (!$koneksi) { // Asumsi $koneksi adalah objek MySQLi
        $message = 'Error koneksi database untuk backup.';
        $message_type = 'danger';
    } else {
        $timestamp = date('Ymd_His');
        $backup_file_name = DB_NAME . '_backup_' . $timestamp . '.sql';
        $sql_content = backupDatabasePurePHP($koneksi, DB_NAME); // Panggil fungsi backup PHP murni

        if ($sql_content === false) { // Cek jika ada error di fungsi backup
            $message = 'Gagal membuat konten backup database.';
            $message_type = 'danger';
        } else {
            // Langsung kirimkan file ke browser untuk di-download
            header('Content-Description: File Transfer');
            header('Content-Type: application/octet-stream');
            header('Content-Disposition: attachment; filename="' . basename($backup_file_name) . '"');
            header('Expires: 0');
            header('Cache-Control: must-revalidate');
            header('Pragma: public');
            header('Content-Length: ' . strlen($sql_content));
            
            // Bersihkan output buffer sebelum mengirim header
            while (ob_get_level() > 0) {
                ob_end_clean();
            }

            echo $sql_content; // Kirim konten SQL langsung
            exit; // Penting untuk menghentikan eksekusi skrip setelah file dikirim
        }
    }
}

// Logika Restore
if (isset($_POST['action']) && $_POST['action'] == 'restore') {
    if (!empty($_FILES['backup_file_upload']['tmp_name'])) {
        $uploaded_file_path = $_FILES['backup_file_upload']['tmp_name'];
        $file_extension = pathinfo($_FILES['backup_file_upload']['name'], PATHINFO_EXTENSION);

        if (strtolower($file_extension) !== 'sql') {
            $message = 'File yang diunggah harus berformat .sql.';
            $message_type = 'danger';
        } else {
            $sql_content = file_get_contents($uploaded_file_path);
            if ($sql_content === false) {
                $message = 'Gagal membaca isi file SQL yang diunggah.';
                $message_type = 'danger';
            } else {
                 // Nonaktifkan foreign key checks sementara untuk menghindari masalah urutan restore
                $koneksi->query("SET foreign_key_checks = 0;");

                // Kosongkan database saat ini (DROP TABLE jika diperlukan)
                // Ini opsional, tapi disarankan untuk restore yang bersih
                $tables = array();
                $result = $koneksi->query("SHOW TABLES");
                while($row = $result->fetch_row()){
                    $tables[] = $row[0];
                }
                foreach($tables as $table){
                    $koneksi->query("DROP TABLE IF EXISTS `" . $table . "`");
                }

                $errors = restoreDatabasePurePHP($koneksi, $sql_content); // Panggil fungsi restore PHP murni

                // Aktifkan kembali foreign key checks
                $koneksi->query("SET foreign_key_checks = 1;");

                if (empty($errors)) {
                    $message = 'Restore database berhasil dari file: ' . htmlspecialchars($_FILES['backup_file_upload']['name']);
                    $message_type = 'success';
                } else {
                    $message = 'Restore database selesai dengan beberapa kesalahan: <pre>' . htmlspecialchars(implode("\n", $errors)) . '</pre>';
                    $message_type = 'warning';
                }
            }
        }
    } else {
        $message = 'Silakan pilih file backup untuk diunggah.';
        $message_type = 'danger';
    }
}


// Tidak ada lagi daftar file backup dari server karena backup langsung di-download
// dan restore mengandalkan upload file
?>

<div class="main-content">
    <div class="top-header">
        <div class="alert-message">
            Peringatan: Fitur restore akan menghapus data saat ini dan menggantinya dengan data backup. Selalu lakukan backup secara berkala.
        </div>
        <div class="welcome-message">
            <span>Selamat datang, <?php echo htmlspecialchars($_SESSION['username'] ?? 'User'); ?>!</span>
            <a href="../logout.php" class="btn-logout">Logout</a>
        </div>
    </div>

    <div class="container">
        <h2>Backup & Restore Database (PHP Murni)</h2>

        <?php if ($message): ?>
            <div class="alert alert-<?php echo htmlspecialchars($message_type, ENT_QUOTES, "UTF-8"); ?>">
                <?php echo htmlspecialchars($message, ENT_QUOTES, "UTF-8"); ?>
            </div>
        <?php endif; ?>

        <div class="card" style="margin-bottom: 20px;">
            <div class="card-header">
                <h3>Buat & Download Backup Database</h3>
            </div>
            <div class="card-body">
                <p>Klik tombol di bawah ini untuk membuat salinan (backup) database Anda dan langsung mengunduhnya ke komputer Anda. Metode ini menggunakan PHP murni.</p>
                <form method="POST"><?php if (!isset($_SESSION['csrf_token'])) { $_SESSION['csrf_token'] = bin2hex(random_bytes(32)); } ?><input type='hidden' name='csrf_token' value='<?php echo $_SESSION['csrf_token']; ?>'>
                    <input type="hidden" name="action" value="backup">
                    <button type="submit" class="btn btn-primary" onclick="return confirm('Apakah Anda yakin ingin membuat dan mengunduh backup database sekarang?');">
                        <i class="fas fa-download"></i> Buat & Download Backup
                    </button>
                </form>
            </div>
        </div>

        <div class="card">
            <div class="card-header">
                <h3>Restore Database dari File Backup (.sql)</h3>
            </div>
            <div class="card-body">
                <p>Pilih file backup (.sql) dari komputer Anda untuk mengembalikan database ke kondisi sebelumnya. **PERINGATAN: Proses ini akan menghapus semua data saat ini dan menggantinya dengan data dari file backup.**</p>
                <form method="POST" enctype="multipart/form-data"><?php if (!isset($_SESSION['csrf_token'])) { $_SESSION['csrf_token'] = bin2hex(random_bytes(32)); } ?><input type='hidden' name='csrf_token' value='<?php echo $_SESSION['csrf_token']; ?>'>
                    <input type="hidden" name="action" value="restore">
                    <div class="form-group">
                        <label for="backup_file_upload">Pilih File Backup (.sql):</label>
                        <input type="file" name="backup_file_upload" id="backup_file_upload" class="form-control" accept=".sql" required>
                    </div>
                    <button type="submit" class="btn btn-danger" onclick="return confirm('PERINGATAN: Anda akan MENGHAPUS SEMUA DATA SAAT INI dan menggantinya dengan data dari file backup yang diunggah. Lanjutkan?');">
                        <i class="fas fa-undo"></i> Restore Database
                    </button>
                </form>
            </div>
        </div>
    </div>
</div>

<?php include '../includes/footer.php'; ?>