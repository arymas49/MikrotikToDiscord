<?php
// C:\xampp\htdocs\billing_isp_app\pages\buat_tagihan_manual.php
ob_start(); // Aktifkan output buffering
ini_set('session.use_strict_mode', 1);
ini_set('session.cookie_httponly', 1);
ini_set('session.cookie_samesite', 'Lax');
if (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on') {
    ini_set('session.cookie_secure', 1);
}
session_start();
include '../config/koneksi.php';
include '../includes/header.php'; // Header akan meng-include sidebar dan fungsi hasRole()

// Batasi akses: hanya superadmin dan admin yang bisa mengakses halaman ini
if (!hasRole(['superadmin', 'admin'])) {
    header('Location: dashboard.php');
    exit();
}

$message = '';
$current_month_year = date('Y-m'); // Format YYYY-MM

// Ambil semua data pelanggan yang aktif untuk dropdown
$pelanggan_options = [];
$query_pelanggan = "SELECT p.id_pelanggan, p.nama_pelanggan, p.alamat, p.telepon, p.email,
                           p.paket_id, pk.nama_paket, pk.harga, pk.kecepatan, p.uses_ppn, p.penagih_id
                    FROM pelanggan p
                    JOIN paket_layanan pk ON p.paket_id = pk.id_paket
                    WHERE p.status_aktif = 'Aktif'
                    ORDER BY p.nama_pelanggan ASC";
$result_pelanggan = $koneksi->query($query_pelanggan);
if ($result_pelanggan) {
    while ($row = $result_pelanggan->fetch_assoc()) {
        $pelanggan_options[] = $row;
    }
} else {
    error_log("Error fetching pelanggan options: " . $koneksi->error);
}


// --- Logika Buat Tagihan Baru (Reguler, masuk ke tabel `tagihan`) ---
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['action']) && $_POST['action'] == 'create_manual_invoice') {
    $pelanggan_id = $koneksi->real_escape_string($_POST['pelanggan_id']);
    $bulan_tagihan = $koneksi->real_escape_string($_POST['bulan_tagihan']); // Ex: 2025-07
    $tanggal_terbit = $koneksi->real_escape_string($_POST['tanggal_terbit']);
    $tanggal_jatuh_tempo = $koneksi->real_escape_string($_POST['tanggal_jatuh_tempo']);

    // Ambil detail pelanggan dan paket untuk menghitung harga
    $stmt_get_detail = $koneksi->prepare("SELECT p.paket_id, pk.harga, p.uses_ppn, p.penagih_id
                                          FROM pelanggan p
                                          JOIN paket_layanan pk ON p.paket_id = pk.id_paket
                                          WHERE p.id_pelanggan = ?");
    $stmt_get_detail->bind_param("i", $pelanggan_id);
    $stmt_get_detail->execute();
    $result_detail = $stmt_get_detail->get_result();
    $detail_pelanggan = $result_detail->fetch_assoc();
    $stmt_get_detail->close();

    if ($detail_pelanggan) {
        $paket_id = $detail_pelanggan['paket_id'];
        $harga_dasar = $detail_pelanggan['harga']; // Ini adalah jumlah_tagihan (harga bersih) yang akan disimpan
        $uses_ppn = $detail_pelanggan['uses_ppn'];
        $penagih_id = $detail_pelanggan['penagih_id']; // Ambil penagih_id dari pelanggan

        // Hitung total_tagihan (termasuk PPN jika berlaku) dan sisa_tagihan
        $ppn_percentage = 0.11;
        $total_tagihan_final_amount = $harga_dasar;
        if ($uses_ppn == 1) {
            $total_tagihan_final_amount += ($harga_dasar * $ppn_percentage);
        }
        $sisa_tagihan_initial = $total_tagihan_final_amount; // Saat pertama dibuat, sisa = total

        // Cek apakah tagihan untuk bulan ini sudah ada
        $stmt_check_exist = $koneksi->prepare("SELECT id_tagihan FROM tagihan WHERE pelanggan_id = ? AND bulan_tagihan = ?");
        $stmt_check_exist->bind_param("is", $pelanggan_id, $bulan_tagihan);
        $stmt_check_exist->execute();
        $result_check_exist = $stmt_check_exist->get_result();

        if ($result_check_exist->num_rows > 0) {
            $message = '<div class="alert alert-warning">Tagihan untuk pelanggan ini pada bulan ' . htmlspecialchars($bulan_tagihan) . ' sudah ada.</div>';
        } else {
            // Masukkan tagihan baru ke tabel `tagihan`
            $status_tagihan = 'Belum Lunas'; // Default saat membuat tagihan baru

            $stmt_insert_tagihan = $koneksi->prepare("INSERT INTO tagihan (pelanggan_id, paket_id, bulan_tagihan, jumlah_tagihan, tanggal_terbit, tanggal_jatuh_tempo, status_tagihan, sisa_tagihan, penagih_id, total_tagihan) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
            // Tipe binding: pelanggan_id(i), paket_id(i), bulan_tagihan(s), jumlah_tagihan(d), tgl_terbit(s), tgl_jatuh_tempo(s), status_tagihan(s), sisa_tagihan(d), penagih_id(i/s), total_tagihan(d)
            // Sesuaikan tipe penagih_id jika NULL diperbolehkan (s) atau selalu integer (i)
            $penagih_type = is_null($penagih_id) ? 's' : 'i';
            $types = "iisdsssd" . $penagih_type . "d";

            $bind_params = [
                $pelanggan_id,
                $paket_id,
                $bulan_tagihan,
                $harga_dasar, // Simpan harga bersih di `jumlah_tagihan`
                $tanggal_terbit,
                $tanggal_jatuh_tempo,
                $status_tagihan,
                $sisa_tagihan_initial,
                $penagih_id,
                $total_tagihan_final_amount // Simpan total termasuk PPN di `total_tagihan`
            ];

            $refs = [];
            foreach ($bind_params as $key => $value) {
                $refs[$key] = &$bind_params[$key];
            }
            call_user_func_array([$stmt_insert_tagihan, 'bind_param'], array_merge([$types], $refs));
            
            if ($stmt_insert_tagihan->execute()) {
                $last_tagihan_id = $koneksi->insert_id;
                logActivity('Create', 'Membuat tagihan baru ID ' . $last_tagihan_id . ' untuk pelanggan ' . $pelanggan_id . ' bulan ' . $bulan_tagihan . '. Total: ' . number_format($total_tagihan_final_amount));
                
                // Redirect ke halaman pembayaran dengan pre-fill data tagihan yang baru dibuat
                $_SESSION['form_message'] = '<div class="alert alert-success">Tagihan berhasil dibuat.</div>';
                header('Location: bayar?tab=belumLunas&pelanggan_id=' . $pelanggan_id . '&tagihan_id=' . $last_tagihan_id);
                ob_end_clean(); // Pastikan tidak ada output sebelum redirect
                exit();
            } else {
                $message = '<div class="alert alert-danger">Gagal membuat tagihan: ' . $stmt_insert_tagihan->error . '</div>';
            }
            $stmt_insert_tagihan->close();
        }
        $stmt_check_exist->close();
    } else {
        $message = '<div class="alert alert-danger">Detail pelanggan atau paket tidak ditemukan.</div>';
    }
}

// --- Menampilkan Pesan Setelah Redirect (GET) ---
if (isset($_GET['msg'])) {
    if ($_GET['msg'] == 'add_success') {
        // Pesan ini sekarang tidak lagi dibutuhkan karena redirect di atas akan menangani pesan
        // $message = '<div class="alert alert-success">Tagihan manual berhasil dibuat.</div>';
    } 
}


// Ambil data pelanggan untuk dropdown
// Ini perlu diperbarui untuk mengambil uses_ppn juga, agar JavaScript bisa menghitungnya
$query_pelanggan_options = "SELECT p.id_pelanggan, p.nama_pelanggan, pk.harga, p.uses_ppn 
                            FROM pelanggan p 
                            JOIN paket_layanan pk ON p.paket_id = pk.id_paket 
                            WHERE p.status_aktif = 'Aktif' 
                            ORDER BY p.nama_pelanggan ASC";
$result_pelanggan_options = $koneksi->query($query_pelanggan_options);
?>

<div class="main-content">
    <div class="top-header">
        <div class="alert-message">
            Pemberitahuan: Gunakan fitur ini untuk membuat tagihan bulanan pelanggan di luar jadwal otomatis.
        </div>
        <div class="welcome-message">
            <span>Selamat datang, <?php echo htmlspecialchars($_SESSION['username'] ?? 'User'); ?>!</span>
            <a href="../logout.php" class="btn-logout">Logout</a> 
        </div>
    </div>

    <div class="container">
        <h2>Buat Tagihan Bulanan</h2>

        <?php echo $message; ?>

        <div class="card" style="margin-bottom: 20px;">
            <div class="card-header">
                <h3>Form Buat Tagihan</h3>
            </div>
            <div class="card-body">
                <form method="POST"><?php if (!isset($_SESSION['csrf_token'])) { $_SESSION['csrf_token'] = bin2hex(random_bytes(32)); } ?><input type='hidden' name='csrf_token' value='<?php echo $_SESSION['csrf_token']; ?>'><?php if (!isset($_SESSION['csrf_token'])) { $_SESSION['csrf_token'] = bin2hex(random_bytes(32)); } ?><input type='hidden' name='csrf_token' value='<?php echo $_SESSION['csrf_token']; ?>'>
                    <input type="hidden" name="action" value="create_manual_invoice">
                    <div class="form-group">
                        <label for="pelanggan_id">Pilih Pelanggan:</label>
                        <select id="pelanggan_id" name="pelanggan_id" required onchange="updateTagihanInfo()">
                            <option value="">Pilih Pelanggan</option>
                            <?php 
                            if ($result_pelanggan_options->num_rows > 0) {
                                $result_pelanggan_options->data_seek(0);
                            }
                            while($row_pelanggan = $result_pelanggan_options->fetch_assoc()): ?>
                                <option 
                                    value="<?php echo htmlspecialchars($row_pelanggan['id_pelanggan']); ?>"
                                    data-harga-paket="<?php echo htmlspecialchars($row_pelanggan['harga']); ?>"
                                    data-uses-ppn="<?php echo htmlspecialchars($row_pelanggan['uses_ppn']); ?>"
                                >
                                    <?php 
                                    $display_price = $row_pelanggan['harga'];
                                    if ($row_pelanggan['uses_ppn'] == 1) {
                                        $display_price += ($row_pelanggan['harga'] * 0.11);
                                    }
                                    echo htmlspecialchars($row_pelanggan['nama_pelanggan'] . ' (ID: ' . $row_pelanggan['id_pelanggan'] . ') - Rp ' . number_format($display_price, 0, ',', '.')); 
                                    ?>
                                </option>
                            <?php endwhile; ?>
                        </select>
                    </div>
                    <div class="form-group">
                        <label for="bulan_tagihan">Bulan Tagihan (YYYY-MM):</label>
                        <input type="month" id="bulan_tagihan" name="bulan_tagihan" value="<?php echo htmlspecialchars($current_month_year, ENT_QUOTES, "UTF-8"); ?>" placeholder="Contoh: 2025-06" required>
                    </div>
                    <div class="form-group">
                        <label for="tanggal_terbit">Tanggal Terbit:</label>
                        <input type="date" id="tanggal_terbit" name="tanggal_terbit" value="<?php echo date('Y-m-d'); ?>" required>
                    </div>
                    <div class="form-group">
                        <label for="tanggal_jatuh_tempo">Tanggal Jatuh Tempo:</label>
                        <input type="date" id="tanggal_jatuh_tempo" name="tanggal_jatuh_tempo" value="<?php echo date('Y-m-d', strtotime('+30 days')); ?>" required>
                    </div>
                    <div class="form-group">
                        <label for="jumlah_tagihan">Jumlah Tagihan (Rp):</label>
                        <input type="number" id="jumlah_tagihan" name="jumlah_tagihan" step="0.01" value="" required readonly>
                        <small>Harga paket saat ini: <span id="harga_paket_display">Rp 0</span> <span id="ppn_info"></span></small>
                    </div>
                    <button type="submit" class="btn btn-primary">Buat Tagihan</button>
                    <button type="reset" class="btn btn-secondary" onclick="resetFormCustom()">Reset Form</button>
                </form>
            </div>
        </div>

    </div>
</div>

<script>
document.addEventListener('DOMContentLoaded', function() {
    const pelangganSelect = document.getElementById('pelanggan_id');
    const jumlahTagihanInput = document.getElementById('jumlah_tagihan'); // Ini input tersembunyi
    const hargaPaketDisplay = document.getElementById('harga_paket_display');
    const ppnInfoSpan = document.getElementById('ppn_info');
    const tanggalTerbitInput = document.getElementById('tanggal_terbit');
    const tanggalJatuhTempoInput = document.getElementById('tanggal_jatuh_tempo');
    const bulanTagihanInput = document.getElementById('bulan_tagihan');

    // Fungsi untuk mengupdate info tagihan
    window.updateTagihanInfo = function() {
        if (pelangganSelect.value === "") {
            jumlahTagihanInput.value = '';
            hargaPaketDisplay.innerText = 'Rp 0';
            ppnInfoSpan.innerText = '';
            return;
        }

        const selectedOption = pelangganSelect.options[pelangganSelect.selectedIndex];
        const hargaDasar = parseFloat(selectedOption.dataset.hargaPaket || '0');
        const usesPpn = parseInt(selectedOption.dataset.usesPpn || '0');

        let totalTagihanDenganPpn = hargaDasar;
        let ppnText = '';
        if (usesPpn === 1) {
            const ppnAmount = hargaDasar * 0.11;
            totalTagihanDenganPpn += ppnAmount;
            ppnText = `+ PPN 11% (Rp ${ppnAmount.toLocaleString('id-ID', {minimumFractionDigits: 0, maximumFractionDigits: 0})})`;
        }

        jumlahTagihanInput.value = totalTagihanDenganPpn.toFixed(0); // Simpan total termasuk PPN di sini
        hargaPaketDisplay.innerText = 'Rp ' + hargaDasar.toLocaleString('id-ID', {minimumFractionDigits: 0, maximumFractionDigits: 0});
        ppnInfoSpan.innerText = ppnText;
    };

    // Fungsi reset form kustom untuk mengatur ulang elemen dengan benar
    window.resetFormCustom = function() {
        document.querySelector('form').reset();
        
        // Reset dropdown ke opsi pertama (Pilih Pelanggan)
        pelangganSelect.value = "";
        
        // Set nilai default untuk input tanggal dan bulan
        tanggalTerbitInput.value = new Date().toISOString().slice(0,10);
        
        const today = new Date();
        const nextMonth = new Date(today.getFullYear(), today.getMonth() + 1, 1);
        const lastDayOfNextMonth = new Date(nextMonth.getFullYear(), nextMonth.getMonth() + 1, 0);
        tanggalJatuhTempoInput.value = lastDayOfNextMonth.toISOString().slice(0,10);

        bulanTagihanInput.value = new Date().toISOString().slice(0,7); // YYYY-MM format
        
        updateTagihanInfo(); // Panggil untuk mereset tampilan harga
    };


    // Event listener untuk tanggal terbit agar tanggal jatuh tempo otomatis +30 hari
    tanggalTerbitInput.addEventListener('change', function() {
        const tglTerbit = new Date(this.value);
        if (!isNaN(tglTerbit)) {
            const tglJatuhTempo = new Date(tglTerbit);
            tglJatuhTempo.setDate(tglJatuhTempo.getDate() + 30);
            tanggalJatuhTempoInput.value = tglJatuhTempo.toISOString().slice(0, 10);
        }
    });

    // Inisialisasi saat halaman dimuat
    updateTagihanInfo();
});
</script>

<?php include '../includes/footer.php'; ?>
<?php ob_end_flush(); // Akhiri output buffering ?>