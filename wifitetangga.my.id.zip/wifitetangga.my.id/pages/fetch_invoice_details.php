<?php
// pages/fetch_invoice_details.php
ini_set('session.use_strict_mode', 1);
ini_set('session.cookie_httponly', 1);
ini_set('session.cookie_samesite', 'Lax');
if (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on') {
    ini_set('session.cookie_secure', 1);
}
session_start();

// Hanya izinkan akses via AJAX POST request
if ($_SERVER['REQUEST_METHOD'] !== 'POST' || empty($_SERVER['HTTP_X_REQUESTED_WITH']) || strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) !== 'xmlhttprequest') {
    http_response_code(403);
    echo json_encode(['status' => 'error', 'message' => 'Akses terlarang. Hanya boleh diakses via AJAX POST.']);
    exit();
}

ini_set('display_errors', 0); // Pastikan ini 0 di lingkungan produksi
error_reporting(E_ALL); // Untuk logging error ke file log

include '../config/koneksi.php'; // Sesuaikan path koneksi database Anda

header('Content-Type: application/json'); // Tetapkan header respons sebagai JSON

$response = ['status' => 'error', 'message' => 'Permintaan tidak valid.'];

$input = file_get_contents('php://input');
$data = json_decode($input, true);

if (json_last_error() !== JSON_ERROR_NONE) {
    $response['message'] = 'Input JSON tidak valid: ' . json_last_error_msg();
    echo json_encode($response);
    exit();
}

$invoiceNumber = $data['invoiceNumber'] ?? ''; // Ambil nomor invoice dari data POST

if (empty($invoiceNumber)) {
    $response['message'] = 'Nomor Invoice tidak boleh kosong.';
    echo json_encode($response);
    exit();
}

try {
    // Pastikan input adalah numerik untuk id_tagihan
    if (!is_numeric($invoiceNumber)) {
        $response['message'] = 'Nomor Invoice harus berupa angka (ID Tagihan).';
        echo json_encode($response);
        exit();
    }

    $invoiceDetails = null;
    $sourceTable = '';

    // --- Coba cari di tabel tagihan (invoice reguler ISP) ---
    $queryTagihan = "
        SELECT
            t.id_tagihan,
            p.nama_pelanggan,
            p.alamat,
            p.telepon,
            t.bulan_tagihan,
            t.jumlah_tagihan,
            t.tanggal_terbit,
            t.tanggal_jatuh_tempo,
            t.status_tagihan,
            t.sisa_tagihan,
            p.uses_ppn,
            pk.nama_paket,
            pk.kecepatan
        FROM
            tagihan t
        JOIN
            pelanggan p ON t.pelanggan_id = p.id_pelanggan
        LEFT JOIN
            paket_layanan pk ON p.paket_id = pk.id_paket
        WHERE
            t.id_tagihan = ?
        LIMIT 1";

    if ($stmt = $koneksi->prepare($queryTagihan)) {
        $stmt->bind_param("i", $invoiceNumber);
        $stmt->execute();
        $result = $stmt->get_result();
        if ($result->num_rows > 0) {
            $invoiceDetails = $result->fetch_assoc();
            $sourceTable = 'tagihan';
        }
        $stmt->close();
    } else {
        error_log("Error preparing tagihan query: " . $koneksi->error);
    }

    // --- Jika tidak ditemukan di tagihan, coba cari di tagihan_manual ---
    if (!$invoiceDetails) {
        $queryTagihanManual = "
            SELECT
                tm.id_tagihan_manual AS id_tagihan,
                tm.nama_pelanggan_manual AS nama_pelanggan,
                tm.alamat_manual AS alamat,
                tm.telepon_manual AS telepon,
                NULL AS bulan_tagihan, -- Tagihan manual tidak punya bulan_tagihan
                tm.jumlah_tagihan,
                tm.tanggal_terbit,
                tm.tanggal_jatuh_tempo,
                tm.status_tagihan,
                tm.jumlah_tagihan AS sisa_tagihan, -- Asumsi sisa tagihan manual sama dengan jumlah tagihan (karena tidak ada kolom sisa_tagihan terpisah di sql dump)
                0 AS uses_ppn, -- Asumsi tagihan manual tidak pakai PPN kecuali ada kolomnya
                tm.nama_paket_manual AS nama_paket,
                tm.deskripsi_tagihan_manual AS kecepatan -- Menggunakan kolom kecepatan_manual atau deskripsi sebagai kecepatan
            FROM
                tagihan_manual tm
            WHERE
                tm.id_tagihan_manual = ?
            LIMIT 1";

        if ($stmt = $koneksi->prepare($queryTagihanManual)) {
            $stmt->bind_param("i", $invoiceNumber);
            $stmt->execute();
            $result = $stmt->get_result();
            if ($result->num_rows > 0) {
                $invoiceDetails = $result->fetch_assoc();
                $sourceTable = 'tagihan_manual';
            }
            $stmt->close();
        } else {
            error_log("Error preparing tagihan_manual query: " . $koneksi->error);
        }
    }


    if ($invoiceDetails) {
        // Logika untuk menghitung PPN dan Sisa Tagihan (disesuaikan dari print_invoice.php)
        $ppn_amount = 0;
        $total_tagihan_penuh_awal = $invoiceDetails['jumlah_tagihan']; // Harga dasar dari DB

        if ($sourceTable == 'tagihan' && ($invoiceDetails['uses_ppn'] ?? 0) == 1) {
            $ppn_percentage = 0.11;
            $ppn_amount = $invoiceDetails['jumlah_tagihan'] * $ppn_percentage;
            $total_tagihan_penuh_awal += $ppn_amount;
        }

        $sisa_tagihan_sekarang = $invoiceDetails['sisa_tagihan'] ?? $total_tagihan_penuh_awal;
        $jumlah_sudah_dibayar = $total_tagihan_penuh_awal - $sisa_tagihan_sekarang;

        $current_invoice_status = $invoiceDetails['status_tagihan'];
        $amount_to_display = $total_tagihan_penuh_awal; // Default: tampilkan total penuh

        if ($sisa_tagihan_sekarang <= 0.01) {
            $current_invoice_status = 'Lunas';
            $amount_to_display = $total_tagihan_penuh_awal; // Jika lunas, tampilkan total penuh yang dibayar
        } elseif ($sisa_tagihan_sekarang < $total_tagihan_penuh_awal - 0.01 && $jumlah_sudah_dibayar > 0.01) {
            $current_invoice_status = 'Pembayaran Parsial';
            $amount_to_display = $sisa_tagihan_sekarang; // Jika parsial, tampilkan sisa yang harus dibayar
        }
        // Jika statusnya 'Belum Lunas' dan belum ada pembayaran parsial, amount_to_display tetap total_tagihan_penuh_awal

        $periode_display = 'N/A';
        if ($sourceTable == 'tagihan' && !empty($invoiceDetails['bulan_tagihan'])) {
            $periode_display = date('F Y', strtotime($invoiceDetails['bulan_tagihan'] . '-01'));
        } elseif ($sourceTable == 'tagihan_manual' && !empty($invoiceDetails['tanggal_terbit'])) {
            // Untuk tagihan manual, periode bisa disamakan dengan bulan terbit
            $periode_display = date('F Y', strtotime($invoiceDetails['tanggal_terbit']));
        }

        $response = [
            'status' => 'success',
            'message' => 'Invoice ditemukan.',
            'invoice' => [
                'id_tagihan' => htmlspecialchars($invoiceDetails['id_tagihan']),
                'nama_pelanggan' => htmlspecialchars($invoiceDetails['nama_pelanggan'] ?? 'N/A'),
                'alamat' => htmlspecialchars($invoiceDetails['alamat'] ?? 'N/A'),
                'telepon' => htmlspecialchars($invoiceDetails['telepon'] ?? 'N/A'),
                'item_description' => htmlspecialchars(($invoiceDetails['nama_paket'] ?? '') . ' ' . ($invoiceDetails['kecepatan'] ?? '')),
                'bulan_tagihan' => $periode_display,
                'jumlah_tagihan_bersih' => 'Rp ' . number_format($invoiceDetails['jumlah_tagihan'], 0, ',', '.'),
                'ppn_amount' => 'Rp ' . number_format($ppn_amount, 0, ',', '.'),
                'total_tagihan_penuh' => 'Rp ' . number_format($total_tagihan_penuh_awal, 0, ',', '.'),
                'jumlah_sudah_dibayar' => 'Rp ' . number_format($jumlah_sudah_dibayar, 0, ',', '.'),
                'sisa_tagihan' => 'Rp ' . number_format($sisa_tagihan_sekarang, 0, ',', '.'),
                'jumlah_yang_ditampilkan_di_invoice' => 'Rp ' . number_format($amount_to_display, 0, ',', '.'),
                'tanggal_terbit' => date('d M Y', strtotime($invoiceDetails['tanggal_terbit'])),
                'tanggal_jatuh_tempo' => date('d M Y', strtotime($invoiceDetails['tanggal_jatuh_tempo'])),
                'status_tagihan' => htmlspecialchars($current_invoice_status),
                'link_invoice_print' => '../pages/print_invoice.php?source_table=' . $sourceTable . '&id=' . $invoiceDetails['id_tagihan']
            ]
        ];
    } else {
        $response['message'] = 'Invoice tidak ditemukan untuk ID: ' . htmlspecialchars($invoiceNumber);
    }

} catch (Exception $e) {
    $response['message'] = 'Kesalahan server: ' . $e->getMessage();
    error_log("Error in fetch_invoice_details.php: " . $e->getMessage());
}

$koneksi->close();
echo json_encode($response);
exit();
?>