<?php
// \pay.triplezhinetwork.id\pages\send_whatsapp_message.php

// --- PENTING: PENGATURAN DEBUGGING DAN LOGGING (HAPUS ATAU UBAH DI LINGKUNGAN PRODUKSI!) ---
ini_set('display_errors', 0); // Pastikan ini 0 di lingkungan produksi
ini_set('display_startup_errors', 0); // Pastikan ini 0 di lingkungan produksi
error_reporting(E_ALL); // Tetap log semua error, tapi jangan tampilkan

// Mulai sesi untuk mengakses $_SESSION, penting untuk CSRF
session_start();

// Tentukan path log secara langsung
// Sesuai dengan yang Anda sebutkan, semua log ke cron_whatsapp.log
$log_file_path = '/var/www/html/wifitetangga.my.id/php_logs/cron_whatsapp.log';

// --- COBA TULIS LOG SECARA MANUAL UNTUK DEBUGGING MASALAH PENULISAN LOG ---
function log_debug_message($message) {
    global $log_file_path; // Pastikan ini didefinisikan secara global
    $timestamp = date('Y-m-d H:i:s');
    // Pastikan direktori log ada dan dapat ditulis
    $log_dir = dirname($log_file_path);
    if (!is_dir($log_dir)) {
        if (!mkdir($log_dir, 0755, true) && !is_dir($log_dir)) {
            error_log("Failed to create log directory: " . $log_dir);
            return;
        }
        chmod($log_dir, 0775); // Set permissions for newly created directory and make it group-writable
    }
    file_put_contents($log_file_path, "[$timestamp] $message\n", FILE_APPEND);
}

log_debug_message("--- NEW REQUEST TO send_whatsapp_message.php AT " . date('Y-m-d H:i:s') . " ---");
log_debug_message("REQUEST_METHOD: " . ($_SERVER['REQUEST_METHOD'] ?? 'N/A'));
log_debug_message("HTTP_CONTENT_TYPE: " . ($_SERVER['HTTP_CONTENT_TYPE'] ?? 'N/A'));
log_debug_message("PHP SAPI Name: " . php_sapi_name());
log_debug_message("Attempting to write log to: " . $log_file_path);

// --- AKHIR PENGATURAN DEBUGGING MANUAL ---

set_time_limit(3600); // PHP script execution timeout (1 hour for cron job)

// --- MULAI OUTPUT BUFFERING SECARA AGRESIF ---
ob_start();

// --- FUNGSI UNTUK MENGIRIM RESPON JSON DAN KELUAR ---
function sendJsonResponseAndExit($response_data) {
    // Pastikan tidak ada output lain
    if (ob_get_length() > 0) {
        ob_clean(); // Bersihkan buffer
    }
    // Pastikan header JSON sudah diset (hanya jika dipanggil via HTTP)
    if (php_sapi_name() !== 'cli' && !headers_sent()) {
        header('Content-Type: application/json');
    }
    echo json_encode($response_data);
    log_debug_message("DEBUG: Final JSON response to frontend: " . json_encode($response_data));
    exit(); // Penting untuk keluar setelah mengirim respons
}

// --- DAFTARKAN FUNGSI SHUTDOWN UNTUK MENANGKAP FATAL ERROR ---
// Panggil sendJsonResponseAndExit di shutdown_handler untuk konsistensi
register_shutdown_function(function() {
    $error = error_get_last();
    if ($error !== null && ($error['type'] === E_ERROR || $error['type'] === E_PARSE || $error['type'] === E_CORE_ERROR || $error['type'] === E_COMPILE_ERROR)) {
        $fatal_error_message = "Fatal Error: " . $error['message'] . " in " . $error['file'] . " on line " . $error['line'];
        log_debug_message("FATAL ERROR CAUGHT BY SHUTDOWN HANDLER: " . $fatal_error_message);
        if (php_sapi_name() !== 'cli') {
            // Gunakan sendJsonResponseAndExit untuk respons JSON yang bersih
            sendJsonResponseAndExit(['status' => 'error', 'message' => 'Internal Server Error: ' . $fatal_error_message]);
        }
    } else {
        // Hanya flush buffer jika tidak ada error fatal dan belum ada header yang dikirim
        if (ob_get_length() > 0 && !headers_sent()) {
             ob_end_flush();
        }
    }
});


// --- KONEKSI DATABASE ---
global $koneksi; // Deklarasikan sebagai global di scope utama
try {
    $koneksi_path = __DIR__ . '/../config/koneksi.php';
    log_debug_message("DEBUG: Attempting to connect to DB via: " . $koneksi_path);

    if (!file_exists($koneksi_path)) {
        throw new Exception("File koneksi.php tidak ditemukan di: " . $koneksi_path);
    }
    require_once $koneksi_path;
    // Periksa apakah $koneksi sudah diinisialisasi dan merupakan objek mysqli
    if (!($koneksi instanceof mysqli) || $koneksi->connect_error) {
        throw new Exception("Gagal terhubung ke database: " . ($koneksi->connect_error ?? 'Objek koneksi tidak valid.'));
    }
    log_debug_message("DEBUG: Database connection successful.");
} catch (Exception $e) {
    log_debug_message("CRITICAL ERROR: Database connection issue caught: " . $e->getMessage());
    sendJsonResponseAndExit(['status' => 'error', 'message' => 'Gagal terhubung ke database. Detail: ' . $e->getMessage()]);
}

// --- KONFIGURASI API FONNTE ---
global $whatsapp_config; // Deklarasikan sebagai global di scope utama
$whatsapp_config = [];

try {
    $whatsapp_config_path = __DIR__ . '/../config/whatsapp_config.php';
    log_debug_message("DEBUG: Attempting to load whatsapp_config.php from: " . $whatsapp_config_path);

    if (!file_exists($whatsapp_config_path)) {
        throw new Exception("File konfigurasi WhatsApp tidak ditemukan di jalur: " . $whatsapp_config_path);
    }

    $whatsapp_config_loaded_value = require $whatsapp_config_path;
    if (!is_array($whatsapp_config_loaded_value)) {
        throw new Exception("whatsapp_config.php tidak mengembalikan array yang valid. Periksa sintaksnya, harus `return array(...)`.");
    }
    $whatsapp_config = $whatsapp_config_loaded_value;

    $fonnte_token = $whatsapp_config['whatsapp_api_key'] ?? '';
    $fonnte_api_url = $whatsapp_config['whatsapp_api_url'] ?? 'https://api.fonnte.com/send';
    $app_base_url = $whatsapp_config['app_base_url'] ?? 'https://wifitetangga.my.id';
    $api_access_token_for_invoice = $whatsapp_config['api_access_token'] ?? '';

    log_debug_message("DEBUG: Config loaded - Fonnte Token (first 5 chars): " . substr($fonnte_token, 0, 5) . ", Fonnte API URL: " . $fonnte_api_url);

    if (empty($fonnte_token)) {
        throw new Exception('Token API Fonnte kosong setelah dimuat dari konfigurasi.');
    }

} catch (Exception $e) {
    log_debug_message("CRITICAL ERROR: Fonnte config issue caught: " . $e->getMessage());
    sendJsonResponseAndExit(['status' => 'error', 'message' => 'Kesalahan konfigurasi WhatsApp API: ' . $e->getMessage()]);
}


// --- FUNGSI KIRIM PESAN MENGGUNAKAN API FONNTE ---
function Kirimfonnte(mysqli $db_koneksi_param, string $token, string $apiUrl, string $target, string $message_text): array
{
    global $log_file_path; // Pastikan fungsi ini bisa mengakses path log
    $log_status = 'failed';
    $log_response_data = null;
    $result_message = 'Pesan gagal dikirim. Terjadi kesalahan tak dikenal.';

    // Gunakan parameter $db_koneksi_param sebagai koneksi utama dalam fungsi ini
    $db_koneksi_local = $db_koneksi_param;

    try {
        log_debug_message("DEBUG: Kirimfonnte called. Target: " . $target . ", Message: " . substr($message_text, 0, 50) . "...");

        if (empty($token) || empty($apiUrl)) {
            throw new Exception('Konfigurasi API Fonnte tidak lengkap (token atau URL API kosong).');
        }
        if (empty($message_text)) {
            throw new Exception('Isi pesan kosong.');
        }

        $cleanedTarget = preg_replace('/[^0-9]/', '', $target);
        if (substr($cleanedTarget, 0, 1) === '0') {
            $cleanedTarget = '62' . substr($cleanedTarget, 1);
        }
        if (!preg_match('/^62/', $cleanedTarget)) {
            if (strlen($cleanedTarget) >= 8) {
                 $cleanedTarget = '62' . $cleanedTarget;
            } else {
                $cleanedTarget = '';
            }
        }

        log_debug_message("DEBUG: Kirimfonnte - Original: " . $target . ", Cleaned: " . $cleanedTarget);

        if (empty($cleanedTarget) || strlen($cleanedTarget) < 10) {
            throw new Exception('Nomor telepon tidak valid atau terlalu pendek setelah pembersihan: ' . htmlspecialchars($target) . ' (Final: ' . $cleanedTarget . ')');
        }

        $curl = curl_init();
        $post_fields = array(
            'target' => $cleanedTarget,
            'message' => $message_text,
        );
        log_debug_message("DEBUG: Kirimfonnte - cURL POST fields to Fonnte: " . print_r($post_fields, true));

        curl_setopt_array($curl, array(
            CURLOPT_URL => $apiUrl,
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_ENCODING => '',
            CURLOPT_MAXREDIRS => 10,
            CURLOPT_TIMEOUT => 90,
            CURLOPT_FOLLOWLOCATION => true,
            CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
            CURLOPT_CUSTOMREQUEST => 'POST',
            CURLOPT_POSTFIELDS => $post_fields,
            CURLOPT_HTTPHEADER => array(
                'Authorization: ' . $token
            ),
            CURLOPT_SSL_VERIFYPEER => true,
            CURLOPT_SSL_VERIFYHOST => 2,
        ));

        $response = curl_exec($curl);
        $http_code = curl_getinfo($curl, CURLINFO_HTTP_CODE);
        $curl_error = curl_error($curl);

        curl_close($curl);

        log_debug_message("DEBUG: Kirimfonnte - cURL Raw Response for " . $cleanedTarget . ": " . ($response ?: 'EMPTY_RESPONSE'));
        log_debug_message("DEBUG: Kirimfonnte - cURL HTTP Code: " . $http_code);
        log_debug_message("DEBUG: Kirimfonnte - cURL Error: " . ($curl_error ?: 'No cURL error.'));

        if ($curl_error) {
            throw new Exception('cURL Error: ' . $curl_error);
        } else {
            $api_response = json_decode($response, true);

            if (json_last_error() !== JSON_ERROR_NONE) {
                throw new Exception('Fonnte respons tidak valid JSON. HTTP Code: ' . $http_code . '. Raw: ' . substr($response, 0, 200) . '...');
            } else {
                log_debug_message("DEBUG: Kirimfonnte - Fonnte API Decoded Response: " . print_r($api_response, true));

                if ($http_code == 200 && (isset($api_response['status']) && $api_response['status'] === true)) {
                    $log_status = 'sent';
                    $result_message = 'Pesan berhasil dikirim melalui Fonnte.';
                    $log_response_data = json_encode($api_response);
                } else {
                    $errorMessage = 'Gagal mengirim pesan melalui Fonnte. ';
                    $errorMessage .= 'HTTP Code: ' . $http_code . '. ';
                    if (isset($api_response['message'])) {
                        $errorMessage .= 'Fonnte Message: ' . $api_response['message'];
                    } elseif (isset($api_response['error'])) {
                        $errorMessage .= 'Fonnte Error: ' . (is_array($api_response['error']) ? json_encode($api_response['error']) : $api_response['error']);
                    } else {
                        $errorMessage .= 'Respons Fonnte (unknown error): ' . json_encode($api_response);
                    }
                    throw new Exception($errorMessage);
                }
            }
        }

    } catch (Exception $e) {
        $result_message = $e->getMessage();
        $log_status = 'failed';
        log_debug_message("ERROR: Kirimfonnte - Exception caught: " . $result_message);
        if (empty($log_response_data)) {
            $log_response_data = json_encode(['error' => $result_message, 'trace' => $e->getTraceAsString()]);
        }
    } finally {
        // Pastikan koneksi DB aktif sebelum mencoba log, jika tidak, coba re-establish
        if (!($db_koneksi_local instanceof mysqli) || $db_koneksi_local->connect_error || !$db_koneksi_local->ping()) {
             log_debug_message("WARNING: DB connection invalid/lost for logging in Kirimfonnte. Attempting to re-establish...");
             @$db_koneksi_local->close(); // Tutup koneksi yang rusak jika ada
             if (!defined('DB_HOST')) { // Pastikan konstanta DB terdefinisi
                 log_debug_message("CRITICAL ERROR: DB constants not defined for re-connection in Kirimfonnte.");
                 return ['status' => $log_status, 'message' => $result_message . " (Logging to DB failed: DB constants missing)", 'detail' => $result_message . " (DB re-connect failed)"];
             }
             // Coba sambungkan kembali
             $db_koneksi_local = new mysqli(DB_HOST, DB_USER, DB_PASS, DB_NAME);
             if ($db_koneksi_local->connect_error) {
                 log_debug_message("CRITICAL ERROR: Failed to re-establish DB connection for logging: " . $db_koneksi_local->connect_error);
                 return ['status' => $log_status, 'message' => $result_message . " (Logging to DB failed: DB re-connect failed)", 'detail' => $result_message . " (DB re-connect failed)"];
             } else {
                 log_debug_message("DEBUG: DB reconnected successfully for logging.");
                 // Penting: pastikan koneksi global juga diperbarui jika ini adalah satu-satunya koneksi
                 // Ini relevan jika $koneksi dari scope global juga perlu diperbarui
                 global $koneksi;
                 $koneksi = $db_koneksi_local;
             }
        }

        // Hanya coba log jika koneksi DB valid dan aktif
        if ($db_koneksi_local instanceof mysqli && !$db_koneksi_local->connect_error && $db_koneksi_local->ping()) {
            $insert_query = "INSERT INTO whatsapp_message_logs (phone_number, message_content, status, response_data, sent_at) VALUES (?, ?, ?, ?, NOW())";
            if ($stmt_log = $db_koneksi_local->prepare($insert_query)) {
                $max_log_data_length = 65535; // Ukuran MEDIUMTEXT
                $log_response_data_str = is_string($log_response_data) ? $log_response_data : json_encode($log_response_data);
                $log_response_data_str = substr($log_response_data_str, 0, $max_log_data_length);

                $stmt_log->bind_param("ssss", $target, $message_text, $log_status, $log_response_data_str);

                if (!$stmt_log->execute()) {
                    log_debug_message("CRITICAL ERROR: Failed to insert WhatsApp message log into DB: " . $stmt_log->error . " for phone: " . $target);
                    $result_message .= " (Gagal log ke DB)";
                }
                $stmt_log->close();
            } else {
                log_debug_message("CRITICAL ERROR: Failed to prepare WhatsApp message log insert query: " . $db_koneksi_local->error);
                $result_message .= " (Gagal menyiapkan log DB)";
            }
        } else {
            log_debug_message("CRITICAL ERROR: Final DB connection check failed. Log not saved for " . $target);
            $result_message .= " (Gagal log ke DB)";
        }
        return ['status' => $log_status, 'message' => $result_message, 'detail' => $result_message];
    }
}


// --- PENANGANAN AKSI: UNTUK CRON JOB ATAU PANGGILAN LANGSUNG (TEST/REMINDER) ---
$action = '';
$message_content = '';
$phone_number_single = '';
$customer_ids_selected = [];
$broadcast_id_to_delete = null;
$clear_activity_logs_flag = false; // Flag untuk aksi hapus log aktivitas
$received_csrf_token = ''; // Tambahkan variabel untuk menampung CSRF token yang diterima

if (php_sapi_name() === 'cli') {
    $action = 'process_queue';
    log_debug_message("DEBUG: Running in CLI mode. Setting action to 'process_queue'.");
    // Dalam mode CLI, jangan langsung keluar, biarkan cron job menjalankan fungsinya
    // processBroadcastQueue akan memanggil exit() jika diperlukan, atau script berakhir secara alami
    processBroadcastQueue($koneksi, $fonnte_token, $fonnte_api_url);
    exit(); // Pastikan exit setelah proses CLI selesai
} else {
    $input = file_get_contents('php://input');
    $data_from_frontend = json_decode($input, true);

    if (json_last_error() !== JSON_ERROR_NONE) {
        $json_error_msg = json_last_error_msg();
        log_debug_message("ERROR: json_decode failed: " . $json_error_msg . " for input: " . ($input ?: 'EMPTY_INPUT'));
        sendJsonResponseAndExit(['status' => 'error', 'message' => 'Gagal memproses data JSON yang diterima. Error: ' . $json_error_msg . '. Pastikan `Content-Type` header adalah `application/json` dan body tidak kosong.']);
    }

    if (!is_array($data_from_frontend) || empty($data_from_frontend)) {
        log_debug_message("ERROR: Decoded JSON data is empty or not an array. Input: " . ($input ?: 'EMPTY_INPUT'));
        sendJsonResponseAndExit(['status' => 'error', 'message' => 'Data permintaan kosong atau tidak valid setelah decoding JSON.']);
    }
    log_debug_message("DEBUG: Decoded/Parsed JSON data: " . print_r($data_from_frontend, true));

    $action = $data_from_frontend['action'] ?? '';
    $message_content = $data_from_frontend['message_content'] ?? '';
    $phone_number_single = $data_from_frontend['phoneNumber'] ?? '';
    // Ini akan digunakan saat pengiriman reminder dari frontend
    $customer_data_from_frontend = $data_from_frontend['customer_data'] ?? []; 
    // Ini akan digunakan saat pengiriman reminder massal
    $customer_ids_selected = $data_from_frontend['customer_ids'] ?? []; 
    $received_csrf_token = $data_from_frontend['csrf_token'] ?? ''; // Ambil CSRF token dari payload

    $broadcast_id_to_delete = $data_from_frontend['broadcast_id'] ?? null;
    $clear_activity_logs_flag = ($action == 'clear_all_activity_logs');
}

// Validasi CSRF token untuk semua POST request dari frontend
if ($_SERVER['REQUEST_METHOD'] == 'POST' && php_sapi_name() !== 'cli') {
    if (!isset($_SESSION['csrf_token']) || $received_csrf_token !== $_SESSION['csrf_token']) {
        log_debug_message("ERROR: CSRF validation failed. Session Token: " . ($_SESSION['csrf_token'] ?? 'N/A') . ", Received Token: " . ($received_csrf_token ?? 'N/A'));
        sendJsonResponseAndExit(['status' => 'error', 'message' => 'CSRF validation failed.']);
    }
    log_debug_message("DEBUG: CSRF validation successful.");
}


$response_to_frontend = ['status' => 'error', 'message' => 'Permintaan tidak valid atau pesan kosong.'];

switch ($action) {
    case 'test_message':
        if (empty($phone_number_single) || empty($message_content)) {
            $response_to_frontend = ['status' => 'error', 'message' => 'Nomor telepon atau pesan untuk tes tidak boleh kosong.'];
        } else {
            log_debug_message("DEBUG: Processing action 'test_message' for " . $phone_number_single);
            $result = Kirimfonnte($koneksi, $fonnte_token, $fonnte_api_url, $phone_number_single, $message_content);
            $response_to_frontend = ['status' => $result['status'] === 'sent' ? 'success' : 'error', 'message' => $result['message']];
        }
        sendJsonResponseAndExit($response_to_frontend); // Pastikan keluar di sini
        break;

     case 'send_reminder':
        if (empty($message_content)) {
             sendJsonResponseAndExit(['status' => 'error', 'message' => 'Isi pesan reminder tidak boleh kosong.']);
        }
        log_debug_message("DEBUG: Processing action 'send_reminder'.");
        $customer_targets_data = [];
        $overall_sent_count = 0;
        $overall_failed_count = 0;
        $detailed_results = [];

        // Jika ini adalah pengiriman reminder tunggal dari frontend (melalui customer_data)
        if (!empty($customer_data_from_frontend)) {
            $customer_targets_data[] = $customer_data_from_frontend;
            log_debug_message("DEBUG: Processing single customer reminder from frontend.");
        }
        // Jika ini adalah pengiriman reminder massal (melalui customer_ids_selected)
        else if (!empty($customer_ids_selected)) {
            $placeholders = implode(',', array_fill(0, count($customer_ids_selected), '?'));
            $types = str_repeat('i', count($customer_ids_selected));

            // MODIFIKASI QUERY: Ambil semua kolom yang dibutuhkan untuk placeholder
            $query_get_selected_customers = "SELECT p.telepon, p.nama_pelanggan, t.id_tagihan, t.bulan_tagihan, t.jumlah_tagihan, t.tanggal_jatuh_tempo, t.payment_link
                                            FROM pelanggan p
                                            JOIN tagihan t ON p.id_pelanggan = t.pelanggan_id
                                            WHERE t.status_tagihan IN ('Belum Lunas', 'Jatuh Tempo') AND p.telepon IS NOT NULL AND p.telepon != '' AND p.id_pelanggan IN ($placeholders)
                                            GROUP BY p.id_pelanggan, p.nama_pelanggan, p.telepon, t.id_tagihan, t.bulan_tagihan, t.jumlah_tagihan, t.tanggal_jatuh_tempo, t.payment_link";

            if ($stmt_selected = $koneksi->prepare($query_get_selected_customers)) {
                $stmt_selected->bind_param($types, ...$customer_ids_selected);
                $stmt_selected->execute();
                $result_selected = $stmt_selected->get_result();
                while ($row = $result_selected->fetch_assoc()) {
                    $customer_targets_data[] = $row;
                }
                $stmt_selected->close();
            } else {
                log_debug_message("ERROR: 'send_reminder' - Failed to prepare selected customers query: " . $koneksi->error);
                sendJsonResponseAndExit(['status' => 'error', 'message' => 'Gagal menyiapkan query untuk pelanggan terpilih: ' . $koneksi->error]);
            }

            if (empty($customer_targets_data)) {
                log_debug_message("WARNING: 'send_reminder' - No unpaid selected customers with phone numbers found.");
                sendJsonResponseAndExit(['status' => 'warning', 'message' => 'Tidak ada pelanggan yang belum lunas dan terpilih dengan nomor telepon yang terdaftar.']);
            }
        }
        // Jika tidak ada customer_data dari frontend dan tidak ada customer_ids_selected (berarti "Kirim ke Semua")
        else {
            log_debug_message("DEBUG: Processing 'send_reminder' for all unpaid customers.");
            // PASTIKAN SINTAKS SQL DI BAWAH INI SANGAT BERSIH DAN BENAR
            $query_get_unpaid_customers = "SELECT p.telepon, p.nama_pelanggan, t.id_tagihan, t.bulan_tagihan, t.jumlah_tagihan, t.tanggal_jatuh_tempo, t.payment_link
                                            FROM pelanggan p
                                            JOIN tagihan t ON p.id_pelanggan = t.pelanggan_id
                                            WHERE p.status_aktif = 'Aktif' AND t.status_tagihan IN ('Belum Lunas', 'Jatuh Tempo') AND p.telepon IS NOT NULL AND p.telepon != ''
                                            GROUP BY p.id_pelanggan, p.nama_pelanggan, p.telepon, t.id_tagihan, t.bulan_tagihan, t.jumlah_tagihan, t.tanggal_jatuh_tempo, t.payment_link";
            
            // Eksekusi query langsung (ini baris 404 yang disebut di error)
            // Lakukan pengecekan error di sini
            $result_unpaid_customers = $koneksi->query($query_get_unpaid_customers);

            if (!$result_unpaid_customers) { // Tambahkan pengecekan jika query gagal
                log_debug_message("CRITICAL ERROR: Failed to execute query_get_unpaid_customers: " . $koneksi->error . " Query: " . $query_get_unpaid_customers);
                sendJsonResponseAndExit(['status' => 'error', 'message' => 'Gagal mengambil data pelanggan belum lunas: ' . $koneksi->error]);
            }

            if ($result_unpaid_customers->num_rows > 0) {
                while ($row = $result_unpaid_customers->fetch_assoc()) {
                    $customer_targets_data[] = $row;
                }
            } else {
                log_debug_message("WARNING: 'send_reminder' - No unpaid customers with phone numbers found.");
                sendJsonResponseAndExit(['status' => 'warning', 'message' => 'Tidak ada pelanggan dengan tagihan belum lunas yang memiliki nomor telepon terdaftar.']);
            }
        }

        foreach ($customer_targets_data as $customer_data_row) {
            // Periksa koneksi DB di awal setiap iterasi
            if (!$koneksi->ping()) {
                log_debug_message("WARNING: Database connection lost during send_reminder loop. Attempting to reconnect.");
                @$koneksi->close();
                if (!defined('DB_HOST')) {
                    log_debug_message("CRITICAL ERROR: DB constants not defined for re-connection in send_reminder. Stopping reminder process.");
                    $detailed_results[] = [
                        'phone' => $customer_data_row['telepon'],
                        'status' => 'failed',
                        'detail' => 'Gagal mengirim (koneksi database terputus dan konstanta DB hilang).'
                    ];
                    $overall_failed_count++;
                    continue; // Lanjutkan ke pelanggan berikutnya jika ini bukan fatal error global
                }
                $koneksi = new mysqli(DB_HOST, DB_USER, DB_PASS, DB_NAME);
                if ($koneksi->connect_error) {
                    log_debug_message("CRITICAL ERROR: Failed to reconnect to database during send_reminder loop: " . $koneksi->connect_error);
                    $detailed_results[] = [
                        'phone' => $customer_data_row['telepon'],
                        'status' => 'failed',
                        'detail' => 'Gagal mengirim (koneksi database terputus dan tidak dapat disambungkan kembali).'
                    ];
                    $overall_failed_count++;
                    continue; // Lanjutkan ke pelanggan berikutnya
                }
                log_debug_message("DEBUG: Database reconnected successfully during send_reminder loop.");
            }

            $phone_to_send = $customer_data_row['telepon'];

            // Tentukan link internal (print_invoice.php)
            $internal_invoice_link = $app_base_url . '/pages/print_invoice.php?source_table=tagihan&id=' . $customer_data_row['id_tagihan'] . '&api_access_token=' . $api_access_token_for_invoice;

            // Tentukan link Xendit (dari database). Jika kosong, isi dengan teks tertentu.
            $xendit_payment_link = !empty($customer_data_row['payment_link']) ? $customer_data_row['payment_link'] : 'Lengkapi data anda di admin untuk melakukan pembayaran online';

            // --- BARIS DEBUGGING ---
            log_debug_message("DEBUG: Value of \$internal_invoice_link (for [invoice_link_internal]): " . $internal_invoice_link);
            log_debug_message("DEBUG: Value of \$xendit_payment_link (for [xendit_link]): " . $xendit_payment_link);
            log_debug_message("DEBUG: Original \$message_content before replace: " . $message_content);
            // --- AKHIR BARIS DEBUGGING ---

            $personalized_message = str_replace(
                ['[nama_pelanggan]', '[bulan]', '[jumlah]', '[jatuh_tempo]', '[invoice_link_internal]', '[xendit_link]'],
                [
                    $customer_data_row['nama_pelanggan'],
                    date('F Y', strtotime($customer_data_row['bulan_tagihan'] . '-01')),
                    number_format($customer_data_row['jumlah_tagihan'], 0, ',', '.'),
                    date('d M Y', strtotime($customer_data_row['tanggal_jatuh_tempo'])),
                    $internal_invoice_link,
                    $xendit_payment_link
                ],
                $message_content
            );
            log_debug_message("DEBUG: 'send_reminder' - Sending personalized message to " . $phone_to_send . ": " . substr($personalized_message, 0, 250) . " (Internal: " . $internal_invoice_link . ", Xendit: " . $xendit_payment_link . ")");
            $result = Kirimfonnte($koneksi, $fonnte_token, $fonnte_api_url, $phone_to_send, $personalized_message);

            $detailed_results[] = [
                'phone' => $phone_to_send,
                'status' => $result['status'],
                'detail' => $result['detail']
            ];
            if ($result['status'] === 'sent') {
                $overall_sent_count++;
            } else {
                $overall_failed_count++;
            }
            sleep(1); // Mengurangi jeda untuk testing, bisa disesuaikan
        }
        log_debug_message("DEBUG: 'send_reminder' - Completed. Sent: " . $overall_sent_count . ", Failed: " . $overall_failed_count);
        $response_to_frontend = [
            'status' => 'success',
            'message' => 'Pengingat selesai! Berhasil: ' . $overall_sent_count . ', Gagal: ' . $overall_failed_count . '.',
            'detailed_results' => $detailed_results
        ];
        sendJsonResponseAndExit($response_to_frontend); // Pastikan keluar di sini
        break;

    case 'delete_broadcast_history':
        if ($broadcast_id_to_delete !== null && is_numeric($broadcast_id_to_delete)) {
            $koneksi->begin_transaction();
            try {
                $stmt_delete_details = $koneksi->prepare("DELETE FROM whatsapp_broadcast_queue_details WHERE broadcast_id = ?");
                $stmt_delete_details->bind_param("i", $broadcast_id_to_delete);
                $stmt_delete_details->execute();
                $rows_deleted_details = $stmt_delete_details->affected_rows;
                $stmt_delete_details->close();

                $stmt_delete_queue = $koneksi->prepare("DELETE FROM whatsapp_broadcast_queue WHERE id = ?");
                $stmt_delete_queue->bind_param("i", $broadcast_id_to_delete);
                $stmt_delete_queue->execute();
                $rows_deleted_queue = $stmt_delete_queue->affected_rows;
                $stmt_delete_queue->close();

                if ($rows_deleted_queue > 0) {
                    $koneksi->commit();
                    $response_to_frontend = ['status' => 'success', 'message' => 'Riwayat broadcast ID ' . $broadcast_id_to_delete . ' berhasil dihapus.'];
                    log_debug_message("INFO: Broadcast history ID " . $broadcast_id_to_delete . " deleted successfully.");
                } else {
                    $koneksi->rollback();
                    $response_to_frontend = ['status' => 'error', 'message' => 'Riwayat broadcast ID ' . $broadcast_id_to_delete . ' tidak ditemukan atau gagal dihapus.'];
                    log_debug_message("WARNING: Attempted to delete broadcast ID " . $broadcast_id_to_delete . " but it was not found or not deleted.");
                }

            } catch (mysqli_sql_exception $e) {
                $koneksi->rollback();
                $response_to_frontend = ['status' => 'error', 'message' => 'Gagal menghapus riwayat broadcast karena kesalahan database: ' . htmlspecialchars($e->getMessage())];
                log_debug_message("ERROR: Database error while deleting broadcast ID " . $broadcast_id_to_delete . ": " . $e->getMessage());
            }
        } else {
            $response_to_frontend = ['status' => 'error', 'message' => 'ID broadcast tidak valid untuk dihapus.'];
        }
        sendJsonResponseAndExit($response_to_frontend); // Pastikan keluar di sini
        break;

    case 'clear_all_broadcast_history':
        $koneksi->begin_transaction();
        try {
            log_debug_message("INFO: Starting 'clear_all_broadcast_history' action.");

            // Hapus log pesan terkait broadcast/pengingat
            $koneksi->query("DELETE FROM whatsapp_message_logs WHERE message_content LIKE '%broadcast%' OR message_content LIKE '%Pengingat%';");
            log_debug_message("DEBUG: Deleted related entries from whatsapp_message_logs.");

            $stmt_delete_all_details = $koneksi->prepare("DELETE FROM whatsapp_broadcast_queue_details");
            $stmt_delete_all_details->execute();
            $stmt_delete_all_details->close();
            log_debug_message("DEBUG: Deleted all from whatsapp_broadcast_queue_details.");

            $stmt_delete_all_queue = $koneksi->prepare("DELETE FROM whatsapp_broadcast_queue");
            $stmt_delete_all_queue->execute();
            $stmt_delete_all_queue->close();
            log_debug_message("DEBUG: Deleted all from whatsapp_broadcast_queue.");

            // Reset AUTO_INCREMENT hanya jika tabel tidak kosong sebelumnya
            // Lebih aman menggunakan SQL murni untuk reset AUTO_INCREMENT
            $koneksi->query("ALTER TABLE whatsapp_broadcast_queue AUTO_INCREMENT = 1;");
            $koneksi->query("ALTER TABLE whatsapp_broadcast_queue_details AUTO_INCREMENT = 1;");
            log_debug_message("DEBUG: AUTO_INCREMENT for broadcast_queue and details tables reset to 1.");

            $koneksi->commit();
            $response_to_frontend = ['status' => 'success', 'message' => 'Seluruh riwayat broadcast berhasil dihapus dan ID direset.'];
            log_debug_message("INFO: All broadcast history cleared successfully and AUTO_INCREMENT reset.");

        } catch (mysqli_sql_exception $e) {
            $koneksi->rollback();
            $response_to_frontend = ['status' => 'error', 'message' => 'Gagal menghapus seluruh riwayat broadcast karena kesalahan database: ' . htmlspecialchars($e->getMessage())];
            log_debug_message("ERROR: Database error while clearing all broadcast history: " . $e->getMessage());
        }
        sendJsonResponseAndExit($response_to_frontend); // Pastikan keluar di sini
        break;

    case 'clear_all_activity_logs':
        $koneksi->begin_transaction();
        try {
            log_debug_message("INFO: Starting 'clear_all_activity_logs' action.");

            $stmt_delete_logs = $koneksi->prepare("DELETE FROM activity_logs");
            $stmt_delete_logs->execute();
            $stmt_delete_logs->close();
            log_debug_message("DEBUG: Deleted all entries from activity_logs table.");

            $koneksi->query("ALTER TABLE activity_logs AUTO_INCREMENT = 1;");
            log_debug_message("DEBUG: AUTO_INCREMENT for activity_logs table reset to 1.");

            $koneksi->commit();
            $response_to_frontend = ['status' => 'success', 'message' => 'Seluruh log aktivitas berhasil dihapus.'];
            log_debug_message("INFO: All activity logs cleared successfully.");

        } catch (mysqli_sql_exception $e) {
            $koneksi->rollback();
            $response_to_frontend = ['status' => 'error', 'message' => 'Gagal menghapus log aktivitas karena kesalahan database: ' . htmlspecialchars($e->getMessage())];
            log_debug_message("ERROR: Database error while clearing activity logs: " . $e->getMessage());
        }
        sendJsonResponseAndExit($response_to_frontend); // Pastikan keluar di sini
        break;

    case 'check_status':
        log_debug_message("DEBUG: Processing action 'check_status'.");
        if (empty($fonnte_token) || empty($fonnte_api_url)) {
            $response_to_frontend = ['status' => 'error', 'message' => 'Konfigurasi API Fonnte belum lengkap.'];
        } else {
            $response_to_frontend = ['status' => 'success', 'message' => 'Konfigurasi API Fonnte ditemukan.'];
        }
        sendJsonResponseAndExit($response_to_frontend); // Pastikan keluar di sini
        break;

    default:
        log_debug_message("ERROR: Unknown action or empty action parameter detected. Action: '" . $action . "'");
        // Jika aksi tidak dikenal dan bukan CLI, kirimkan respons JSON
        sendJsonResponseAndExit(['status' => 'error', 'message' => 'Aksi tidak dikenal atau kosong.']);
        break;
}

// --- FUNGSI BARU: PROCESS BROADCAST QUEUE ---
function processBroadcastQueue(mysqli $db_koneksi_param, string $fonnte_token, string $fonnte_api_url) {
    global $log_file_path;
    log_debug_message("INFO: processBroadcastQueue started.");

    $max_execution_time_for_this_run = 55;
    $start_time = microtime(true);

    // Gunakan $db_koneksi_param sebagai koneksi utama dalam fungsi ini
    $db_koneksi_local = $db_koneksi_param;

    // Kunci baris yang sedang diproses untuk mencegah race condition
    // Menggunakan begin_transaction dan commit untuk memastikan LOCK bekerja.
    $db_koneksi_local->begin_transaction();
    $query_get_broadcast = "SELECT id, message_content FROM whatsapp_broadcast_queue WHERE status IN ('pending', 'processing') ORDER BY requested_at ASC LIMIT 1 FOR UPDATE";
    $result_broadcast = $db_koneksi_local->query($query_get_broadcast);

    if ($result_broadcast && $result_broadcast->num_rows > 0) {
        $broadcast_data = $result_broadcast->fetch_assoc();
        $broadcast_id = $broadcast_data['id'];
        $message_content = $broadcast_data['message_content'];

        log_debug_message("INFO: Processing broadcast_id: " . $broadcast_id);

        $stmt_update_broadcast = $db_koneksi_local->prepare("UPDATE whatsapp_broadcast_queue SET status = 'processing', processed_at = NOW() WHERE id = ?");
        $stmt_update_broadcast->bind_param("i", $broadcast_id);
        $stmt_update_broadcast->execute();
        $stmt_update_broadcast->close();
        $db_koneksi_local->commit(); // Commit setelah update status processing

        $batch_size = 100;
        $offset = 0;

        while (true) {
            if ((microtime(true) - $start_time) > $max_execution_time_for_this_run) {
                log_debug_message("WARNING: Max execution time (" . $max_execution_time_for_this_run . "s) reached for broadcast_id: " . $broadcast_id . ". Script will exit and resume next minute.");
                break;
            }

            // Kunci baris detail yang sedang diproses
            $db_koneksi_local->begin_transaction();
            $query_get_details = "SELECT id, phone_number, attempt_count FROM whatsapp_broadcast_queue_details WHERE broadcast_id = ? AND status IN ('pending', 'retrying') ORDER BY id ASC LIMIT ? OFFSET ? FOR UPDATE";
            $stmt_get_details = $db_koneksi_local->prepare($query_get_details);
            $stmt_get_details->bind_param("iii", $broadcast_id, $batch_size, $offset);
            $stmt_get_details->execute();
            $result_details = $stmt_get_details->get_result();

            $phones_to_process = [];
            while ($row = $result_details->fetch_assoc()) {
                $phones_to_process[] = $row;
            }
            $stmt_get_details->close();
            $db_koneksi_local->commit(); // Commit setelah mengambil detail

            if (empty($phones_to_process)) {
                log_debug_message("INFO: No more pending/retrying numbers for broadcast_id: " . $broadcast_id);
                break;
            }

            foreach ($phones_to_process as $detail_item) {
                if ((microtime(true) - $start_time) > $max_execution_time_for_this_run) {
                    log_debug_message("WARNING: Max execution time (" . $max_execution_time_for_this_run . "s) reached during batch processing for broadcast_id: " . $broadcast_id . ". Script will exit and resume next minute.");
                    break 2;
                }

                $detail_id = $detail_item['id'];
                $phone_number = $detail_item['phone_number'];
                $attempt_count = $detail_item['attempt_count'];

                log_debug_message("DEBUG: Processing detail_id: " . $detail_id . " (Phone: " . $phone_number . ", Attempts: " . $attempt_count . ")");

                if ($attempt_count >= 3) {
                    $response_detail_msg = 'Max retry attempts reached.';
                    $stmt_update_detail = $db_koneksi_local->prepare("UPDATE whatsapp_broadcast_queue_details SET status = 'failed', response_detail = ?, last_attempt_at = NOW(), attempt_count = ? WHERE id = ?");
                    $stmt_update_detail->bind_param("sii", $response_detail_msg, $attempt_count + 1, $detail_id);
                    $stmt_update_detail->execute();
                    $stmt_update_detail->close();
                    log_debug_message("WARNING: Max retries reached for detail_id: " . $detail_id);
                    continue;
                }

                // Periksa koneksi DB di sini juga
                if (!$db_koneksi_local->ping()) {
                    log_debug_message("WARNING: Database connection lost during queue processing. Attempting to reconnect.");
                    @$db_koneksi_local->close();
                    if (!defined('DB_HOST')) {
                        log_debug_message("CRITICAL ERROR: DB constants not defined for re-connection in processBroadcastQueue.");
                        return; // Fatal, tidak bisa melanjutkan
                    }
                    $db_koneksi_local = new mysqli(DB_HOST, DB_USER, DB_PASS, DB_NAME);
                    if ($db_koneksi_local->connect_error) {
                        log_debug_message("CRITICAL ERROR: Failed to reconnect to database during queue processing: " . $db_koneksi_local->connect_error);
                        return; // Fatal, tidak bisa melanjutkan
                    }
                    log_debug_message("DEBUG: Database reconnected successfully during queue processing.");
                    // Penting: pastikan koneksi global juga diperbarui jika ini adalah satu-satunya koneksi
                    global $koneksi;
                    $koneksi = $db_koneksi_local;
                }

                $result = Kirimfonnte($db_koneksi_local, $fonnte_token, $fonnte_api_url, $phone_number, $message_content);

                $new_status = ($result['status'] === 'sent') ? 'sent' : 'failed';
                $response_detail = $db_koneksi_local->real_escape_string($result['detail'] ?? $result['message']);

                $stmt_update_detail = $db_koneksi_local->prepare("UPDATE whatsapp_broadcast_queue_details SET status = ?, response_detail = ?, attempt_count = attempt_count + 1, last_attempt_at = NOW() WHERE id = ?");
                $stmt_update_detail->bind_param("ssi", $new_status, $response_detail, $detail_id);
                $stmt_update_detail->execute();
                $stmt_update_detail->close();

                sleep(1); // Mengurangi jeda untuk testing, bisa disesuaikan
            }
            $offset += $batch_size;
        }

        // Rekap dan perbarui status broadcast utama
        $recount_query = "SELECT SUM(CASE WHEN status = 'sent' THEN 1 ELSE 0 END) as sent,
                                SUM(CASE WHEN status = 'failed' THEN 1 ELSE 0 END) as failed,
                                SUM(CASE WHEN status IN ('pending', 'retrying') THEN 1 ELSE 0 END) as pending_retrying
                            FROM whatsapp_broadcast_queue_details WHERE broadcast_id = ?";
        $stmt_recount = $db_koneksi_local->prepare($recount_query);
        $stmt_recount->bind_param("i", $broadcast_id);
        $stmt_recount->execute();
        $recount_result = $stmt_recount->get_result()->fetch_assoc();
        $stmt_recount->close();

        $final_sent_count = $recount_result['sent'];
        $final_failed_count = $recount_result['failed'];
        $remaining_pending_retrying = $recount_result['pending_retrying'];

        $broadcast_overall_status = 'processing';
        if ($remaining_pending_retrying == 0) {
            $broadcast_overall_status = 'completed';
        }

        $update_broadcast_status_query = $db_koneksi_local->prepare("UPDATE whatsapp_broadcast_queue SET sent_count = ?, failed_count = ?, status = ? WHERE id = ?");
        $update_broadcast_status_query->bind_param("iisi", $final_sent_count, $final_failed_count, $broadcast_overall_status, $broadcast_id);
        $update_broadcast_status_query->execute();
        $update_broadcast_status_query->close();

        log_debug_message("INFO: Finished processing broadcast_id: " . $broadcast_id . ". Status: " . $broadcast_overall_status . ", Sent: " . $final_sent_count . ", Failed: " . $final_failed_count . ", Remaining: " . $remaining_pending_retrying);

    } else {
        log_debug_message("INFO: No pending broadcasts found in the queue.");
    }
}
