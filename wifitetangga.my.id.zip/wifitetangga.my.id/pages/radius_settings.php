<?php
// C:\xampp\htdocs\billing_isp_app\pages\radius_settings.php

// Sertakan file koneksi database. Ini harus di atas dan murni PHP.
require_once __DIR__ . '/../config/koneksi.php';

// Pastikan session dimulai dan fungsi hasRole tersedia di awal.
// Ini harus di bagian paling atas file, sebelum output apapun.
if (session_status() == PHP_SESSION_NONE) {
ini_set('session.use_strict_mode', 1);
ini_set('session.cookie_httponly', 1);
ini_set('session.cookie_samesite', 'Lax');
if (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on') {
    ini_set('session.cookie_secure', 1);
}
    session_start();
}

// Definisikan fungsi hasRole jika belum ada (misal, jika functions.php tidak terpisah)
// Ini untuk memastikan hasRole bisa dipanggil sebelum header.php di-include.
if (!function_exists('hasRole')) {
    function hasRole($required_role) {
        if (!isset($_SESSION['role'])) {
            return false;
        }
        $user_role = $_SESSION['role'];

        if ($user_role === 'superadmin') {
            return true;
        }

        if (is_array($required_role)) {
            return in_array($user_role, $required_role);
        }
        else {
            return $user_role === $required_role;
        }
    }
}

// Periksa peran pengguna dan lakukan redirect jika tidak memenuhi syarat.
// Karena kita belum meng-include header.php, kita bisa menggunakan header() untuk redirect.
if (!hasRole('superadmin')) {
    header('Location: dashboard.php');
    exit();
}

$message = '';
$message_type = '';
$editing_mikrotik = null;

// Tangani aksi DELETE
if (isset($_GET['action']) && $_GET['action'] === 'delete' && isset($_GET['id'])) {
    $id_to_delete = intval($_GET['id']);
    try {
        $stmt = $koneksi->prepare("DELETE FROM radius_configs WHERE id = ?");
        if ($stmt) {
            $stmt->bind_param("i", $id_to_delete);
            $stmt->execute();
            if ($stmt->affected_rows > 0) {
                $message = "Konfigurasi MikroTik berhasil dihapus.";
                $message_type = "success";
            } else {
                $message = "Konfigurasi MikroTik tidak ditemukan atau gagal dihapus.";
                $message_type = "warning";
            }
            $stmt->close();
        } else {
            throw new Exception("Gagal menyiapkan statement delete: " . $koneksi->error);
        }
    } catch (Exception $e) {
        error_log("Error deleting Mikrotik config: " . $e->getMessage());
        $message = "Terjadi kesalahan saat menghapus konfigurasi MikroTik: " . $e->getMessage();
        $message_type = "error";
    }
    // Redirect setelah operasi delete. Pesan akan diambil oleh JavaScript.
    header('Location: radius_settings.php?message=' . urlencode($message) . '&type=' . $message_type);
    exit(); // Penting: Hentikan eksekusi setelah redirect
}

// Tangani aksi EDIT (memuat data ke form)
if (isset($_GET['action']) && $_GET['action'] === 'edit' && isset($_GET['id'])) {
    $id_to_edit = intval($_GET['id']);
    try {
        $stmt = $koneksi->prepare("SELECT * FROM radius_configs WHERE id = ?");
        if ($stmt) {
            $stmt->bind_param("i", $id_to_edit);
            $stmt->execute();
            $result = $stmt->get_result();
            $editing_mikrotik = $result->fetch_assoc();
            $stmt->close();
            if (!$editing_mikrotik) {
                $message = "Konfigurasi MikroTik yang akan diedit tidak ditemukan.";
                $message_type = "error";
            }
        } else {
            throw new Exception("Gagal menyiapkan statement edit: " . $koneksi->error);
        }
    } catch (Exception $e) {
        error_log("Error fetching Mikrotik config for edit: " . $e->getMessage());
        $message = "Terjadi kesalahan saat memuat konfigurasi MikroTik untuk diedit: " . $e->getMessage();
        $message_type = "error";
    }
}

// Tangani pengiriman formulir (ADD atau UPDATE)
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $id = $_POST['id'] ?? null;
    $name = $_POST['name'] ?? '';
    $ip_address = $_POST['ip_address'] ?? '';
    $shared_secret = $_POST['shared_secret'] ?? '';

    if (empty($name) || empty($ip_address) || empty($shared_secret)) {
        $message = "Nama, IP Address, dan Shared Secret tidak boleh kosong.";
        $message_type = "error";
    } else {
        try {
            if ($id) {
                $stmt = $koneksi->prepare("UPDATE radius_configs SET name = ?, ip_address = ?, shared_secret = ? WHERE id = ?");
                if ($stmt) {
                    $stmt->bind_param("sssi", $name, $ip_address, $shared_secret, $id);
                    $stmt->execute();
                    $stmt->close();
                    $message = "Konfigurasi MikroTik berhasil diperbarui.";
                    $message_type = "success";
                } else {
                    throw new Exception("Gagal menyiapkan statement update: " . $koneksi->error);
                }
            } else {
                $stmt = $koneksi->prepare("INSERT INTO radius_configs (name, ip_address, shared_secret) VALUES (?, ?, ?)");
                if ($stmt) {
                    $stmt->bind_param("sss", $name, $ip_address, $shared_secret);
                    $stmt->execute();
                    $stmt->close();
                    $message = "Konfigurasi MikroTik baru berhasil ditambahkan.";
                    $message_type = "success";
                } else {
                    throw new Exception("Gagal menyiapkan statement insert: " . $koneksi->error);
                }
            }
            $editing_mikrotik = null;
        } catch (Exception $e) {
            error_log("Error saving Mikrotik config: " . $e->getMessage());
            $message = "Terjadi kesalahan saat menyimpan konfigurasi MikroTik: " . $e->getMessage();
            $message_type = "error";
        }
    }
    // Redirect setelah operasi POST (tambah/update). Pesan akan diambil oleh JavaScript.
    header('Location: radius_settings.php?message=' . urlencode($message) . '&type=' . $message_type);
    exit(); // Penting: Hentikan eksekusi setelah redirect
}

// Ambil pesan dan tipe dari URL jika ada setelah redirect
if (isset($_GET['message']) && isset($_GET['type'])) {
    $message = htmlspecialchars($_GET['message']);
    $message_type = htmlspecialchars($_GET['type']);
}

// Ambil semua konfigurasi Mikrotik dari database (setelah semua operasi CRUD)
$mikrotik_configs = [];
try {
    $result = $koneksi->query("SELECT * FROM radius_configs ORDER BY name ASC");
    if ($result) {
        while ($row = $result->fetch_assoc()) {
            $mikrotik_configs[] = $row;
        }
        $result->free();
    }
} catch (Exception $e) {
    error_log("Error fetching all Mikrotik configs: " . $e->getMessage());
    $message = "Terjadi kesalahan saat mengambil daftar konfigurasi MikroTik: " . $e->getMessage();
    $message_type = "error";
}

// Sekarang baru include header.php yang mulai menghasilkan output HTML.
// Pastikan tidak ada spasi kosong atau baris baru sebelum tag <?php di file ini.
require_once __DIR__ . '/../includes/header.php';
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Pengaturan RADIUS - Billing ISP App</title>
    <link rel="stylesheet" href="../css/style.css"> <!-- Pastikan ini mengarah ke file style.css yang benar -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <style>
        /* Gaya tambahan yang spesifik untuk halaman ini */
        .main-content {
            padding-top: 70px;
            padding-bottom: 20px;
            box-sizing: border-box;
            min-height: 100vh;
            overflow-y: auto;
        }

        body.dashboard-layout {
            height: 100vh;
            overflow: hidden;
            display: flex;
            flex-direction: row;
        }

        .wrapper {
            display: flex;
            flex-direction: row;
            width: 100%;
            height: 100vh;
            overflow: hidden;
        }

        .container {
            max-width: 900px;
            margin: 20px auto;
            background-color: #ffffff;
            padding: 30px;
            border-radius: 12px;
            box-shadow: 0 4px 20px rgba(0, 0, 0, 0.08);
            border: 1px solid #e0e0e0;
        }

        /* Gaya info-box */
        .info-box {
            background-color: var(--tznpisp-card-bg);
            border-left: 6px solid var(--tznpisp-primary-blue);
            padding: 20px;
            margin-bottom: 20px;
            border-radius: 8px;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.15);
            color: var(--tznpisp-text-light);
        }
        .info-box h3 {
            color: var(--tznpisp-text-light);
            margin-top: 0;
            margin-bottom: 15px;
            font-size: 1.4em;
            font-weight: 700;
        }
        .info-box p {
            margin: 0 0 10px 0;
            color: var(--tznpisp-text-muted);
            font-size: 0.95em;
        }
        .info-box ul {
            margin: 0;
            padding-left: 25px;
            list-style-type: disc;
            color: var(--tznpisp-text-muted);
        }
        .info-box li {
            margin-bottom: 5px;
            line-height: 1.5;
        }
        .info-box pre {
            background-color: var(--tznpisp-dark-bg);
            border: 1px solid var(--tznpnpisp-border-color);
            padding: 15px;
            border-radius: 6px;
            overflow-x: auto;
            font-family: 'Roboto Mono', monospace;
            font-size: 0.9em;
            color: var(--tznpisp-text-light);
            white-space: pre-wrap;
            word-break: break-all;
            line-height: 1.4;
        }
        .info-box strong {
            color: var(--tznpisp-accent-red);
        }

        /* Tabel konfigurasi MikroTik */
        .mikrotik-config-table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
        }
        .mikrotik-config-table th,
        .mikrotik-config-table td {
            border: 1px solid var(--tznpisp-border-color);
            padding: 10px 12px;
            text-align: left;
            font-size: 0.9em;
            color: var(--tznpisp-text-muted);
        }
        .mikrotik-config-table th {
            background-color: var(--tznpisp-sidebar-bg);
            color: var(--tznpisp-text-light);
            font-weight: 600;
        }
        .mikrotik-config-table tbody tr:nth-child(even) {
            background-color: var(--tznpisp-card-bg);
        }
        .mikrotik-config-table tbody tr:nth-child(odd) {
            background-color: var(--tznpisp-dark-bg);
        }
        .mikrotik-config-table tbody tr:hover {
            background-color: var(--tznpisp-active-menu-bg);
            color: var(--tznpisp-active-menu-color);
        }
        .mikrotik-config-table tbody tr:hover td {
            color: var(--tznpisp-active-menu-color);
        }
        .mikrotik-config-table .actions {
            white-space: nowrap;
        }
        .mikrotik-config-table .btn-action {
            padding: 6px 10px;
            font-size: 0.8em;
            margin-right: 5px;
        }

        /* Tombol Tambah Baru */
        .btn-add-new {
            background-color: var(--tznpisp-accent-green);
            color: #fff;
            border-color: var(--tznpisp-accent-green);
        }
        .btn-add-new:hover {
            background-color: #00b347;
            border-color: #00b347;
        }

        /* Responsive adjustments */
        @media (max-width: 768px) {
            .main-content {
                padding-top: 60px;
                padding: 15px;
            }
            .container {
                margin: 15px auto;
                padding: 20px;
            }
            h1 {
                font-size: 1.8em;
                margin-bottom: 15px;
            }
            .form-group label {
                font-size: 1em;
            }
            .form-group input[type="text"] {
                padding: 10px;
            }
            .btn-primary, .btn-add-new {
                padding: 12px 20px;
                font-size: 1em;
            }
            .alert {
                padding: 15px;
                font-size: 0.95em;
            }
            .info-box {
                padding: 15px;
            }
            .info-box h3 {
                font-size: 1.3em;
            }
            .info-box pre {
                padding: 10px;
                font-size: 0.9em;
            }
            .mikrotik-config-table th,
            .mikrotik-config-table td {
                padding: 8px;
                font-size: 0.85em;
            }
            .mikrotik-config-table .btn-action {
                padding: 4px 8px;
                font-size: 0.7em;
            }
        }
    </style>
</head>
<body class="<?php echo htmlspecialchars($body_class, ENT_QUOTES, "UTF-8"); ?>">
    <div class="wrapper">
        <?php include __DIR__ . '/../includes/sidebar.php'; ?>
        <div class="main-content">
            <?php // include __DIR__ . '/../includes/navbar.php'; // Dihapus karena navbar ada di header.php ?>
            
            <div class="page-header">
                <h1><i class="fa-solid fa-server"></i> Pengaturan RADIUS</h1>
                <p>Konfigurasi detail koneksi RADIUS untuk otentikasi MikroTik.</p>
            </div>

            <div class="card mb-4">
                <div class="card-header">
                    <h3>Daftar Konfigurasi MikroTik</h3>
                    <button class="btn btn-add-new" onclick="location.href='radius_settings.php'">
                        <i class="fas fa-plus"></i> Tambah Baru
                    </button>
                </div>
                <div class="card-body">
                    <?php if ($message): ?>
                        <div class="alert <?php echo htmlspecialchars($message_type, ENT_QUOTES, "UTF-8"); ?>">
                            <?php echo htmlspecialchars($message); ?>
                        </div>
                    <?php endif; ?>

                    <?php if (!empty($mikrotik_configs)): ?>
                        <div class="table-responsive">
                            <table class="mikrotik-config-table">
                                <thead>
                                    <tr>
                                        <th>Nama</th>
                                        <th>IP Address</th>
                                        <th>Shared Secret</th>
                                        <th style="width: 120px;">Aksi</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php foreach ($mikrotik_configs as $config): ?>
                                        <tr>
                                            <td><?php echo htmlspecialchars($config['name']); ?></td>
                                            <td><?php echo htmlspecialchars($config['ip_address']); ?></td>
                                            <td><?php echo htmlspecialchars($config['shared_secret']); ?></td>
                                            <td class="actions">
                                                <a href="radius_settings.php?action=edit&id=<?php echo $config['id']; ?>" class="btn btn-edit btn-action"><i class="fas fa-edit"></i> Edit</a>
                                                <a href="javascript:void(0);" onclick="confirmDelete(<?php echo $config['id']; ?>, '<?php echo htmlspecialchars($config['name']); ?>')" class="btn btn-delete btn-action"><i class="fas fa-trash"></i> Hapus</a>
                                            </td>
                                        </tr>
                                    <?php endforeach; ?>
                                </tbody>
                            </table>
                        </div>
                    <?php else: ?>
                        <div class="alert alert-info">
                            <i class="fas fa-info-circle"></i> Belum ada konfigurasi MikroTik yang tersimpan. Silakan tambahkan yang baru.
                        </div>
                    <?php endif; ?>
                </div>
            </div>

            <div class="card">
                <div class="card-header">
                    <h3><?php echo $editing_mikrotik ? 'Edit Konfigurasi MikroTik' : 'Tambah Konfigurasi MikroTik Baru'; ?></h3>
                </div>
                <div class="card-body">
                    <form method="POST"><?php if (!isset($_SESSION['csrf_token'])) { $_SESSION['csrf_token'] = bin2hex(random_bytes(32)); } ?><input type='hidden' name='csrf_token' value='<?php echo $_SESSION['csrf_token']; ?>'>
                        <?php if ($editing_mikrotik): ?>
                            <input type="hidden" name="id" value="<?php echo htmlspecialchars($editing_mikrotik['id']); ?>">
                        <?php endif; ?>
                        <div class="form-group">
                            <label for="name">Nama MikroTik:</label>
                            <input type="text" id="name" name="name" class="form-control" value="<?php echo htmlspecialchars($editing_mikrotik['name'] ?? ''); ?>" placeholder="Contoh: MikroTik Kantor Pusat" required>
                            <small>Nama untuk mengidentifikasi perangkat MikroTik ini.</small>
                        </div>
                        <div class="form-group">
                            <label for="ip_address">IP Address MikroTik:</label>
                            <input type="text" id="ip_address" name="ip_address" class="form-control" value="<?php echo htmlspecialchars($editing_mikrotik['ip_address'] ?? ''); ?>" placeholder="Contoh: 192.168.88.1" required>
                            <small>Masukkan IP Address MikroTik yang akan terhubung ke RADIUS ini. Harus unik.</small>
                        </div>
                        <div class="form-group">
                            <label for="shared_secret">Shared Secret:</label>
                            <input type="text" id="shared_secret" name="shared_secret" class="form-control" value="<?php echo htmlspecialchars($editing_mikrotik['shared_secret'] ?? ''); ?>" placeholder="Masukkan shared secret" required>
                            <small>Rahasia bersama antara server RADIUS ini dan MikroTik Anda. Harus sama di kedua sisi.</small>
                        </div>
                        <button type="submit" class="btn btn-primary mt-3"><i class="fas fa-save"></i> Simpan Konfigurasi</button>
                        <?php if ($editing_mikrotik): ?>
                            <a href="radius_settings.php" class="btn btn-secondary mt-3 ms-2"><i class="fas fa-plus"></i> Tambah Baru / Batal Edit</a>
                        <?php endif; ?>
                    </form>
                </div>
            </div>

            <div class="info-box mt-4">
                <h3>Petunjuk Konfigurasi Mikrotik:</h3>
                <p>Untuk mengkoneksikan MikroTik Anda ke server RADIUS ini, ikuti langkah-langkah berikut di MikroTik Anda:</p>
                <ul>
                    <li>Pastikan Anda telah menginstal RouterOS dengan versi yang mendukung RADIUS.</li>
                    <li>Tambahkan server RADIUS baru di MikroTik:
                        <pre>/radius add address=<strong><?php echo $_SERVER['SERVER_ADDR']; ?></strong> secret=<strong><span id="dynamicSharedSecret">YOUR_SHARED_SECRET</span></strong> service=hotspot,ppp authentication-port=1812 accounting-port=1813 timeout=300ms protocol=udp</pre>
                        Ganti <code>YOUR_SHARED_SECRET</code> dengan <code>Shared Secret</code> yang sesuai untuk perangkat MikroTik yang Anda konfigurasi.
                    </li>
                    <li>Aktifkan penggunaan RADIUS untuk Hotspot atau PPP:
                        <ul>
                            <li>Untuk Hotspot:
                                <pre>/ip hotspot profile set [find name=default] use-radius=yes</pre>
                                (Ganti <code>default</code> dengan nama profil hotspot Anda)
                            </li>
                            <li>Untuk PPP:
                                <pre>/ppp secret set [find name=default] service=ppp use-radius=yes</pre>
                                (Ganti <code>default</code> dengan nama profil PPP Anda)
                            </li>
                        </ul>
                    </li>
                    <li>Pastikan firewall MikroTik Anda mengizinkan koneksi ke port RADIUS (UDP 1812 dan 1813).</li>
                    <li>Pastikan juga alamat IP server billing ini (<code><?php echo $_SERVER['SERVER_ADDR']; ?></code>) dapat dijangkau oleh MikroTik Anda.</li>
                </ul>
                <p><strong>Catatan:</strong> IP Server Billing ini adalah <code><?php echo $_SERVER['SERVER_ADDR']; ?></code>. Pastikan ini adalah IP yang benar dan dapat diakses dari MikroTik Anda.</p>
            </div>

        </div>
    </div>
    <?php include __DIR__ . '/../includes/footer.php'; ?>
    <script>
        // Fungsi untuk mengkonfirmasi penghapusan MikroTik
        function confirmDelete(id, name) {
            // Menggunakan fungsi showCustomConfirm dari header.php
            if (typeof showCustomConfirm === 'function') {
                showCustomConfirm('Konfirmasi Hapus', `Anda yakin ingin menghapus konfigurasi MikroTik "${name}"?`, function(result) {
                    if (result) {
                        window.location.href = 'radius_settings.php?action=delete&id=' + id;
                    }
                });
            } else {
                console.error("showCustomConfirm function is not defined.");
                // Fallback ke confirm() jika fungsi kustom tidak ditemukan
                if (confirm(`Anda yakin ingin menghapus konfigurasi MikroTik "${name}"?`)) {
                    window.location.href = 'radius_settings.php?action=delete&id=' + id;
                }
            }
        }

        // Script untuk menampilkan shared secret yang sedang diedit/baru di petunjuk
        document.addEventListener('DOMContentLoaded', function() {
            const sharedSecretInput = document.getElementById('shared_secret');
            const dynamicSharedSecretSpan = document.getElementById('dynamicSharedSecret');

            if (sharedSecretInput && dynamicSharedSecretSpan) {
                // Inisialisasi dengan nilai saat ini dari input
                if (sharedSecretInput.value) {
                    dynamicSharedSecretSpan.textContent = sharedSecretInput.value;
                } else {
                    dynamicSharedSecretSpan.textContent = 'YOUR_SHARED_SECRET';
                }

                // Update saat input shared secret berubah
                sharedSecretInput.addEventListener('input', function() {
                    dynamicSharedSecretSpan.textContent = this.value || 'YOUR_SHARED_SECRET';
                });
            }

            // Tangani pesan dari URL setelah redirect
            const urlParams = new URLSearchParams(window.location.search);
            const message = urlParams.get('message');
            const type = urlParams.get('type');

            if (message && type) {
                if (typeof showNotification === 'function') {
                    showNotification(decodeURIComponent(message), type);
                } else {
                    console.warn('showNotification function is not defined. Message:', message, 'Type:', type);
                    // alert(decodeURIComponent(message)); // Jangan pakai alert()
                }
                // Hapus parameter dari URL agar tidak tampil lagi saat refresh
                history.replaceState(null, '', window.location.pathname);
            }
        });
    </script>
</body>
</html>