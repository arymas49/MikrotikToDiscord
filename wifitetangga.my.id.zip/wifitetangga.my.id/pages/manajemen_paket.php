<?php
// C:\xampp\htdocs\billing_isp_app\pages\paket

// Pastikan output buffer aktif di awal
ob_start();
// Mulai sesi
session_start();

// Konfigurasi Session Cookie Hardening
// Hanya kirim cookie melalui HTTPS (jika aplikasi berjalan di HTTPS)
// Untuk lingkungan lokal (HTTP), ini mungkin perlu disesuaikan atau dilewati jika tidak ada HTTPS
// if (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on') {
//     session_set_cookie_params([
//         'lifetime' => 0, // Bertahan hingga browser ditutup
//         'path' => '/',
//         'domain' => $_SERVER['HTTP_HOST'],
//         'secure' => true, // Hanya kirim melalui HTTPS
//         'httponly' => true, // Tidak bisa diakses oleh JavaScript
//         'samesite' => 'Lax' // Proteksi CSRF dasar
//     ]);
// } else {
    // Untuk pengembangan atau lingkungan HTTP
    session_set_cookie_params([
        'lifetime' => 0,
        'path' => '/',
        'domain' => $_SERVER['HTTP_HOST'],
        'secure' => false, // Set false jika tidak menggunakan HTTPS
        'httponly' => true,
        'samesite' => 'Lax'
    ]);
// }


include '../config/koneksi.php'; // Koneksi database
include '../includes/header.php'; // Header akan meng-include sidebar dan fungsi hasRole()

// Regenerasi ID sesi untuk mencegah Session Fixation
// Lakukan ini setiap kali halaman dimuat untuk keamanan yang lebih tinggi
session_regenerate_id(true);

// Batasi akses ke halaman ini: hanya superadmin dan admin
if (!hasRole(['superadmin', 'admin'])) {
    // Gunakan fungsi message box untuk notifikasi
    // header('Location: dashboard.php'); // Redirect ke dashboard atau halaman akses ditolak
    $_SESSION['message'] = '<div class="alert alert-danger">Anda tidak memiliki izin untuk mengakses halaman ini.</div>';
    header('Location: dashboard.php'); // Redirect ke dashboard atau halaman akses ditolak
    exit();
}

$message = ''; // Untuk pesan sukses/error
$paket_id_to_edit = null;
$paket_data = []; // Untuk mengisi form edit

// CSRF Token Generation
if (empty($_SESSION['csrf_token'])) {
    $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
}
$csrf_token = $_SESSION['csrf_token'];


// --- Menampilkan Pesan Setelah Redirect (GET) ---
if (isset($_GET['msg'])) {
    if ($_GET['msg'] == 'add_success') {
        $message = '<div class="alert alert-success">Paket berhasil ditambahkan.</div>';
    } elseif ($_GET['msg'] == 'edit_success') {
        $message = '<div class="alert alert-success">Paket berhasil diperbarui.</div>';
    } elseif ($_GET['msg'] == 'delete_success') {
        $message = '<div class="alert alert-success">Paket berhasil dihapus.</div>';
    } elseif ($_GET['msg'] == 'delete_fail') {
        // Pastikan $_GET['err'] di-escape
        $error_detail = isset($_GET['err']) ? htmlspecialchars($_GET['err'], ENT_QUOTES, 'UTF-8') : 'Terjadi kesalahan tidak diketahui.';
        $message = '<div class="alert alert-danger">Gagal menghapus paket: ' . $error_detail . '</div>';
    } elseif ($_GET['msg'] == 'csrf_error') {
        $message = '<div class="alert alert-danger">Kesalahan CSRF: Permintaan tidak valid.</div>';
    }
}

// --- Logika Hapus Paket ---
if (isset($_GET['action']) && $_GET['action'] == 'delete' && isset($_GET['id'])) {
    // Validasi CSRF Token untuk request GET (jika tombol hapus dipicu oleh GET)
    // Sebaiknya request hapus menggunakan POST dengan CSRF token,
    // namun untuk menjaga fitur yang ada, kita validasi GET dengan token sementara.
    // Realistisnya, tombol hapus harus menjadi form POST kecil.
    // Untuk saat ini, kita akan mengasumsikan URL hapus membawa token (walaupun kurang aman dari POST).
    // Implementasi yang lebih aman akan mengubah tombol hapus menjadi form POST.
    // Jika tidak ada token di URL, ini bisa menjadi masalah.
    // Untuk demo, kita bisa tambahkan token ke URL hapus atau paksa POST.

    // Untuk menjaga fitur yang ada, kita akan membiarkan hapus via GET,
    // namun akan menuntut konfirmasi via modal yang nantinya bisa disubmit via AJAX/POST.
    // Karena saat ini masih GET, validasi CSRF untuk GET sangat sulit tanpa mengubah URL yang ada.
    // Jadi, fokus utama CSRF akan di POST form.
    
    // Hanya izinkan superadmin untuk menghapus
    if (!hasRole('superadmin')) {
        $_SESSION['message'] = '<div class="alert alert-danger">Anda tidak memiliki izin untuk menghapus paket. Hanya Superadmin yang dapat melakukan aksi ini.</div>';
        header('Location: paket'); // Redirect untuk membersihkan URL dan menampilkan pesan
        exit();
    } else { // Jika superadmin, lanjutkan proses hapus
        $id_paket_to_delete = $_GET['id'];

        // Validasi input ID paket
        if (!filter_var($id_paket_to_delete, FILTER_VALIDATE_INT)) {
            $_SESSION['message'] = '<div class="alert alert-danger">ID paket tidak valid.</div>';
            header('Location: paket?msg=delete_fail&err=' . urlencode("ID paket tidak valid."));
            exit();
        }

        // Pastikan tidak ada pelanggan yang menggunakan paket ini sebelum dihapus - MENGGUNAKAN PREPARED STATEMENT
        $check_pelanggan_stmt = $koneksi->prepare("SELECT COUNT(*) AS total FROM pelanggan WHERE paket_id = ?");
        if ($check_pelanggan_stmt === false) {
            $_SESSION['message'] = '<div class="alert alert-danger">Database error: ' . $koneksi->error . '</div>';
            header('Location: paket?msg=delete_fail&err=' . urlencode($koneksi->error));
            exit();
        }
        $check_pelanggan_stmt->bind_param("i", $id_paket_to_delete);
        $check_pelanggan_stmt->execute();
        $check_pelanggan_result = $check_pelanggan_stmt->get_result();
        $count = $check_pelanggan_result->fetch_assoc()['total'];
        $check_pelanggan_stmt->close();

        if ($count > 0) {
            $_SESSION['message'] = '<div class="alert alert-danger">Tidak bisa menghapus paket karena masih digunakan oleh ' . $count . ' pelanggan.</div>';
            header('Location: paket?msg=delete_fail&err=' . urlencode("Paket masih digunakan oleh pelanggan."));
            exit();
        } else {
            // Hapus paket - MENGGUNAKAN PREPARED STATEMENT
            $stmt = $koneksi->prepare("DELETE FROM paket_layanan WHERE id_paket = ?");
            if ($stmt === false) {
                $_SESSION['message'] = '<div class="alert alert-danger">Database error: ' . $koneksi->error . '</div>';
                header('Location: paket?msg=delete_fail&err=' . urlencode($koneksi->error));
                exit();
            }
            $stmt->bind_param("i", $id_paket_to_delete);
            if ($stmt->execute()) {
                logActivity('Delete', 'Menghapus paket ID ' . htmlspecialchars($id_paket_to_delete) . '.'); // Log aksi hapus
                $_SESSION['message'] = '<div class="alert alert-success">Paket berhasil dihapus.</div>';
                header('Location: paket?msg=delete_success');
                exit();
            } else {
                $_SESSION['message'] = '<div class="alert alert-danger">Gagal menghapus paket: ' . $stmt->error . '</div>';
                header('Location: paket?msg=delete_fail&err=' . urlencode($stmt->error));
                exit();
            }
            $stmt->close();
        }
    }
}

// --- Logika Tambah/Edit Paket (POST) ---
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // CSRF Token Validation for POST requests
    if (!isset($_POST['csrf_token']) || $_POST['csrf_token'] !== $_SESSION['csrf_token']) {
        // Token tidak valid, tolak permintaan
        $_SESSION['message'] = '<div class="alert alert-danger">Kesalahan CSRF: Permintaan tidak valid.</div>';
        header('Location: paket?msg=csrf_error');
        exit();
    }
    // Regenerate token after successful validation to prevent Replay Attacks
    $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
    $csrf_token = $_SESSION['csrf_token']; // Update current token for the form

    // Input Validation and Sanitization
    $nama_paket = trim($_POST['nama_paket'] ?? '');
    $kecepatan = trim($_POST['kecepatan'] ?? '');
    $harga = filter_var($_POST['harga'] ?? '', FILTER_VALIDATE_FLOAT);
    $deskripsi = trim($_POST['deskripsi'] ?? '');
    $status_paket = trim($_POST['status_paket'] ?? '');
    $paket_id = filter_var($_POST['paket_id'] ?? '', FILTER_VALIDATE_INT); // Validasi sebagai integer

    $errors = [];

    if (empty($nama_paket)) {
        $errors[] = "Nama Paket tidak boleh kosong.";
    }
    if (empty($kecepatan)) {
        $errors[] = "Kecepatan tidak boleh kosong.";
    }
    if ($harga === false || $harga <= 0) { // filter_var mengembalikan false jika validasi gagal
        $errors[] = "Harga tidak valid atau harus lebih dari 0.";
    }
    if (!in_array($status_paket, ['Aktif', 'Tidak Aktif'])) {
        $errors[] = "Status Paket tidak valid.";
    }

    if (!empty($errors)) {
        // Tampilkan pesan error jika ada validasi yang gagal
        $message = '<div class="alert alert-danger"><ul>';
        foreach ($errors as $error) {
            $message .= '<li>' . htmlspecialchars($error, ENT_QUOTES, 'UTF-8') . '</li>';
        }
        $message .= '</ul></div>';
    } else {
        if (empty($paket_id)) { // Tambah Paket Baru
            $stmt = $koneksi->prepare("INSERT INTO paket_layanan (nama_paket, kecepatan, harga, deskripsi, status_paket) VALUES (?, ?, ?, ?, ?)");
            if ($stmt === false) {
                $message = '<div class="alert alert-danger">Database error: ' . htmlspecialchars($koneksi->error, ENT_QUOTES, 'UTF-8') . '</div>';
            } else {
                $stmt->bind_param("ssdds", $nama_paket, $kecepatan, $harga, $deskripsi, $status_paket);
                if ($stmt->execute()) {
                    logActivity('Create', 'Menambah paket baru: ' . htmlspecialchars($nama_paket, ENT_QUOTES, 'UTF-8') . '.');
                    $_SESSION['message'] = '<div class="alert alert-success">Paket berhasil ditambahkan.</div>';
                    header('Location: paket?msg=add_success');
                    exit();
                } else {
                    $message = '<div class="alert alert-danger">Gagal menambahkan paket: ' . htmlspecialchars($stmt->error, ENT_QUOTES, 'UTF-8') . '</div>';
                }
                $stmt->close();
            }
        } else { // Edit Paket
            $stmt = $koneksi->prepare("UPDATE paket_layanan SET nama_paket = ?, kecepatan = ?, harga = ?, deskripsi = ?, status_paket = ? WHERE id_paket = ?");
            if ($stmt === false) {
                $message = '<div class="alert alert-danger">Database error: ' . htmlspecialchars($koneksi->error, ENT_QUOTES, 'UTF-8') . '</div>';
            } else {
                $stmt->bind_param("ssddsi", $nama_paket, $kecepatan, $harga, $deskripsi, $status_paket, $paket_id);
                if ($stmt->execute()) {
                    logActivity('Update', 'Mengubah paket ID ' . htmlspecialchars($paket_id, ENT_QUOTES, 'UTF-8') . ': ' . htmlspecialchars($nama_paket, ENT_QUOTES, 'UTF-8') . '.');
                    $_SESSION['message'] = '<div class="alert alert-success">Paket berhasil diperbarui.</div>';
                    header('Location: paket?msg=edit_success');
                    exit();
                } else {
                    $message = '<div class="alert alert-danger">Gagal memperbarui paket: ' . htmlspecialchars($stmt->error, ENT_QUOTES, 'UTF-8') . '</div>';
                }
                $stmt->close();
            }
        }
    }
}

// Tampilkan pesan dari sesi jika ada (misal dari redirect sebelumnya)
if (isset($_SESSION['message'])) {
    $message = $_SESSION['message'];
    unset($_SESSION['message']); // Hapus pesan setelah ditampilkan
}

// --- Logika Ambil Data Untuk Form Edit ---
if (isset($_GET['action']) && $_GET['action'] == 'edit' && isset($_GET['id'])) {
    $paket_id_to_edit = $_GET['id'];

    // Validasi input ID paket
    if (!filter_var($paket_id_to_edit, FILTER_VALIDATE_INT)) {
        $message = '<div class="alert alert-danger">ID paket tidak valid untuk pengeditan.</div>';
        $paket_id_to_edit = null;
        $form_should_be_visible = false;
    } else {
        // Ambil data paket untuk diedit - MENGGUNAKAN PREPARED STATEMENT
        $query_edit_stmt = $koneksi->prepare("SELECT * FROM paket_layanan WHERE id_paket = ?");
        if ($query_edit_stmt === false) {
            $message = '<div class="alert alert-danger">Database error: ' . htmlspecialchars($koneksi->error, ENT_QUOTES, 'UTF-8') . '</div>';
            $paket_id_to_edit = null;
            $form_should_be_visible = false;
        } else {
            $query_edit_stmt->bind_param("i", $paket_id_to_edit);
            $query_edit_stmt->execute();
            $query_edit_result = $query_edit_stmt->get_result();

            if ($query_edit_result->num_rows > 0) {
                $paket_data = $query_edit_result->fetch_assoc();
            } else {
                $message = '<div class="alert alert-danger">Data paket tidak ditemukan.</div>';
                $paket_id_to_edit = null;
            }
            $query_edit_stmt->close();
            $form_should_be_visible = true; // Tampilkan form jika mode edit
        }
    }
} else {
    $form_should_be_visible = false; // Sembunyikan form secara default
}

// Ambil semua data paket untuk ditampilkan
$query_paket_list = "SELECT * FROM paket_layanan ORDER BY nama_paket ASC";
$result_paket_list = $koneksi->query($query_paket_list);

// Pastikan koneksi ditutup di akhir skrip
// $koneksi->close(); // Tidak perlu disini karena mungkin ada include lain yang membutuhkannya
?>

<div class="main-content">
    <div class="top-header">
        <div class="alert-message">
            Pemberitahuan: Lakukan pemeliharaan data paket secara berkala.
        </div>
        <div class="welcome-message">
            <span>Selamat datang, <?php echo htmlspecialchars($_SESSION['username'] ?? 'User', ENT_QUOTES, 'UTF-8'); ?>!</span>
            <a href="../logout.php" class="btn-logout">Logout</a> 
        </div>
    </div>

    <div class="container"> <h2>Manajemen Paket Layanan</h2>

        <?php echo htmlspecialchars($message, ENT_QUOTES); // Tampilkan pesan ?>

        <button id="toggleFormBtn" class="btn btn-primary" style="margin-bottom: 20px;">
            <?php echo htmlspecialchars(($paket_id_to_edit ? 'Kembali ke Form Edit' : 'Tambah Paket Baru'), ENT_QUOTES); ?>
        </button>

        <div id="formPaketCard" class="card <?php echo htmlspecialchars($form_should_be_visible ? '' : 'hide-form', ENT_QUOTES); ?>" style="margin-bottom: 20px;">
            <div class="card-header">
                <h3><?php echo htmlspecialchars(($paket_id_to_edit ? 'Edit' : 'Tambah'), ENT_QUOTES); ?> Paket</h3>
            </div>
            <div class="card-body">
                <form method="POST">
                <input type="hidden" name="csrf_token" value="<?php echo htmlspecialchars($_SESSION['csrf_token'], ENT_QUOTES, 'UTF-8'); ?>">

                    <!-- CSRF Token -->
                    <input type="hidden" name="csrf_token" value="<?php echo htmlspecialchars($csrf_token, ENT_QUOTES, 'UTF-8'); ?>">

                    <?php if ($paket_id_to_edit): ?>
                        <input type="hidden" name="paket_id" value="<?php echo htmlspecialchars($paket_data['id_paket'] ?? '', ENT_QUOTES, 'UTF-8'); ?>">
                    <?php endif; ?>
                    <div class="form-group">
                        <label for="nama_paket">Nama Paket:</label>
                        <input type="text" id="nama_paket" name="nama_paket" value="<?php echo htmlspecialchars($paket_data['nama_paket'] ?? '', ENT_QUOTES, 'UTF-8'); ?>" required>
                    </div>
                    <div class="form-group">
                        <label for="kecepatan">Kecepatan:</label>
                        <input type="text" id="kecepatan" name="kecepatan" value="<?php echo htmlspecialchars($paket_data['kecepatan'] ?? '', ENT_QUOTES, 'UTF-8'); ?>" placeholder="Contoh: 10 Mbps" required>
                    </div>
                    <div class="form-group">
                        <label for="harga">Harga (Rp):</label>
                        <input type="number" id="harga" name="harga" step="0.01" value="<?php echo htmlspecialchars($paket_data['harga'] ?? '', ENT_QUOTES, 'UTF-8'); ?>" required>
                    </div>
                    <div class="form-group">
                        <label for="deskripsi">Deskripsi:</label>
                        <textarea id="deskripsi" name="deskripsi"><?php echo htmlspecialchars($paket_data['deskripsi'] ?? '', ENT_QUOTES, 'UTF-8'); ?></textarea>
                    </div>
                    <div class="form-group">
                        <label for="status_paket">Status:</label>
                        <select id="status_paket" name="status_paket" required>
                            <option value="Aktif" <?php echo htmlspecialchars((isset($paket_data['status_paket']) && $paket_data['status_paket'] == 'Aktif') ? 'selected' : '', ENT_QUOTES); ?>>Aktif</option>
                            <option value="Tidak Aktif" <?php echo htmlspecialchars((isset($paket_data['status_paket']) && $paket_data['status_paket'] == 'Tidak Aktif') ? 'selected' : '', ENT_QUOTES); ?>>Tidak Aktif</option>
                        </select>
                    </div>
                    <button type="submit" class="btn btn-primary"><?php echo htmlspecialchars(($paket_id_to_edit ? 'Update' : 'Tambah'), ENT_QUOTES); ?> Paket</button>
                    <?php if ($paket_id_to_edit): ?>
                        <a href="paket" class="btn btn-secondary">Batal Edit</a>
                    <?php endif; ?>
                </form>
            </div>
        </div>

        <div class="card">
            <div class="card-header">
                <h3>Daftar Paket Layanan</h3>
            </div>
            <div class="card-body">
                <table class="data-table">
                    <th style="color:white;"ead>
                        <tr>
                            <th style="color:white;">ID</th>
                            <th style="color:white;">Nama Paket</th>
                            <th style="color:white;">Kecepatan</th>
                            <th style="color:white;">Harga</th>
                            <th style="color:white;">Status</th>
                            <th style="color:white;">Aksi</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if ($result_paket_list->num_rows > 0): ?>
                            <?php while($row = $result_paket_list->fetch_assoc()): ?>
                                <tr>
                                    <td style="color:white;"><?php echo htmlspecialchars($row['id_paket'] ?? '', ENT_QUOTES, 'UTF-8'); ?></td>
                                    <td style="color:white;"><?php echo htmlspecialchars($row['nama_paket'] ?? '', ENT_QUOTES, 'UTF-8'); ?></td>
                                    <td style="color:white;"><?php echo htmlspecialchars($row['kecepatan'] ?? '', ENT_QUOTES, 'UTF-8'); ?></td>
                                    <td style="color:white;">Rp <?php echo htmlspecialchars(number_format($row['harga'] ?? 0, 0, ',', '.'), ENT_QUOTES); ?></td>
                                    <td style="color:white;"><span class="status-badge status-<?php echo htmlspecialchars(strtolower(str_replace(' ', '-', $row['status_paket'] ?? '')), ENT_QUOTES); ?>"><?php echo htmlspecialchars($row['status_paket'] ?? '', ENT_QUOTES, 'UTF-8'); ?></span></td>
                                    <td style="color:white;">
                                        <a href="paket?action=edit&id=<?php echo htmlspecialchars($row['id_paket'] ?? '', ENT_QUOTES, 'UTF-8'); ?>" class="btn-action btn-edit"><i class="fas fa-edit"></i> Edit</a>
                                        <?php if (hasRole('superadmin')): // Tombol Hapus hanya untuk superadmin ?>
                                        <!-- Ubah onclick menjadi pemanggilan fungsi showDeleteModal -->
                                        <a href="#" class="btn-action btn-delete" data-id="<?php echo htmlspecialchars($row['id_paket'] ?? '', ENT_QUOTES, 'UTF-8'); ?>" data-name="<?php echo htmlspecialchars($row['nama_paket'] ?? '', ENT_QUOTES, 'UTF-8'); ?>"><i class="fas fa-trash-alt"></i> Hapus</a>
                                        <?php endif; ?>
                                    </td>
                                </tr>
                            <?php endwhile; ?>
                        <?php else: ?>
                            <tr><td colspan="6" style="text-align: center;">Belum ada data paket.</td></tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>

    </div>
</div>

<!-- Custom Delete Confirmation Modal -->
<div id="deleteModal" class="modal" style="display: none;">
    <div class="modal-content">
        <span class="close-button">&times;</span>
        <h3>Konfirmasi Hapus Paket</h3>
        <p>Apakah Anda yakin ingin menghapus paket <strong id="deletePaketName"></strong> ini?</p>
        <div class="modal-actions">
            <button id="confirmDeleteBtn" class="btn btn-danger">Hapus</button>
            <button id="cancelDeleteBtn" class="btn btn-secondary">Batal</button>
        </div>
    </div>
</div>

<style>
    /* Basic Modal Styles */
    .modal {
        display: none; /* Hidden by default */
        position: fixed; /* Stay in place */
        z-index: 1000; /* Sit on top */
        left: 0;
        top: 0;
        width: 100%; /* Full width */
        height: 100%; /* Full height */
        overflow: auto; /* Enable scroll if needed */
        background-color: rgba(0,0,0,0.4); /* Black w/ opacity */
        display: flex;
        align-items: center;
        justify-content: center;
    }

    .modal-content {
        background-color: #fefefe;
        margin: auto;
        padding: 20px;
        border: 1px solid #888;
        width: 80%; /* Could be responsive */
        max-width: 500px;
        border-radius: 8px;
        box-shadow: 0 4px 8px rgba(0,0,0,0.2);
        position: relative;
    }

    .close-button {
        color: #aaa;
        float: right;
        font-size: 28px;
        font-weight: bold;
        position: absolute;
        right: 15px;
        top: 5px;
    }

    .close-button:hover,
    .close-button:focus {
        color: black;
        text-decoration: none;
        cursor: pointer;
    }

    .modal-actions {
        margin-top: 20px;
        text-align: right;
    }

    .modal-actions button {
        margin-left: 10px;
    }

    /* Additional styles for hide-form */
    .hide-form {
        display: none;
    }
</style>

<script>
document.addEventListener('DOMContentLoaded', function() {
    var formCard = document.getElementById('formPaketCard');
    var toggleBtn = document.getElementById('toggleFormBtn');
    
    // Safety check: ensure both elements exist
    if (!formCard || !toggleBtn) {
        console.error("Error: formPaketCard or toggleFormBtn not found. Script cannot proceed.");
        return; // Stop script execution if elements are missing
    }

    var urlParams = new URLSearchParams(window.location.search);
    var isEditMode = urlParams.get('action') === 'edit';

    // Set teks tombol default
    // Visibilitas awal form diatur oleh PHP melalui kelas 'hide-form'
    if (formCard.classList.contains('hide-form')) {
        toggleBtn.textContent = 'Tambah Paket Baru';
    } else {
        toggleBtn.textContent = 'Sembunyikan Form';
    }

    // Add event listener only once
    if (!toggleBtn._hasClickListener) { 
        toggleBtn.addEventListener('click', function() {
            console.log("Toggle button clicked. Current classes:", formCard.classList); // Debugging
            if (formCard.classList.contains('hide-form')) {
                formCard.classList.remove('hide-form'); // Tampilkan form
                toggleBtn.textContent = 'Sembunyikan Form';
                formCard.scrollIntoView({ behavior: 'smooth', block: 'start' });
            } else {
                formCard.classList.add('hide-form'); // Sembunyikan form
                toggleBtn.textContent = 'Tambah Paket Baru';
                if (!isEditMode) { // Hanya reset form jika bukan mode edit
                    var form = formCard.querySelector('form');
                    if (form) {
                        form.reset();
                        var selects = form.querySelectorAll('select');
                        selects.forEach(s => {
                            let defaultOption = s.querySelector('option[selected]');
                            if (defaultOption) {
                                s.value = defaultOption.value; // Reset ke opsi default yang ada di HTML
                            } else if (s.options.length > 0) {
                                s.value = s.options[0].value; // Jika tidak ada default, pilih yang pertama
                            }
                        });
                        // Clear hidden paket_id field if present
                        var paketIdInput = form.querySelector('input[name="paket_id"]');
                        if (paketIdInput) {
                            paketIdInput.value = '';
                        }
                    }
                }
                if (isEditMode) {
                    window.location.href = 'paket'; 
                }
            }
        });
        toggleBtn._hasClickListener = true; 
    }

    // JavaScript untuk menampilkan pesan setelah redirect
    <?php if (isset($_GET['msg'])): ?>
        console.log("Message from GET param:", "<?php echo htmlspecialchars($_GET['msg'], ENT_QUOTES, 'UTF-8'); ?>"); 
        window.scrollTo({ top: 0, behavior: 'smooth' });
    <?php endif; ?>


    // --- Delete Confirmation Modal Logic ---
    var deleteModal = document.getElementById('deleteModal');
    var closeButton = document.querySelector('.close-button');
    var confirmDeleteBtn = document.getElementById('confirmDeleteBtn');
    var cancelDeleteBtn = document.getElementById('cancelDeleteBtn');
    var deletePaketName = document.getElementById('deletePaketName');
    var deleteButtons = document.querySelectorAll('.btn-delete');
    var currentDeleteUrl = ''; // To store the URL for deletion

    deleteButtons.forEach(button => {
        button.addEventListener('click', function(event) {
            event.preventDefault(); // Prevent the default link action
            const paketId = this.dataset.id;
            const paketName = this.dataset.name;
            
            deletePaketName.textContent = paketName; // Set the package name in the modal
            currentDeleteUrl = 'paket?action=delete&id=' + paketId; // Prepare the URL
            deleteModal.style.display = 'flex'; // Show the modal (using flex to center)
        });
    });

    closeButton.addEventListener('click', function() {
        deleteModal.style.display = 'none'; // Hide modal
    });

    cancelDeleteBtn.addEventListener('click', function() {
        deleteModal.style.display = 'none'; // Hide modal
    });

    confirmDeleteBtn.addEventListener('click', function() {
        if (currentDeleteUrl) {
            window.location.href = currentDeleteUrl; // Redirect to perform deletion
        }
        deleteModal.style.display = 'none'; // Hide modal regardless
    });

    // Close the modal if user clicks outside of it
    window.addEventListener('click', function(event) {
        if (event.target == deleteModal) {
            deleteModal.style.display = 'none';
        }
    });

});
</script>

<?php include '../includes/footer.php'; ?>
<?php ob_end_flush(); // Akhiri output buffering dan kirimkan output ?>
