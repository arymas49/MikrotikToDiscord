<?php
// C:\xampp\htdocs\billing_isp_app\pages\print_dashboard_sales.php
ob_start();
ini_set('session.use_strict_mode', 1);
ini_set('session.cookie_httponly', 1);
ini_set('session.cookie_samesite', 'Lax');
if (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on') {
    ini_set('session.cookie_secure', 1);
}
session_start();
include '../config/koneksi.php';

// Batasi akses ke halaman ini: hanya superadmin dan admin
if (!isset($_SESSION['user_id']) || (!isset($_SESSION['role']) || ($_SESSION['role'] !== 'superadmin' && $_SESSION['role'] !== 'admin'))) {
    echo "Akses ditolak.";
    exit();
}

// --- Tangkap parameter filter bulan dan tahun ---
$filter_month = $_GET['filter_month'] ?? '';
$filter_year = $_GET['filter_year'] ?? '';

$filtered_month_year_for_registration = '';
$where_registration_clause = "1";
$bind_params_registration = [];
$bind_types_registration = "";

if (!empty($filter_month) && !empty($filter_year)) {
    $filtered_month_year_for_registration = $filter_year . '-' . sprintf('%02d', $filter_month);
    $where_registration_clause = "SUBSTRING(p.tanggal_registrasi, 1, 7) = ?";
    $bind_params_registration[] = $filtered_month_year_for_registration;
    $bind_types_registration .= "s";
    $display_filtered_date = date('F Y', strtotime($filtered_month_year_for_registration . '-01'));
} elseif (!empty($filter_year)) {
    $where_registration_clause = "SUBSTRING(p.tanggal_registrasi, 1, 4) = ?";
    $bind_params_registration[] = $filter_year;
    $bind_types_registration .= "s";
    $display_filtered_date = "Tahun " . $filter_year;
} elseif (!empty($filter_month)) {
    $where_registration_clause = "SUBSTRING(p.tanggal_registrasi, 6, 2) = ?";
    $bind_params_registration[] = sprintf('%02d', $filter_month);
    $bind_types_registration .= "s";
    $display_filtered_date = "Bulan " . date('F', strtotime("2000-" . sprintf('%02d', $filter_month) . "-01")) . " (Semua Tahun)";
} else {
    $display_filtered_date = "Semua Periode";
}

$filtered_month_year_for_tagihan = '';
$where_tagihan_clause = "1";
$bind_params_tagihan = [];
$bind_types_tagihan = "";

if (!empty($filter_month) && !empty($filter_year)) {
    $filtered_month_year_for_tagihan = $filter_year . '-' . sprintf('%02d', $filter_month);
    $where_tagihan_clause = "t_filtered.bulan_tagihan = ?";
    $bind_params_tagihan[] = $filtered_month_year_for_tagihan;
    $bind_types_tagihan .= "s";
}


// --- Sorting Parameters ---
$sort_column = $_GET['sort_column'] ?? 'total_pelanggan_recorded';
$sort_order = $_GET['sort_order'] ?? 'DESC';

$allowed_sort_columns = [
    's.id_sales', 's.nama_sales', 's.email', 's.telepon',
    'total_pelanggan_recorded', 'total_pelanggan_aktif_overall',
    'total_pelanggan_tidak_aktif_overall', 'total_pelanggan_blokir_overall',
    'pelanggan_lunas_bulan_terpilih', 'pelanggan_belum_lunas_bulan_terpilih',
    's.status_aktif'
];
if (!in_array($sort_column, $allowed_sort_columns)) {
    $sort_column = 'total_pelanggan_recorded';
}
if (!in_array(strtoupper($sort_order), ['ASC', 'DESC'])) {
    $sort_order = 'DESC';
}


// --- Ambil data sales performance ke dalam array ---
$query_sales_performance = "
    SELECT
        s.id_sales,
        s.nama_sales,
        s.email,
        s.telepon,
        s.tanggal_bergabung,
        s.status_aktif,
        COUNT(p.id_pelanggan) AS total_pelanggan_recorded,
        SUM(CASE WHEN p.status_aktif = 'Aktif' THEN 1 ELSE 0 END) AS total_pelanggan_aktif_overall,
        SUM(CASE WHEN p.status_aktif = 'Tidak Aktif' THEN 1 ELSE 0 END) AS total_pelanggan_tidak_aktif_overall,
        SUM(CASE WHEN p.status_aktif = 'Blokir' THEN 1 ELSE 0 END) AS total_pelanggan_blokir_overall,
        
        SUM(CASE
            WHEN " . ($filtered_month_year_for_tagihan ? $where_tagihan_clause : '0') . " AND t_filtered.status_tagihan = 'Lunas' THEN 1
            ELSE 0
        END) AS pelanggan_lunas_bulan_terpilih,
        SUM(CASE
            WHEN " . ($filtered_month_year_for_tagihan ? $where_tagihan_clause : '0') . " AND t_filtered.status_tagihan = 'Belum Lunas' THEN 1
            ELSE 0
        END) AS pelanggan_belum_lunas_bulan_terpilih
    FROM
        sales s
    LEFT JOIN
        pelanggan p ON s.id_sales = p.sales_id AND " . $where_registration_clause . "
    LEFT JOIN
        tagihan t_filtered ON p.id_pelanggan = t_filtered.pelanggan_id
            AND " . ($filtered_month_year_for_tagihan ? $where_tagihan_clause : '1') . "
    GROUP BY
        s.id_sales, s.nama_sales, s.email, s.telepon, s.tanggal_bergabung, s.status_aktif
    ORDER BY
        " . $sort_column . " " . $sort_order . ", s.nama_sales ASC
";

$stmt_sales_performance = $koneksi->prepare($query_sales_performance);
if ($stmt_sales_performance === false) {
    die('Prepare failed for sales performance: ' . htmlspecialchars($koneksi->error));
}

$final_bind_params_sales = array_merge($bind_params_registration);
if ($filtered_month_year_for_tagihan) {
    $final_bind_params_sales = array_merge($final_bind_params_sales, $bind_params_tagihan, $bind_params_tagihan, $bind_params_tagihan);
}
$final_bind_types_sales = $bind_types_registration;
if ($filtered_month_year_for_tagihan) {
    $final_bind_types_sales .= str_repeat($bind_types_tagihan, 3);
}

if (!empty($final_bind_params_sales)) {
    $refs_sales = [];
    foreach ($final_bind_params_sales as $key => $value) {
        $refs_sales[$key] = &$final_bind_params_sales[$key];
    }
    call_user_func_array([$stmt_sales_performance, 'bind_param'], array_merge([$final_bind_types_sales], $refs_sales));
}

$stmt_sales_performance->execute();
$sales_performance_data = $stmt_sales_performance->get_result()->fetch_all(MYSQLI_ASSOC);
$stmt_sales_performance->close();


// --- Ambil data detail pelanggan per sales untuk sub-tabel ---
$sales_customer_details = [];
foreach ($sales_performance_data as $row) {
    $sales_id = $row['id_sales'];
    $sales_customer_details[$sales_id] = [];

    // Query untuk semua pelanggan yang dicatat oleh sales ini, di periode registrasi yang difilter
    $query_customers_for_sales = "
        SELECT p.id_pelanggan, p.nama_pelanggan, p.alamat, p.telepon
        FROM pelanggan p
        WHERE p.sales_id = ? AND " . $where_registration_clause . "
        ORDER BY p.nama_pelanggan ASC
    ";
    $stmt_customers = $koneksi->prepare($query_customers_for_sales);
    if ($stmt_customers === false) {
        error_log("Prepare failed for customers for sales (ID: {$sales_id}): " . $koneksi->error);
        continue;
    }

    $bind_params_customers = [$sales_id];
    $bind_types_customers = "i";
    if ($where_registration_clause !== "1") {
        $bind_params_customers[] = $bind_params_registration[0];
        $bind_types_customers .= "s";
    }

    $refs_customers = [];
    foreach ($bind_params_customers as $key => $value) {
        $refs_customers[$key] = &$bind_params_customers[$key];
    }
    call_user_func_array([$stmt_customers, 'bind_param'], array_merge([$bind_types_customers], $refs_customers));
    
    $stmt_customers->execute();
    $result_customers = $stmt_customers->get_result();
    while ($customer_row = $result_customers->fetch_assoc()) {
        $sales_customer_details[$sales_id][] = $customer_row;
    }
    $stmt_customers->close();
}

?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Laporan Performa Sales - <?php echo htmlspecialchars($display_filtered_date, ENT_QUOTES, "UTF-8"); ?></title>
    <link rel="icon" href="../assets/img/logo_isp.png" type="image/png">
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 20px;
            color: #333;
        }
        .container {
            width: 100%;
            max-width: 1200px;
            margin: 0 auto;
        }
        h1, h2, h3 {
            text-align: center;
            margin-bottom: 10px;
        }
        .report-info {
            text-align: center;
            margin-bottom: 20px;
            font-size: 0.9em;
        }
        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
        }
        th, td {
            border: 1px solid #ddd;
            padding: 8px;
            text-align: left;
            font-size: 0.85em;
            vertical-align: top;
        }
        th {
            background-color: #f2f2f2;
            font-weight: bold;
        }
        .status-badge {
            padding: 3px 6px;
            border-radius: 3px;
            font-size: 0.75em;
            color: white;
            white-space: nowrap;
        }
        .status-aktif { background-color: #28a745; }
        .status-tidak-aktif { background-color: #ffc107; }
        .status-blokir { background-color: #dc3545; }
        .status-lunas { background-color: #28a745; }
        .status-belum-lunas { background-color: #ffc107; }
        .status-default, .status-n-a { background-color: #6c757d; }

        .sub-data-table {
            width: 98%; /* Slightly smaller than parent table */
            margin: 10px auto;
            border-collapse: collapse;
        }
        .sub-data-table th, .sub-data-table td {
            border: 1px solid #eee; /* Lighter border for sub-table */
            padding: 6px;
            font-size: 0.8em; /* Smaller font for sub-table */
        }
        .sub-data-table th {
            background-color: #e9e9e9;
        }
        .sub-data-table tbody tr:nth-child(even) {
            background-color: #fcfcfc;
        }
        .sub-data-table tbody tr:hover {
            background-color: #f5f5f5;
        }
        td a {
            text-decoration: none;
            color: #007bff;
        }
        td a:hover {
            text-decoration: underline;
        }
        
        @media print {
            body {
                margin: 0;
            }
            .container {
                width: auto;
                max-width: none;
            }
            th, td {
                font-size: 0.7em;
                padding: 4px;
            }
            /* Menghilangkan elemen non-esensial saat mencetak */
            .no-print {
                display: none;
            }
        }
    </style>
</head>
<body onload="window.print()">
    <div class="container">
        <h1>Laporan Performa Sales</h1>
        <h2>Billing ISP System</h2>
        <div class="report-info">
            Periode Laporan Registrasi & Tagihan: **<?php echo htmlspecialchars($display_filtered_date, ENT_QUOTES, "UTF-8"); ?>** <br>
            Dicetak pada: <?php echo date('d M Y H:i:s'); ?> oleh <?php echo htmlspecialchars($_SESSION['username'] ?? 'User'); ?>
        </div>

        <table>
            <thead>
                <tr>
                    <th>ID Sales</th>
                    <th>Nama Sales</th>
                    <th>Email</th>
                    <th>Telepon</th>
                    <th>Total Pelanggan Dicatat (Periode Ini)</th>
                    <th>Pelanggan Aktif (Keseluruhan)</th>
                    <th>Pelanggan Tidak Aktif (Keseluruhan)</th>
                    <th>Pelanggan Diblokir (Keseluruhan)</th>
                    <th>Tagihan Lunas (Bulan Terpilih)</th>
                    <th>Tagihan Belum Lunas (Bulan Terpilih)</th>
                    <th>Status Sales</th>
                </tr>
            </thead>
            <tbody>
                <?php if (count($sales_performance_data) > 0): ?>
                    <?php foreach ($sales_performance_data as $row): ?>
                        <tr>
                            <td><?php echo htmlspecialchars($row['id_sales']); ?></td>
                            <td><?php echo htmlspecialchars($row['nama_sales']); ?></td>
                            <td><?php echo htmlspecialchars($row['email']); ?></td>
                            <td><?php echo htmlspecialchars($row['telepon']); ?></td>
                            <td><?php echo htmlspecialchars($row['total_pelanggan_recorded']); ?></td>
                            <td><?php echo htmlspecialchars($row['total_pelanggan_aktif_overall']); ?></td>
                            <td><?php echo htmlspecialchars($row['total_pelanggan_tidak_aktif_overall']); ?></td>
                            <td><?php echo htmlspecialchars($row['total_pelanggan_blokir_overall']); ?></td>
                            <td><?php echo htmlspecialchars($row['pelanggan_lunas_bulan_terpilih']); ?></td>
                            <td><?php echo htmlspecialchars($row['pelanggan_belum_lunas_bulan_terpilih']); ?></td>
                            <td><span class="status-badge status-<?php echo strtolower(str_replace(' ', '-', $row['status_aktif'])); ?>"><?php echo htmlspecialchars($row['status_aktif']); ?></span></td>
                        </tr>
                        <tr>
                            <td colspan="11"> <h4>Detail Pelanggan Dicatat (Periode Ini):</h4>
                                <?php 
                                $customers = $sales_customer_details[$row['id_sales']] ?? [];
                                if (!empty($customers)): 
                                ?>
                                    <table class="sub-data-table">
                                        <thead>
                                            <tr>
                                                <th>ID Pelanggan</th>
                                                <th>Nama Pelanggan</th>
                                                <th>Alamat</th>
                                                <th>Telepon</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php foreach ($customers as $customer): ?>
                                                <tr>
                                                    <td><?php echo htmlspecialchars($customer['id_pelanggan']); ?></td>
                                                    <td><?php echo htmlspecialchars($customer['nama_pelanggan']); ?></td>
                                                    <td><?php echo htmlspecialchars($customer['alamat']); ?></td>
                                                    <td><?php echo htmlspecialchars($customer['telepon']); ?></td>
                                                </tr>
                                            <?php endforeach; ?>
                                        </tbody>
                                    </table>
                                <?php else: ?>
                                    <p>Tidak ada pelanggan dicatat untuk sales ini pada periode yang dipilih.</p>
                                <?php endif; ?>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                <?php else: ?>
                    <tr><td colspan="11" style="text-align: center;">Tidak ada data sales ditemukan untuk periode ini.</td></tr>
                <?php endif; ?>
            </tbody>
        </table>

    </div>

    <script>
        // No window.onload = window.print(); here, as it's triggered from dashboard_sales.php
    </script>
</body>
</html>
<?php
$koneksi->close();
ob_end_flush();
?>