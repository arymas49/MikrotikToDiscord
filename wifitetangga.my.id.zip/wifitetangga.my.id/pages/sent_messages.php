<?php
// C:\xampp\htdocs\billing_isp_app\pages\sent_messages.php
ini_set('display_errors', 1); // Aktifkan pelaporan error untuk debugging
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

ob_start();
ini_set('session.use_strict_mode', 1);
ini_set('session.cookie_httponly', 1);
ini_set('session.cookie_samesite', 'Lax');
if (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on') {
    ini_set('session.cookie_secure', 1);
}
session_start();
include '../config/koneksi.php';
include '../includes/header.php'; // Meng-include sidebar dan fungsi hasRole()

// Batasi akses ke halaman ini: hanya superadmin
if (!hasRole('superadmin')) {
    header('Location: dashboard.php');
    exit();
}

$message = '';
$filter_bulan = $_GET['filter_bulan'] ?? date('m');
$filter_tahun = $_GET['filter_tahun'] ?? date('Y');

// --- Logika Hapus Semua Pesan Terkirim ---
if (isset($_GET['action']) && $_GET['action'] == 'clear_sent_logs') { // Pastikan action ini sama dengan yang dikirim JS
    if (!hasRole('superadmin')) { // Verifikasi ulang izin
        header('Location: sent_messages.php?msg=permission_denied');
        exit();
    }
    $stmt_delete = $koneksi->prepare("DELETE FROM whatsapp_message_logs WHERE status = 'sent'");
    if ($stmt_delete === false) {
        // Tambahkan logging error prepare statement
        error_log("Failed to prepare DELETE query for sent messages: " . $koneksi->error);
        header('Location: sent_messages.php?msg=clear_fail&err=' . urlencode("Failed to prepare query: " . $koneksi->error));
        exit();
    }

    if ($stmt_delete->execute()) {
        logActivity('Delete', 'Membersihkan semua log pesan WhatsApp yang berhasil terkirim.');
        header('Location: sent_messages.php?msg=clear_success');
        exit();
    } else {
        // Tambahkan logging error execute statement
        error_log("Failed to execute DELETE query for sent messages: " . $stmt_delete->error);
        header('Location: sent_messages.php?msg=clear_fail&err=' . urlencode("Execute failed: " . $stmt_delete->error));
        exit();
    }
    $stmt_delete->close();
}

// --- Menampilkan Pesan Setelah Redirect (GET) ---
if (isset($_GET['msg'])) {
    if ($_GET['msg'] == 'clear_success') {
        $message = '<div class="alert alert-success">Semua log pesan terkirim berhasil dibersihkan.</div>';
    } elseif ($_GET['msg'] == 'clear_fail') {
        $error_detail = $_GET['err'] ?? 'Terjadi kesalahan tidak diketahui.';
        $message = '<div class="alert alert-danger">Gagal membersihkan log pesan terkirim: ' . htmlspecialchars($error_detail) . '</div>';
    } elseif ($_GET['msg'] == 'permission_denied') {
        $message = '<div class="alert alert-danger">Anda tidak memiliki izin untuk melakukan aksi ini.</div>';
    }
}


// Query untuk mengambil pesan terkirim
$query = "SELECT * FROM whatsapp_message_logs WHERE status = 'sent'";
$params = [];
$param_types = "";

if (!empty($filter_bulan) && !empty($filter_tahun)) {
    $query .= " AND MONTH(timestamp) = ? AND YEAR(timestamp) = ?";
    $params[] = (int)$filter_bulan; // Pastikan integer
    $params[] = (int)$filter_tahun; // Pastikan integer
    $param_types .= "ii";
}

$query .= " ORDER BY timestamp DESC";

if ($stmt = $koneksi->prepare($query)) {
    if (!empty($params)) {
        $bind_args = array($param_types);
        foreach ($params as $key => $value) {
            $bind_args[] = &$params[$key]; // Pass by reference
        }
        call_user_func_array(array($stmt, 'bind_param'), $bind_args);
    }
    $stmt->execute();
    $result = $stmt->get_result();
    while ($row = $result->fetch_assoc()) {
        $messages[] = $row;
    }
    $stmt->close();
} else {
    $messages[] = ['id' => 'Error', 'phone_number' => '', 'message_content' => 'Gagal menyiapkan query: ' . $koneksi->error, 'status' => '', 'response_data' => '', 'timestamp' => ''];
}

?>

<div class="main-content">
    <div class="top-header">
        <div class="alert-message">
            Log pesan WhatsApp yang berhasil terkirim.
        </div>
        <div class="welcome-message">
            <span>Selamat datang, <?php echo htmlspecialchars($_SESSION['username'] ?? 'User'); ?>!</span>
            <a href="../logout.php" class="btn-logout">Logout</a>
        </div>
    </div>

    <div class="container">
        <h2>Data Pesan Terkirim</h2>

        <?php echo htmlspecialchars($message, ENT_QUOTES, "UTF-8"); ?>

        <div class="card" style="margin-bottom: 20px;">
            <div class="card-header">
                <h3>Filter Pesan Terkirim</h3>
                <div class="filter-form" style="display: flex; justify-content: space-between; align-items: center; flex-wrap: wrap; gap: 10px;">
                    <form method="GET" action="sent_messages.php" style="display: flex; align-items: center; gap: 10px; flex-wrap: wrap;">
                        <label for="filter_bulan">Bulan:</label>
                        <select name="filter_bulan" id="filter_bulan">
                            <option value="">Semua Bulan</option>
                            <?php
                            $bulan_array = [1=>'01','02','03','04','05','06','07','08','09','10','11','12']; // Ubah ke format '01'
                            $nama_bulan_array = [1=>'Januari','Februari','Maret','April','Mei','Juni','Juli','Agustus','September','Oktober','November','Desember'];
                            foreach ($bulan_array as $num_key => $num_val) {
                                $selected = ($filter_bulan == $num_val) ? 'selected' : '';
                                echo "<option value='{$num_val}' {$selected}>{$nama_bulan_array[$num_key]}</option>";
                            }
                            ?>
                        </select>
                        <label for="filter_tahun">Tahun:</label>
                        <select name="filter_tahun" id="filter_tahun">
                            <option value="">Semua Tahun</option>
                            <?php
                            $current_year = date('Y');
                            for ($year = $current_year; $year >= $current_year - 5; $year--) {
                                $selected = ($filter_tahun == $year) ? 'selected' : '';
                                echo "<option value='{$year}' {$selected}>{$year}</option>";
                            }
                            ?>
                        </select>
                        <button type="submit" class="btn btn-secondary btn-sm"><i class="fas fa-filter"></i> Filter</button>
                        <a href="sent_messages.php" class="btn btn-secondary btn-sm"><i class="fas fa-redo"></i> Reset</a>
                    </form>
                    <?php if (hasRole('superadmin')): ?>
                    <button type="button" class="btn btn-danger btn-sm" onclick="confirmClearSentLogs();" style="margin-left: auto;">
                        <i class="fas fa-trash-alt"></i> Bersihkan Semua Log Terkirim
                    </button>
                    <?php endif; ?>
                </div>
            </div>
            <div class="card-body">
                <table class="data-table">
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>Nomor Telepon</th>
                            <th>Isi Pesan</th>
                            <th>Status</th>
                            <th>Waktu Pengiriman</th>
                            <th>Status Detail (dari Gateway)</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if (!empty($messages)): ?>
                            <?php foreach ($messages as $msg): ?>
                                <tr>
                                    <td><?php echo htmlspecialchars($msg['id']); ?></td>
                                    <td><?php echo htmlspecialchars($msg['phone_number']); ?></td>
                                    <td><?php echo htmlspecialchars(mb_strimwidth($msg['message_content'], 0, 100, "...")); ?></td>
                                    <td><span class="status-badge status-success"><?php echo htmlspecialchars($msg['status']); ?></span></td>
                                    <td><?php echo htmlspecialchars($msg['timestamp']); ?></td>
                                    <td>
                                        <?php
                                        // Displaying only the 'detail' or 'message' from the response_data JSON
                                        $response_data = json_decode($msg['response_data'], true);
                                        if (isset($response_data['detail'])) {
                                            echo htmlspecialchars($response_data['detail']);
                                        } elseif (isset($response_data['message'])) {
                                            echo htmlspecialchars($response_data['message']);
                                        } elseif (isset($response_data['error'])) {
                                            echo 'Error: ' . (is_array($response_data['error']) ? json_encode($response_data['error']) : htmlspecialchars($response_data['error']));
                                        } else {
                                            echo 'N/A'; // If no specific detail/message is found
                                        }
                                        ?>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        <?php else: ?>
                            <tr><td colspan="6" style="text-align: center;">Tidak ada pesan terkirim yang ditemukan.</td></tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>

<script>
    function confirmClearSentLogs() {
        if (confirm('Apakah Anda yakin ingin menghapus SEMUA log pesan yang BERHASIL terkirim? Tindakan ini tidak dapat dibatalkan.')) {
            window.location.href = 'sent_messages.php?action=clear_sent_logs';
        }
    }
</script>

<?php include '../includes/footer.php'; ?>