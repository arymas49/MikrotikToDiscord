<?php
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!isset($_POST['csrf_token']) || $_POST['csrf_token'] !== $_SESSION['csrf_token']) {
        die('CSRF validation failed.');
    }
}
?>
<?php
// C:\xampp\htdocs\billing_isp_app\pages\dashboard.php
ini_set('session.use_strict_mode', 1);
ini_set('session.cookie_httponly', 1);
ini_set('session.cookie_samesite', 'Lax');
if (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on') {
    ini_set('session.cookie_secure', 1);
}
session_start();

ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

register_shutdown_function(function() {
    $error = error_get_last();
    if ($error && ($error['type'] === E_ERROR || $error['type'] === E_PARSE || $error['type'] === E_CORE_ERROR || $error['type'] === E_COMPILE_ERROR)) {
        echo "<div style='background-color: #fdd; border: 1px solid red; padding: 10px;'>";
        echo "<h2>Fatal Error Detected:</h2>";
        echo "<strong>Type:</strong> " . $error['type'] . "<br>";
        echo "<strong>Message:</strong> " . $error['message'] . "<br>";
        echo "<strong>File:</strong> " . $error['file'] . " (Line: " . $error['line'] . ")<br>";
        echo "</div>";
    }
});

include '../config/koneksi.php';
include '../includes/header.php';

// --- Bagian PHP untuk Query Dashboard ---
$tahun_ini = date('Y');
$bulan_sekarang_format_mysql = date('Y-m');
$bulan_sekarang_for_query_num = date('m');
$tahun_sekarang_for_query_num = date('Y');
$bulan_ini_label = date('F Y');

// 1. Ambil jumlah total pelanggan
$total_pelanggan = 0;
$query_total_pelanggan = "SELECT COUNT(id_pelanggan) AS total_pelanggan FROM pelanggan";
$result_total_pelanggan = $koneksi->query($query_total_pelanggan);
if ($result_total_pelanggan && $result_total_pelanggan->num_rows > 0) {
    $total_pelanggan = $result_total_pelanggan->fetch_assoc()['total_pelanggan'];
}

// 2. Ambil jumlah tagihan yang sudah lunas untuk bulan ini (dari tagihan ISP reguler)
// Mengembalikan ke logika yang menghitung jumlah tagihan, bukan pelanggan unik
$pelanggan_lunas = 0;
$query_pelanggan_lunas = "
    SELECT COUNT(id_tagihan) AS total_lunas
    FROM tagihan
    WHERE status_tagihan = 'Lunas'
    AND bulan_tagihan = ?
";
if ($stmt_lunas = $koneksi->prepare($query_pelanggan_lunas)) {
    $stmt_lunas->bind_param("s", $bulan_sekarang_format_mysql);
    $stmt_lunas->execute();
    $result_lunas = $stmt_lunas->get_result();
    $data_lunas = $result_lunas->fetch_assoc();
    $pelanggan_lunas = $data_lunas['total_lunas'] ?? 0;
    $stmt_lunas->close();
}

// 3. Ambil jumlah tagihan belum lunas (berdasarkan status tagihan 'Belum Lunas')
// Mengembalikan ke logika yang menghitung jumlah tagihan, termasuk 'Jatuh Tempo'
$pelanggan_belum_lunas = 0;
$query_pelanggan_belum_lunas = "
    SELECT COUNT(id_tagihan) AS total_belum_lunas
    FROM tagihan
    WHERE status_tagihan IN ('Belum Lunas', 'Jatuh Tempo')
    AND bulan_tagihan = ?
";
if ($stmt_belum_lunas = $koneksi->prepare($query_pelanggan_belum_lunas)) {
    $stmt_belum_lunas->bind_param("s", $bulan_sekarang_format_mysql);
    $stmt_belum_lunas->execute();
    $result_belum_lunas = $stmt_belum_lunas->get_result();
    $data_belum_lunas = $result_belum_lunas->fetch_assoc();
    $pelanggan_belum_lunas = $data_belum_lunas['total_belum_lunas'] ?? 0;
    $stmt_belum_lunas->close();
}


// 4. Ambil total pemasukan ISP bulan ini (menjumlahkan semua pembayaran yang tercatat)
$total_pemasukan_isp_bulan_ini = 0;
if ($stmt_pemasukan_isp = $koneksi->prepare("SELECT SUM(jumlah_bayar) AS total_pemasukan_isp_bulan_ini FROM pembayaran WHERE YEAR(tanggal_bayar) = ? AND MONTH(tanggal_bayar) = ?")) {
    $stmt_pemasukan_isp->bind_param("ii", $tahun_sekarang_for_query_num, $bulan_sekarang_for_query_num);
    $stmt_pemasukan_isp->execute();
    $result_pemasukan_isp = $stmt_pemasukan_isp->get_result();
    $data_pemasukan_isp = $result_pemasukan_isp->fetch_assoc();
    $total_pemasukan_isp_bulan_ini = $data_pemasukan_isp['total_pemasukan_isp_bulan_ini'] ?? 0;
    $stmt_pemasukan_isp->close();
}

// NEW: 4a. Ambil total pemasukan dari pelanggan corporate bulan ini
$total_pemasukan_corporate_bulan_ini = 0;
$query_pemasukan_corporate = "
    SELECT SUM(py.jumlah_bayar) AS total_pemasukan_corporate_bulan_ini
    FROM pembayaran py
    JOIN pelanggan p ON py.pelanggan_id = p.id_pelanggan
    WHERE p.pelanggan_corporate = 1
    AND YEAR(py.tanggal_bayar) = ?
    AND MONTH(py.tanggal_bayar) = ?
";
if ($stmt_pemasukan_corporate = $koneksi->prepare($query_pemasukan_corporate)) {
    $stmt_pemasukan_corporate->bind_param("ii", $tahun_sekarang_for_query_num, $bulan_sekarang_for_query_num);
    $stmt_pemasukan_corporate->execute();
    $result_pemasukan_corporate = $stmt_pemasukan_corporate->get_result();
    $data_pemasukan_corporate = $result_pemasukan_corporate->fetch_assoc();
    $total_pemasukan_corporate_bulan_ini = $data_pemasukan_corporate['total_pemasukan_corporate_bulan_ini'] ?? 0;
    $stmt_pemasukan_corporate->close();
}

// Sesuaikan total pemasukan ISP reguler (non-corporate)
$total_pemasukan_isp_reguler_bulan_ini = $total_pemasukan_isp_bulan_ini - $total_pemasukan_corporate_bulan_ini;


// 5. Ambil total pemasukan nota manual bulan ini (Pemasukan dari Jasa Lainnya)
$total_pemasukan_manual_bulan_ini = 0;
if ($stmt_pemasukan_manual = $koneksi->prepare("SELECT SUM(jumlah_bayar_manual) AS total_pemasukan_manual_bulan_ini FROM tagihan_manual WHERE YEAR(tanggal_bayar_manual) = ? AND MONTH(tanggal_bayar_manual) = ? AND status_tagihan = 'Lunas'")) {
    $stmt_pemasukan_manual->bind_param("ii", $tahun_sekarang_for_query_num, $bulan_sekarang_for_query_num);
    $stmt_pemasukan_manual->execute();
    $result_pemasukan_manual = $stmt_pemasukan_manual->get_result();
    $data_pemasukan_manual = $result_pemasukan_manual->fetch_assoc();
    $total_pemasukan_manual_bulan_ini = $data_pemasukan_manual['total_pemasukan_manual_bulan_ini'] ?? 0;
    $stmt_pemasukan_manual->close();
}

// Total Pemasukan Bulan Ini (ISP + Nota Manual)
$total_pemasukan_bulan_ini_combined = $total_pemasukan_isp_bulan_ini + $total_pemasukan_manual_bulan_ini;


// 6. Ambil total pengeluaran bulan ini (Dinamis dari tabel `pengeluaran`)
$total_pengeluaran_bulan_ini = 0;
if ($stmt_pengeluaran = $koneksi->prepare("SELECT SUM(jumlah) AS total_pengeluaran FROM pengeluaran WHERE YEAR(tanggal_pengeluaran) = ? AND MONTH(tanggal_pengeluaran) = ?")) {
    $stmt_pengeluaran->bind_param("ii", $tahun_sekarang_for_query_num, $bulan_sekarang_for_query_num);
    $stmt_pengeluaran->execute();
    $result_pengeluaran = $stmt_pengeluaran->get_result();
    $data_pengeluaran = $result_pengeluaran->fetch_assoc();
    $total_pengeluaran_bulan_ini = $data_pengeluaran['total_pengeluaran'] ?? 0;
    $stmt_pengeluaran->close();
}

// Hitung Balance Bulan Ini
$balance_bulan_ini = $total_pemasukan_bulan_ini_combined - $total_pengeluaran_bulan_ini;

// --- Dapatkan status WhatsApp Gateway yang sebenarnya dari API (PHP Sisi Server) ---
// Load konfigurasi WhatsApp Gateway dari file
$whatsapp_config_path = '../config/whatsapp_config.php';
$whatsapp_config = [];
if (file_exists($whatsapp_config_path)) {
    $whatsapp_config = include $whatsapp_config_path;
}
$whatsapp_api_key_for_js = $whatsapp_config['whatsapp_api_key'] ?? '';

// --- PHP: Ambil Status API Key dari send_whatsapp_message.php secara langsung (sebelum rendering HTML) ---
$whatsapp_gateway_status_text = 'Memuat...';
$whatsapp_gateway_card_color_class = 'bg-secondary';

if (!empty($whatsapp_api_key_for_js)) {
    $simulator_base_url = $whatsapp_config['app_base_url'] ?? 'http://localhost/billing_isp_app';
    // Menggunakan send_whatsapp_message.php sebagai endpoint utama
    $gateway_status_url = $simulator_base_url . '/pages/send_whatsapp_message.php';

    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $gateway_status_url);
    curl_setopt($ch, CURLOPT_POST, 1);
    // Menggunakan action 'check_status' yang sudah ada di send_whatsapp_message.php
    curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode(['action' => 'check_status', 'api_key' => $whatsapp_api_key_for_js]));
    curl_setopt($ch, CURLOPT_HTTPHEADER, array('Content-Type: application/json'));
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_TIMEOUT, 5); // Timeout lebih singkat untuk cek status

    $response = curl_exec($ch);
    $http_code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    $curl_error = curl_error($ch);
    curl_close($ch);

    if ($response === false) {
        error_log("cURL Error fetching WhatsApp status in dashboard: " . $curl_error);
        $whatsapp_gateway_status_text = 'Error Koneksi API';
        $whatsapp_gateway_card_color_class = 'bg-red';
    } else {
        $data = json_decode($response, true);
        if ($http_code == 200 && isset($data['status'])) {
            if ($data['status'] === 'success') { // Respons 'success' dari send_whatsapp_message.php 'check_status'
                $whatsapp_gateway_status_text = 'API Aktif'; // Ubah label agar lebih jelas
                $whatsapp_gateway_card_color_class = 'bg-green';
            } else {
                $whatsapp_gateway_status_text = 'API Tidak Aktif'; // Ubah label agar lebih jelas
                $whatsapp_gateway_card_color_class = 'bg-red';
            }
        } else {
            error_log("Invalid response from WhatsApp status check: " . $response);
            $whatsapp_gateway_status_text = 'Respons Invalid';
            $whatsapp_gateway_card_color_class = 'bg-red';
        }
    }
} else {
    $whatsapp_gateway_status_text = 'API Key Kosong';
    $whatsapp_gateway_card_color_class = 'bg-red';
}


// Ambil data pelanggan baru (PSB) untuk bulan ini
$new_customers_this_month = [];
$total_psb_bulan_ini = 0;
$total_pemasukan_psb_bulan_ini = 0;

$query_psb = "
    SELECT p.id_pelanggan, p.nama_pelanggan, p.tanggal_registrasi, pk.harga AS harga_paket, p.uses_ppn
    FROM pelanggan p
    JOIN paket_layanan pk ON p.paket_id = pk.id_paket
    WHERE DATE_FORMAT(p.tanggal_registrasi, '%Y-%m') = ?
    ORDER BY p.tanggal_registrasi DESC
";

if ($stmt_psb = $koneksi->prepare($query_psb)) {
    $stmt_psb->bind_param("s", $bulan_sekarang_format_mysql);
    $stmt_psb->execute();
    $result_psb = $stmt_psb->get_result();
    if ($result_psb->num_rows > 0) {
        while ($row_psb = $result_psb->fetch_assoc()) {
            $harga_final_psb = $row_psb['harga_paket'];
            if ($row_psb['uses_ppn'] == 1) {
                $harga_final_psb += ($row_psb['harga_paket'] * 0.11);
            }
            $new_customers_this_month[] = $row_psb;
            $total_pemasukan_psb_bulan_ini += $harga_final_psb;
        }
        $total_psb_bulan_ini = count($new_customers_this_month);
    }
    $stmt_psb->close();
}

// --- Ambil data dinamis untuk Status On/Off (Pelanggan Aktif/Tidak Aktif/Blokir) ---
$status_on = 0;
$query_status_on = "SELECT COUNT(id_pelanggan) AS total_on FROM pelanggan WHERE status_aktif = 'Aktif'";
$result_status_on = $koneksi->query($query_status_on);
if ($result_status_on && $result_status_on->num_rows > 0) {
    $status_on = $result_status_on->fetch_assoc()['total_on'];
}

$status_off = 0;
$query_status_off = "SELECT COUNT(id_pelanggan) AS total_off FROM pelanggan WHERE status_aktif IN ('Tidak Aktif', 'Blokir')";
$result_status_off = $koneksi->query($query_status_off);
if ($result_status_off && $result_status_off->num_rows > 0) {
    $status_off = $result_status_off->fetch_assoc()['total_off'];
}

// NEW: Query untuk menghitung jumlah tagihan belum lunas corporate (tanpa penagih)
$count_corporate_no_penagih_bl = 0;
$query_corporate_no_penagih_bl = "
    SELECT COUNT(t.id_tagihan) AS total
    FROM tagihan t
    JOIN pelanggan pl ON t.pelanggan_id = pl.id_pelanggan
    WHERE t.status_tagihan IN ('Belum Lunas', 'Jatuh Tempo', 'Kadaluarsa')
    AND pl.pelanggan_corporate = 1
    AND pl.penagih_id IS NULL
    AND t.bulan_tagihan = ?
";
if ($stmt_count_corporate_bl = $koneksi->prepare($query_corporate_no_penagih_bl)) {
    $stmt_count_corporate_bl->bind_param("s", $bulan_sekarang_format_mysql);
    $stmt_count_corporate_bl->execute();
    $result_count_corporate_bl = $stmt_count_corporate_bl->get_result();
    $data_count_corporate_bl = $result_count_corporate_bl->fetch_assoc();
    $count_corporate_no_penagih_bl = $data_count_corporate_bl['total'] ?? 0;
    $stmt_count_corporate_bl->close();
}
// NEW: Query untuk menghitung total nominal tagihan belum lunas corporate (tanpa penagih)
$total_nominal_corporate_no_penagih_bl = 0;
$query_nominal_corporate_no_penagih_bl = "
    SELECT SUM(t.sisa_tagihan) AS total_nominal
    FROM tagihan t
    JOIN pelanggan pl ON t.pelanggan_id = pl.id_pelanggan
    WHERE t.status_tagihan IN ('Belum Lunas', 'Jatuh Tempo', 'Kadaluarsa')
    AND pl.pelanggan_corporate = 1
    AND pl.penagih_id IS NULL
    AND t.bulan_tagihan = ?
";
if ($stmt_nominal_corporate_bl = $koneksi->prepare($query_nominal_corporate_no_penagih_bl)) {
    $stmt_nominal_corporate_bl->bind_param("s", $bulan_sekarang_format_mysql);
    $stmt_nominal_corporate_bl->execute();
    $result_nominal_corporate_bl = $stmt_nominal_corporate_bl->get_result();
    $data_nominal_corporate_bl = $result_nominal_corporate_bl->fetch_assoc();
    $total_nominal_corporate_no_penagih_bl = $data_nominal_corporate_bl['total_nominal'] ?? 0;
    $stmt_nominal_corporate_bl->close();
}

// NEW: Query untuk menghitung jumlah tagihan belum lunas tanpa penagih (non-corporate dan corporate)
$count_all_no_penagih_bl = 0;
$query_all_no_penagih_bl = "
    SELECT COUNT(t.id_tagihan) AS total
    FROM tagihan t
    JOIN pelanggan pl ON t.pelanggan_id = pl.id_pelanggan
    WHERE t.status_tagihan IN ('Belum Lunas', 'Jatuh Tempo', 'Kadaluarsa')
    AND pl.penagih_id IS NULL
    AND t.bulan_tagihan = ?
";
if ($stmt_count_all_bl = $koneksi->prepare($query_all_no_penagih_bl)) {
    $stmt_count_all_bl->bind_param("s", $bulan_sekarang_format_mysql);
    $stmt_count_all_bl->execute();
    $result_count_all_bl = $stmt_count_all_bl->get_result();
    $data_count_all_bl = $result_count_all_bl->fetch_assoc();
    $count_all_no_penagih_bl = $data_count_all_bl['total'] ?? 0;
    $stmt_count_all_bl->close();
}


// Ambil data penagih dan jumlah tagihan yang belum lunas per penagih
$penagih_belum_lunas_data_list = [];
$query_penagih_belum_lunas_tagihan = "
    SELECT
        p.id_penagih,
        p.nama_penagih,
        COUNT(DISTINCT CASE WHEN t.status_tagihan = 'Belum Lunas' THEN pl.id_pelanggan ELSE NULL END) AS total_pelanggan_belum_lunas_di_penagih,
        SUM(CASE WHEN t.status_tagihan = 'Belum Lunas' THEN t.sisa_tagihan ELSE 0 END) AS total_nominal_belum_lunas
    FROM
        penagih p
    LEFT JOIN
        pelanggan pl ON p.id_penagih = pl.penagih_id
    LEFT JOIN
        tagihan t ON pl.id_pelanggan = t.pelanggan_id AND t.bulan_tagihan = ?
    GROUP BY
        p.id_penagih, p.nama_penagih
    ORDER BY
        p.nama_penagih ASC
";

if ($stmt_penagih_belum_lunas_tagihan = $koneksi->prepare($query_penagih_belum_lunas_tagihan)) {
    $stmt_penagih_belum_lunas_tagihan->bind_param("s", $bulan_sekarang_format_mysql);
    $stmt_penagih_belum_lunas_tagihan->execute();
    $result_penagih_belum_lunas_tagihan = $stmt_penagih_belum_lunas_tagihan->get_result();
    while ($row = $result_penagih_belum_lunas_tagihan->fetch_assoc()) {
        $penagih_belum_lunas_data_list[] = $row;
    }
    $stmt_penagih_belum_lunas_tagihan->close();
}

// Ambil data penagih dan jumlah tagihan yang sudah lunas per penagih
$penagih_lunas_data_list = [];
$query_penagih_lunas_tagihan = "
    SELECT
        p.id_penagih,
        p.nama_penagih,
        COUNT(DISTINCT CASE WHEN t.status_tagihan = 'Lunas' THEN t.pelanggan_id ELSE NULL END) AS total_pelanggan_lunas_di_penagih,
        SUM(CASE WHEN t.status_tagihan = 'Lunas' THEN t.total_tagihan ELSE 0 END) AS total_nominal_lunas
    FROM
        penagih p
    LEFT JOIN
        pelanggan pl ON p.id_penagih = pl.penagih_id
    LEFT JOIN
        tagihan t ON pl.id_pelanggan = t.pelanggan_id AND t.bulan_tagihan = ?
    GROUP BY
        p.id_penagih, p.nama_penagih
    ORDER BY
        p.nama_penagih ASC
";

if ($stmt_penagih_lunas_tagihan = $koneksi->prepare($query_penagih_lunas_tagihan)) {
    $stmt_penagih_lunas_tagihan->bind_param("s", $bulan_sekarang_format_mysql);
    $stmt_penagih_lunas_tagihan->execute();
    $result_penagih_lunas_tagihan = $stmt_penagih_lunas_tagihan->get_result();
    while ($row = $result_penagih_lunas_tagihan->fetch_assoc()) {
        $penagih_lunas_data_list[] = $row;
    }
    $stmt_penagih_lunas_tagihan->close();
} else {
    error_log("Error preparing Penagih Lunas query: " . $koneksi->error);
    echo "<div class='alert alert-danger'>Terjadi kesalahan saat menyiapkan data Lunas Penagih. Silakan hubungi administrator.</div>";
}

?>

<div class="main-content">
    <div class="top-header">
        <div class="header-search-bar">
            <i class="fas fa-search"></i>
            <input type="text" placeholder="Invoice Number">
            <button><i class="fas fa-barcode"></i></button>
        </div>
        <div class="alert-message">
            <i class="fas fa-info-circle"></i> Selamat datang di billing PT Triple Zhi Network | 7 hari begadang cuma mau bikin billing.. kerja bae bae ee !!!
        </div>
        <div class="welcome-message">
            <span>Selamat Bekerja, <?php echo htmlspecialchars($_SESSION['username'] ?? 'User'); ?></span>
            <a href="../logout.php" class="btn-logout">Logout</a>
        </div>
    </div>

    <div class="container dashboard-grid-area">
        <div class="dashboard-content-grid">

            <div class="info-card card-financial" id="financialCard">
                <h3>Keuangan Bulan Ini
                    <button class="toggle-nominal-btn" id="toggleNominalBtn">
                        <i class="fas fa-eye"></i>
                    </button>
                    <i class="icon-placeholder fas fa-dollar-sign"></i>
                </h3>
                <div class="value-label">Pemasukan ISP Reguler Bulan Ini</div>
                <div class="value-amount"><span class="nominal-value" id="incomeISPRegulerValue"><?php echo "Rp " . number_format($total_pemasukan_isp_reguler_bulan_ini, 0, ',', '.'); ?></span></div>

                <div class="value-label">Pemasukan Corporate Bulan Ini</div>
                <div class="value-amount"><span class="nominal-value" id="incomeCorporateValue"><?php echo "Rp " . number_format($total_pemasukan_corporate_bulan_ini, 0, ',', '.'); ?></span></div>

                <div class="value-label">Pemasukan Nota Manual Bulan Ini</div>
                <div class="value-amount"><span class="nominal-value" id="incomeManualValue"><?php echo "Rp " . number_format($total_pemasukan_manual_bulan_ini, 0, ',', '.'); ?></span></div>

                <div class="value-label">Total Pemasukan Bulan Ini</div>
                <div class="value-amount"><span class="nominal-value" id="incomeTotalValue"><?php echo "Rp " . number_format($total_pemasukan_bulan_ini_combined, 0, ',', '.'); ?></span></div>

                <div class="value-label">Pengeluaran Bulan Ini</div>
                <div class="value-amount expense"><span class="nominal-value" id="expenseValue"><?php echo "Rp " . number_format($total_pengeluaran_bulan_ini, 0, ',', '.'); ?></span></div>
                <div class="value-label">Balance Bulan Ini</div>
                <div class="value-amount balance"><span class="nominal-value" id="balanceValue"><?php echo "Rp " . number_format($balance_bulan_ini, 0, ',', '.'); ?></span></div>
                <div class="card-footer">
                    <a href="../pages/laporan_keuangan.php" class="btn-detail">Selengkapnya &#10140;</a>
                </div>
            </div>

            <?php if (!empty($new_customers_this_month)): ?>
            <div class="info-card psb-card">
                <h3>
                    PSB Bulan Ini <i class="icon-placeholder fas fa-user-plus"></i>
                </h3>
                <div class="card-value"><?php echo htmlspecialchars($total_psb_bulan_ini, ENT_QUOTES, "UTF-8"); ?></div>
                <div class="value-label">Pemasukan PSB Bulan Ini</div>
                <div class="value-amount"><span class="nominal-value"><?php echo "Rp " . number_format($total_pemasukan_psb_bulan_ini, 0, ',', '.'); ?></span></div>

                <div class="profile-list">
                    <?php foreach ($new_customers_this_month as $customer): ?>
                        <div class="profile-item">
                            <img src="../assets/images/default-avatar.png" alt="Avatar">
                            <p class="customer-name"><?php echo htmlspecialchars($customer['nama_pelanggan']); ?></p>
                            <p><?php echo date('d F Y', strtotime($customer['tanggal_registrasi'])); ?></p>
                        </div>
                    <?php endforeach; ?>
                </div>
                <div class="card-footer">
                    <a href="../pages/manajemen_pelanggan.php?filter_status_aktif=Aktif&filter_tanggal_registrasi_mulai=<?php echo date('Y-m-01'); ?>&filter_tanggal_registrasi_akhir=<?php echo date('Y-m-t'); ?>" class="btn-detail">Selengkapnya &#10140;</a>
                </div>
            </div>
            <?php endif; ?>

            <?php if (!empty($penagih_belum_lunas_data_list)): ?>
            <div class="info-card penagih-card">
                <h3>
                    Tagihan Belum Lunas Per Penagih <i class="icon-placeholder fas fa-clipboard-list"></i>
                </h3>
                <div class="tagih-list">
                    <?php foreach ($penagih_belum_lunas_data_list as $penagih): ?>
                        <div class="tagih-item">
                            <span class="penagih-name"><?php echo htmlspecialchars($penagih['nama_penagih']); ?>:</span>
                            <span class="tagih-info">
                                <span class="tagih-count"><?php echo htmlspecialchars($penagih['total_pelanggan_belum_lunas_di_penagih']); ?></span>
                            </span> <span class="tagih-amount">Rp <?php echo number_format($penagih['total_nominal_belum_lunas'] ?? 0, 0, ',', '.'); ?></span>
                        </div>
                    <?php endforeach; ?>
                </div>
                <div class="card-footer">
                    <a href="../pages/dashboard_penagih.php" class="btn-detail">Detail Penagih &#10140;</a>
                </div>
            </div>
            <?php endif; ?>

            <?php if (!empty($penagih_lunas_data_list)): ?>
            <div class="info-card penagih-lunas-card">
                <h3>
                    Tagihan Sudah Lunas Per Penagih <i class="icon-placeholder fas fa-check-double"></i>
                </h3>
                <div class="tagih-list">
                    <?php foreach ($penagih_lunas_data_list as $penagih): ?>
                        <div class="tagih-item">
                            <span class="penagih-name"><?php echo htmlspecialchars($penagih['nama_penagih']); ?>:</span>
                            <span class="tagih-info">
                                <span class="tagih-count"><?php echo htmlspecialchars($penagih['total_pelanggan_lunas_di_penagih']); ?></span>
                            </span> <span class="tagih-amount">Rp <?php echo number_format($penagih['total_nominal_lunas'] ?? 0, 0, ',', '.'); ?></span>
                        </div>
                    <?php endforeach; ?>
                </div>
                <div class="card-footer">
                    <a href="../pages/dashboard_penagih.php" class="btn-detail">Detail Penagih &#10140;</a>
                </div>
            </div>
            <?php endif; ?>

            <div class="info-card">
                <h3>Total Pelanggan <i class="icon-placeholder fas fa-users"></i></h3>
                <div class="card-value"><?php echo htmlspecialchars($total_pelanggan, ENT_QUOTES, "UTF-8"); ?></div>
                <div class="card-footer">
                    <a href="../pages/manajemen_pelanggan.php" class="btn-detail">Selengkapnya &#10140;</a>
                </div>
            </div>

            <div class="info-card">
                <h3>Pelanggan Sudah Lunas <i class="icon-placeholder fas fa-check-circle"></i></h3>
                <div class="card-value"><?php echo htmlspecialchars($pelanggan_lunas, ENT_QUOTES, "UTF-8"); ?></div>
                <div class="card-footer">
                    <a href="../pages/pembayaran.php?status=lunas" class="btn-detail">Selengkapnya &#10140;</a>
                </div>
            </div>

            <div class="info-card">
                <h3>Pelanggan Belum Lunas <i class="icon-placeholder fas fa-exclamation-circle"></i></h3>
                <div class="card-value"><?php echo htmlspecialchars($pelanggan_belum_lunas, ENT_QUOTES, "UTF-8"); ?></div>
                <div class="card-footer">
                    <a href="../pages/pembayaran.php?status=belum_lunas" class="btn-detail">Selengkapnya &#10140;</a>
                </div>
            </div>

            <div class="info-card">
                <h3>Status On <i class="icon-placeholder fas fa-toggle-on"></i></h3>
                <div class="card-value"><?php echo htmlspecialchars($status_on, ENT_QUOTES, "UTF-8"); ?></div>
                <div class="card-footer">
                    <a href="../pages/manajemen_pelanggan.php?status_aktif_dropdown=Aktif" class="btn-detail">Selengkapnya &#10140;</a>
                </div>
            </div>

            <div class="info-card">
                <h3>Status Off <i class="icon-placeholder fas fa-toggle-off"></i></h3>
                <div class="card-value"><?php echo htmlspecialchars($status_off, ENT_QUOTES, "UTF-8"); ?></div>
                <div class="card-footer">
                    <a href="../pages/manajemen_pelanggan.php?status_aktif_dropdown=Tidak Aktif" class="btn-detail">Selengkapnya &#10140;</a>
                </div>
            </div>

            <div class="info-card">
                <h3>Tagihan Corporate Belum Lunas <i class="icon-placeholder fas fa-building"></i></h3>
                <div class="card-value"><?php echo htmlspecialchars($count_corporate_no_penagih_bl, ENT_QUOTES, "UTF-8"); ?></div>
                <div class="value-amount"><span class="nominal-value"><?php echo "Rp " . number_format($total_nominal_corporate_no_penagih_bl, 0, ',', '.'); ?></span></div> <div class="card-footer">
                    <a href="../pages/tagihan_belum_lunas_corporate.php" class="btn-detail">Selengkapnya &#10140;</a>
                </div>
            </div>

            <div class="info-card <?php echo htmlspecialchars($whatsapp_gateway_card_color_class, ENT_QUOTES, "UTF-8"); ?>" id="whatsappGatewayCard">
                <h3>WhatsApp Gateway <i class="icon-placeholder fas fa-comment-dots"></i></h3>
                <div class="card-value" id="whatsappStatusText"><?php echo htmlspecialchars($whatsapp_gateway_status_text, ENT_QUOTES, "UTF-8"); ?></div>
                <div class="card-footer">
                    <a href="#" class="btn-detail" onclick="openSendWhatsappModal(); return false;">Kirim Pesan Tes &#10140;</a>
                </div>
            </div>

        </div> </div> </div> <div id="whatsappSendModal" class="modal">
    <div class="modal-content">
        <span class="close-button" onclick="closeWhatsappSendModal()">&times;</span>
        <h3>Kirim Pesan WhatsApp Tes</h3>
        <form id="whatsappForm">
            <div class="form-group">
                <label for="whatsapp_number">Nomor Telepon (contoh: 6281234567890):</label>
                <input type="text" id="whatsapp_number" name="whatsapp_number" required>
            </div>
            <div class="form-group">
                <label for="whatsapp_message">Pesan:</label>
                <textarea id="whatsapp_message" name="whatsapp_message" rows="4" required></textarea>
            </div>
            <button type="submit" class="btn btn-primary">Kirim Pesan</button>
        </form>
        <div id="whatsappMessageStatus" class="modal-message" style="display: none;"></div>
    </div>
</div>

<script>
document.addEventListener('DOMContentLoaded', function() {
    var toggleBtn = document.getElementById('toggleNominalBtn');
    
    // Select all elements that contain numbers you want to hide
    var nominalValues = document.querySelectorAll(
        '.nominal-value, ' + // Existing financial nominals
        '.psb-card .card-value, ' + // PSB Bulan Ini count
        '.psb-card .nominal-value, ' + // PSB Bulan Ini nominal
        '.info-card:not(.card-financial):not(.psb-card):not(.penagih-card):not(.penagih-lunas-card):not(#whatsappGatewayCard) .card-value, ' + // Other general info cards like Total Pelanggan, Pelanggan Sudah/Belum Lunas, Status On/Off
        '.penagih-card .tagih-count, ' + // Tagihan Belum Lunas Per Penagih count
        '.penagih-card .tagih-amount, ' + // Tagihan Belum Lunas Per Penagih amount
        '.penagih-lunas-card .tagih-count, ' + // Tagihan Sudah Lunas Per Penagih count
        '.penagih-lunas-card .tagih-amount' // Tagihan Sudah Lunas Per Penagih amount
    );
    
    var eyeIcon = toggleBtn ? toggleBtn.querySelector('i') : null;

    var isNominalHiddenKey = 'isNominalHidden';
    var isHidden = localStorage.getItem(isNominalHiddenKey) === 'true';

    function toggleNominalVisibility(shouldHide) {
        nominalValues.forEach(function(element) {
            var originalText = element.dataset.originalText;
            if (!originalText) {
                element.dataset.originalText = element.textContent;
                originalText = element.textContent;
            }

            if (shouldHide) {
                // Determine if it's a financial value or a simple count
                if (element.classList.contains('nominal-value') || element.classList.contains('tagih-amount')) {
                    // For financial values (with Rp or just numbers with commas/periods)
                    element.textContent = originalText.replace(/[\dRp.,]/g, '*');
                } else {
                    // For simple counts like Total Pelanggan, PSB count, etc.
                    element.textContent = originalText.replace(/[\d]/g, '*');
                }
                
                if (eyeIcon) {
                    eyeIcon.classList.remove('fas', 'fa-eye');
                    eyeIcon.classList.add('fas', 'fa-eye-slash');
                }
            } else {
                element.textContent = originalText;
                if (eyeIcon) {
                    eyeIcon.classList.remove('fas', 'fa-eye-slash');
                    eyeIcon.classList.add('fas', 'fa-eye');
                }
            }
        });
        localStorage.setItem(isNominalHiddenKey, shouldHide);
    }

    if (toggleBtn) {
        toggleNominalVisibility(isHidden);

        toggleBtn.addEventListener('click', function() {
            isHidden = !isHidden;
            toggleNominalVisibility(isHidden);
        });
    }

    // --- WhatsApp Modal Functions (rest of your existing code) ---
    var whatsappSendModal = document.getElementById('whatsappSendModal');
    var whatsappForm = document.getElementById('whatsappForm');
    var whatsappMessageStatus = document.getElementById('whatsappMessageStatus');

    window.openSendWhatsappModal = function() {
        if (whatsappSendModal) whatsappSendModal.style.display = "block";
        if (whatsappMessageStatus) whatsappMessageStatus.style.display = "none";
        if (whatsappForm) whatsappForm.reset();
    }

    window.closeWhatsappSendModal = function() {
        if (whatsappSendModal) whatsappSendModal.style.display = "none";
        if (whatsappForm) whatsappForm.reset();
        if (whatsappMessageStatus) whatsappMessageStatus.style.display = "none";
    }

    window.onclick = function(event) {
        if (whatsappSendModal && event.target == whatsappSendModal) {
            closeWhatsappSendModal();
        }
    }

    if (whatsappForm) {
        whatsappForm.addEventListener('submit', function(e) {
            e.preventDefault();

            const phoneNumber = document.getElementById('whatsapp_number').value;
            const message = document.getElementById('whatsapp_message').value;

            if (whatsappMessageStatus) {
                whatsappMessageStatus.style.display = "block";
                whatsappMessageStatus.className = 'modal-message';
                whatsappMessageStatus.textContent = 'Mengirim pesan...';
            }

            fetch('../pages/send_whatsapp_message.php', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify({ action: 'test_message', phoneNumber: phoneNumber, message_content: message }),
            })
            .then(response => {
                if (!response.ok) {
                    return response.json().then(errorData => {
                        throw new Error(errorData.message || 'Network response was not ok.');
                    });
                }
                return response.json();
            })
            .then(data => {
                if (whatsappMessageStatus) {
                    if (data.status === 'sent' || data.status === 'success') {
                        whatsappMessageStatus.classList.add('success');
                        whatsappMessageStatus.textContent = 'Pesan berhasil dikirim!';
                    } else {
                        whatsappMessageStatus.classList.add('error');
                        whatsappMessageStatus.textContent = 'Gagal mengirim pesan: ' + (data.message || 'Terjadi kesalahan tidak diketahui.');
                    }
                }
            })
            .catch(error => {
                console.error('Error:', error);
                if (whatsappMessageStatus) {
                    whatsappMessageStatus.classList.add('error');
                    whatsappMessageStatus.textContent = 'Terjadi kesalahan jaringan atau server: ' + error.message;
                }
            });
        });
    }

    // --- WhatsApp Gateway Status Sync (rest of your existing code) ---
    const whatsappGatewayCard = document.getElementById('whatsappGatewayCard');
    const whatsappStatusText = document.getElementById('whatsappStatusText');
    const whatsappAPIKey = <?php echo htmlspecialchars(json_encode($whatsapp_api_key_for_js), ENT_QUOTES, "UTF-8"); ?>;

    function updateWhatsappGatewayStatus(status) {
        if (whatsappStatusText && whatsappGatewayCard) {
            whatsappStatusText.textContent = status;
            whatsappGatewayCard.classList.remove('bg-green', 'bg-red', 'bg-secondary');
            if (status === 'API Aktif') {
                whatsappGatewayCard.classList.add('bg-green');
            } else {
                whatsappGatewayCard.classList.add('bg-red');
            }
        }
    }

    function fetchWhatsappAPIKeyStatus() {
        if (!whatsappAPIKey || whatsappAPIKey.trim() === '') {
            updateWhatsappGatewayStatus('API Key Kosong');
            return;
        }
        
        updateWhatsappGatewayStatus('Memuat...');

        fetch('../pages/send_whatsapp_message.php', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({ action: 'check_status', api_key: whatsappAPIKey }),
        })
        .then(response => {
            if (!response.ok) {
                throw new Error(`HTTP error! status: ${response.status}`);
            }
            return response.json();
        })
        .then(data => {
            if (data.status === 'success') {
                updateWhatsappGatewayStatus('API Aktif');
            } else {
                updateWhatsappGatewayStatus('API Tidak Aktif');
            }
        })
        .catch(error => {
            console.error('Error fetching WhatsApp API status:', error);
            updateWhatsappGatewayStatus('Error Koneksi API');
        });
    }

    fetchWhatsappAPIKeyStatus();
    setInterval(fetchWhatsappAPIKeyStatus, 20000);
});
</script>

<?php include '../includes/footer.php'; ?>