<?php
// C:\xampp\htdocs\billing_isp_app\pages\logs
ob_start();
ini_set('session.use_strict_mode', 1);
ini_set('session.cookie_httponly', 1);
ini_set('session.cookie_samesite', 'Lax');
if (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on') {
    ini_set('session.cookie_secure', 1);
}
session_start();
include '../config/koneksi.php';
include '../includes/header.php'; // Meng-include sidebar dan hasRole()

// Batasi akses ke halaman ini: hanya superadmin
if (!hasRole('superadmin')) { // Sesuaikan role yang berhak menghapus log
    header('Location: dashboard.php');
    exit();
}

$message = ''; // Variabel untuk pesan feedback
$logs = [];
$limit = 20; // Jumlah log per halaman
$page = isset($_GET['page']) && is_numeric($_GET['page']) ? (int)$_GET['page'] : 1;
$offset = ($page - 1) * $limit;

// Ambil URL dasar dari konfigurasi (sama seperti di broadcast_message.php)
global $whatsapp_config;
if (!isset($whatsapp_config) || empty($whatsapp_config)) {
    $whatsapp_config_path = __DIR__ . '/../config/whatsapp_config.php';
    if (file_exists($whatsapp_config_path)) {
        $whatsapp_config = include $whatsapp_config_path;
    } else {
        $whatsapp_config = [];
    }
}
$app_base_url = $whatsapp_config['app_base_url'] ?? 'https://wifitetangga.my.id';
$api_endpoint = $app_base_url . '/pages/send_whatsapp_message.php'; // Endpoint yang sama untuk API


// --- Penanganan POST Request untuk Hapus Log ---
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['action'])) {
    $action_performed = $_POST['action'];
    $response_status = 'error';
    $response_msg = 'Terjadi kesalahan tidak dikenal saat memproses permintaan.';

    if ($action_performed == 'clear_all_activity_logs') {
        $payload = json_encode([
            'action' => 'clear_all_activity_logs' // Aksi baru untuk menghapus log aktivitas
        ]);

        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $api_endpoint);
        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_POSTFIELDS, $payload);
        curl_setopt($ch, CURLOPT_HTTPHEADER, array(
            'Content-Type: application/json',
            'Content-Length: ' . strlen($payload)
        ));
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_TIMEOUT, 60);

        $response = curl_exec($ch);
        $http_code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        $curl_error = curl_error($ch);
        curl_close($ch);

        error_log("DEBUG: Clear All Activity Logs - Payload: " . $payload);
        error_log("DEBUG: Clear All Activity Logs - Raw Response: " . $response);
        error_log("DEBUG: Clear All Activity Logs - HTTP Code: " . $http_code);
        error_log("DEBUG: Clear All Activity Logs - cURL Error: " . $curl_error);

        if ($curl_error) {
            $response_msg = 'Error menghapus log aktivitas (cURL Error): ' . htmlspecialchars($curl_error);
            $response_status = 'danger';
        } else {
            $response_data = json_decode($response, true);
            if ($http_code == 200 && isset($response_data['status']) && $response_data['status'] == 'success') {
                $response_msg = htmlspecialchars($response_data['message']);
                $response_status = 'success';
            } else {
                $error_msg = $response_data['message'] ?? 'Respons tidak valid dari server.';
                $response_msg = 'Gagal menghapus log aktivitas: ' . htmlspecialchars($error_msg);
                $response_status = 'danger';
            }
        }
    }
    // Tambahkan logika lain jika ada aksi POST lain di halaman ini
    // else { /* ... */ }

    // Redirect untuk menampilkan pesan feedback
    header('Location: logs?message=' . urlencode($response_msg) . '&status=' . urlencode($response_status));
    exit();
}

// Ambil pesan dan status dari URL jika ada (setelah redirect)
if (isset($_GET['message']) && isset($_GET['status'])) {
    $message = '<div class="alert alert-' . htmlspecialchars($_GET['status']) . '">' . htmlspecialchars($_GET['message']) . '</div>';
}

// --- Logika Filter dan Ambil Data Log ---
$filter_username = $_GET['filter_username'] ?? '';
$filter_activity_type = $_GET['filter_activity_type'] ?? '';
$filter_date_start = $_GET['filter_date_start'] ?? '';
$filter_date_end = $_GET['filter_date_end'] ?? '';

$where_clauses = [];
$params = [];
$param_types = "";

if (!empty($filter_username)) {
    $where_clauses[] = "username LIKE ?";
    $params[] = '%' . $filter_username . '%';
    $param_types .= "s";
}
if (!empty($filter_activity_type)) {
    $where_clauses[] = "activity_type = ?";
    $params[] = $filter_activity_type;
    $param_types .= "s";
}
if (!empty($filter_date_start)) {
    $where_clauses[] = "DATE(timestamp) >= ?";
    $params[] = $filter_date_start;
    $param_types .= "s";
}
if (!empty($filter_date_end)) {
    $where_clauses[] = "DATE(timestamp) <= ?";
    $params[] = $filter_date_end;
    $param_types .= "s";
}

$where_sql = count($where_clauses) > 0 ? " WHERE " . implode(" AND ", $where_clauses) : "";

// Query untuk mengambil log
$query_logs = "SELECT * FROM activity_logs" . $where_sql . " ORDER BY timestamp DESC LIMIT ? OFFSET ?";
$stmt_logs = $koneksi->prepare($query_logs);

if (!empty($params)) {
    $param_types .= "ii"; // Tambahkan tipe untuk limit dan offset
    $params[] = $limit;
    $params[] = $offset;
    $stmt_logs->bind_param($param_types, ...$params);
} else {
    $stmt_logs->bind_param("ii", $limit, $offset);
}

$stmt_logs->execute();
$result_logs = $stmt_logs->get_result();

if ($result_logs->num_rows > 0) {
    while ($row = $result_logs->fetch_assoc()) {
        $logs[] = $row;
    }
}
$stmt_logs->close();

// Query untuk menghitung total log (untuk pagination)
$query_total_logs = "SELECT COUNT(*) AS total_logs FROM activity_logs" . $where_sql;
$stmt_total_logs = $koneksi->prepare($query_total_logs);
if (!empty($params)) {
    // Hapus limit dan offset dari parameter untuk query total
    array_pop($params);
    array_pop($params);
    $param_types_total = substr($param_types, 0, -2); // Hapus tipe 'ii'
    $stmt_total_logs->bind_param($param_types_total, ...$params);
}
$stmt_total_logs->execute();
$total_logs = $stmt_total_logs->get_result()->fetch_assoc()['total_logs'];
$stmt_total_logs->close();

$total_pages = ceil($total_logs / $limit);

// Ambil daftar unik tipe aktivitas untuk filter
$activity_types_options = [];
$query_activity_types = "SELECT DISTINCT activity_type FROM activity_logs ORDER BY activity_type ASC";
$result_activity_types = $koneksi->query($query_activity_types);
while ($row = $result_activity_types->fetch_assoc()) {
    $activity_types_options[] = $row['activity_type'];
}
?>

<div class="main-content">
    <div class="top-header">
        <div class="alert-message">
            Monitor dan filter log aktivitas pengguna.
        </div>
        <div class="welcome-message">
            <span>Selamat datang, <?php echo htmlspecialchars($_SESSION['username'] ?? 'User'); ?>!</span>
            <a href="../logout.php" class="btn-logout">Logout</a>
        </div>
    </div>

    <div class="container">
        <h2>Log Aktivitas Admin</h2>

        <?php
        // Menampilkan pesan feedback
        if (isset($message) && !empty($message)) {
            echo $message;
        }
        ?>

        <div class="card" style="margin-bottom: 20px;">
            <div class="card-header">
                <h3>Filter Log Aktivitas</h3>
            </div>
            <div class="card-body">
                <form method="GET" action="logs" style="display: flex; flex-wrap: wrap; gap: 10px; align-items: flex-end;">
                    <div class="form-group" style="flex: 1 1 200px;">
                        <label for="filter_username">Username:</label>
                        <input type="text" id="filter_username" name="filter_username" class="form-control"
                               value="<?php echo htmlspecialchars($filter_username); ?>" placeholder="Cari Username">
                    </div>
                    <div class="form-group" style="flex: 1 1 200px;">
                        <label for="filter_activity_type">Tipe Aktivitas:</label>
                        <select name="filter_activity_type" id="filter_activity_type" class="form-control">
                            <option value="">-- Semua Tipe --</option>
                            <?php foreach ($activity_types_options as $type): ?>
                                <option value="<?php echo htmlspecialchars($type); ?>"
                                    <?php echo ($filter_activity_type == $type) ? 'selected' : ''; ?>>
                                    <?php echo htmlspecialchars($type); ?>
                                </option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <div class="form-group" style="flex: 1 1 180px;">
                        <label for="filter_date_start">Tanggal Mulai:</label>
                        <input type="date" id="filter_date_start" name="filter_date_start" class="form-control"
                               value="<?php echo htmlspecialchars($filter_date_start); ?>">
                    </div>
                    <div class="form-group" style="flex: 1 1 180px;">
                        <label for="filter_date_end">Tanggal Akhir:</label>
                        <input type="date" id="filter_date_end" name="filter_date_end" class="form-control"
                               value="<?php echo htmlspecialchars($filter_date_end); ?>">
                    </div>
                    <div class="form-group">
                        <button type="submit" class="btn btn-secondary"><i class="fas fa-filter"></i> Filter</button>
                    </div>
                    <div class="form-group">
                        <a href="logs" class="btn btn-secondary"><i class="fas fa-redo"></i> Reset</a>
                    </div>
                </form>
            </div>
        </div>

        <div class="card">
            <div class="card-header">
                <h3 style="display:inline-block; margin-right: 10px;">Daftar Log Aktivitas</h3>
                <?php if (!empty($logs)): // Hanya tampilkan tombol jika ada log ?>
                    <form method="POST" style="display:inline-block; float:right;" onsubmit="return confirm('PERINGATAN! Anda akan menghapus SELURUH log aktivitas. Tindakan ini TIDAK dapat dibatalkan. Lanjutkan?');"><?php if (!isset($_SESSION['csrf_token'])) { $_SESSION['csrf_token'] = bin2hex(random_bytes(32)); } ?><input type='hidden' name='csrf_token' value='<?php echo $_SESSION['csrf_token']; ?>'>
                        <input type="hidden" name="action" value="clear_all_activity_logs">
                        <button type="submit" class="btn btn-sm btn-warning"><i class="fas fa-eraser"></i> Hapus Log</button>
                    </form>
                <?php endif; ?>
            </div>
            <div class="card-body">
                <table class="data-table">
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>Timestamp</th>
                            <th>Username</th>
                            <th>Role</th>
                            <th>Tipe Aktivitas</th>
                            <th>Deskripsi</th>
                            <th>IP Address</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if (!empty($logs)): ?>
                            <?php foreach ($logs as $log): ?>
                                <tr>
                                    <td><?php echo htmlspecialchars($log['id']); ?></td>
                                    <td><?php echo htmlspecialchars($log['timestamp']); ?></td>
                                    <td><?php echo htmlspecialchars($log['username']); ?></td>
                                    <td><?php echo htmlspecialchars($log['role']); ?></td>
                                    <td><?php echo htmlspecialchars($log['activity_type']); ?></td>
                                    <td><?php echo htmlspecialchars($log['description']); ?></td>
                                    <td><?php echo htmlspecialchars($log['ip_address']); ?></td>
                                </tr>
                            <?php endforeach; ?>
                        <?php else: ?>
                            <tr><td colspan="7" style="text-align: center;">Tidak ada log aktivitas ditemukan.</td></tr>
                        <?php endif; ?>
                    </tbody>
                </table>

                <div class="pagination" style="margin-top: 20px; text-align: center;">
                    <?php if ($total_pages > 1): ?>
                        <?php
                        $query_params = $_GET; // Ambil semua parameter URL saat ini

                        // Fungsi helper untuk membuat URL pagination
                        function buildPaginationUrl($page_num, $query_params) {
                            $query_params['page'] = $page_num;
                            return 'logs?' . http_build_query($query_params);
                        }
                        ?>

                        <a href="<?php echo htmlspecialchars(buildPaginationUrl(1, $query_params), ENT_QUOTES, "UTF-8"); ?>" class="btn btn-sm <?php echo ($page == 1) ? 'disabled' : ''; ?>">First</a>
                        <a href="<?php echo htmlspecialchars(buildPaginationUrl($page - 1, $query_params), ENT_QUOTES, "UTF-8"); ?>" class="btn btn-sm <?php echo ($page <= 1) ? 'disabled' : ''; ?>">Previous</a>

                        <?php
                        $start_page = max(1, $page - 2);
                        $end_page = min($total_pages, $page + 2);

                        for ($i = $start_page; $i <= $end_page; $i++):
                        ?>
                            <a href="<?php echo htmlspecialchars(buildPaginationUrl($i, $query_params), ENT_QUOTES, "UTF-8"); ?>" class="btn btn-sm <?php echo ($i == $page) ? 'btn-primary' : ''; ?>">
                                <?php echo htmlspecialchars($i, ENT_QUOTES, "UTF-8"); ?>
                            </a>
                        <?php endfor; ?>

                        <a href="<?php echo htmlspecialchars(buildPaginationUrl($page + 1, $query_params), ENT_QUOTES, "UTF-8"); ?>" class="btn btn-sm <?php echo ($page >= $total_pages) ? 'disabled' : ''; ?>">Next</a>
                        <a href="<?php echo htmlspecialchars(buildPaginationUrl($total_pages, $query_params), ENT_QUOTES, "UTF-8"); ?>" class="btn btn-sm <?php echo ($page == $total_pages) ? 'disabled' : ''; ?>">Last</a>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
</div>

<?php include '../includes/footer.php'; ?>