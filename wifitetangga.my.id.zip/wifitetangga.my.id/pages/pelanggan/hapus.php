<?php
include '../../config/koneksi.php';

if (isset($_GET['id'])) {
    $id = (int)$_GET['id'];

    if ($id === 0) {
        $_SESSION['message'] = "ID Pelanggan tidak valid.";
        $_SESSION['message_type'] = "danger";
        header('Location: index.php');
        exit;
    }

    $query = "DELETE FROM pelanggan WHERE id = ?";
    $stmt = $koneksi->prepare($query);
    $stmt->bind_param("i", $id);

    if ($stmt->execute()) {
        $_SESSION['message'] = "Pelanggan berhasil dihapus!";
        $_SESSION['message_type'] = "success";
    } else {
        $_SESSION['message'] = "Gagal menghapus pelanggan: " . $stmt->error;
        $_SESSION['message_type'] = "danger";
    }
} else {
    $_SESSION['message'] = "Permintaan hapus tidak valid.";
    $_SESSION['message_type'] = "danger";
}

header('Location: index.php');
exit;
?>