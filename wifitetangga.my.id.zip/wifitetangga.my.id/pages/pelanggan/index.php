<?php
include '../../config/koneksi.php';
include '../../includes/header.php';

// Gabungkan tabel pelanggan dan paket untuk menampilkan nama paket
$query = "SELECT p.*, pk.nama_paket FROM pelanggan p LEFT JOIN paket pk ON p.id_paket = pk.id ORDER BY p.nama ASC";
$result = $koneksi->query($query);
?>

<div class="container">
    <h2>Manajemen Pelanggan</h2>
    <?php if (isset($_SESSION['message'])): ?>
        <div class="alert alert-<?php echo $_SESSION['message_type']; ?>">
            <?php echo $_SESSION['message']; unset($_SESSION['message']); unset($_SESSION['message_type']); ?>
        </div>
    <?php endif; ?>

    <div class="add-button-container">
        <a href="tambah.php" class="btn">Tambah Pelanggan Baru</a>
    </div>

    <table>
        <thead>
            <tr>
                <th>ID</th>
                <th>Nama</th>
                <th>Alamat</th>
                <th>Telepon</th>
                <th>Paket Internet</th>
                <th>Tanggal Aktif</th>
                <th>Status</th>
                <th>Aksi</th>
            </tr>
        </thead>
        <tbody>
            <?php if ($result->num_rows > 0): ?>
                <?php while ($row = $result->fetch_assoc()): ?>
                    <tr>
                        <td><?php echo htmlspecialchars($row['id']); ?></td>
                        <td><?php echo htmlspecialchars($row['nama']); ?></td>
                        <td><?php echo htmlspecialchars($row['alamat']); ?></td>
                        <td><?php echo htmlspecialchars($row['telepon']); ?></td>
                        <td><?php echo htmlspecialchars($row['nama_paket'] ?? 'Belum Ada Paket'); ?></td>
                        <td><?php echo htmlspecialchars($row['tanggal_aktif']); ?></td>
                        <td><?php echo htmlspecialchars(ucfirst($row['status'])); ?></td>
                        <td class="action-buttons">
                            <a href="edit.php?id=<?php echo $row['id']; ?>" class="btn btn-warning btn-edit">Edit</a>
                            <a href="hapus.php?id=<?php echo $row['id']; ?>" class="btn btn-danger btn-delete" onclick="return confirm('Yakin ingin menghapus pelanggan ini? Semua data pembayaran akan ikut terhapus!');">Hapus</a>
                        </td>
                    </tr>
                <?php endwhile; ?>
            <?php else: ?>
                <tr>
                    <td colspan="8" class="text-center">Belum ada data pelanggan.</td>
                </tr>
            <?php endif; ?>
        </tbody>
    </table>
</div>

<?php include '../../includes/footer.php'; ?>