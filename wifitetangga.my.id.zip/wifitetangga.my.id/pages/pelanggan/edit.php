<?php
include '../../config/koneksi.php';
include '../../includes/header.php';

$id = isset($_GET['id']) ? (int)$_GET['id'] : 0;

if ($id === 0) {
    $_SESSION['message'] = "ID Pelanggan tidak valid.";
    $_SESSION['message_type'] = "danger";
    header('Location: index.php');
    exit;
}

// Ambil data pelanggan yang akan diedit
$query_select_pelanggan = "SELECT * FROM pelanggan WHERE id = ?";
$stmt_select_pelanggan = $koneksi->prepare($query_select_pelanggan);
$stmt_select_pelanggan->bind_param("i", $id);
$stmt_select_pelanggan->execute();
$result_select_pelanggan = $stmt_select_pelanggan->get_result();

if ($result_select_pelanggan->num_rows === 0) {
    $_SESSION['message'] = "Pelanggan tidak ditemukan.";
    $_SESSION['message_type'] = "danger";
    header('Location: index.php');
    exit;
}
$pelanggan = $result_select_pelanggan->fetch_assoc();

// Ambil data paket untuk dropdown
$query_paket = "SELECT id, nama_paket, kecepatan, harga FROM paket ORDER BY nama_paket ASC";
$result_paket = $koneksi->query($query_paket);

if (isset($_POST['submit'])) {
    $nama = $koneksi->real_escape_string($_POST['nama']);
    $alamat = $koneksi->real_escape_string($_POST['alamat']);
    $telepon = $koneksi->real_escape_string($_POST['telepon']);
    $id_paket = $koneksi->real_escape_string($_POST['id_paket']);
    $tanggal_aktif = $koneksi->real_escape_string($_POST['tanggal_aktif']);
    $status = $koneksi->real_escape_string($_POST['status']);

    // Validasi sederhana
    if (empty($nama) || empty($alamat) || empty($telepon) || empty($id_paket) || empty($tanggal_aktif) || empty($status)) {
        $_SESSION['message'] = "Semua field harus diisi!";
        $_SESSION['message_type'] = "danger";
    } else {
        $query_update = "UPDATE pelanggan SET nama = ?, alamat = ?, telepon = ?, id_paket = ?, tanggal_aktif = ?, status = ? WHERE id = ?";
        $stmt_update = $koneksi->prepare($query_update);
        $stmt_update->bind_param("sssisdi", $nama, $alamat, $telepon, $id_paket, $tanggal_aktif, $status, $id);

        if ($stmt_update->execute()) {
            $_SESSION['message'] = "Pelanggan berhasil diperbarui!";
            $_SESSION['message_type'] = "success";
            header('Location: index.php');
            exit;
        } else {
            $_SESSION['message'] = "Gagal memperbarui pelanggan: " . $stmt_update->error;
            $_SESSION['message_type'] = "danger";
        }
    }
}
?>

<div class="container form-container">
    <h2>Edit Pelanggan</h2>
    <?php if (isset($_SESSION['message'])): ?>
        <div class="alert alert-<?php echo $_SESSION['message_type']; ?>">
            <?php echo $_SESSION['message']; unset($_SESSION['message']); unset($_SESSION['message_type']); ?>
        </div>
    <?php endif; ?>

    <form action="" method="POST"><?php if (!isset($_SESSION['csrf_token'])) { $_SESSION['csrf_token'] = bin2hex(random_bytes(32)); } ?><input type='hidden' name='csrf_token' value='<?php echo $_SESSION['csrf_token']; ?>'>
        <div class="form-group">
            <label for="nama">Nama Pelanggan:</label>
            <input type="text" id="nama" name="nama" value="<?php echo htmlspecialchars($pelanggan['nama']); ?>" required>
        </div>
        <div class="form-group">
            <label for="alamat">Alamat:</label>
            <textarea id="alamat" name="alamat" rows="3" required><?php echo htmlspecialchars($pelanggan['alamat']); ?></textarea>
        </div>
        <div class="form-group">
            <label for="telepon">Telepon:</label>
            <input type="text" id="telepon" name="telepon" value="<?php echo htmlspecialchars($pelanggan['telepon']); ?>" required>
        </div>
        <div class="form-group">
            <label for="id_paket">Pilih Paket:</label>
            <select id="id_paket" name="id_paket" required>
                <option value="">-- Pilih Paket --</option>
                <?php
                $current_paket_id = $pelanggan['id_paket'];
                while ($paket = $result_paket->fetch_assoc()):
                    $selected = ($paket['id'] == $current_paket_id) ? 'selected' : '';
                ?>
                    <option value="<?php echo htmlspecialchars($paket['id']); ?>" <?php echo htmlspecialchars($selected, ENT_QUOTES, "UTF-8"); ?>>
                        <?php echo htmlspecialchars($paket['nama_paket'] . ' (' . $paket['kecepatan'] . ' - Rp ' . number_format($paket['harga'], 0, ',', '.') . ')'); ?>
                    </option>
                <?php endwhile; ?>
            </select>
        </div>
        <div class="form-group">
            <label for="tanggal_aktif">Tanggal Aktif:</label>
            <input type="date" id="tanggal_aktif" name="tanggal_aktif" value="<?php echo htmlspecialchars($pelanggan['tanggal_aktif']); ?>" required>
        </div>
        <div class="form-group">
            <label for="status">Status:</label>
            <select id="status" name="status" required>
                <option value="aktif" <?php echo ($pelanggan['status'] == 'aktif') ? 'selected' : ''; ?>>Aktif</option>
                <option value="nonaktif" <?php echo ($pelanggan['status'] == 'nonaktif') ? 'selected' : ''; ?>>Nonaktif</option>
            </select>
        </div>
        <button type="submit" name="submit">Update Pelanggan</button>
        <a href="index.php" class="btn btn-danger">Batal</a>
    </form>
</div>

<?php include '../../includes/footer.php'; ?>