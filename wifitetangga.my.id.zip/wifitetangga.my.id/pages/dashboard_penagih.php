<?php
// C:\xampp\htdocs\billing_isp_app\pages\dashboard_penagih.php

// DEBUGGING AGRESIV: Pastikan semua error ditampilkan
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

// Coba tangkap fatal error juga
register_shutdown_function(function() {
    $error = error_get_last();
    if ($error && ($error['type'] === E_ERROR || $error['type'] === E_PARSE || $error['type'] === E_CORE_ERROR || $error['type'] === E_COMPILE_ERROR)) {
        echo "<div style='background-color: #fdd; border: 1px solid red; padding: 10px;'>";
        echo "<h2>Fatal Error Detected:</h2>";
        echo "<strong>Type:</strong> " . $error['type'] . "<br>";
        echo "<strong>Message:</strong> " . $error['message'] . "<br>";
        echo "<strong>File:</strong> " . $error['file'] . " (Line: " . $error['line'] . ")<br>";
        echo "</div>";
    }
});


ini_set('session.use_strict_mode', 1);
ini_set('session.cookie_httponly', 1);
ini_set('session.cookie_samesite', 'Lax');
if (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on') {
    ini_set('session.cookie_secure', 1);
}
session_start();
include '../config/koneksi.php'; // Pastikan path ini benar dan koneksi berhasil
include '../includes/header.php'; // Ini akan meng-include sidebar dan fungsi hasRole()

// Batasi akses ke halaman ini: hanya superadmin dan admin
if (!hasRole(['superadmin', 'admin'])) {
    header('Location: dashboard.php'); // Redirect ke dashboard atau halaman akses ditolak
    exit();
}

// --- Ambil parameter filter bulan dan tahun ---
// Default ke bulan dan tahun saat ini jika tidak ada di URL
$selected_year = $_GET['filter_year'] ?? date('Y');
$selected_month = $_GET['filter_month'] ?? date('m');

// Format YYYY-MM untuk query (digunakan untuk bulan_tagihan)
$filtered_month_year = $selected_year . '-' . sprintf('%02d', $selected_month); // Ensures MM is two digits

// Label untuk tampilan di halaman
$bulan_ini_label = date('F Y', strtotime($selected_year . '-' . $selected_month . '-01'));


// Ambil semua penagih yang aktif untuk dropdown filter
$all_penagih = [];
$query_all_penagih = "SELECT id_penagih, nama_penagih FROM penagih WHERE status_aktif = 'Aktif' ORDER BY nama_penagih ASC";
$result_all_penagih = $koneksi->query($query_all_penagih);
if ($result_all_penagih) {
    while ($row = $result_all_penagih->fetch_assoc()) {
        $all_penagih[] = $row;
    }
} else {
    error_log("Error fetching all penagih: " . $koneksi->error);
}


// Filter berdasarkan penagih yang dipilih
$selected_penagih_id = $_GET['penagih_id'] ?? '';
$where_penagih_clause_for_main_query = ''; // Clause for the main query's WHERE (penagih table)
$param_penagih_value_for_bind = []; // Array to store bind parameter values

if (!empty($selected_penagih_id)) {
    // This filter applies to the 'pn.id_penagih' in the main query's WHERE clause
    $where_penagih_clause_for_main_query = " AND pn.id_penagih = ?";
    $param_penagih_value_for_bind[] = $selected_penagih_id;
}


// --- Common Table Expression (CTE) for All Invoices (Regular and Manual) ---
// Ensure penagih_id is always part of the CTE for filtering purposes.
$cte_invoices = "
WITH CombinedInvoices AS (
    SELECT
        t.id_tagihan AS id,
        t.pelanggan_id,
        p.nama_pelanggan,
        p.alamat,
        p.telepon,
        pk.nama_paket,
        t.total_tagihan AS jumlah_tagihan_total,
        t.bulan_tagihan,
        t.tanggal_jatuh_tempo,
        t.status_tagihan,
        t.penagih_id,
        'regular' AS type_invoice
    FROM
        tagihan t
    JOIN
        pelanggan p ON t.pelanggan_id = p.id_pelanggan
    JOIN
        paket_layanan pk ON t.paket_id = pk.id_paket
    WHERE
        p.status_aktif = 'Aktif'
    
    UNION ALL
    
    SELECT
        tm.id_tagihan_manual AS id,
        NULL AS pelanggan_id, 
        tm.nama_pelanggan_manual AS nama_pelanggan,
        tm.alamat_manual AS alamat,
        tm.telepon_manual AS telepon,
        COALESCE(tm.nama_paket_manual, 'Manual Invoice') AS nama_paket,
        tm.jumlah_tagihan AS jumlah_tagihan_total,
        DATE_FORMAT(tm.tanggal_terbit, '%Y-%m') AS bulan_tagihan, 
        tm.tanggal_jatuh_tempo,
        tm.status_tagihan,
        tm.penagih_id, 
        'manual' AS type_invoice
    FROM
        tagihan_manual tm
    WHERE 1
)
";


// 1. Total Tagihan Belum Lunas bulan ini per Penagih (menggunakan CTE CombinedInvoices)
$tagihan_belum_lunas_per_penagih = [];
$query_tagihan_belum_lunas = $cte_invoices . "
    SELECT
        pn.id_penagih,
        pn.nama_penagih,
        COUNT(DISTINCT ci.pelanggan_id) AS total_pelanggan_belum_lunas_reguler,
        COUNT(DISTINCT CASE WHEN ci.type_invoice = 'manual' THEN ci.id ELSE NULL END) AS total_pelanggan_belum_lunas_manual,
        COALESCE(SUM(ci.jumlah_tagihan_total), 0) AS total_nominal_belum_lunas
    FROM
        penagih pn
    LEFT JOIN
        CombinedInvoices ci 
        ON pn.id_penagih = ci.penagih_id
        AND ci.bulan_tagihan = ? -- Filter by selected month-year
        AND ci.status_tagihan = 'Belum Lunas'
    WHERE
        pn.status_aktif = 'Aktif'
        " . $where_penagih_clause_for_main_query . "
    GROUP BY
        pn.id_penagih, pn.nama_penagih
    ORDER BY
        pn.nama_penagih ASC
";

$stmt_belum_lunas_penagih = $koneksi->prepare($query_tagihan_belum_lunas);
if ($stmt_belum_lunas_penagih === false) {
    error_log("Prepare failed for tagihan_belum_lunas: " . $koneksi->error);
    $tagihan_belum_lunas_per_penagih = [];
} else {
    $bind_args = array_merge([$filtered_month_year], $param_penagih_value_for_bind); // Use filtered_month_year
    $bind_types = "s"; 
    if (!empty($param_penagih_value_for_bind)) {
        $bind_types .= str_repeat('i', count($param_penagih_value_for_bind));
    }

    $refs = [];
    foreach($bind_args as $key => $value) {
        $refs[$key] = &$bind_args[$key];
    }
    call_user_func_array([$stmt_belum_lunas_penagih, 'bind_param'], array_merge([$bind_types], $refs));

    if ($stmt_belum_lunas_penagih->execute()) {
        $result_belum_lunas_penagih = $stmt_belum_lunas_penagih->get_result();
        while ($row = $result_belum_lunas_penagih->fetch_assoc()) {
            $tagihan_belum_lunas_per_penagih[] = $row;
        }
    } else {
        error_log("Execute failed for tagihan_belum_lunas: " . $stmt_belum_lunas_penagih->error);
    }
    $stmt_belum_lunas_penagih->close();
}


// 2. Total Pembayaran Lunas bulan ini per Penagih (menggunakan CTE CombinedInvoices)
$pembayaran_lunas_per_penagih = [];
$query_pembayaran_lunas = $cte_invoices . "
    SELECT
        pn.id_penagih,
        pn.nama_penagih,
        COUNT(DISTINCT ci.pelanggan_id) AS total_pelanggan_lunas_reguler,
        COUNT(DISTINCT CASE WHEN ci.type_invoice = 'manual' THEN ci.id ELSE NULL END) AS total_pelanggan_lunas_manual,
        COALESCE(SUM(ci.jumlah_tagihan_total), 0) AS total_nominal_lunas
    FROM
        penagih pn
    LEFT JOIN
        CombinedInvoices ci 
        ON pn.id_penagih = ci.penagih_id
        AND ci.bulan_tagihan = ? -- Filter by selected month-year
        AND ci.status_tagihan = 'Lunas'
    WHERE
        pn.status_aktif = 'Aktif'
        " . $where_penagih_clause_for_main_query . "
    GROUP BY
        pn.id_penagih, pn.nama_penagih
    ORDER BY
        pn.nama_penagih ASC
";

$stmt_lunas_penagih = $koneksi->prepare($query_pembayaran_lunas);
if ($stmt_lunas_penagih === false) {
    error_log("Prepare failed for pembayaran_lunas: " . $koneksi->error);
    $pembayaran_lunas_per_penagih = [];
} else {
    $bind_args_lunas = array_merge([$filtered_month_year], $param_penagih_value_for_bind); // Use filtered_month_year
    $bind_types_lunas = "s"; 
    if (!empty($param_penagih_value_for_bind)) {
        $bind_types_lunas .= str_repeat('i', count($param_penagih_value_for_bind));
    }

    $refs_lunas = [];
    foreach($bind_args_lunas as $key => $value) {
        $refs_lunas[$key] = &$bind_args_lunas[$key];
    }
    call_user_func_array([$stmt_lunas_penagih, 'bind_param'], array_merge([$bind_types_lunas], $refs_lunas));

    if ($stmt_lunas_penagih->execute()) {
        $result_lunas_penagih = $stmt_lunas_penagih->get_result();
        while ($row = $result_lunas_penagih->fetch_assoc()) {
            $pembayaran_lunas_per_penagih[] = $row;
        }
    } else {
        error_log("Execute failed for pembayaran_lunas: " . $stmt_lunas_penagih->error);
    }
    $stmt_lunas_penagih->close();
}


// Gabungkan data untuk ditampilkan
$merged_penagih_data = [];
foreach ($all_penagih as $penagih) {
    $id = $penagih['id_penagih'];
    $nama = $penagih['nama_penagih'];

    // Temukan data belum lunas untuk penagih ini
    $belum_lunas_data = null;
    foreach ($tagihan_belum_lunas_per_penagih as $item) {
        if ($item['id_penagih'] == $id) {
            $belum_lunas_data = $item;
            break;
        }
    }

    // Temukan data lunas untuk penagih ini
    $lunas_data = null;
    foreach ($pembayaran_lunas_per_penagih as $item) {
        if ($item['id_penagih'] == $id) {
            $lunas_data = $item;
            break;
        }
    }

    $merged_penagih_data[] = [
        'id_penagih' => $id,
        'nama_penagih' => $nama,
        'total_pelanggan_belum_lunas' => ($belum_lunas_data['total_pelanggan_belum_lunas_reguler'] ?? 0) + ($belum_lunas_data['total_pelanggan_belum_lunas_manual'] ?? 0),
        'total_nominal_belum_lunas' => $belum_lunas_data['total_nominal_belum_lunas'] ?? 0,
        'total_pelanggan_lunas' => ($lunas_data['total_pelanggan_lunas_reguler'] ?? 0) + ($lunas_data['total_pelanggan_lunas_manual'] ?? 0),
        'total_nominal_lunas' => $lunas_data['total_nominal_lunas'] ?? 0,
    ];
}


// Ambil daftar pelanggan yang belum lunas (detail tabel) - menggunakan CTE CombinedInvoices
$pelanggan_belum_lunas_detail = [];
$query_pelanggan_belum_lunas_detail = $cte_invoices . "
    SELECT
        ci.id,
        ci.pelanggan_id,
        ci.nama_pelanggan,
        ci.alamat,
        ci.telepon,
        ci.nama_paket,
        ci.jumlah_tagihan_total AS total_tagihan,
        ci.tanggal_jatuh_tempo,
        ci.type_invoice
    FROM
        CombinedInvoices ci
    WHERE
        ci.bulan_tagihan = ? -- Filter by selected month-year
        AND ci.status_tagihan = 'Belum Lunas'
        AND ci.penagih_id IS NOT NULL " . // Only show invoices assigned to a collector
        // Apply filter for selected_penagih_id to this query as well
        (!empty($selected_penagih_id) ? " AND ci.penagih_id = ?" : "") . "
    ORDER BY
        ci.nama_pelanggan ASC
";
$stmt_pelanggan_belum_lunas_detail = $koneksi->prepare($query_pelanggan_belum_lunas_detail);

if ($stmt_pelanggan_belum_lunas_detail === false) {
    error_log("Prepare failed for pelanggan_belum_lunas_detail: " . $koneksi->error);
    $pelanggan_belum_lunas_detail = [];
} else {
    $bind_args_detail = [$filtered_month_year]; // Use filtered_month_year
    $bind_types_detail = "s";

    // If a penagih is selected, add its ID to the bind parameters
    if (!empty($selected_penagih_id)) {
        $bind_args_detail[] = $selected_penagih_id;
        $bind_types_detail .= "i";
    }

    $refs_detail = [];
    foreach($bind_args_detail as $key => $value) {
        $refs_detail[$key] = &$bind_args_detail[$key];
    }
    call_user_func_array([$stmt_pelanggan_belum_lunas_detail, 'bind_param'], array_merge([$bind_types_detail], $refs_detail));

    if ($stmt_pelanggan_belum_lunas_detail->execute()) {
        $result_pelanggan_belum_lunas_detail = $stmt_pelanggan_belum_lunas_detail->get_result();
        while ($row = $result_pelanggan_belum_lunas_detail->fetch_assoc()) {
            $pelanggan_belum_lunas_detail[] = $row;
        }
    } else {
        error_log("Execute failed for pelanggan_belum_lunas_detail: " . $stmt_pelanggan_belum_lunas_detail->error);
    }
    $stmt_pelanggan_belum_lunas_detail->close();
}


?>

<div class="main-content">
    <div class="top-header">
        <div class="alert-message">
            Ringkasan kinerja penagih untuk bulan ini.
        </div>
        <div class="welcome-message">
            <span>Selamat datang, <?php echo htmlspecialchars($_SESSION['username'] ?? 'User'); ?>!</span>
            <a href="../logout.php" class="btn-logout">Logout</a>
        </div>
    </div>

    <div class="container">
        <h2>Dashboard Penagih - <?php echo htmlspecialchars($bulan_ini_label, ENT_QUOTES, "UTF-8"); ?></h2>
        <div class="print-button-container" style="text-align: right; margin-bottom: 20px;">
            <div class="print-button-container" style="text-align: right; margin-bottom: 20px;">
                <a href="print_penagih.php?filter_year=<?php echo htmlspecialchars($selected_year); ?>&filter_month=<?php echo htmlspecialchars($selected_month); ?><?php echo !empty($selected_penagih_id) ? '&penagih_id=' . htmlspecialchars($selected_penagih_id) : ''; ?>" target="_blank" class="btn-action bg-blue">
                  <i class="fas fa-print"></i> Cetak Laporan
                </a>
            </div>
        </div>

        <div class="card" style="margin-bottom: 20px;">
            <div class="card-header">
                <h3>Filter Penagih</h3>
            </div>
            <div class="card-body">
                <form method="GET" action="dashboard_penagih.php">
                    <div class="form-group" style="display: flex; gap: 10px; align-items: center; flex-wrap: wrap;">
                        <label for="filter_month">Bulan:</label>
                        <select id="filter_month" name="filter_month" style="padding: 8px; border-radius: 4px; border: 1px solid #ddd;">
                            <?php
                            $months = [
                                1 => 'Januari', 2 => 'Februari', 3 => 'Maret', 4 => 'April',
                                5 => 'Mei', 6 => 'Juni', 7 => 'Juli', 8 => 'Agustus',
                                9 => 'September', 10 => 'Oktober', 11 => 'November', 12 => 'Desember'
                            ];
                            foreach ($months as $num => $name) {
                                $selected = ($selected_month == $num) ? 'selected' : '';
                                echo "<option value='{$num}' {$selected}>{$name}</option>";
                            }
                            ?>
                        </select>

                        <label for="filter_year">Tahun:</label>
                        <select id="filter_year" name="filter_year" style="padding: 8px; border-radius: 4px; border: 1px solid #ddd;">
                            <?php
                            $current_year = date('Y');
                            for ($year = $current_year - 2; $year <= $current_year + 1; $year++) { // Tampilkan 3 tahun ke belakang dan 1 tahun ke depan
                                $selected = ($selected_year == $year) ? 'selected' : '';
                                echo "<option value='{$year}' {$selected}>{$year}</option>";
                            }
                            ?>
                        </select>

                        <label for="penagih_id">Pilih Penagih:</label>
                        <select id="penagih_id" name="penagih_id" style="padding: 8px; border-radius: 4px; border: 1px solid #ddd;">
                            <option value="">-- Semua Penagih --</option>
                            <?php foreach ($all_penagih as $penagih_option): ?>
                                <option value="<?php echo htmlspecialchars($penagih_option['id_penagih']); ?>"
                                    <?php echo ($selected_penagih_id == $penagih_option['id_penagih']) ? 'selected' : ''; ?>>
                                    <?php echo htmlspecialchars($penagih_option['nama_penagih']); ?>
                                </option>
                            <?php endforeach; ?>
                        </select>
                        <button type="submit" class="btn btn-secondary btn-sm" style="padding: 8px 12px;"><i class="fas fa-filter"></i> Filter</button>
                        <a href="dashboard_penagih.php" class="btn btn-secondary btn-sm" style="padding: 8px 12px;"><i class="fas fa-redo"></i> Reset</a>
                    </div>
                </form>
            </div>
        </div>

        <div class="dashboard-grid">
            <?php if (!empty($merged_penagih_data)): ?>
                <?php foreach ($merged_penagih_data as $data): ?>
                <div class="info-card bg-white">
                    <h3>Kinerja <?php echo htmlspecialchars($data['nama_penagih']); ?> <i class="icon-placeholder fas fa-user-circle"></i></h3>
                    <div class="value-label">Pelanggan Belum Lunas</div>
                    <div class="card-value status-red" style="font-size: 1.6em;"><?php echo $data['total_pelanggan_belum_lunas']; ?></div>
                    <div class="value-label">Nominal Belum Lunas</div>
                    <div class="value-amount expense"><span class="nominal-value">Rp <?php echo number_format($data['total_nominal_belum_lunas'] ?? 0, 0, ',', '.'); ?></span></div>

                    <div class="value-label">Pelanggan Lunas</div>
                    <div class="card-value status-green" style="font-size: 1.6em;"><?php echo $data['total_pelanggan_lunas']; ?></div>
                    <div class="value-label">Nominal Lunas</div>
                    <div class="value-amount balance"><span class="nominal-value">Rp <?php echo number_format($data['total_nominal_lunas'] ?? 0, 0, ',', '.'); ?></span></div>

                    <div class="card-footer">
                        <a href="manajemen_pelanggan.php?penagih_id=<?php echo $data['id_penagih']; ?>&status_aktif_dropdown=Aktif&status_bayar_bulan_ini=Belum Lunas" class="btn-detail bg-blue">Lihat Pelanggan &#10140;</a>
                    </div>
                </div>
                <?php endforeach; ?>
            <?php else: ?>
                <div class="info-card bg-secondary" style="grid-column: 1 / -1; text-align: center;">
                    <h3>Tidak ada data penagih atau tagihan untuk bulan ini.</h3>
                </div>
            <?php endif; ?>
        </div>

        <div class="card" style="margin-top: 20px;">
            <div class="card-header">
                <h3>Daftar Tagihan Belum Lunas (<?php echo htmlspecialchars($bulan_ini_label, ENT_QUOTES, "UTF-8"); ?>)</h3>
            </div>
            <div class="card-body">
                <table class="data-table">
                    <thead>
                        <tr>
                            <th>ID Invoice</th>
                            <th>Tipe Invoice</th>
                            <th>ID Pelanggan</th>
                            <th>Nama Pelanggan</th>
                            <th>Alamat</th>
                            <th>Telepon</th>
                            <th>Paket</th>
                            <th>Total Tagihan</th>
                            <th>Jatuh Tempo</th>
                            <th>Aksi</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if (!empty($pelanggan_belum_lunas_detail)): ?>
                            <?php foreach ($pelanggan_belum_lunas_detail as $tagihan_detail): ?>
                                <tr>
                                    <td>
                                        <?php 
                                            // Menampilkan ID Tagihan sesuai dengan tipenya
                                            echo htmlspecialchars($tagihan_detail['type_invoice'] === 'manual' ? 
                                                'MAN-' . $tagihan_detail['id'] : $tagihan_detail['id']); 
                                        ?>
                                    </td>
                                    <td>
                                        <span class="status-badge 
                                            <?php echo ($tagihan_detail['type_invoice'] === 'manual' ? 'status-info' : 'status-default'); ?>">
                                            <?php echo htmlspecialchars($tagihan_detail['type_invoice'] === 'manual' ? 'Manual' : 'Reguler'); ?>
                                        </span>
                                    </td>
                                    <td><?php echo htmlspecialchars($tagihan_detail['pelanggan_id'] ?? 'N/A'); ?></td>
                                    <td><?php echo htmlspecialchars($tagihan_detail['nama_pelanggan']); ?></td>
                                    <td><?php echo htmlspecialchars($tagihan_detail['alamat']); ?></td>
                                    <td><?php echo htmlspecialchars($tagihan_detail['telepon']); ?></td>
                                    <td><?php echo htmlspecialchars($tagihan_detail['nama_paket']); ?></td>
                                    <td>Rp <?php echo number_format($tagihan_detail['total_tagihan'], 0, ',', '.'); ?></td>
                                    <td><?php echo htmlspecialchars(date('d-m-Y', strtotime($tagihan_detail['tanggal_jatuh_tempo']))); ?></td>
                                    <td>
                                        <a href="pembayaran.php?tab=belumLunas&pelanggan_id=<?php echo htmlspecialchars($tagihan_detail['pelanggan_id'] ?? ''); ?>&tagihan_id=<?php echo htmlspecialchars($tagihan_detail['id']); ?>" class="btn-action btn-info" title="Bayar Tagihan"><i class="fas fa-money-bill-wave"></i> Bayar</a>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        <?php else: ?>
                            <tr><td colspan="10" style="text-align: center;">Tidak ada pelanggan dengan tagihan belum lunas untuk bulan ini.</td></tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>

    </div>
</div>

<script>
// JavaScript untuk fungsionalitas sembunyikan/tampilkan nominal (jika digunakan)
document.addEventListener('DOMContentLoaded', function() {
    var toggleBtns = document.querySelectorAll('.toggle-nominal-btn');

    toggleBtns.forEach(function(toggleBtn) {
        var card = toggleBtn.closest('.info-card');
        var nominalValues = card.querySelectorAll('.nominal-value');
        var eyeIcon = toggleBtn.querySelector('i');

        // Gunakan ID unik untuk setiap card untuk menyimpan state di localStorage
        var cardId = card.id || 'card_' + Math.random().toString(36).substr(2, 9); // Fallback ID
        var isNominalHiddenKey = 'isNominalHidden_' + cardId;

        var isHidden = localStorage.getItem(isNominalHiddenKey) === 'true';

        function toggleNominalVisibility(shouldHide) {
            nominalValues.forEach(function(element) {
                var originalText = element.dataset.originalText;
                if (!originalText) {
                    element.dataset.originalText = element.textContent;
                    originalText = element.textContent;
                }

                if (shouldHide) {
                    var rpPrefix = originalText.substring(0, originalText.indexOf('Rp') + 3);
                    var numericPart = originalText.substring(originalText.indexOf('Rp') + 3).trim();
                    var hiddenText = numericPart.replace(/[\d]/g, '*');
                    hiddenText = hiddenText.replace(/[,.]/g, function(match) { return match === ',' ? ',' : '.'; });

                    element.textContent = rpPrefix + hiddenText;
                    eyeIcon.classList.remove('fas', 'fa-eye');
                    eyeIcon.classList.add('fas', 'fa-eye-slash');
                } else {
                    element.textContent = originalText;
                    eyeIcon.classList.remove('fas', 'fa-eye-slash');
                    eyeIcon.classList.add('fas', 'fa-eye');
                }
            });
            localStorage.setItem(isNominalHiddenKey, shouldHide);
        }

        toggleNominalVisibility(isHidden);

        toggleBtn.addEventListener('click', function() {
            isHidden = !isHidden;
            toggleNominalVisibility(isHidden);
        });
    });
});
</script>

<?php include '../includes/footer.php'; ?>