<?php
// C:\xampp\htdocs\billing_isp_app\pages\get_sisa_tagihan.php
include '../config/koneksi.php'; // Pastikan path ini benar

header('Content-Type: application/json');

$pelanggan_id = $_GET['pelanggan_id'] ?? null;
$bulan_tagihan = $_GET['bulan_tagihan'] ?? null;

$response = [
    'sisa_tagihan' => null,
    'error' => null
];

if (!$pelanggan_id || !$bulan_tagihan) {
    $response['error'] = 'Parameter pelanggan_id atau bulan_tagihan tidak lengkap.';
    echo json_encode($response);
    exit();
}

// Ambil sisa_tagihan dari tagihan yang belum lunas untuk bulan dan pelanggan tertentu
$stmt = $koneksi->prepare("SELECT t.sisa_tagihan, t.jumlah_tagihan, p.uses_ppn 
                           FROM tagihan t 
                           JOIN pelanggan p ON t.pelanggan_id = p.id_pelanggan
                           WHERE t.pelanggan_id = ? AND t.bulan_tagihan = ? AND t.status_tagihan = 'Belum Lunas' LIMIT 1");

if ($stmt) {
    $stmt->bind_param("is", $pelanggan_id, $bulan_tagihan);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        $row = $result->fetch_assoc();
        $sisa_tagihan_dari_db = $row['sisa_tagihan'];
        $jumlah_tagihan_asli = $row['jumlah_tagihan']; // Harga dasar dari DB
        $uses_ppn = $row['uses_ppn'];
        $ppn_percentage = 0.11;

        // Jika sisa_tagihan di DB null, hitung total awal (harga dasar + PPN) sebagai sisa
        if (is_null($sisa_tagihan_dari_db)) {
            $total_seharusnya = $jumlah_tagihan_asli;
            if ($uses_ppn == 1) {
                $total_seharusnya += ($jumlah_tagihan_asli * $ppn_percentage);
            }
            $response['sisa_tagihan'] = $total_seharusnya;
        } else {
            $response['sisa_tagihan'] = (float)$sisa_tagihan_dari_db;
        }
    } else {
        // Tagihan belum lunas untuk bulan tersebut tidak ditemukan
        // Ini bisa berarti tagihan sudah lunas, atau belum dibuat.
        // Untuk tujuan pengisian form, kita mungkin ingin default ke harga paket penuh (termasuk PPN)
        // Dapatkan harga paket penuh untuk pelanggan ini
        $stmt_get_full_price = $koneksi->prepare("SELECT pk.harga, p.uses_ppn FROM pelanggan p JOIN paket_layanan pk ON p.paket_id = pk.id_paket WHERE p.id_pelanggan = ?");
        $stmt_get_full_price->bind_param("i", $pelanggan_id);
        $stmt_get_full_price->execute();
        $price_result = $stmt_get_full_price->get_result();
        if ($price_result->num_rows > 0) {
            $price_data = $price_result->fetch_assoc();
            $base_price = $price_data['harga'];
            $uses_ppn_customer = $price_data['uses_ppn'];
            $full_amount = $base_price;
            if ($uses_ppn_customer == 1) {
                $full_amount += ($base_price * $ppn_percentage);
            }
            $response['sisa_tagihan'] = $full_amount;
        } else {
            $response['sisa_tagihan'] = 0; // Pelanggan atau paket tidak ditemukan
        }
        $stmt_get_full_price->close();
    }
    $stmt->close();
} else {
    $response['error'] = 'Gagal menyiapkan statement: ' . $koneksi->error;
}

$koneksi->close();
echo json_encode($response);
?>