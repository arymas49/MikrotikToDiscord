<?php
// C:\xampp\htdocs\billing_isp_app\pages\pembayaran.php
ob_start(); // Aktifkan output buffering
ini_set('session.use_strict_mode', 1);
ini_set('session.cookie_httponly', 1);
ini_set('session.cookie_samesite', 'Lax');
if (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on') {
    ini_set('session.cookie_secure', 1);
}
session_start();
session_regenerate_id(true);
include '../config/koneksi.php';
include '../includes/header.php'; // Header akan meng-include sidebar dan fungsi hasRole()

// Fungsi untuk mendapatkan token CSRF (jika belum ada, buat yang baru)
function get_csrf_token() {
    if (empty($_SESSION['csrf_token'])) {
        $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
    }
    return $_SESSION['csrf_token'];
}

// Batasi akses ke halaman ini: hanya superadmin dan admin
if (!hasRole(['superadmin', 'admin'])) {
    header('Location: dashboard.php'); // Redirect ke dashboard atau halaman akses ditolak
    exit();
}

// Ambil CSRF token untuk digunakan di HTML/JavaScript
$csrf_token = get_csrf_token();

// --- Proactively unset common notification parameters from $_GET
// This ensures that these parameters are not present in the $_GET array
// when PHP generates URLs, unless they are specifically re-added (like msg_original).
unset($_GET['msg']);
unset($_GET['new_status']);
unset($_GET['count']);
unset($_GET['err']);
unset($_GET['detail']);
// --- END unset common notification parameters ---

$message_script = ''; // Variabel baru untuk menampung script notifikasi JS

$current_month_year = date('Y-m'); // FormatYYYY-MM untuk bulan saat ini

// --- Konfigurasi WhatsApp Gateway (untuk pesan pengingat default) ---
$whatsapp_config_path = '../config/whatsapp_config.php';
$whatsapp_config = [];
if (file_exists($whatsapp_config_path)) {
    $whatsapp_config = include $whatsapp_config_path;
}

// Definisikan template pesan default di PHP
// UBAH BARIS INI: Tambahkan [invoice_link_internal] untuk link PDF
$default_reminder_message_template_php = "Yth. [nama_pelanggan],\n\nTagihan internet Anda untuk bulan [bulan] sebesar Rp [jumlah] telah jatuh tempo pada tanggal [jatuh_tempo].\n\nMohon segera lunasi untuk menghindari pemutusan layanan. Anda dapat melihat detail tagihan di:\nLink Invoice (PDF): [invoice_link_internal]\nLink Pembayaran Online: [xendit_link]\n\nTerima kasih atas perhatiannya.";

// Dapatkan app_base_url dan api_access_token untuk link cetak
$app_base_url_for_print = $whatsapp_config['app_base_url'] ?? '';
$api_access_token_for_print = $whatsapp_config['api_access_token'] ?? '';

// --- Menampilkan Pesan Setelah Redirect (GET) ---
// We use 'msg_original' to differentiate from 'msg' that might be part of filters.
// This ensures the notification is only displayed once after a relevant action.
if (isset($_GET['msg_original'])) {
    if ($_GET['msg_original'] == 'payment_success') {
        $message_script = "showNotification('" . htmlspecialchars($_GET['detail_original'] ?? 'Pembayaran berhasil dicatat.', ENT_QUOTES, 'UTF-8') . "', 'success');";
    } elseif ($_GET['msg_original'] == 'payment_fail') {
        $error_detail = $_GET['err_original'] ?? 'Terjadi kesalahan tidak diketahui.';
        $message_script = "showNotification('Gagal mencatat pembayaran: " . htmlspecialchars($error_detail, ENT_QUOTES, 'UTF-8') . "', 'error');";
    } elseif ($_GET['msg_original'] == 'delete_payment_success') {
        $message_script = "showNotification('" . htmlspecialchars($_GET['detail_original'] ?? 'Pembayaran berhasil dihapus dan tagihan diperbarui.', ENT_QUOTES, 'UTF-8') . "', 'success');";
    } elseif ($_GET['msg_original'] == 'delete_payment_fail') {
        $error_detail = $_GET['err_original'] ?? 'Terjadi kesalahan tidak diketahui.';
        $message_script = "showNotification('Gagal menghapus pembayaran: " . htmlspecialchars($error_detail, ENT_QUOTES, 'UTF-8') . "', 'error');";
    } elseif ($_GET['msg_original'] == 'delete_tagihan_success') {
        $message_script = "showNotification('Tagihan berhasil dihapus.', 'success');";
    } elseif ($_GET['msg_original'] == 'delete_tagihan_fail') {
        $error_detail = $_GET['err_original'] ?? 'Terjadi kesalahan tidak diketahui.';
        $message_script = "showNotification('Gagal menghapus tagihan: " . htmlspecialchars($error_detail, ENT_QUOTES, 'UTF-8') . "', 'error');";
    } elseif ($_GET['msg_original'] == 'warning') {
        $warning_detail = $_GET['err_original'] ?? 'Terjadi peringatan.';
        $message_script = "showNotification('Peringatan: " . htmlspecialchars($warning_detail, ENT_QUOTES, 'UTF-8') . "', 'warning');";
    }
    // After the notification is displayed, clear the 'original' parameters from the URL history
    // to prevent them from showing up again on manual refresh or back/forward navigation.
    $message_script .= "
        if (window.history.replaceState) {
            const url = new URL(window.location.href);
            url.searchParams.delete('msg_original');
            url.searchParams.delete('new_status_original');
            url.searchParams.delete('count_original');
            url.searchParams.delete('err_original');
            url.searchParams.delete('detail_original');
            window.history.replaceState({path: url.href}, '', url.href);
        }
    ";
}


// --- Tangkap parameter filter dari URL ---
$filter_pelanggan_id = $_GET['pelanggan_id'] ?? null;
$filter_pelanggan_nama = ''; // Untuk ditampilkan di header tabel
$filter_status = $_GET['status'] ?? ''; // Filter dari dashboard (lunas/belum_lunas)

// NEW: Filter pencarian nama pelanggan
$filter_nama_pelanggan_riwayat = $_GET['filter_nama_pelanggan_riwayat'] ?? ''; // Untuk tab Riwayat Pembayaran
$filter_nama_pelanggan_bl = $_GET['filter_nama_pelanggan_bl'] ?? '';        // Untuk tab Belum Lunas

// Filter tanggal untuk Riwayat Pembayaran
$filter_tgl_mulai_riwayat = $_GET['filter_tgl_mulai_riwayat'] ?? '';
$filter_tgl_akhir_riwayat = $_GET['filter_tgl_akhir_riwayat'] ?? '';

// Filter tanggal terbit untuk Belum Lunas
$filter_tgl_terbit_mulai_bl = $_GET['filter_tgl_terbit_mulai_bl'] ?? '';
$filter_tgl_terbit_akhir_bl = $_GET['filter_tgl_terbit_akhir_bl'] ?? '';

// NEW: Filter berdasarkan penagih di halaman pembayaran
$filter_penagih_id_bl = $_GET['filter_penagih_id_bl'] ?? ''; // Untuk tab Belum Lunas
$filter_penagih_id_riwayat = $_GET['filter_penagih_id_riwayat'] ?? ''; // Untuk tab Riwayat

// New: Sorting parameters for Riwayat Pembayaran
$sort_column_riwayat = $_GET['sort_column_riwayat'] ?? 'py.tanggal_bayar'; // Default sort column
$sort_order_riwayat = $_GET['sort_order_riwayat'] ?? 'DESC'; // Default sort order

// Validate sort column for Riwayat Pembayaran
$allowed_sort_columns_riwayat = [
    'py.id_pembayaran',
    'p.nama_pelanggan',
    'pk.nama_paket',
    'coll.nama_penagih', // NEW: Tambahkan nama penagih
    'py.bulan_tagihan',
    'py.tanggal_bayar',
    'py.jumlah_bayar',
    'py.metode_pembayaran',
    'py.status_pembayaran'
];
if (!in_array($sort_column_riwayat, $allowed_sort_columns_riwayat)) {
    $sort_column_riwayat = 'py.tanggal_bayar';
}

// New: Sorting parameters for Tagihan Belum Lunas
$sort_column_belum_lunas = $_GET['sort_column_belum_lunas'] ?? 't.bulan_tagihan'; // Default sort column
$sort_order_belum_lunas = $_GET['sort_order_belum_lunas'] ?? 'ASC'; // Default sort order

// Validate sort column for Tagihan Belum Lunas
$allowed_sort_columns_belum_lunas = [
    't.id_tagihan',
    't.pelanggan_id',
    'p.nama_pelanggan',
    'p.alamat',
    'p.telepon',
    'coll.nama_penagih', // NEW: Tambahkan nama penagih
    'pk.nama_paket',
    't.jumlah_tagihan',
    't.bulan_tagihan',
    't.tanggal_terbit',
    't.tanggal_jatuh_tempo'
];
if (!in_array($sort_column_belum_lunas, $allowed_sort_columns_belum_lunas)) {
    $sort_column_belum_lunas = 't.bulan_tagihan';
}

// Validate sort order for both
if (!in_array(strtoupper($sort_order_riwayat), ['ASC', 'DESC'])) {
    $sort_order_riwayat = 'DESC';
}
if (!in_array(strtoupper($sort_order_belum_lunas), ['ASC', 'DESC'])) {
    $sort_order_belum_lunas = 'ASC';
}


if ($filter_pelanggan_id) {
    $stmt_nama_pelanggan = $koneksi->prepare("SELECT nama_pelanggan FROM pelanggan WHERE id_pelanggan = ?");
    if ($stmt_nama_pelanggan) {
        $stmt_nama_pelanggan->bind_param("i", $filter_pelanggan_id);
        $stmt_nama_pelanggan->execute();
        $result_nama_pelanggan = $stmt_nama_pelanggan->get_result();
        if ($result_nama_pelanggan->num_rows > 0) {
            $filter_pelanggan_nama = $result_nama_pelanggan->fetch_assoc()['nama_pelanggan'];
        }
        $stmt_nama_pelanggan->close();
    } else {
        error_log("Failed to prepare statement for nama_pelanggan: " . $koneksi->error);
    }
}


// --- Logika Hapus Pembayaran (yang sudah lunas) ---
if (isset($_GET['action']) && $_GET['action'] == 'delete_payment' && isset($_GET['id'])) {
    if (!hasRole('superadmin')) {
        header('Location: pembayaran.php?msg_original=delete_payment_fail&err_original=' . urlencode("Anda tidak memiliki izin untuk menghapus pembayaran. Hanya Superadmin yang dapat melakukan aksi ini."));
        ob_end_clean();
        exit();
    } else {
        $id_pembayaran_to_delete = $koneksi->real_escape_string($_GET['id']);
        
        // Dapatkan detail pembayaran yang akan dihapus
        $stmt_get_payment_detail = $koneksi->prepare("SELECT pelanggan_id, bulan_tagihan, jumlah_bayar FROM pembayaran WHERE id_pembayaran = ?");
        if (!$stmt_get_payment_detail) {
            header('Location: pembayaran.php?msg_original=delete_payment_fail&err_original=' . urlencode("Prepare get payment detail failed: " . $koneksi->error));
            ob_end_clean();
            exit();
        } else {
            $stmt_get_payment_detail->bind_param("i", $id_pembayaran_to_delete);
            $stmt_get_payment_detail->execute();
            $payment_detail = $stmt_get_payment_detail->get_result()->fetch_assoc();
            $stmt_get_payment_detail->close();

            if ($payment_detail) {
                $pelanggan_id_terkait = $payment_detail['pelanggan_id'];
                $bulan_tagihan_terkait = $payment_detail['bulan_tagihan'];
                $jumlah_bayar_dihapus = (float)$payment_detail['jumlah_bayar']; // Pastikan float

                // Hapus pembayaran dari tabel pembayaran
                $koneksi->begin_transaction(); // Mulai transaksi
                
                try {
                    $stmt_delete_payment = $koneksi->prepare("DELETE FROM pembayaran WHERE id_pembayaran = ?");
                    if (!$stmt_delete_payment) {
                        throw new Exception("Prepare delete payment failed: " . $koneksi->error);
                    }
                    $stmt_delete_payment->bind_param("i", $id_pembayaran_to_delete);
                    
                    if (!$stmt_delete_payment->execute()) {
                        throw new Exception("Execute delete payment failed: " . $stmt_delete_payment->error);
                    }
                    $stmt_delete_payment->close();

                    // Sekarang, perbarui tagihan terkait
                    $stmt_get_tagihan_to_update = $koneksi->prepare("SELECT id_tagihan, jumlah_tagihan, sisa_tagihan, p.uses_ppn
                                                                    FROM tagihan t
                                                                    JOIN pelanggan p ON t.pelanggan_id = p.id_pelanggan
                                                                    WHERE t.pelanggan_id = ? AND t.bulan_tagihan = ?");
                    if (!$stmt_get_tagihan_to_update) {
                        throw new Exception("Prepare get tagihan failed: " . $koneksi->error);
                    }
                    $stmt_get_tagihan_to_update->bind_param("is", $pelanggan_id_terkait, $bulan_tagihan_terkait);
                    $stmt_get_tagihan_to_update->execute();
                    $tagihan_to_update = $stmt_get_tagihan_to_update->get_result()->fetch_assoc();
                    $stmt_get_tagihan_to_update->close();

                    if ($tagihan_to_update) {
                        $id_tagihan = $tagihan_to_update['id_tagihan'];
                        $harga_dasar_tagihan_asli = (float)$tagihan_to_update['jumlah_tagihan'];
                        $sisa_tagihan_lama = (float)$tagihan_to_update['sisa_tagihan'];
                        $uses_ppn = $tagihan_to_update['uses_ppn'];
                        $ppn_percentage = 0.11;

                        $total_tagihan_penuh_awal = $harga_dasar_tagihan_asli;
                        if ($uses_ppn == 1) {
                            $total_tagihan_penuh_awal += ($harga_dasar_tagihan_asli * $ppn_percentage);
                        }

                        // Hitung sisa tagihan yang baru setelah pembayaran ini dihapus
                        $sisa_tagihan_baru = $sisa_tagihan_lama + $jumlah_bayar_dihapus;

                        // Pastikan sisa_tagihan tidak melebihi total tagihan awal (untuk mencegah double counting jika ada data anomali)
                        if ($sisa_tagihan_baru > $total_tagihan_penuh_awal) {
                            $sisa_tagihan_baru = $total_tagihan_penuh_awal;
                        }
                        
                        $epsilon = 0.01; // Toleransi untuk perbandingan floating point
                        // Tentukan status tagihan baru
                        $status_tagihan_baru = ($sisa_tagihan_baru <= $epsilon) ? 'Lunas' : 'Belum Lunas';

                        // Jika sisa tagihan baru sudah kembali menjadi total_tagihan_penuh_awal (atau mendekati),
                        // dan tidak ada pembayaran lain, set id_pembayaran_terkait ke NULL
                        $id_pembayaran_terkait_update = null;
                        
                        // Periksa apakah masih ada pembayaran lain untuk tagihan ini
                        $stmt_check_other_payments = $koneksi->prepare("SELECT id_pembayaran FROM pembayaran WHERE pelanggan_id = ? AND bulan_tagihan = ? LIMIT 1");
                        if (!$stmt_check_other_payments) {
                            throw new Exception("Prepare check other payments failed: " . $koneksi->error);
                        }
                        $stmt_check_other_payments->bind_param("is", $pelanggan_id_terkait, $bulan_tagihan_terkait);
                        $stmt_check_other_payments->execute();
                        $other_payment_result = $stmt_check_other_payments->get_result();
                        
                        if ($other_payment_result->num_rows > 0) { // Jika masih ada pembayaran lain
                            // Cari pembayaran terbaru yang terkait untuk dijadikan id_pembayaran_terkait
                            $stmt_get_last_payment_id = $koneksi->prepare("SELECT id_pembayaran FROM pembayaran WHERE pelanggan_id = ? AND bulan_tagihan = ? ORDER BY tanggal_bayar DESC, id_pembayaran DESC LIMIT 1");
                            if (!$stmt_get_last_payment_id) {
                                throw new Exception("Prepare get last payment ID failed: " . $koneksi->error);
                            }
                            $stmt_get_last_payment_id->bind_param("is", $pelanggan_id_terkait, $bulan_tagihan_terkait);
                            $stmt_get_last_payment_id->execute();
                            $last_payment_result = $stmt_get_last_payment_id->get_result();
                            if ($last_payment_result->num_rows > 0) {
                                $id_pembayaran_terkait_update = $last_payment_result->fetch_assoc()['id_pembayaran'];
                            }
                            $stmt_get_last_payment_id->close();
                        }
                        $stmt_check_other_payments->close();

                        $sisa_tagihan_final = $sisa_tagihan_baru;

                        $stmt_update_tagihan = $koneksi->prepare("UPDATE tagihan SET status_tagihan = ?, id_pembayaran_terkait = ?, sisa_tagihan = ? WHERE id_tagihan = ?");
                        if (!$stmt_update_tagihan) {
                            throw new Exception("Prepare update tagihan failed: " . $koneksi->error);
                        }
                        $stmt_update_tagihan->bind_param("sidi", $status_tagihan_baru, $id_pembayaran_terkait_update, $sisa_tagihan_final, $id_tagihan);
                        
                        if (!$stmt_update_tagihan->execute()) {
                            throw new Exception("Execute update tagihan failed: " . $stmt_update_tagihan->error);
                        }
                        $stmt_update_tagihan->close();

                        $koneksi->commit(); // Komit transaksi jika berhasil
                        logActivity('Delete', 'Menghapus pembayaran ID ' . $id_pembayaran_to_delete . '. Tagihan ID ' . $id_tagihan . ' diperbarui. Sisa: ' . number_format($sisa_tagihan_baru, 0, ',', '.') . '.');
                        header('Location: pembayaran.php?msg_original=delete_payment_success&detail_original=' . urlencode('Pembayaran berhasil dihapus dan tagihan diperbarui. Sisa tagihan sekarang: Rp ' . number_format($sisa_tagihan_baru, 0, ',', '.') . '.'));
                        ob_end_clean();
                        exit();
                    } else {
                        $koneksi->rollback(); // Rollback jika tagihan tidak ditemukan
                        header('Location: pembayaran.php?msg_original=delete_payment_fail&err_original=' . urlencode('Pembayaran dihapus, tetapi tagihan terkait untuk bulan ' . $bulan_tagihan_terkait . ' pelanggan ' . $pelanggan_id_terkait . ' tidak ditemukan untuk diperbarui.'));
                        ob_end_clean();
                        exit();
                    }
                } catch (Exception $e) {
                    $koneksi->rollback(); // Rollback jika terjadi kesalahan
                    header('Location: pembayaran.php?msg_original=delete_payment_fail&err_original=' . urlencode($e->getMessage()));
                    ob_end_clean();
                    exit();
                }
            } else {
                header('Location: pembayaran.php?msg_original=delete_payment_fail&err_original=' . urlencode('Pembayaran dengan ID ' . htmlspecialchars($id_pembayaran_to_delete) . ' tidak ditemukan.'));
                ob_end_clean();
                exit();
            }
        }
    }
}


// --- Logika Hapus Tagihan (Belum Lunas) ---
if (isset($_GET['action']) && $_GET['action'] == 'delete_tagihan' && isset($_GET['id'])) {
    if (!hasRole('superadmin')) {
        header('Location: pembayaran.php?msg_original=delete_tagihan_fail&err_original=' . urlencode("Anda tidak memiliki izin untuk menghapus tagihan. Hanya Superadmin yang dapat melakukan aksi ini."));
        ob_end_clean();
        exit();
    } else {
        $id_tagihan_to_delete = $koneksi->real_escape_string($_GET['id']);
        
        $stmt = $koneksi->prepare("DELETE FROM tagihan WHERE id_tagihan = ? AND status_tagihan = 'Belum Lunas'");
        if (!$stmt) {
            header('Location: pembayaran.php?msg_original=delete_tagihan_fail&err_original=' . urlencode("Prepare delete tagihan failed: " . $koneksi->error));
            ob_end_clean();
            exit();
        } else {
            $stmt->bind_param("i", $id_tagihan_to_delete);
            if ($stmt->execute()) {
                if ($stmt->affected_rows > 0) {
                    header('Location: pembayaran.php?msg_original=delete_tagihan_success');
                    ob_end_clean();
                    exit();
                } else {
                    header('Location: pembayaran.php?msg_original=delete_tagihan_fail&err_original=' . urlencode('Tagihan tidak ditemukan atau sudah lunas dan tidak dapat dihapus.'));
                    ob_end_clean();
                    exit();
                }
            } else {
                header('Location: pembayaran.php?msg_original=delete_tagihan_fail&err_original=' . urlencode($stmt->error));
                ob_end_clean();
                exit();
            }
            $stmt->close();
        }
    }
}


// --- Logika Catat Pembayaran Baru ---
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['action']) && $_POST['action'] == 'catat_pembayaran') {
    // CSRF Token Validation for payment form submission
    if (!isset($_POST['csrf_token']) || $_POST['csrf_token'] !== $_SESSION['csrf_token']) {
        header('Location: pembayaran.php?msg_original=payment_fail&err_original=' . urlencode('CSRF validation failed for payment submission.'));
        ob_end_clean();
        exit();
    }

    $pelanggan_id = $koneksi->real_escape_string($_POST['pelanggan_id']);
    $paket_id_from_pelanggan = $koneksi->real_escape_string($_POST['paket_id_from_pelanggan']);
    $bulan_tagihan = $koneksi->real_escape_string($_POST['bulan_tagihan']);
    $tanggal_bayar = $koneksi->real_escape_string($_POST['tanggal_bayar']);
    $jumlah_bayar_input = (float)$koneksi->real_escape_string($_POST['jumlah_bayar']); // Ini adalah jumlah yang dibayar
    // Ambil nilai metode pembayaran dari input hidden yang diatur oleh JS
    $metode_pembayaran = $koneksi->real_escape_string($_POST['metode_pembayaran']);
    
    // Server-side validation for metode_pembayaran
    if (empty($metode_pembayaran)) {
        header('Location: pembayaran.php?msg_original=payment_fail&err_original=' . urlencode('Metode pembayaran harus dipilih.'));
        ob_end_clean();
        exit();
    } else {
        $koneksi->begin_transaction(); // Mulai transaksi

        try {
            // Ambil detail tagihan yang akan dibayar untuk perhitungan sisa
            $stmt_get_tagihan_detail = $koneksi->prepare("SELECT t.id_tagihan, t.jumlah_tagihan, t.sisa_tagihan, p.uses_ppn 
                                                          FROM tagihan t 
                                                          JOIN pelanggan p ON t.pelanggan_id = p.id_pelanggan
                                                          WHERE t.pelanggan_id = ? AND t.bulan_tagihan = ? LIMIT 1"); // Jangan batasi status, agar bisa bayar tagihan yang 'Jatuh Tempo'
            if (!$stmt_get_tagihan_detail) {
                throw new Exception("Prepare get tagihan detail failed: " . $koneksi->error);
            }
            $stmt_get_tagihan_detail->bind_param("is", $pelanggan_id, $bulan_tagihan);
            $stmt_get_tagihan_detail->execute();
            $result_tagihan_detail = $stmt_get_tagihan_detail->get_result();
            $tagihan_detail = $result_tagihan_detail->fetch_assoc();
            $stmt_get_tagihan_detail->close();

            if (!$tagihan_detail) {
                throw new Exception('Tagihan untuk pelanggan ini pada bulan tersebut tidak ditemukan.');
            } else {
                $id_tagihan_terkait = $tagihan_detail['id_tagihan'];
                $harga_dasar_tagihan_asli = (float)$tagihan_detail['jumlah_tagihan'];
                $sisa_tagihan_sekarang = (float)$tagihan_detail['sisa_tagihan']; // Sisa tagihan saat ini
                $uses_ppn = $tagihan_detail['uses_ppn'];
                $ppn_percentage = 0.11;

                $total_tagihan_penuh = $harga_dasar_tagihan_asli;
                if ($uses_ppn == 1) {
                    $total_tagihan_penuh += ($harga_dasar_tagihan_asli * $ppn_percentage);
                }

                // Jika ini pembayaran pertama kali atau sisa_tagihan belum diatur, asumsikan sisa adalah total penuh
                if (is_null($sisa_tagihan_sekarang)) {
                    $sisa_tagihan_sekarang = $total_tagihan_penuh;
                }

                // --- VALIDASI BARU: Jumlah bayar tidak boleh melebihi sisa tagihan yang seharusnya ---
                if ($jumlah_bayar_input > $sisa_tagihan_sekarang + 0.01) { // Tambahkan sedikit toleransi untuk float
                    throw new Exception('Jumlah pembayaran tidak boleh melebihi sisa tagihan yang harus dibayar (Rp ' . number_format($sisa_tagihan_sekarang, 0, ',', '.') . ').');
                }
                // --- AKHIR VALIDASI BARU ---

                // Hitung sisa tagihan yang baru setelah pembayaran ini
                $sisa_tagihan_baru = $sisa_tagihan_sekarang - $jumlah_bayar_input;
                $epsilon = 0.01; // Toleransi untuk perbandingan floating point

                // Pastikan sisa tagihan tidak negatif (jika ada pembulatan kecil)
                if ($sisa_tagihan_baru < -$epsilon) { // Jika sisa tagihan sedikit di bawah nol, set ke nol
                    $sisa_tagihan_baru = 0;
                }
                
                // Tentukan status tagihan baru
                $status_tagihan_update = ($sisa_tagihan_baru <= $epsilon) ? 'Lunas' : 'Belum Lunas';

                // Masukkan pembayaran baru ke tabel pembayaran
                $stmt_insert_payment = $koneksi->prepare("INSERT INTO pembayaran (pelanggan_id, paket_id, bulan_tagihan, tanggal_bayar, jumlah_bayar, metode_pembayaran, status_pembayaran) VALUES (?, ?, ?, ?, ?, ?, ?)");
                if (!$stmt_insert_payment) {
                    throw new Exception("Prepare insert payment failed: " . $koneksi->error);
                }
                $status_pembayaran_catat = ($sisa_tagihan_baru <= $epsilon) ? 'Lunas' : 'Parsial'; // Status pembayaran yang dicatat
                $stmt_insert_payment->bind_param("iisssss", $pelanggan_id, $paket_id_from_pelanggan, $bulan_tagihan, $tanggal_bayar, $jumlah_bayar_input, $metode_pembayaran, $status_pembayaran_catat);
                
                if (!$stmt_insert_payment->execute()) {
                    throw new Exception("Execute insert payment failed: " . $stmt_insert_payment->error);
                }
                $new_payment_id = $stmt_insert_payment->insert_id;
                $stmt_insert_payment->close();

                // Perbarui tabel tagihan dengan sisa_tagihan yang baru dan status
                $id_pembayaran_terkait_update = null;
                // Jika masih ada sisa, cari pembayaran terbaru yang terkait untuk dijadikan id_pembayaran_terkait
                // Ini akan selalu menunjuk ke pembayaran terakhir yang berhasil dicatat
                $stmt_get_last_payment_id = $koneksi->prepare("SELECT id_pembayaran FROM pembayaran WHERE pelanggan_id = ? AND bulan_tagihan = ? ORDER BY tanggal_bayar DESC, id_pembayaran DESC LIMIT 1");
                if (!$stmt_get_last_payment_id) {
                    throw new Exception("Prepare get last payment ID failed: " . $koneksi->error);
                }
                $stmt_get_last_payment_id->bind_param("is", $pelanggan_id, $bulan_tagihan);
                $stmt_get_last_payment_id->execute();
                $last_payment_result = $stmt_get_last_payment_id->get_result();
                if ($last_payment_result->num_rows > 0) {
                    $id_pembayaran_terkait_update = $last_payment_result->fetch_assoc()['id_pembayaran'];
                }
                $stmt_get_last_payment_id->close();


                $sisa_tagihan_final = $sisa_tagihan_baru;

                $stmt_update_tagihan = $koneksi->prepare("UPDATE tagihan SET status_tagihan = ?, id_pembayaran_terkait = ?, sisa_tagihan = ? WHERE id_tagihan = ?");
                if (!$stmt_update_tagihan) {
                    throw new Exception("Prepare update tagihan failed: " . $koneksi->error);
                }
                $stmt_update_tagihan->bind_param("sidi", $status_tagihan_update, $id_pembayaran_terkait_update, $sisa_tagihan_final, $id_tagihan_terkait);
                
                if (!$stmt_update_tagihan->execute()) {
                    throw new Exception("Execute update tagihan failed: " . $stmt_update_tagihan->error);
                }
                $stmt_update_tagihan->close();

                $koneksi->commit(); // Komit transaksi jika berhasil
                logActivity('Create', 'Mencatat pembayaran ID ' . $new_payment_id . ' untuk pelanggan ' . $pelanggan_id . ' (Bulan ' . $bulan_tagihan . '). Jumlah: ' . number_format($jumlah_bayar_input) . ', Sisa: ' . number_format($sisa_tagihan_final) . ', Status: ' . $status_tagihan_update);

                if ($status_tagihan_update == 'Lunas') {
                    header('Location: pembayaran.php?msg_original=payment_success&detail_original=' . urlencode('Pembayaran berhasil dicatat dan tagihan lunas!'));
                    ob_end_clean();
                    exit();
                } else {
                    header('Location: pembayaran.php?msg_original=payment_success&detail_original=' . urlencode('Pembayaran parsial berhasil dicatat. Sisa tagihan: Rp ' . number_format($sisa_tagihan_final, 0, ',', '.') . '.'));
                    ob_end_clean();
                    exit();
                }

            }
        } catch (Exception $e) {
            $koneksi->rollback(); // Rollback on any exception
            // Pastikan pesan error dari throw new Exception juga ditangkap
            header('Location: pembayaran.php?msg_original=payment_fail&err_original=' . urlencode('Terjadi kesalahan saat memproses pembayaran: ' . $e->getMessage()));
            ob_end_clean();
            exit();
        }
    }
}

// --- Ambil Data Pelanggan untuk Dropdown Pembayaran (hanya yang punya tagihan 'Belum Lunas') ---
$query_pelanggan_options_bayar = "
    SELECT DISTINCT
        p.id_pelanggan, 
        p.nama_pelanggan, 
        pk.id_paket, 
        pk.harga, 
        p.uses_ppn
    FROM 
        pelanggan p 
    JOIN 
        paket_layanan pk ON p.paket_id = pk.id_paket
    JOIN 
        tagihan t ON p.id_pelanggan = t.pelanggan_id
    WHERE 
        p.status_aktif = 'Aktif' AND t.status_tagihan IN ('Belum Lunas', 'Jatuh Tempo')
    ORDER BY 
        p.nama_pelanggan ASC
";
$result_pelanggan_options_bayar = $koneksi->query($query_pelanggan_options_bayar);


// --- Logika Paginasi untuk Tagihan Belum Lunas ---
$per_page_options_bl = [30, 50, 100]; // Opsi jumlah baris per halaman untuk Belum Lunas
$per_page_bl = isset($_GET['per_page_bl']) && in_array((int)$_GET['per_page_bl'], $per_page_options_bl) ? (int)$_GET['per_page_bl'] : 30; // Default 30 baris per halaman
$current_page_bl = isset($_GET['page_bl']) && (int)$_GET['page_bl'] > 0 ? (int)$_GET['page_bl'] : 1; // Mendapatkan halaman saat ini
$offset_bl = ($current_page_bl - 1) * $per_page_bl; // Menghitung offset untuk query database

// --- Logika Ambil Data Tagihan Belum Lunas (dengan filter dan sorting dinamis) ---
$pelanggan_belum_lunas_list = [];
$where_clauses_belum_lunas = ["t.status_tagihan IN (?, ?)"]; // Menggunakan IN untuk 'Belum Lunas' dan 'Jatuh Tempo'
$bind_values_belum_lunas = ['Belum Lunas', 'Jatuh Tempo']; // This will hold the actual values to bind
$bind_types_belum_lunas = "ss"; // This will hold the type string

if ($filter_pelanggan_id) {
    $where_clauses_belum_lunas[] = "t.pelanggan_id = ?";
    $bind_values_belum_lunas[] = $filter_pelanggan_id;
    $bind_types_belum_lunas .= "i";
}

if (!empty($filter_penagih_id_bl)) { // NEW: Filter penagih untuk Belum Lunas
    $where_clauses_belum_lunas[] = "t.penagih_id = ?";
    $bind_values_belum_lunas[] = $filter_penagih_id_bl;
    $bind_types_belum_lunas .= "i";
}

// NEW: Filter berdasarkan nama pelanggan untuk Belum Lunas
if (!empty($filter_nama_pelanggan_bl)) {
    $where_clauses_belum_lunas[] = "p.nama_pelanggan LIKE ?";
    $bind_values_belum_lunas[] = '%' . $filter_nama_pelanggan_bl . '%';
    $bind_types_belum_lunas .= "s";
}


if (!empty($filter_tgl_terbit_mulai_bl)) {
    $where_clauses_belum_lunas[] = "t.tanggal_terbit >= ?";
    $bind_values_belum_lunas[] = $filter_tgl_terbit_mulai_bl;
    $bind_types_belum_lunas .= "s";
}
if (!empty($filter_tgl_terbit_akhir_bl)) {
    $where_clauses_belum_lunas[] = "t.tanggal_terbit <= ?";
    $bind_values_belum_lunas[] = $filter_tgl_terbit_akhir_bl;
    $bind_types_belum_lunas .= "s";
}

$final_where_clause_belum_lunas = " WHERE " . implode(" AND ", $where_clauses_belum_lunas);

// --- LOGIKA PAGINASI: Ambil TOTAL data tanpa LIMIT untuk menghitung total halaman untuk Belum Lunas ---
$query_count_belum_lunas = "
    SELECT COUNT(*) AS total_records
    FROM tagihan t
    JOIN pelanggan p ON t.pelanggan_id = p.id_pelanggan
    JOIN paket_layanan pk ON t.paket_id = pk.id_paket
    LEFT JOIN penagih coll ON t.penagih_id = coll.id_penagih
    " . $final_where_clause_belum_lunas;

$stmt_count_bl = $koneksi->prepare($query_count_belum_lunas);
if ($stmt_count_bl === false) {
    die('Prepare count failed (Belum Lunas): ' . htmlspecialchars($koneksi->error));
}

// Bind parameter for count query
$bind_args_count_bl = [$bind_types_belum_lunas]; // Start with the type string
foreach ($bind_values_belum_lunas as $key => $value) {
    $bind_args_count_bl[] = &$bind_values_belum_lunas[$key]; // Pass each value by reference
}
call_user_func_array([$stmt_count_bl, 'bind_param'], $bind_args_count_bl);

$stmt_count_bl->execute();
$total_records_result_bl = $stmt_count_bl->get_result()->fetch_assoc();
$total_records_bl = $total_records_result_bl['total_records'];
$stmt_count_bl->close();

$total_pages_bl = ceil($total_records_bl / $per_page_bl);

// Pastikan current_page_bl tidak melebihi total_pages_bl
if ($current_page_bl > $total_pages_bl && $total_pages_bl > 0) {
    $current_page_bl = $total_pages_bl;
    $offset_bl = ($current_page_bl - 1) * $per_page_bl;
} elseif ($total_pages_bl == 0) {
    $current_page_bl = 1;
    $offset_bl = 0;
}


// Ambil juga p.uses_ppn, t.sisa_tagihan, dan nama penagih
// PASTIKAN KOLOM payment_link diambil dari t.*
$query_belum_lunas = "SELECT t.*, p.nama_pelanggan, p.alamat, p.telepon, p.email, p.tanggal_registrasi, p.uses_ppn, pk.nama_paket, pk.kecepatan, coll.nama_penagih
                      FROM tagihan t
                      JOIN pelanggan p ON t.pelanggan_id = p.id_pelanggan
                      JOIN paket_layanan pk ON t.paket_id = pk.id_paket
                      LEFT JOIN penagih coll ON t.penagih_id = coll.id_penagih"
                      . $final_where_clause_belum_lunas . " ORDER BY " . $sort_column_belum_lunas . " " . $sort_order_belum_lunas .
                      " LIMIT ? OFFSET ?"; // Tambahkan LIMIT dan OFFSET

$stmt_belum_lunas = $koneksi->prepare($query_belum_lunas);
if ($stmt_belum_lunas === false) {
    die('Prepare main query failed (Belum Lunas): ' . htmlspecialchars($koneksi->error));
}

// Siapkan parameter untuk query utama Belum Lunas (termasuk LIMIT dan OFFSET)
$final_bind_values_bl = array_merge($bind_values_belum_lunas, [$per_page_bl, $offset_bl]);
$final_bind_types_bl = $bind_types_belum_lunas . "ii";

$bind_args_bl_stmt = [$final_bind_types_bl]; // Add type string as first argument
foreach ($final_bind_values_bl as $key => $value) {
    $bind_args_bl_stmt[] = &$final_bind_values_bl[$key]; // Pass each value by reference
}
// Using try-catch for call_user_func_array for better error handling in PHP
try {
    call_user_func_array([$stmt_belum_lunas, 'bind_param'], $bind_args_bl_stmt);
} catch (ArgumentCountError $e) {
    error_log("ArgumentCountError for belum_lunas query: " . $e->getMessage() . " Types: " . $final_bind_types_bl . ", Values Count: " . count($final_bind_values_bl));
    die("Error in binding parameters for Tagihan Belum Lunas query. Please check server logs for details.");
}


$stmt_belum_lunas->execute();
$result_belum_lunas = $stmt_belum_lunas->get_result();

if ($result_belum_lunas->num_rows > 0) :
    while ($tagihan_bl = $result_belum_lunas->fetch_assoc()) :
        // Hitung jumlah tagihan_display dari sisa_tagihan atau hitung ulang jika sisa_tagihan null
        $ppn_percentage = 0.11;
        if (is_null($tagihan_bl['sisa_tagihan'])) {
            // Jika sisa_tagihan null, hitung total asli (paket + PPN jika ada)
            $harga_dasar_tagihan_bl = (float)$tagihan_bl['jumlah_tagihan'];
            $total_seharusnya = $harga_dasar_tagihan_bl;
            if ($tagihan_bl['uses_ppn'] == 1) {
                $total_seharusnya += ($harga_dasar_tagihan_bl * $ppn_percentage);
            }
            $tagihan_bl['jumlah_tagihan_display'] = $total_seharusnya;
        } else {
            // Jika sisa_tagihan ada, gunakan itu sebagai jumlah yang perlu dibayar
            $tagihan_bl['jumlah_tagihan_display'] = (float)$tagihan_bl['sisa_tagihan'];
        }
        $pelanggan_belum_lunas_list[] = $tagihan_bl;
    endwhile;
endif;
$stmt_belum_lunas->close();


// --- Ambil Data Riwayat Pembayaran (untuk filter, pelanggan, dan sorting dinamis) ---
$where_clauses_riwayat = [];
$bind_values_riwayat = []; // Use a distinct name for bind parameters
$bind_types_riwayat = "";

$query_riwayat_pembayaran_list = "SELECT
                                         py.*,
                                         p.nama_pelanggan,
                                         pk.nama_paket,
                                         pk.kecepatan,
                                         p.id_pelanggan as pelanggan_terkait_id,
                                         t.id_tagihan as id_tagihan_terkait,
                                         t.sisa_tagihan,       -- Tambahkan kolom sisa_tagihan dari tabel tagihan
                                         t.jumlah_tagihan as total_tagihan_asli, -- Tambahkan kolom jumlah_tagihan dari tabel tagihan
                                         p.uses_ppn,            -- Tambahkan kolom uses_ppn dari tabel pelanggan
                                         t.status_tagihan AS tagihan_status, -- ADDED: Ambil status_tagihan dari tabel tagihan
                                         coll.nama_penagih       -- NEW: Nama penagih dari tabel tagihan
                                   FROM pembayaran py
                                   JOIN pelanggan p ON py.pelanggan_id = p.id_pelanggan
                                   JOIN paket_layanan pk ON py.paket_id = pk.id_paket
                                   LEFT JOIN tagihan t ON py.bulan_tagihan = t.bulan_tagihan AND py.pelanggan_id = t.pelanggan_id
                                   LEFT JOIN penagih coll ON t.penagih_id = coll.id_penagih"; // NEW: Join dengan penagih


if ($filter_pelanggan_id) {
    $where_clauses_riwayat[] = "py.pelanggan_id = ?";
    $bind_values_riwayat[] = $filter_pelanggan_id;
    $bind_types_riwayat .= "i";
}

if (!empty($filter_penagih_id_riwayat)) {
    $where_clauses_riwayat[] = "t.penagih_id = ?";
    $bind_values_riwayat[] = $filter_penagih_id_riwayat;
    $bind_types_riwayat .= "i";
}

// NEW: Filter berdasarkan nama pelanggan untuk Riwayat Pembayaran
if (!empty($filter_nama_pelanggan_riwayat)) {
    $where_clauses_riwayat[] = "p.nama_pelanggan LIKE ?";
    $bind_values_riwayat[] = '%' . $filter_nama_pelanggan_riwayat . '%';
    $bind_types_riwayat .= "s";
}


if (!empty($filter_tgl_mulai_riwayat)) {
    $where_clauses_riwayat[] = "py.tanggal_bayar >= ?";
    $bind_values_riwayat[] = $filter_tgl_mulai_riwayat;
    $bind_types_riwayat .= "s";
}
if (!empty($filter_tgl_akhir_riwayat)) {
    $where_clauses_riwayat[] = "py.tanggal_bayar <= ?";
    $bind_values_riwayat[] = $filter_tgl_akhir_riwayat;
    $bind_types_riwayat .= "s";
}

$final_where_clause_riwayat = count($where_clauses_riwayat) > 0 ? " WHERE " . implode(" AND ", $where_clauses_riwayat) : "";

$query_riwayat_pembayaran_list .= $final_where_clause_riwayat . " ORDER BY " . $sort_column_riwayat . " " . $sort_order_riwayat;

$result_riwayat_pembayaran_list = false; // Inisialisasi dengan false
$stmt_riwayat = $koneksi->prepare($query_riwayat_pembayaran_list);
if ($stmt_riwayat) {
    if (!empty($bind_values_riwayat)) { // Use the dynamically built array
        // Menggunakan call_user_func_array untuk bind_param
        $bind_args_riwayat_stmt = [$bind_types_riwayat]; // First argument is the type string
        foreach ($bind_values_riwayat as $key => $value) {
            $bind_args_riwayat_stmt[] = &$bind_values_riwayat[$key]; // Pass each value by reference
        }
        try {
            call_user_func_array([$stmt_riwayat, 'bind_param'], $bind_args_riwayat_stmt);
        } catch (ArgumentCountError $e) {
            error_log("ArgumentCountError for riwayat query: " . $e->getMessage() . " Types: " . $bind_types_riwayat . ", Values Count: " . count($bind_values_riwayat));
            die("Error in binding parameters for Riwayat Pembayaran query. Please check server logs for details.");
        }
    }
    $stmt_riwayat->execute();
    $result_riwayat_pembayaran_list = $stmt_riwayat->get_result();
    $stmt_riwayat->close();
} else {
    error_log("Failed to prepare statement for riwayat pembayaran: " . $koneksi->error);
}


// Ambil semua penagih untuk dropdown filter
$all_penagih_options = [];
$query_all_penagih = "SELECT id_penagih, nama_penagih FROM penagih WHERE status_aktif = 'Aktif' ORDER BY nama_penagih ASC";
$result_all_penagih = $koneksi->query($query_all_penagih);
if ($result_all_penagih) {
    while ($row = $result_all_penagih->fetch_assoc()) {
        $all_penagih_options[] = $row;
    }
} else {
    error_log("Error fetching all penagih for filter dropdown: " . $koneksi->error);
}


// Function to generate sorting URL parameters
function get_sort_url_params($current_params, $column, $current_sort_column, $current_sort_order) {
    $new_order = 'ASC';
    if ($current_sort_column === $column) {
        $new_order = ($current_sort_order === 'ASC') ? 'DESC' : 'ASC';
    }
    
    // Create a new array and only add allowed parameters from current_params
    $cleaned_params = [];
    $allowed_param_keys = [
        'pelanggan_id', 'status', 'filter_tgl_mulai_riwayat', 'filter_tgl_akhir_riwayat',
        'filter_tgl_terbit_mulai_bl', 'filter_tgl_terbit_akhir_bl',
        'filter_penagih_id_bl', 'filter_penagih_id_riwayat',
        'filter_nama_pelanggan_riwayat', // NEW: Tambahkan
        'filter_nama_pelanggan_bl',      // NEW: Tambahkan
        'per_page_bl', 'page_bl', 'per_page_riwayat', 'page_riwayat', 'tab'
    ];

    foreach ($current_params as $key => $value) {
        if (in_array($key, $allowed_param_keys)) {
            $cleaned_params[$key] = $value;
        }
    }
    
    // Add new sort parameters to the cleaned array
    $params = array_merge($cleaned_params, [
        'sort_column_' . str_replace(['t.', 'py.', 'p.', 'pk.', 'coll.'], '', $column) => $column,
        'sort_order_' . str_replace(['t.', 'py.', 'p.', 'pk.', 'coll.'], '', $column) => $new_order
    ]);
    
    // Ensure 'tab' parameter is always correctly set for the current tab
    if (isset($current_params['tab'])) {
        $params['tab'] = $current_params['tab'];
    }

    // This unset is redundant if `get_current_params_for_sort` effectively cleans,
    // but kept as a failsafe just in case.
    unset($params['status']); 
    
    return http_build_query($params);
}

// Helper to handle multiple sort parameters
function get_current_params_for_sort($tab_id) {
    // Create a new array and only add allowed parameters from $_GET
    $params = [];
    $allowed_param_keys = [
        'pelanggan_id', 'status', 'filter_tgl_mulai_riwayat', 'filter_tgl_akhir_riwayat',
        'filter_tgl_terbit_mulai_bl', 'filter_tgl_terbit_akhir_bl',
        'filter_penagih_id_bl', 'filter_penagih_id_riwayat',
        'filter_nama_pelanggan_riwayat', // NEW: Tambahkan
        'filter_nama_pelanggan_bl',      // NEW: Tambahkan
        'per_page_bl', 'page_bl', 'per_page_riwayat', 'page_riwayat'
    ];

    foreach ($_GET as $key => $value) {
        if (in_array($key, $allowed_param_keys)) {
            $params[$key] = $value;
        }
    }
    // Always set the current tab
    $params['tab'] = $tab_id;
    return $params;
}


?>

<style>
    /* NEW: Styles for the Action Menu Modal */
    .action-menu-modal-overlay {
        position: fixed;
        top: 0;
        left: 0;
        width: 100%;
        height: 100%;
        background-color: rgba(0, 0, 0, 0.6);
        display: flex;
        justify-content: center;
        align-items: center;
        z-index: 2000; /* Higher than other modals like customConfirmModal (1000) */
        opacity: 0;
        visibility: hidden;
        transition: opacity 0.3s ease, visibility 0.3s ease;
    }

    .action-menu-modal-overlay.show {
        opacity: 1;
        visibility: visible;
    }

    .action-menu-modal-content {
        background-color: var(--tznpisp-card-bg); /* Use theme variable */
        padding: 25px;
        border-radius: 8px;
        box-shadow: 0 5px 15px rgba(0, 0, 0, 0.4);
        text-align: center;
        max-width: 350px;
        width: 90%;
        color: var(--tznpisp-text-light); /* Use theme variable */
        transform: translateY(-20px);
        transition: transform 0.3s ease;
        position: relative; /* Needed for close button positioning */
    }

    .action-menu-modal-content h3 {
        margin-top: 0;
        margin-bottom: 20px;
        color: var(--tznpisp-text-light); /* Use theme variable */
        font-size: 1.2em;
    }

    .action-menu-modal-content .close-button-modal {
        position: absolute;
        top: 10px;
        right: 15px;
        font-size: 24px;
        color: var(--tznpisp-text-muted);
        cursor: pointer;
        transition: color 0.2s ease;
    }
    .action-menu-modal-content .close-button-modal:hover {
        color: var(--tznpisp-primary-blue); /* Use theme variable */
    }

    .action-menu-list {
        display: flex;
        flex-direction: column; /* Stack buttons vertically */
        gap: 10px; /* Space between buttons */
    }

    .action-menu-list .btn-action-modal {
        display: flex; /* Make buttons flex items */
        align-items: center;
        justify-content: flex-start; /* Align text to left */
        padding: 10px 15px;
        border-radius: 6px;
        font-size: 0.95em;
        text-decoration: none;
        color: var(--tznpisp-text-light);
        background-color: var(--tznpisp-sidebar-bg); /* Slightly darker background for buttons */
        border: 1px solid var(--tznpisp-border-color);
        transition: background-color 0.2s ease, color 0.2s ease, border-color 0.2s ease;
    }

    .action-menu-list .btn-action-modal i {
        margin-right: 10px;
        color: var(--tznpisp-text-muted); /* Icon color */
        font-size: 1.1em;
        transition: color 0.2s ease;
    }

    .action-menu-list .btn-action-modal:hover {
        background-color: var(--tznpisp-active-menu-bg); /* Hover background */
        color: var(--tznpisp-primary-blue); /* Hover text color */
        border-color: var(--tznpisp-primary-blue);
    }
    .action-menu-list .btn-action-modal:hover i {
        color: var(--tznpisp-primary-blue); /* Hover icon color */
    }

    /* Specific colors for action buttons (optional) */
    .action-menu-list .btn-action-modal.delete-modal {
        color: var(--tznpisp-accent-red);
    }
    .action-menu-list .btn-action-modal.delete-modal:hover {
        background-color: rgba(255, 23, 68, 0.1);
    }
    .action-menu-list .btn-action-modal.warning-modal {
        color: var(--tznpisp-accent-orange);
    }
    .action-menu-list .btn-action-modal.warning-modal:hover {
        background-color: rgba(255, 152, 0, 0.1);
    }
    .action-menu-list .btn-action-modal.success-modal {
        color: var(--tznpisp-accent-green);
    }
    .action-menu-list .btn-action-modal.success-modal:hover {
        background-color: rgba(0, 200, 83, 0.1);
    }
    .action-menu-list .btn-action-modal.info-modal {
        color: var(--tznpisp-primary-blue);
    }
    .action-menu-list .btn-action-modal.info-modal:hover {
        background-color: rgba(34, 150, 243, 0.1);
    }
    
    /* Gaya untuk Custom Modal (old/general confirm modal) */
    .custom-modal-overlay {
        position: fixed;
        top: 0;
        left: 0;
        width: 100%;
        height: 100%;
        background-color: rgba(0, 0, 0, 0.5);
        display: flex;
        justify-content: center;
        align-items: center;
        z-index: 1000; /* Pastikan di atas elemen lain */
        opacity: 0;
        visibility: hidden;
        transition: opacity 0.3s ease, visibility 0.3s ease;
    }

    .custom-modal-overlay.show {
        opacity: 1;
        visibility: visible;
    }

    .custom-modal-content {
        background-color: #fff;
        padding: 30px;
        border-radius: 8px;
        box-shadow: 0 5px 15px rgba(0, 0, 0, 0.3);
        text-align: center;
        max-width: 400px;
        width: 90%;
        transform: translateY(-20px);
        transition: transform 0.3s ease;
    }

    .custom-modal-overlay.show .custom-modal-content {
        transform: translateY(0);
    }

    .custom-modal-content h3 {
        margin-top: 0;
        margin-bottom: 20px;
        color: #333;
    }

    .custom-modal-buttons {
        display: flex;
        justify-content: center;
        gap: 15px;
        margin-top: 25px;
    }

    .custom-modal-buttons .btn {
        padding: 10px 25px;
        border-radius: 5px;
        cursor: pointer;
        font-size: 1em;
        border: none;
        transition: background-color 0.2s ease;
    }

    .custom-modal-buttons .btn-confirm {
        background-color: #dc3545; /* Merah untuk konfirmasi aksi berbahaya */
        color: #fff;
    }

    .custom-modal-buttons .btn-confirm:hover {
        background-color: #c82333;
    }

    .custom-modal-buttons .btn-cancel {
        background-color: #6c757d; /* Abu-abu untuk batal */
        color: #fff;
    }

    .custom-modal-buttons .btn-cancel:hover {
        background-color: #5a6268;
    }

</style>

<div class="main-content">
    <div class="top-header">
        <div class="alert-message">
            <i class="fas fa-info-circle"></i> Pemberitahuan: Catat setiap pembayaran untuk menjaga akurasi laporan keuangan.
        </div>
        <div class="welcome-message">
            <span>Selamat datang, <?php echo htmlspecialchars($_SESSION['username'] ?? 'User'); ?>!</span>
            <a href="../logout.php" class="btn-logout">Logout</a>
        </div>
    </div>

    <div class="container">
        <h2>Manajemen Pembayaran</h2>

        <div class="tabs" style="margin-bottom: 20px;">
            <button class="btn btn-secondary" id="btnCatatPembayaran">Catat Pembayaran</button>
            <button class="btn btn-secondary" id="btnRiwayatPembayaran">Riwayat Pembayaran</button>
            <button class="btn btn-secondary" id="btnBelumLunas">Tagihan Belum Lunas
                <?php
                if ($filter_pelanggan_id && $filter_pelanggan_nama) {
                    echo "untuk " . htmlspecialchars($filter_pelanggan_nama) . " (ID: " . htmlspecialchars($filter_pelanggan_id) . ")";
                } else if (!empty($filter_tgl_terbit_mulai_bl) || !empty($filter_tgl_terbit_akhir_bl)) {
                } else {
                    echo "(Semua Periode)";
                }
                ?>
            </button>
        </div>

        <div id="catatPembayaran" class="tab-content">
            <div class="card" style="margin-bottom: 20px;">
                <div class="card-header">
                    <h3>Catat Pembayaran Baru</h3>
                </div>
                <div class="card-body">
                    <form method="POST" id="paymentForm">
                        <input type="hidden" name="action" value="catat_pembayaran">
                        <input type="hidden" name="csrf_token" value="<?php echo htmlspecialchars($csrf_token); ?>">
                        <div class="form-group">
                            <label for="pelanggan_id">Pilih Pelanggan:</label>
                            <select id="pelanggan_id" name="pelanggan_id" required onchange="updatePaketInfo()">
                                <option value="">Pilih Pelanggan</option>
                                <?php
                                if ($result_pelanggan_options_bayar->num_rows > 0) :
                                    $result_pelanggan_options_bayar->data_seek(0);
                                endif;
                                while($row_pelanggan_bayar = $result_pelanggan_options_bayar->fetch_assoc()): ?>
                                    <option value="<?php echo htmlspecialchars($row_pelanggan_bayar['id_pelanggan']); ?>"
                                            data-paket-id="<?php echo htmlspecialchars($row_pelanggan_bayar['id_paket']); ?>"
                                            data-harga-paket="<?php echo htmlspecialchars($row_pelanggan_bayar['harga']); ?>"
                                            data-uses-ppn="<?php echo htmlspecialchars($row_pelanggan_bayar['uses_ppn']); ?>"
                                            <?php echo ($filter_pelanggan_id == $row_pelanggan_bayar['id_pelanggan']) ? 'selected' : ''; ?>>
                                            <?php echo htmlspecialchars($row_pelanggan_bayar['nama_pelanggan'] . ' (Rp ' . number_format($row_pelanggan_bayar['harga'], 0, ',', '.') . ')'); ?>
                                    </option>
                                <?php endwhile; ?>
                            </select>
                            <input type="hidden" id="paket_id_from_pelanggan" name="paket_id_from_pelanggan">
                        </div>
                        <div class="form-group">
                            <label for="bulan_tagihan">Bulan Tagihan:</label>
                            <input type="month" id="bulan_tagihan" name="bulan_tagihan" value="<?php echo $current_month_year; ?>" placeholder="YYYY-MM" required>
                        </div>
                        <div class="form-group">
                            <label for="tanggal_bayar">Tanggal Bayar:</label>
                            <input type="date" id="tanggal_bayar" name="tanggal_bayar" value="<?php echo date('Y-m-d'); ?>" required>
                        </div>
                        <div class="form-group">
                            <label for="jumlah_bayar">Jumlah Bayar (Rp):</label>
                            <input type="number" id="jumlah_bayar" name="jumlah_bayar" step="0.01" required>
                            <small>Sisa tagihan yang harus dibayar: <span id="harga_seharusnya">Rp 0</span></small>
                        </div>
                        <div class="form-group">
                            <label>Metode Pembayaran:</label><br>
                            <div style="display: flex; gap: 15px; margin-top: 5px;">
                                <label for="metode_cash" style="display: flex; align-items: center; gap: 5px;">
                                    <input type="checkbox" id="metode_cash" name="metode_pembayaran_checkbox[]" value="Cash" onchange="updateMetodePembayaranInput()">
                                    Cash
                                </label>
                                <label for="metode_transfer" style="display: flex; align-items: center; gap: 5px;">
                                    <input type="checkbox" id="metode_transfer" name="metode_pembayaran_checkbox[]" value="Transfer Bank" onchange="updateMetodePembayaranInput()">
                                    Transfer Bank
                                </label>
                                <input type="hidden" id="metode_pembayaran_hidden" name="metode_pembayaran">
                            </div>
                            <small>Pilih satu atau keduanya.</small>
                            <div id="metodePembayaranError" style="color: red; display: none; margin-top: 5px;">
                                Pilih setidaknya satu metode pembayaran.
                            </div>
                        </div>
                        <button type="submit" class="btn btn-primary">Catat Pembayaran</button>
                    </form>
                </div>
            </div>
        </div>

        <div id="riwayatPembayaran" class="tab-content">
            <div class="card">
                <div class="card-header">
                    <h3>Riwayat Pembayaran
                        <?php
                        if ($filter_pelanggan_id && $filter_pelanggan_nama) {
                            echo "untuk " . htmlspecialchars($filter_pelanggan_nama) . " (ID: " . htmlspecialchars($filter_pelanggan_id) . ")";
                        } else if ($filter_status == 'lunas') {
                            echo "(Lunas)";
                        } else if (!empty($filter_tgl_mulai_riwayat) || !empty($filter_tgl_akhir_riwayat)) {
                            echo "(Filter Tanggal)";
                        } else {
                            echo "(Semua)";
                        }
                        ?>
                    </h3>
                    <div class="filter-form" style="margin-top: 15px; display: flex; align-items: center; gap: 10px; flex-wrap: wrap;">
                        <form method="GET" action="pembayaran.php" id="riwayatFilterForm" style="display: flex; align-items: center; gap: 10px; flex-wrap: wrap;">
                            <input type="hidden" name="tab" value="riwayatPembayaran">
                            <?php if ($filter_pelanggan_id): ?>
                                <input type="hidden" name="pelanggan_id" value="<?php echo htmlspecialchars($filter_pelanggan_id); ?>">
                            <?php endif; ?>
                            <label for="filter_penagih_id_riwayat">Penagih:</label>
                            <select id="filter_penagih_id_riwayat" name="filter_penagih_id_riwayat" style="padding: 8px; border-radius: 4px; border: 1px solid #ddd;">
                                <option value="">Semua Penagih</option>
                                <?php foreach ($all_penagih_options as $po): ?>
                                    <option value="<?php echo htmlspecialchars($po['id_penagih']); ?>" <?php echo ($filter_penagih_id_riwayat == $po['id_penagih']) ? 'selected' : ''; ?>>
                                        <?php echo htmlspecialchars($po['nama_penagih']); ?>
                                    </option>
                                <?php endforeach; ?>
                            </select>
                            <label for="filter_nama_pelanggan_riwayat">Nama Pelanggan:</label>
                            <input type="text" id="filter_nama_pelanggan_riwayat" name="filter_nama_pelanggan_riwayat"
                                value="<?php echo htmlspecialchars($filter_nama_pelanggan_riwayat); ?>"
                                placeholder="Cari pelanggan..."
                                style="padding: 8px; border-radius: 4px; border: 1px solid #ddd;"
                                onkeyup="delayFilterSubmit('riwayatFilterForm')">
                            <label for="filter_tgl_mulai_riwayat">Dari Tgl Bayar:</label>
                            <input type="date" id="filter_tgl_mulai_riwayat" name="filter_tgl_mulai_riwayat"
                                        value="<?php echo htmlspecialchars($filter_tgl_mulai_riwayat); ?>"
                                        style="padding: 8px; border-radius: 4px; border: 1px solid #ddd;">

                            <label for="filter_tgl_akhir_riwayat">Sampai Tgl Bayar:</label>
                            <input type="date" id="filter_tgl_akhir_riwayat" name="filter_tgl_akhir_riwayat"
                                        value="<?php echo htmlspecialchars($filter_tgl_akhir_riwayat); ?>"
                                        style="padding: 8px; border-radius: 4px; border: 1px solid #ddd;">

                            <button type="submit" class="btn btn-secondary btn-sm" style="padding: 8px 12px;"><i class="fas fa-filter"></i> Filter</button>
                            <a href="pembayaran.php?tab=riwayatPembayaran<?php echo ($filter_pelanggan_id ? '&pelanggan_id=' . htmlspecialchars($filter_pelanggan_id) : ''); ?>" class="btn btn-secondary btn-sm" style="padding: 8px 12px;"><i class="fas fa-redo"></i> Reset</a>
                        </form>
                    </div>
                </div>
                <div class="card-body">
                    <table class="data-table">
                        <thead>
                            <tr>
                                <th><a href="?<?php echo get_sort_url_params(get_current_params_for_sort('riwayatPembayaran'), 'py.id_pembayaran', $sort_column_riwayat, $sort_order_riwayat); ?>">ID Bayar/Pelanggan <?php if ($sort_column_riwayat == 'py.id_pembayaran') echo ($sort_order_riwayat == 'ASC' ? '&#9650;' : '&#9660;'); ?></a></th>
                                <th><a href="?<?php echo get_sort_url_params(get_current_params_for_sort('riwayatPembayaran'), 'p.nama_pelanggan', $sort_column_riwayat, $sort_order_riwayat); ?>">Nama Pelanggan <?php if ($sort_column_riwayat == 'p.nama_pelanggan') echo ($sort_order_riwayat == 'ASC' ? '&#9650;' : '&#9660;'); ?></a></th>
                                <th><a href="?<?php echo get_sort_url_params(get_current_params_for_sort('riwayatPembayaran'), 'coll.nama_penagih', $sort_column_riwayat, $sort_order_riwayat); ?>">Penagih <?php if ($sort_column_riwayat == 'coll.nama_penagih') echo ($sort_order_riwayat == 'ASC' ? '&#9650;' : '&#9660;'); ?></a></th>
                                <th><a href="?<?php echo get_sort_url_params(get_current_params_for_sort('riwayatPembayaran'), 'pk.nama_paket', $sort_column_riwayat, $sort_order_riwayat); ?>">Paket <?php if ($sort_column_riwayat == 'pk.nama_paket') echo ($sort_order_riwayat == 'ASC' ? '&#9650;' : '&#9660;'); ?></a></th>
                                <th><a href="?<?php echo get_sort_url_params(get_current_params_for_sort('riwayatPembayaran'), 'py.bulan_tagihan', $sort_column_riwayat, $sort_order_riwayat); ?>">Bulan Tagihan <?php if ($sort_column_riwayat == 'py.bulan_tagihan') echo ($sort_order_riwayat == 'ASC' ? '&#9650;' : '&#9660;'); ?></a></th>
                                <th><a href="?<?php echo get_sort_url_params(get_current_params_for_sort('riwayatPembayaran'), 'py.tanggal_bayar', $sort_column_riwayat, $sort_order_riwayat); ?>">Tgl Bayar <?php if ($sort_column_riwayat == 'py.tanggal_bayar') echo ($sort_order_riwayat == 'ASC' ? '&#9650;' : '&#9660;'); ?></a></th>
                                <th><a href="?<?php echo get_sort_url_params(get_current_params_for_sort('riwayatPembayaran'), 'py.jumlah_bayar', $sort_column_riwayat, $sort_order_riwayat); ?>">Jumlah <?php if ($sort_column_riwayat == 'py.jumlah_bayar') echo ($sort_order_riwayat == 'ASC' ? '&#9650;' : '&#9660;'); ?></a></th>
                                <th><a href="?<?php echo get_sort_url_params(get_current_params_for_sort('riwayatPembayaran'), 'py.metode_pembayaran', $sort_column_riwayat, $sort_order_riwayat); ?>">Metode <?php if ($sort_column_riwayat == 'py.metode_pembayaran') echo ($sort_order_riwayat == 'ASC' ? '&#9650;' : '&#9660;'); ?></a></th>
                                <th>Status Tagihan</th> <th>Aksi</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php if ($result_riwayat_pembayaran_list && $result_riwayat_pembayaran_list->num_rows > 0): ?>
                                <?php while($row = $result_riwayat_pembayaran_list->fetch_assoc()): ?>
                                    <?php
                                    // Tentukan status tagihan untuk ditampilkan
                                    $display_status = 'N/A'; // Default
                                    $status_class = 'status-default'; // Default class for CSS

                                    // Prioritaskan status dari tabel tagihan jika ada keterkaitan yang jelas
                                    if (!empty($row['id_tagihan_terkait']) && isset($row['tagihan_status'])) {
                                        $display_status = $row['tagihan_status'];
                                    } else {
                                        // Jika tidak ada tagihan terkait, gunakan status pembayaran dari tabel pembayaran
                                        $display_status = $row['status_pembayaran'] ?? 'N/A';
                                    }
                                    $status_class = 'status-' . strtolower(str_replace(' ', '-', $display_status));
                                    ?>
                                    <tr>
                                        <td><?php echo htmlspecialchars($row['id_pembayaran']); ?> / <?php echo htmlspecialchars($row['pelanggan_terkait_id']); ?></td>
                                        <td><?php echo htmlspecialchars($row['nama_pelanggan']); ?></td>
                                        <td><?php echo htmlspecialchars($row['nama_penagih'] ?? 'N/A'); ?></td>
                                        <td><?php echo htmlspecialchars($row['nama_paket'] . ' (' . $row['kecepatan'] . ')'); ?></td>
                                        <td><?php echo htmlspecialchars(date('F Y', strtotime($row['bulan_tagihan'] . '-01'))); ?></td>
                                        <td><?php echo htmlspecialchars(date('d-m-Y', strtotime($row['tanggal_bayar']))); ?></td>
                                        <td>Rp <?php echo number_format($row['jumlah_bayar'], 0, ',', '.'); ?></td>
                                        <td><?php echo htmlspecialchars($row['metode_pembayaran']); ?></td>
                                        <td><span class="status-badge <?php echo $status_class; ?>"><?php echo htmlspecialchars($display_status); ?></span></td>
                                        <td>
                                            <button type="button" class="btn-action btn-secondary open-action-menu-riwayat-btn" 
                                                    data-payment-id="<?php echo htmlspecialchars($row['id_pembayaran']); ?>"
                                                    data-tagihan-id="<?php echo htmlspecialchars($row['id_tagihan_terkait']); ?>"
                                                    data-payment-name="<?php echo htmlspecialchars($row['nama_pelanggan']); ?>"
                                                <i class="fas fa-ellipsis-h"></i> Aksi
                                            </button>
                                        </td>
                                    </tr>
                                <?php endwhile; ?>
                            <?php else: ?>
                                <tr><td colspan="10" style="text-align: center;">Belum ada riwayat pembayaran.</td></tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>

        <div id="belumLunas" class="tab-content">
            <div class="card">
                <div class="card-header">
                    <h3>Tagihan Belum Lunas
                        <?php
                        if ($filter_pelanggan_id && $filter_pelanggan_nama) {
                            echo "untuk " . htmlspecialchars($filter_pelanggan_nama) . " (ID: " . htmlspecialchars($filter_pelanggan_id) . ")";
                        } else if (!empty($filter_tgl_terbit_mulai_bl) || !empty($filter_tgl_terbit_akhir_bl)) {
                        } else {
                            echo "(Semua Periode)";
                        }
                        ?>
                    </h3>
                    <div class="filter-form">
                        <form method="GET" action="pembayaran.php" id="belumLunasFilterForm" style="display: flex; align-items: center; gap: 10px; flex-wrap: wrap;">
                            <input type="hidden" name="tab" value="belumLunas">
                            <?php if ($filter_pelanggan_id): ?>
                                <input type="hidden" name="pelanggan_id" value="<?php echo htmlspecialchars($filter_pelanggan_id); ?>">
                            <?php endif; ?>
                            <label for="filter_penagih_id_bl">Penagih:</label>
                            <select id="filter_penagih_id_bl" name="filter_penagih_id_bl" style="padding: 8px; border-radius: 4px; border: 1px solid #ddd;">
                                <option value="">Semua Penagih</option>
                                <?php foreach ($all_penagih_options as $po): ?>
                                    <option value="<?php echo htmlspecialchars($po['id_penagih']); ?>" <?php echo ($filter_penagih_id_bl == $po['id_penagih']) ? 'selected' : ''; ?>>
                                        <?php echo htmlspecialchars($po['nama_penagih']); ?>
                                    </option>
                                <?php endforeach; ?>
                            </select>
                            <label for="filter_nama_pelanggan_bl">Nama Pelanggan:</label>
                            <input type="text" id="filter_nama_pelanggan_bl" name="filter_nama_pelanggan_bl"
                                value="<?php echo htmlspecialchars($filter_nama_pelanggan_bl); ?>"
                                placeholder="Cari pelanggan..."
                                style="padding: 8px; border-radius: 4px; border: 1px solid #ddd;"
                                onkeyup="delayFilterSubmit('belumLunasFilterForm')">
                            <label for="filter_tgl_terbit_mulai_bl">Dari Tgl Terbit:</label>
                            <input type="date" id="filter_tgl_terbit_mulai_bl" name="filter_tgl_terbit_mulai_bl"
                                        value="<?php echo htmlspecialchars($filter_tgl_terbit_mulai_bl); ?>"
                                        style="padding: 8px; border-radius: 4px; border: 1px solid #ddd;">
                            <label for="filter_tgl_terbit_akhir_bl">Sampai Tgl Terbit:</label>
                            <input type="date" id="filter_tgl_terbit_akhir_bl" name="filter_tgl_terbit_akhir_bl"
                                        value="<?php echo htmlspecialchars($filter_tgl_terbit_akhir_bl); ?>"
                                        style="padding: 8px; border-radius: 4px; border: 1px solid #ddd;">
                            <button type="submit" class="btn btn-secondary btn-sm" style="padding: 8px 12px;"><i class="fas fa-filter"></i> Filter</button>
                            <a href="pembayaran.php?tab=belumLunas<?php echo ($filter_pelanggan_id ? '&pelanggan_id=' . htmlspecialchars($filter_pelanggan_id) : ''); ?>" class="btn btn-secondary btn-sm" style="padding: 8px 12px;"><i class="fas fa-redo"></i> Reset</a>

                            <div style="margin-left: auto; display: flex; align-items: center; gap: 5px;">
                                <label for="per_page_bl" style="white-space: nowrap; margin-bottom: 0;">Baris per halaman:</label>
                                <select id="per_page_bl" name="per_page_bl" onchange="this.form.submit()" style="padding: 6px; border-radius: 4px; border: 1px solid #ddd;">
                                    <?php foreach ($per_page_options_bl as $option): ?>
                                        <option value="<?php echo $option; ?>" <?php echo ($per_page_bl == $option) ? 'selected' : ''; ?>><?php echo $option; ?></option>
                                    <?php endforeach; ?>
                                </select>
                            </div>
                            <?php if (hasRole(['superadmin', 'admin'])): ?>
                            <div class="form-group" style="margin-left: auto; display: flex; align-items: center; gap: 10px;">
                                <label for="reminderMessage" style="white-space: nowrap;">Pesan Pengingat:</label>
                                <textarea id="reminderMessage" rows="2" style="width: 300px; padding: 8px; border-radius: 4px; border: 1px solid #ddd;"
                                            placeholder="Tulis pesan pengingat khusus..."></textarea>
                                <button type="button" class="btn btn-info btn-sm" id="saveReminderMessageBtn"><i class="fas fa-save"></i> Simpan Pesan Default</button>
                                <button type="button" class="btn btn-success btn-sm" id="kirimPengingatBtn">
                                    <i class="fab fa-whatsapp"></i> Kirim Pengingat ke Semua
                                </button>
                            </div>
                            <?php endif; ?>
                        </form>
                    </div>
                </div>
                <div class="card-body">
                    <div id="reminderAllStatus" class="alert" style="display: none; margin-bottom: 15px;"></div>
                    
                    <div class="pagination-controls" style="margin-bottom: 15px;">
                        <div>
                            Menampilkan <?php echo min($total_records_bl, $offset_bl + 1); ?> - <?php echo min($total_records_bl, $offset_bl + $per_page_bl); ?> dari <?php echo $total_records_bl; ?> data.
                        </div>
                        <ul class="pagination" style="margin: 0;">
                            <?php if ($current_page_bl > 1): ?>
                                <li class="page-item"><a class="page-link" href="?<?php echo htmlspecialchars(http_build_query(array_merge(get_current_params_for_sort('belumLunas'), ['page_bl' => 1]))); ?>">First</a></li>
                                <li class="page-item"><a class="page-link" href="?<?php echo htmlspecialchars(http_build_query(array_merge(get_current_params_for_sort('belumLunas'), ['page_bl' => $current_page_bl - 1]))); ?>">Previous</a></li>
                            <?php endif; ?>

                            <?php
                            $start_page_bl = max(1, $current_page_bl - 2);
                            $end_page_bl = min($total_pages_bl, $current_page_bl + 2);

                            if ($start_page_bl > 1) {
                                echo '<li class="page-item disabled"><span class="page-link">...</span></li>';
                            }
                            for ($i = $start_page_bl; $i <= $end_page_bl; $i++): ?>
                                <li class="page-item <?php echo ($i == $current_page_bl) ? 'active' : ''; ?>"><a class="page-link" href="?<?php echo htmlspecialchars(http_build_query(array_merge(get_current_params_for_sort('belumLunas'), ['page_bl' => $i]))); ?>"><?php echo $i; ?></a></li>
                            <?php endfor; ?>

                            <?php
                            if ($end_page_bl < $total_pages_bl) {
                                echo '<li class="page-item disabled"><span class="page-link">...</span></li>';
                            }
                            ?>

                            <?php if ($current_page_bl < $total_pages_bl): ?>
                                <li class="page-item"><a class="page-link" href="?<?php echo htmlspecialchars(http_build_query(array_merge(get_current_params_for_sort('belumLunas'), ['page_bl' => $current_page_bl + 1]))); ?>">Next</a></li>
                                <li class="page-item"><a class="page-link" href="?<?php echo htmlspecialchars(http_build_query(array_merge(get_current_params_for_sort('belumLunas'), ['page_bl' => $total_pages_bl]))); ?>">Last</a></li>
                            <?php endif; ?>
                        </ul>
                    </div>
                    <table class="data-table">
                        <thead>
                            <tr>
                                <th><a href="?<?php echo get_sort_url_params(get_current_params_for_sort('belumLunas'), 't.id_tagihan', $sort_column_belum_lunas, $sort_order_belum_lunas); ?>">ID Tagihan <?php if ($sort_column_belum_lunas == 't.id_tagihan') echo ($sort_order_belum_lunas == 'ASC' ? '&#9650;' : '&#9660;'); ?></a></th>
                                <th><a href="?<?php echo get_sort_url_params(get_current_params_for_sort('belumLunas'), 't.pelanggan_id', $sort_column_belum_lunas, $sort_order_belum_lunas); ?>">ID Pelanggan <?php if ($sort_column_belum_lunas == 't.pelanggan_id') echo ($sort_order_belum_lunas == 'ASC' ? '&#9650;' : '&#9660;'); ?></a></th>
                                <th><a href="?<?php echo get_sort_url_params(get_current_params_for_sort('belumLunas'), 'p.nama_pelanggan', $sort_column_belum_lunas, $sort_order_belum_lunas); ?>">Nama Pelanggan <?php if ($sort_column_belum_lunas == 'p.nama_pelanggan') echo ($sort_order_belum_lunas == 'ASC' ? '&#9650;' : '&#9660;'); ?></a></th>
                                <th><a href="?<?php echo get_sort_url_params(get_current_params_for_sort('belumLunas'), 'coll.nama_penagih', $sort_column_belum_lunas, $sort_order_belum_lunas); ?>">Penagih <?php if ($sort_column_belum_lunas == 'coll.nama_penagih') echo ($sort_order_belum_lunas == 'ASC' ? '&#9650;' : '&#9660;'); ?></a></th>
                                <th><a href="?<?php echo get_sort_url_params(get_current_params_for_sort('belumLunas'), 'p.alamat', $sort_column_belum_lunas, $sort_order_belum_lunas); ?>">Alamat <?php if ($sort_column_belum_lunas == 'p.alamat') echo ($sort_order_belum_lunas == 'ASC' ? '&#9650;' : '&#9660;'); ?></a></th>
                                <th><a href="?<?php echo get_sort_url_params(get_current_params_for_sort('belumLunas'), 'p.telepon', $sort_column_belum_lunas, $sort_order_belum_lunas); ?>">Telepon <?php if ($sort_column_belum_lunas == 'p.telepon') echo ($sort_order_belum_lunas == 'ASC' ? '&#9650;' : '&#9660;'); ?></a></th>
                                <th><a href="?<?php echo get_sort_url_params(get_current_params_for_sort('belumLunas'), 'pk.nama_paket', $sort_column_belum_lunas, $sort_order_belum_lunas); ?>">Paket <?php if ($sort_column_belum_lunas == 'pk.nama_paket') echo ($sort_order_belum_lunas == 'ASC' ? '&#9650;' : '&#9660;'); ?></a></th>
                                <th>Sisa Tagihan <?php if ($sort_column_belum_lunas == 't.jumlah_tagihan') echo ($sort_order_belum_lunas == 'ASC' ? '&#9650;' : '&#9660;'); ?></th>
                                <th><a href="?<?php echo get_sort_url_params(get_current_params_for_sort('belumLunas'), 't.bulan_tagihan', $sort_column_belum_lunas, $sort_order_belum_lunas); ?>">Bulan Tagihan <?php if ($sort_column_belum_lunas == 't.bulan_tagihan') echo ($sort_order_belum_lunas == 'ASC' ? '&#9650;' : '&#9660;'); ?></a></th>
                                <th><a href="?<?php echo get_sort_url_params(get_current_params_for_sort('belumLunas'), 't.tanggal_terbit', $sort_column_belum_lunas, $sort_order_belum_lunas); ?>">Tgl Terbit <?php if ($sort_column_belum_lunas == 'ASC') echo '&#9650;'; elseif ($sort_order_belum_lunas == 'DESC') echo '&#9660;'; ?></a></th>
                                <th>Aksi</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php if (!empty($pelanggan_belum_lunas_list)): ?>
                                <?php foreach ($pelanggan_belum_lunas_list as $tagihan_data): ?>
                                    <tr>
                                        <td><?php echo htmlspecialchars($tagihan_data['id_tagihan']); ?></td>
                                        <td><?php echo htmlspecialchars($tagihan_data['pelanggan_id']); ?></td>
                                        <td><?php echo htmlspecialchars($tagihan_data['nama_pelanggan']); ?></td>
                                        <td><?php echo htmlspecialchars($tagihan_data['nama_penagih'] ?? 'N/A'); ?></td>
                                        <td><?php echo htmlspecialchars($tagihan_data['alamat']); ?></td>
                                        <td><?php echo htmlspecialchars($tagihan_data['telepon']); ?></td>
                                        <td><?php echo htmlspecialchars($tagihan_data['nama_paket'] . ' (' . $tagihan_data['kecepatan'] . ')'); ?></td>
                                        <td>Rp <?php echo number_format($tagihan_data['jumlah_tagihan_display'], 0, ',', '.'); ?></td>
                                        <td><?php echo htmlspecialchars(date('F Y', strtotime($tagihan_data['bulan_tagihan'] . '-01'))); ?></td>
                                        <td><?php echo htmlspecialchars(date('d-m-Y', strtotime($tagihan_data['tanggal_terbit']))); ?></td>
                                        <td>
                                            <button type="button" class="btn-action btn-secondary open-action-menu-belum-lunas-btn" 
                                                    data-pelanggan-id="<?php echo isset($tagihan_data['pelanggan_id']) ? (int)$tagihan_data['pelanggan_id'] : 0; ?>"
                                                    data-jumlah-bayar="<?php echo isset($tagihan_data['jumlah_tagihan_display']) ? (float)$tagihan_data['jumlah_tagihan_display'] : 0.0; ?>"
                                                    data-paket-id="<?php echo isset($tagihan_data['paket_id']) ? (int)$tagihan_data['paket_id'] : 0; ?>"
                                                    data-bulan-tagihan="<?php echo htmlspecialchars($tagihan_data['bulan_tagihan']); ?>"
                                                    data-tagihan-id="<?php echo htmlspecialchars($tagihan_data['id_tagihan']); ?>"
                                                    data-tagihan-name="<?php echo htmlspecialchars($tagihan_data['nama_pelanggan']); ?>"
                                                    data-tanggal-jatuh-tempo="<?php echo htmlspecialchars(date('d M Y', strtotime($tagihan_data['tanggal_jatuh_tempo']))); ?>" 
                                                    data-telepon="<?php echo htmlspecialchars($tagihan_data['telepon']); ?>" 
                                                    data-payment-link-xendit="<?php echo htmlspecialchars($tagihan_data['payment_link'] ?? ''); ?>"
                                                <i class="fas fa-ellipsis-h"></i> Aksi
                                            </button>
                                        </td>
                                    </tr>
                                <?php endforeach; ?>
                            <?php else: ?>
                                <tr><td colspan="11" style="text-align: center;">Tidak ada tagihan belum lunas yang ditemukan.</td></tr>
                            <?php endif; ?>
                        </tbody>
                    </table>

                    <div class="pagination-controls" style="margin-top: 20px;">
                        <div>
                            Menampilkan <?php echo min($total_records_bl, $offset_bl + 1); ?> - <?php echo min($total_records_bl, $offset_bl + $per_page_bl); ?> dari <?php echo $total_records_bl; ?> data.
                        </div>
                        <ul class="pagination" style="margin: 0;">
                            <?php if ($current_page_bl > 1): ?>
                                <li class="page-item"><a class="page-link" href="?<?php echo htmlspecialchars(http_build_query(array_merge(get_current_params_for_sort('belumLunas'), ['page_bl' => 1]))); ?>">First</a></li>
                                <li class="page-item"><a class="page-link" href="?<?php echo htmlspecialchars(http_build_query(array_merge(get_current_params_for_sort('belumLunas'), ['page_bl' => $current_page_bl - 1]))); ?>">Previous</a></li>
                            <?php endif; ?>

                            <?php
                            $start_page_bl = max(1, $current_page_bl - 2);
                            $end_page_bl = min($total_pages_bl, $current_page_bl + 2);

                            if ($start_page_bl > 1) {
                                echo '<li class="page-item disabled"><span class="page-link">...</span></li>';
                            }
                            for ($i = $start_page_bl; $i <= $end_page_bl; $i++): ?>
                                <li class="page-item <?php echo ($i == $current_page_bl) ? 'active' : ''; ?>"><a class="page-link" href="?<?php echo htmlspecialchars(http_build_query(array_merge(get_current_params_for_sort('belumLunas'), ['page_bl' => $i]))); ?>"><?php echo $i; ?></a></li>
                            <?php endfor; ?>

                            <?php
                            if ($end_page_bl < $total_pages_bl) {
                                echo '<li class="page-item disabled"><span class="page-link">...</span></li>';
                            }
                            ?>

                            <?php if ($current_page_bl < $total_pages_bl): ?>
                                <li class="page-item"><a class="page-link" href="?<?php echo htmlspecialchars(http_build_query(array_merge(get_current_params_for_sort('belumLunas'), ['page_bl' => $current_page_bl + 1]))); ?>">Next</a></li>
                                <li class="page-item"><a class="page-link" href="?<?php echo htmlspecialchars(http_build_query(array_merge(get_current_params_for_sort('belumLunas'), ['page_bl' => $total_pages_bl]))); ?>">Last</a></li>
                            <?php endif; ?>
                        </ul>
                    </div>
                </div>
            </div>
        </div>

        <div id="actionMenuModal" class="action-menu-modal-overlay">
            <div class="action-menu-modal-content">
                <span class="close-button-modal" id="closeActionMenuModal">&times;</span>
                <h3 id="actionMenuModalTitle"><span id="actionItemName"></span></h3>
                <div class="action-menu-list" id="actionMenuButtons">
                    </div>
            </div>
        </div>
        <div id="customConfirmModal" class="custom-modal-overlay">
            <div class="custom-modal-content">
                <h3 id="confirmModalTitle">Konfirmasi Aksi</h3>
                <p id="confirmModalMessage"></p>
                <div class="custom-modal-buttons">
                    <button class="btn btn-confirm" id="confirmModalYes">Oke</button>
                    <button class="btn btn-cancel" id="confirmModalNo">Batal</button>
                </div>
            </div>
        </div>

        <script>
    // Global variables for custom modal action
    let modalActionConfig = null;
    // Variable to store the timeout ID for delayed form submission
    let filterTimeout = null;

    // Function to delay form submission
    function delayFilterSubmit(formId) {
        console.log(`delayFilterSubmit called for form: ${formId}`);
        // Clear any existing timeout to reset the delay
        if (filterTimeout) {
            clearTimeout(filterTimeout);
        }
        // Set a new timeout to submit the form after 500ms (0.5 seconds)
        filterTimeout = setTimeout(() => {
            const form = document.getElementById(formId);
            if (form) {
                form.submit();
            }
        }, 500); // 500 milliseconds delay
    }

    // Inisialisasi variabel elemen modal sebagai global
    let customConfirmModal;
    let confirmModalTitle;
    let confirmModalMessage;
    let confirmModalYes;
    let confirmModalNo;

    // Inisialisasi reminderAllStatusDiv di sini sebagai global
    let reminderAllStatusDiv;

    // ====================================================================================================
    // *** PERBAIKAN UTAMA: Deklarasikan APP_BASE_URL_FOR_PRINT dan API_ACCESS_TOKEN_FOR_PRINT di sini ***
    // Ini memastikan variabel-variabel ini didefinisikan sebelum fungsi-fungsi lain menggunakannya.
    // ====================================================================================================
    const APP_BASE_URL_FOR_PRINT = <?php echo json_encode($app_base_url_for_print); ?>;
    const API_ACCESS_TOKEN_FOR_PRINT = <?php echo json_encode($api_access_token_for_print); ?>;
    const DEFAULT_REMINDER_MESSAGE_TEMPLATE = <?php echo json_encode($default_reminder_message_template_php); ?>;
    const CSRF_TOKEN = <?php echo json_encode($csrf_token); ?>; // Pastikan ini ada!
    // ====================================================================================================

    // ====================================================================================================
    // *** FUNGSI UTAMA JAVASCRIPT: DEFINISIKAN SEBELUM DIGUNAKAN ***
    // Pindahkan definisi fungsi-fungsi ini ke atas agar tersedia saat DOMContentLoaded
    // ====================================================================================================

    // Function to show the custom modal
    function showCustomConfirm(title, message, actionDetails) {
        console.log("showCustomConfirm called with:", title, message, actionDetails);
        // Pastikan elemen-elemen ini sudah diinisialisasi sebelum digunakan
        if (!customConfirmModal || !confirmModalTitle || !confirmModalMessage || !confirmModalYes || !confirmModalNo) {
            // Initialize elements here, ensuring they are not null
            customConfirmModal = document.getElementById('customConfirmModal');
            confirmModalTitle = document.getElementById('confirmModalTitle');
            confirmModalMessage = document.getElementById('confirmModalMessage');
            confirmModalYes = document.getElementById('confirmModalYes');
            confirmModalNo = document.getElementById('confirmModalNo');

            // Attach listeners if they haven't been already (important for re-initialization logic)
            if (confirmModalYes && !confirmModalYes._hasListener) {
                confirmModalYes.addEventListener('click', async function() {
                    console.log("Confirm modal Yes clicked.");
                    if (modalActionConfig) {
                        if (modalActionConfig.type === 'redirect' && modalActionConfig.url) {
                            window.location.href = modalActionConfig.url;
                        } else if (modalActionConfig.type === 'callback' && typeof modalActionConfig.func === 'function') {
                            await modalActionConfig.func(...(modalActionConfig.args || []));
                        }
                    }
                    hideCustomConfirm();
                });
                confirmModalYes._hasListener = true;
            }

            if (confirmModalNo && !confirmModalNo._hasListener) {
                confirmModalNo.addEventListener('click', function() {
                    console.log("Confirm modal No clicked.");
                    hideCustomConfirm();
                });
                confirmModalNo._hasListener = true;
            }
        }

        confirmModalTitle.textContent = title;
        confirmModalMessage.textContent = message;

        modalActionConfig = actionDetails;

        customConfirmModal.classList.add('show');
    }

    // Function to hide the custom modal
    function hideCustomConfirm() {
        console.log("hideCustomConfirm called.");
        if (customConfirmModal) {
            customConfirmModal.classList.remove('show');
        }
        modalActionConfig = null;
    }

    // Fungsi untuk mengupdate info paket dan harga (termasuk AJAX get_sisa_tagihan.php)
    function updatePaketInfo() {
        console.log("updatePaketInfo called.");
        var selectPelanggan = document.getElementById('pelanggan_id');
        if (selectPelanggan && selectPelanggan.selectedIndex !== -1) {
            var selectedOption = selectPelanggan.options[selectPelanggan.selectedIndex];
            var hargaPaketDasar = parseFloat(selectedOption.dataset.hargaPaket || '0');
            var usesPpn = parseInt(selectedOption.dataset.usesPpn || '0');
            var paketId = selectedOption.dataset.paketId || '';
            var pelangganId = selectedOption.value;

            let finalHarga = hargaPaketDasar;
            if (usesPpn === 1) {
                finalHarga += (hargaPaketDasar * 0.11);
            }

            const bulanTagihanInput = document.getElementById('bulan_tagihan');
            const bulanTagihan = bulanTagihanInput.value;

            if (pelangganId && bulanTagihan) {
                fetch(`get_sisa_tagihan.php?pelanggan_id=${pelangganId}&bulan_tagihan=${bulanTagihan}`)
                    .then(response => {
                        if (!response.ok) {
                            throw new Error('Network response was not ok');
                        }
                        return response.json();
                    })
                    .then(data => {
                        if (data.sisa_tagihan !== undefined && data.sisa_tagihan !== null) {
                            document.getElementById('jumlah_bayar').value = parseFloat(data.sisa_tagihan).toFixed(0);
                            document.getElementById('harga_seharusnya').innerText = 'Rp ' + parseFloat(data.sisa_tagihan).toLocaleString('id-ID', {
                                minimumFractionDigits: 0,
                                maximumFractionDigits: 0
                            });
                        } else {
                            document.getElementById('jumlah_bayar').value = finalHarga.toFixed(0);
                            document.getElementById('harga_seharusnya').innerText = 'Rp ' + finalHarga.toLocaleString('id-ID', {
                                minimumFractionDigits: 0,
                                maximumFractionDigits: 0
                            });
                        }
                    })
                    .catch(error => {
                        console.error('Error fetching sisa tagihan:', error);
                        document.getElementById('jumlah_bayar').value = finalHarga.toFixed(0);
                        document.getElementById('harga_seharusnya').innerText = 'Rp ' + finalHarga.toLocaleString('id-ID', {
                            minimumFractionDigits: 0,
                            maximumFractionDigits: 0
                        });
                    });
            } else {
                document.getElementById('jumlah_bayar').value = finalHarga.toFixed(0);
                document.getElementById('harga_seharusnya').innerText = 'Rp ' + finalHarga.toLocaleString('id-ID', {
                    minimumFractionDigits: 0,
                    maximumFractionDigits: 0
                });
            }

            document.getElementById('paket_id_from_pelanggan').value = paketId;
        }
    }

    // Fungsi untuk menggabungkan nilai checkbox dan mengaturnya ke input hidden
    function updateMetodePembayaranInput() {
        console.log("updateMetodePembayaranInput called.");
        const cashCheckbox = document.getElementById('metode_cash');
        const transferCheckbox = document.getElementById('metode_transfer');
        const hiddenInput = document.getElementById('metode_pembayaran_hidden');
        const errorDiv = document.getElementById('metodePembayaranError');

        let selectedMethods = [];
        if (cashCheckbox.checked) {
            selectedMethods.push(cashCheckbox.value);
        }
        if (transferCheckbox.checked) {
            selectedMethods.push(transferCheckbox.value);
        }

        hiddenInput.value = selectedMethods.join(', ') || '';

        if (selectedMethods.length === 0) {
            errorDiv.style.display = 'block';
        } else {
            errorDiv.style.display = 'none';
        }
    }

    // Fungsi untuk menampilkan tab
    function showTab(tabId) {
        console.log("showTab called with:", tabId);
        var tabs = document.getElementsByClassName('tab-content');
        for (var i = 0; i < tabs.length; i++) {
            tabs[i].style.display = 'none';
        }
        document.getElementById(tabId).style.display = 'block';

        var buttons = document.querySelectorAll('.tabs .btn');
        buttons.forEach(function(button) {
            button.classList.remove('btn-primary');
            button.classList.add('btn-secondary');
        });

        var activeBtn = document.getElementById('btn' + tabId.charAt(0).toUpperCase() + tabId.slice(1));
        if (activeBtn) {
            activeBtn.classList.remove('btn-secondary');
            activeBtn.classList.add('btn-primary');
        }
    }

 // Fungsi untuk prefill form pembayaran
 function prefillPaymentForm(pelangganId, hargaTotalYangAkanDibayar, paketId, bulanTagihan) {
    console.log("prefillPaymentForm called with:", pelangganId, hargaTotalYangAkanDibayar, paketId, bulanTagihan);
    showTab('catatPembayaran');

    document.getElementById('pelanggan_id').value = pelangganId;
    // --- BARIS BARU DITAMBAHKAN DI SINI ---
    // Setelah nilai pelanggan_id diatur, panggil updatePaketInfo untuk memperbarui detail
    updatePaketInfo(); 
    // --- AKHIR BARIS BARU ---
    document.getElementById('bulan_tagihan').value = bulanTagihan;

    document.getElementById('jumlah_bayar').value = parseFloat(hargaTotalYangAkanDibayar).toFixed(0);
    document.getElementById('harga_seharusnya').innerText = 'Rp ' + parseFloat(hargaTotalYangAkanDibayar).toLocaleString('id-ID', {
        minimumFractionDigits: 0,
        maximumFractionDigits: 0
    });
    document.getElementById('paket_id_from_pelanggan').value = paketId;

    document.getElementById('tanggal_bayar').value = '<?php echo date('Y-m-d'); ?>';

    document.getElementById('catatPembayaran').scrollIntoView({
        behavior: 'smooth',
        block: 'start'
    });
 }

    // Fungsi untuk menyimpan pesan pengingat kustom
    function saveCustomReminderMessage() {
        console.log("saveCustomReminderMessage called.");
        const message = document.getElementById('reminderMessage').value;
        try {
            localStorage.setItem('customReminderMessage', message);
            showNotification('Pesan pengingat berhasil disimpan ke browser Anda!', 'success');
        } catch (e) {
            showNotification('Gagal menyimpan pesan pengingat. Mungkin browser Anda tidak mendukung penyimpanan lokal atau ruang penyimpanan penuh.', 'error');
            console.error('Failed to save reminder message:', e);
        }
    }

    // Fungsi untuk konfirmasi pengiriman pengingat massal
    async function sendReminderToAllUnpaidConfirmation() {
        console.log("sendReminderToAllUnpaidConfirmation called.");
        const reminderMessageTextArea = document.getElementById('reminderMessage');
        const customMessage = reminderMessageTextArea.value;

        if (!customMessage.trim()) {
            showNotification('Pesan pengingat tidak boleh kosong! Silakan isi pesan di bagian atas tabel.', 'warning');
            return;
        }

        // Untuk pratinjau pesan massal, kita akan menggunakan template mentah
        showCustomConfirm(
            'Konfirmasi Kirim Pengingat Massal',
            'Apakah Anda yakin ingin mengirim pesan pengingat tagihan ke SEMUA pelanggan yang belum lunas? Pesan yang akan dikirim: \n\n"' + customMessage + '"',
            { type: 'callback', func: sendReminderToAllUnpaid }
        );
    }

// Fungsi untuk mengirim pengingat massal
        async function sendReminderToAllUnpaid() {
            console.log("sendReminderToAllUnpaid function started.");
            const kirimPengingatBtn = document.getElementById('kirimPengingatBtn');
            const originalButtonHtml = kirimPengingatBtn.innerHTML;
            const reminderMessageTextArea = document.getElementById('reminderMessage');

            const customMessage = reminderMessageTextArea.value;

            kirimPengingatBtn.disabled = true;
            kirimPengingatBtn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Mengirim...';

            // Menghilangkan penggunaan reminderAllStatusDiv di sini karena akan pakai showNotification
            // reminderAllStatusDiv = document.getElementById('reminderAllStatus');
            // if (reminderAllStatusDiv) {
            //     reminderAllStatusDiv.style.display = 'block';
            //     reminderAllStatusDiv.className = 'alert alert-info';
            //     reminderAllStatusDiv.innerHTML = '<i class="fas fa-info-circle"></i> Mengirim pengingat ke semua pelanggan menunggak... Harap tunggu.<br>Terkirim: 0, Gagal: 0';
            // } else {
            //     console.warn("Elemen dengan ID 'reminderAllStatus' tidak ditemukan. Pesan status tidak dapat ditampilkan.");
            // }

            const attachInvoice = false;

            try {
                const response = await fetch('send_whatsapp_message.php', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json',
                    },
                    body: JSON.stringify({
                        action: 'send_reminder',
                        message_content: customMessage,
                        customer_ids: [],
                        attach_invoice: attachInvoice,
                        csrf_token: CSRF_TOKEN // Kirim token CSRF di sini
                    }),
                });

                const responseText = await response.text();
                console.log(`Raw Response Text from send_whatsapp_message.php (All Unpaid):`, responseText);

                let data;
                try {
                    data = JSON.parse(responseText);
                } catch (jsonError) {
                    console.error(`JSON parsing error (All Unpaid):`, jsonError);
                    // Gunakan showNotification untuk error parsing JSON
                    window.showNotification('Gagal memproses respons dari server. Respons tidak valid JSON.', 'error');
                    return;
                }

                console.log(`Parsed Data from send_whatsapp_message.php (All Unpaid):`, data);

                let hasAnyFailed = false;
                let sentCount = 0;
                let failedCount = 0;

                if (data.detailed_results && Array.isArray(data.detailed_results)) {
                    sentCount = data.detailed_results.filter(r => r.status === 'sent').length;
                    failedCount = data.detailed_results.filter(r => r.status === 'failed').length;
                    if (failedCount > 0) {
                        hasAnyFailed = true;
                    }
                } else {
                    const match = data.message ? data.message.match(/Berhasil: (\d+), Gagal: (\d+)/) : null;
                    if (match) {
                        sentCount = parseInt(match[1]);
                        failedCount = parseInt(match[2]);
                        if (failedCount > 0) {
                            hasAnyFailed = true;
                        }
                    }
                }

                // Logika utama untuk menampilkan notifikasi menggunakan showNotification
                if (response.ok && data.status === 'success' && !hasAnyFailed) { // Semua berhasil
                    window.showNotification(`Pengingat Selesai! Semua pesan berhasil dikirim. Terkirim: ${sentCount}, Gagal: ${failedCount}.`, 'success');
                } else if (response.ok && data.status === 'success' && hasAnyFailed) { // Ada yang berhasil, ada yang gagal
                    window.showNotification(`Pengingat Selesai dengan Peringatan! Beberapa pesan gagal terkirim. Terkirim: ${sentCount}, Gagal: ${failedCount}.`, 'warning');
                } else { // Kesalahan total dari HTTP atau status server PHP bukan 'success'
                    window.showNotification(`Gagal mengirim pengingat! ${data.message || 'Terjadi kesalahan tidak diketahui dari server.'}`, 'error');
                }
            } catch (error) {
                console.error(`Catch Error (All Unpaid):`, error);
                // Gunakan showNotification untuk error jaringan
                window.showNotification('Terjadi kesalahan jaringan atau server saat mengirim pengingat: ' + error.message, 'error');
            } finally {
                console.log("Finally block executed (All Unpaid).");
                if (kirimPengingatBtn) {
                    kirimPengingatBtn.disabled = false;
                    kirimPengingatBtn.innerHTML = originalButtonHtml;
                }
                // Tidak perlu menyembunyikan reminderAllStatusDiv lagi karena tidak digunakan
            }
        }
    // Fungsi untuk konfirmasi pengiriman pengingat individu
    async function sendSingleReminderConfirmation(buttonElement) {
        console.log("sendSingleReminderConfirmation called with button:", buttonElement);
        // PASTIKAN NAMA dataset MATCH DENGAN data-attribute DI PHP (camelCase)
        const customerName = buttonElement.dataset.tagihanName;
        const invoiceMonth = buttonElement.dataset.bulanTagihan;
        const invoiceAmount = buttonElement.dataset.jumlahBayar;
        const dueDate = buttonElement.dataset.tanggalJatuhTempo;
        const tagihanId = buttonElement.dataset.tagihanId;
        const paymentLinkXendit = buttonElement.dataset.paymentLinkXendit; // Ini harus 'paymentLinkXendit'

        const reminderMessageTextArea = document.getElementById('reminderMessage');
        let baseMessageContent = reminderMessageTextArea.value;

        if (!baseMessageContent.trim()) {
            showNotification('Pesan pengingat tidak boleh kosong! Silakan isi pesan di bagian atas tabel.', 'warning');
            return;
        }

        // --- Logika untuk membuat link di pratinjau ---
        const internalInvoiceLinkPreview = `${APP_BASE_URL_FOR_PRINT}/pages/print_invoice.php?source_table=tagihan&id=${tagihanId}&api_access_token=${API_ACCESS_TOKEN_FOR_PRINT}`;
        // Jika paymentLinkXendit kosong, beri tahu di pratinjau
        const actualXenditLinkPreview = paymentLinkXendit || '[Link_Pembayaran_Online_Tidak_Tersedia]';

        // --- Lakukan penggantian placeholder untuk pratinjau ---
        // PENTING: PASTIKAN STRING INI MENGGUNAKAN BACKTICKS (`)
        const personalizedMessagePreview = baseMessageContent
            .replace(/\[nama_pelanggan\]/g, customerName)
            .replace(/\[bulan\]/g, invoiceMonth)
            .replace(/\[jumlah\]/g, invoiceAmount)
            .replace(/\[jatuh_tempo\]/g, dueDate)
            .replace(/\[invoice_link_internal\]/g, internalInvoiceLinkPreview)
            .replace(/\[xendit_link\]/g, actualXenditLinkPreview); // Gunakan nama variabel yang sudah diganti

        // PENTING: PASTIKAN STRING TEMPLATE DI SINI MENGGUNAKAN BACKTICKS (`)
        showCustomConfirm(
            'Konfirmasi Kirim Pengingat',
            `Apakah Anda yakin ingin mengirim pengingat ke ${customerName} (Tagihan ${invoiceMonth})?\n\nPesan:\n"${personalizedMessagePreview}"`,
            { type: 'callback', func: sendSingleReminder, args: [buttonElement] }
        );
    }

// Fungsi untuk mengirim pengingat individu
        async function sendSingleReminder(buttonElement) {
            console.log("sendSingleReminder function started for:", buttonElement.dataset.tagihanName);
            // PASTIKAN NAMA dataset MATCH DENGAN data-attribute DI PHP (camelCase)
            const customerId = buttonElement.dataset.pelangganId;
            const customerName = buttonElement.dataset.tagihanName;
            const invoiceId = buttonElement.dataset.tagihanId;
            const invoiceMonth = buttonElement.dataset.bulanTagihan;
            const invoiceAmount = buttonElement.dataset.jumlahBayar;
            const dueDate = buttonElement.dataset.tanggalJatuhTempo;
            const phoneNumber = buttonElement.dataset.telepon;
            const paymentLinkXendit = buttonElement.dataset.paymentLinkXendit;

            // Variabel statusSpan tidak akan digunakan lagi untuk menampilkan notifikasi,
            // tetapi bisa tetap ada jika Anda masih memiliki elemen span di tabel dengan ID seperti `status-${invoiceId}`
            const statusSpan = document.getElementById(`status-${invoiceId}`);
            const originalButtonHtml = buttonElement.innerHTML;

            const reminderMessageTextArea = document.getElementById('reminderMessage');
            const baseMessageContent = reminderMessageTextArea.value;

            // Pastikan pesan tidak kosong
            if (!baseMessageContent.trim()) {
                window.showNotification('Pesan pengingat tidak boleh kosong! Silakan isi pesan di bagian atas tabel.', 'warning');
                return;
            }

            // Status indikator di UI (opsional, jika Anda punya elemen span di tabel dengan ID tsb)
            if (statusSpan) {
                statusSpan.className = 'whatsapp-status-text text-info';
                statusSpan.textContent = 'Mengirim...';
            } else {
                console.warn(`Status span for invoice ID ${invoiceId} not found. Status indicator in table may not update.`);
            }

            buttonElement.disabled = true;
            buttonElement.innerHTML = '<i class="fas fa-spinner fa-spin"></i>';

            // Mengirim data ke send_whatsapp_message.php
            try {
                console.log("Fetching send_whatsapp_message.php for single reminder...");
                const response = await fetch('send_whatsapp_message.php', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json', // Penting: Mengirim JSON
                    },
                    body: JSON.stringify({
                        action: 'send_reminder', // Ini akan memicu logika 'send_reminder' di PHP
                        message_content: baseMessageContent, // Kirim template mentah dari textarea
                        customer_ids: [customerId], // Kirim hanya ID pelanggan yang dipilih
                        customer_data: { // Kirim detail pelanggan agar PHP bisa mengisi placeholder
                            id_tagihan: invoiceId,
                            nama_pelanggan: customerName,
                            bulan_tagihan: invoiceMonth,
                            jumlah_tagihan: invoiceAmount,
                            tanggal_jatuh_tempo: dueDate,
                            telepon: phoneNumber,
                            payment_link: paymentLinkXendit // Kirim juga link Xendit dari data attribute
                        },
                        csrf_token: CSRF_TOKEN // Kirim token CSRF di sini
                    }),
                });

                const responseText = await response.text();
                console.log(`Raw Response Text for ${customerName} (ID: ${customerId}):`, responseText);

                // Perbaiki logika notifikasi di sini
                let data;
                try {
                    data = JSON.parse(responseText);
                } catch (jsonError) {
                    console.error(`JSON parsing error for ${customerName} (ID: ${customerId}):`, jsonError);
                    window.showNotification('Gagal memproses respons dari server untuk pengingat individual. Respons tidak valid JSON.', 'error');
                    return;
                }

                console.log(`Parsed Data for ${customerName} (ID: ${customerId}):`, data);

                // --- INI ADALAH BAGIAN KRUSIAL UNTUK DIPERBAIKI ---
                // PHP Anda mengembalikan status 'success' untuk keberhasilan,
                // dan pesan bisa berisi 'Berhasil: 1, Gagal: 0.'
                let isActuallySuccess = false;
                if (data.status === 'success') {
                    // Untuk pengiriman individual, jika status 'success', kita asumsikan berhasil.
                    // Atau bisa juga cek data.detailed_results[0].status jika ada
                    if (data.detailed_results && data.detailed_results.length > 0 && data.detailed_results[0].status === 'sent') {
                        isActuallySuccess = true;
                    } else if (data.message && data.message.includes('Berhasil: 1, Gagal: 0')) { // Fallback jika detailed_results tidak ada
                        isActuallySuccess = true;
                    } else if (typeof data.status === 'boolean' && data.status === true) { // Jika status berupa boolean true
                        isActuallySuccess = true;
                    } else if (data.message && data.message.includes('success')) { // Jika pesan mengandung kata 'success'
                        isActuallySuccess = true;
                    }
                }

                // Logika notifikasi menggunakan showNotification
                if (isActuallySuccess) {
                    window.showNotification(`Pengingat berhasil dikirim ke ${customerName}!`, 'success');
                } else {
                    window.showNotification(`Gagal mengirim pengingat ke ${customerName}: ${data.message || 'Error tidak diketahui.'}`, 'error');
                }

                // Update statusSpan di tabel jika ada (masih relevan jika Anda ingin indikator per baris)
                if (statusSpan) {
                    if (isActuallySuccess) {
                        statusSpan.className = 'whatsapp-status-text text-success';
                        statusSpan.textContent = 'Terkirim!';
                    } else {
                        statusSpan.className = 'whatsapp-status-text text-danger';
                        statusSpan.textContent = 'Gagal!';
                    }
                }

            } catch (error) {
                console.error(`Catch Error for ${customerName} (ID: ${customerId}):`, error);
                window.showNotification('Terjadi kesalahan jaringan atau server saat mengirim pengingat ke ' + customerName + ': ' + error.message, 'error');
            } finally {
                buttonElement.disabled = false;
                buttonElement.innerHTML = originalButtonHtml;
                // Sembunyikan indikator status di tabel setelah beberapa saat
                if (statusSpan) {
                    setTimeout(() => {
                        statusSpan.textContent = '';
                        statusSpan.className = 'whatsapp-status-text';
                    }, 5000);
                }
            }
        }

    // NEW: Action Menu Modal Functions (for pembayaran.php)
    // Declared globally
    let actionMenuModal;
    let closeActionMenuModalBtn;
    let actionItemNameSpan; // Renamed from actionCustomerNameSpan for generality
    let actionMenuButtonsDiv;

    function showActionMenuModal(itemId, itemName, itemType, itemData = {}) {
        console.log("showActionMenuModal called with:", itemId, itemName, itemType, itemData);
        // Ensure elements are initialized on first call or if they become null
        // This part might be causing issues if elements are not consistently available.
        // Let's ensure these are always defined once, likely in DOMContentLoaded.
        if (!actionMenuModal) { // Check if already initialized
            actionMenuModal = document.getElementById('actionMenuModal');
            closeActionMenuModalBtn = document.getElementById('closeActionMenuModal');
            actionItemNameSpan = document.getElementById('actionItemName');
            actionMenuButtonsDiv = document.getElementById('actionMenuButtons');

            if (closeActionMenuModalBtn && !closeActionMenuModalBtn._hasListener) {
                closeActionMenuModalBtn.addEventListener('click', hideActionMenuModal);
                closeActionMenuModalBtn._hasListener = true;
            }
            if (actionMenuModal && !actionMenuModal._hasListener) {
                actionMenuModal.addEventListener('click', function(event) {
                    if (event.target === actionMenuModal) { // Only close if clicking on the overlay itself
                        hideActionMenuModal();
                    }
                });
                actionMenuModal._hasListener = true;
            }
        }

        actionItemNameSpan.textContent = itemName;
        actionMenuButtonsDiv.innerHTML = ''; // Clear previous buttons

        // Common action: Cetak (Print)
        if (itemType === 'riwayat_pembayaran') {
            let printInvoiceBtn = document.createElement('a');
            printInvoiceBtn.href = `print_invoice.php?source_table=tagihan&id=${itemData.id_tagihan_terkait}`;
            printInvoiceBtn.target = '_blank';
            printInvoiceBtn.className = 'btn-action-modal info-modal';
            printInvoiceBtn.innerHTML = '<i class="fas fa-print"></i> Cetak Invoice';
            // Add an event listener to close the modal when the print button is clicked
            printInvoiceBtn.addEventListener('click', hideActionMenuModal); // FIX: Close modal when print is clicked

            if (!itemData.id_tagihan_terkait) {
                printInvoiceBtn.href = `print_invoice.php?source_table=payment&id=${itemId}`;
                printInvoiceBtn.innerHTML = '<i class="fas fa-print"></i> Cetak Bukti Bayar';
            }
            actionMenuButtonsDiv.appendChild(printInvoiceBtn);

            <?php if (hasRole('superadmin')): ?>
            let deletePaymentBtn = document.createElement('button');
            deletePaymentBtn.type = 'button';
            deletePaymentBtn.className = 'btn-action-modal delete-modal';
            deletePaymentBtn.innerHTML = '<i class="fas fa-trash-alt"></i> Hapus Pembayaran Ini';
            deletePaymentBtn.addEventListener('click', function() {
                showCustomConfirm(
                    'Konfirmasi Hapus Pembayaran',
                    `Apakah Anda yakin ingin menghapus ${itemName}? Aksi ini tidak dapat dibatalkan.`,
                    { type: 'redirect', url: `pembayaran.php?action=delete_payment&id=${itemId}` }
                );
                hideActionMenuModal(); // Hide action modal after showing confirm
            });
            actionMenuButtonsDiv.appendChild(deletePaymentBtn);
            <?php endif; ?>

        } else if (itemType === 'tagihan_belum_lunas') {
            let payNowBtn = document.createElement('button');
            payNowBtn.type = 'button';
            payNowBtn.className = 'btn-action-modal success-modal';
            payNowBtn.innerHTML = '<i class="fas fa-money-bill-wave"></i> Bayar Sekarang';
            payNowBtn.addEventListener('click', function() {
                // Pastikan atribut data yang benar diteruskan ke prefillPaymentForm
                prefillPaymentForm(
                    itemData.pelangganId, // Gunakan itemData.pelangganId
                    itemData.jumlahTagihanDisplay, // Gunakan itemData.jumlahTagihanDisplay
                    itemData.paketId,
                    itemData.bulanTagihan
                );
                hideActionMenuModal();
            });
            actionMenuButtonsDiv.appendChild(payNowBtn);

            let printTagihanBtn = document.createElement('a');
            printTagihanBtn.href = `print_invoice.php?source_table=tagihan&id=${itemId}`;
            printTagihanBtn.target = '_blank';
            printTagihanBtn.className = 'btn-action-modal info-modal';
            printTagihanBtn.innerHTML = '<i class="fas fa-print"></i> Cetak Tagihan';
            // Add an event listener to close the modal when the print button is clicked
            printTagihanBtn.addEventListener('click', hideActionMenuModal); // FIX: Close modal when print is clicked
            actionMenuButtonsDiv.appendChild(printTagihanBtn);

            <?php if (hasRole('superadmin')): ?>
            let deleteTagihanBtn = document.createElement('button');
            deleteTagihanBtn.type = 'button';
            deleteTagihanBtn.className = 'btn-action-modal delete-modal';
            deleteTagihanBtn.innerHTML = '<i class="fas fa-trash-alt"></i> Hapus Tagihan Ini';
            deleteTagihanBtn.addEventListener('click', function() {
                showCustomConfirm(
                    'Konfirmasi Hapus Tagihan',
                    `Apakah Anda yakin ingin menghapus ${itemName}? Aksi ini tidak dapat dibatalkan.`,
                    { type: 'redirect', url: `pembayaran.php?action=delete_tagihan&id=${itemId}` }
                );
                hideActionMenuModal(); // Hide action modal after showing confirm
            });
            actionMenuButtonsDiv.appendChild(deleteTagihanBtn);
            <?php endif; ?>

            <?php if (hasRole(['superadmin', 'admin'])): ?>
            if (itemData.telepon && itemData.telepon.trim() !== '') {
                let sendReminderBtn = document.createElement('button');
                sendReminderBtn.type = 'button';
                sendReminderBtn.className = 'btn-action-modal whatsapp-modal';
                sendReminderBtn.innerHTML = '<i class="fab fa-whatsapp"></i> Kirim Pengingat WA';
                sendReminderBtn.addEventListener('click', function() {
                    // Perhatikan bahwa itemData sudah memiliki semua data yang diperlukan
                    // Kita bisa langsung meneruskannya ke sendSingleReminderConfirmation
                    sendSingleReminderConfirmation(this); // Mengirim elemen tombol itu sendiri
                    hideActionMenuModal(); // Hide action modal after triggering reminder
                });
                // Penting: Salin semua data-attribute dari tombol aksi asli ke tombol Kirim Pengingat WA
                // agar sendSingleReminderConfirmation bisa mengaksesnya.
                for (const key in itemData) {
                    if (itemData.hasOwnProperty(key)) {
                        sendReminderBtn.dataset[key] = itemData[key];
                    }
                }
                actionMenuButtonsDiv.appendChild(sendReminderBtn);
            }
            <?php endif; ?>
        }

        actionMenuModal.classList.add('show');
    }

    function hideActionMenuModal() {
        console.log("hideActionMenuModal called.");
        if (actionMenuModal) {
            actionMenuModal.classList.remove('show');
        }
    }
    // END NEW ACTION MENU MODAL FUNCTIONS


    // ====================================================================================================
    // *** AKHIR DARI FUNGSI JAVASCRIPT ***
    // ====================================================================================================


    // Panggil saat halaman dimuat
    document.addEventListener('DOMContentLoaded', function() {
        console.log("DOMContentLoaded fired."); // Log untuk memastikan ini berjalan

        // Inisialisasi elemen modal di sini setelah DOM dimuat
        // Pastikan ini hanya berjalan SEKALI. Menambahkan properti _initialized
        if (typeof customConfirmModal === 'undefined' || customConfirmModal === null) {
            customConfirmModal = document.getElementById('customConfirmModal');
            confirmModalTitle = document.getElementById('confirmModalTitle');
            confirmModalMessage = document.getElementById('confirmModalMessage');
            confirmModalYes = document.getElementById('confirmModalYes');
            confirmModalNo = document.getElementById('confirmModalNo');

            // Attach listeners if they haven't been already
            if (confirmModalYes && !confirmModalYes._hasListener) {
                confirmModalYes.addEventListener('click', async function() {
                    console.log("Confirm modal Yes clicked.");
                    if (modalActionConfig) {
                        if (modalActionConfig.type === 'redirect' && modalActionConfig.url) {
                            window.location.href = modalActionConfig.url;
                        } else if (modalActionConfig.type === 'callback' && typeof modalActionConfig.func === 'function') {
                            await modalActionConfig.func(...(modalActionConfig.args || []));
                        }
                    }
                    hideCustomConfirm();
                });
                confirmModalYes._hasListener = true;
            }

            if (confirmModalNo && !confirmModalNo._hasListener) {
                confirmModalNo.addEventListener('click', function() {
                    console.log("Confirm modal No clicked.");
                    hideCustomConfirm();
                });
                confirmModalNo._hasListener = true;
            }
        }


        // NEW: Inisialisasi elemen action menu modal
        // Pastikan ini hanya berjalan SEKALI. Menambahkan properti _initialized
        if (typeof actionMenuModal === 'undefined' || actionMenuModal === null) {
            actionMenuModal = document.getElementById('actionMenuModal');
            closeActionMenuModalBtn = document.getElementById('closeActionMenuModal');
            actionItemNameSpan = document.getElementById('actionItemName');
            actionMenuButtonsDiv = document.getElementById('actionMenuButtons');

            if (closeActionMenuModalBtn && !closeActionMenuModalBtn._hasListener) {
                closeActionMenuModalBtn.addEventListener('click', hideActionMenuModal);
                closeActionMenuModalBtn._hasListener = true;
            }
            if (actionMenuModal && !actionMenuModal._hasListener) {
                actionMenuModal.addEventListener('click', function(event) {
                    if (event.target === actionMenuModal) { // Only close if clicking on the overlay itself
                        hideActionMenuModal();
                    }
                });
                actionMenuModal._hasListener = true;
            }
        }

        // Inisialisasi reminderAllStatusDiv di sini saat DOMContentLoaded
        reminderAllStatusDiv = document.getElementById('reminderAllStatus');


        var urlParams = new URLSearchParams(window.location.search);
        var statusFilter = urlParams.get('status');
        var initialPelangganId = urlParams.get('pelanggan_id');
        var initialTagihanId = urlParams.get('tagihan_id');
        var initialTabFromUrl = urlParams.get('tab');
        var filterTglMulaiRiwayat = urlParams.get('filter_tgl_mulai_riwayat');
        var filterTglAkhirRiwayat = urlParams.get('filter_tgl_akhir_riwayat');
        var filterTglTerbitMulaiBl = urlParams.get('filter_tgl_terbit_mulai_bl');
        var filterTglTerbitAkhirBl = urlParams.get('filter_tgl_terbit_akhir_bl');

        const btnCatatPembayaran = document.getElementById('btnCatatPembayaran');
        const btnRiwayatPembayaran = document.getElementById('btnRiwayatPembayaran');
        const btnBelumLunas = document.getElementById('btnBelumLunas');

        if (btnCatatPembayaran) {
            btnCatatPembayaran.addEventListener('click', function() { showTab('catatPembayaran'); });
        }
        if (btnRiwayatPembayaran) {
            btnRiwayatPembayaran.addEventListener('click', function() { showTab('riwayatPembayaran'); });
        }
        if (btnBelumLunas) {
            btnBelumLunas.addEventListener('click', function() { showTab('belumLunas'); });
        }

        const kirimPengingatBtn = document.getElementById('kirimPengingatBtn');
        if (kirimPengingatBtn) {
            kirimPengingatBtn.addEventListener('click', sendReminderToAllUnpaidConfirmation);
            console.log("Event listener attached to kirimPengingatBtn");
        }

        const saveReminderMessageBtn = document.getElementById('saveReminderMessageBtn');
        if (saveReminderMessageBtn) {
            saveReminderMessageBtn.addEventListener('click', saveCustomReminderMessage);
            console.log("Event listener attached to saveReminderMessageBtn");
        }

        // Delegasi event listener untuk tombol kirim pengingat individu (ini sudah tidak digunakan langsung)
        // Logika pengiriman sekarang di handle di showActionMenuModal
        document.addEventListener('click', function(event) {
            const targetButton = event.target.closest('.send-single-reminder-btn');
            if (targetButton) {
                event.preventDefault(); // Mencegah aksi default link/tombol jika ada
                // sendSingleReminderConfirmation(targetButton); // Logika ini dipindahkan ke showActionMenuModal
            }
        }, true); // Use true for capture phase to ensure it runs before other clicks on the same element

        // Delegasi event listener untuk tombol "Aksi" di Riwayat Pembayaran
        document.addEventListener('click', function(event) {
            const targetButton = event.target.closest('.open-action-menu-riwayat-btn');
            if (targetButton) {
                event.preventDefault();
                event.stopPropagation(); // Prevent event from bubbling up and closing modal immediately

                const paymentId = targetButton.dataset.paymentId;
                const tagihanId = targetButton.dataset.tagihanId;
                const paymentName = targetButton.dataset.paymentName;

                // Get the row data (simulated for simplicity, normally you'd fetch or pass more)
                const row = targetButton.closest('tr');
                const rowData = {
                    id_pembayaran: paymentId,
                    id_tagihan_terkait: tagihanId,
                    // Add other relevant data from the row if needed for button logic in modal
                    // e.g., row.cells[1].textContent for customer name
                };

                showActionMenuModal(paymentId, paymentName, 'riwayat_pembayaran', rowData);
            }
        }, true);

        // Delegasi event listener untuk tombol "Aksi" di Tagihan Belum Lunas
        document.addEventListener('click', function(event) {
            const targetButton = event.target.closest('.open-action-menu-belum-lunas-btn');
            if (targetButton) {
                event.preventDefault();
                event.stopPropagation(); // Prevent event from bubbling up and closing modal immediately

                // Ambil semua data dari dataset tombol untuk diteruskan ke modal
                const itemData = targetButton.dataset;

                // Karena itemData sudah berisi semua data dari PHP, kita bisa langsung meneruskannya
                showActionMenuModal(itemData.tagihanId, itemData.tagihanName, 'tagihan_belum_lunas', itemData);
            }
        }, true);


        const savedCustomReminderMessage = localStorage.getItem('customReminderMessage');
        const reminderMessageTextArea = document.getElementById('reminderMessage');
        if (reminderMessageTextArea) {
            if (savedCustomReminderMessage) {
                reminderMessageTextArea.value = savedCustomReminderMessage;
            } else {
                reminderMessageTextArea.value = DEFAULT_REMINDER_MESSAGE_TEMPLATE;
            }
        }

        var defaultTabId = 'catatPembayaran';

        if (initialTabFromUrl) {
            defaultTabId = initialTabFromUrl;
        } else if (filterTglMulaiRiwayat || filterTglAkhirRiwayat || urlParams.has('filter_penagih_id_riwayat') || urlParams.has('filter_nama_pelanggan_riwayat')) {
            defaultTabId = 'riwayatPembayaran';
        } else if (filterTglTerbitMulaiBl || filterTglTerbitAkhirBl || urlParams.has('filter_penagih_id_bl') || urlParams.has('filter_nama_pelanggan_bl')) {
            defaultTabId = 'belumLunas';
        } else if (initialTagihanId) {
            defaultTabId = 'catatPembayaran';
        } else if (initialPelangganId) {
            defaultTabId = 'riwayatPembayaran';
        } else if (statusFilter === 'lunas') {
            defaultTabId = 'riwayatPembayaran';
        } else if (statusFilter === 'belum_lunas') {
            defaultTabId = 'belumLunas';
        }

        showTab(defaultTabId);

        if (initialPelangganId && initialTagihanId) {
            let pelangganBelumLunasList;
            try {
                // Pastikan ini adalah data yang sama persis seperti yang diambil dari query PHP
                pelangganBelumLunasList = <?php echo json_encode($pelanggan_belum_lunas_list, JSON_HEX_TAG | JSON_HEX_APOS | JSON_HEX_AMP | JSON_HEX_QUOT); ?>;
                if (!Array.isArray(pelangganBelumLunasList)) {
                    console.error("pelanggan_belum_lunas_list is not an array:", pelangganBelumLunasList);
                    pelangganBelumLunasList = [];
                }
            } catch (e) {
                console.error("Error parsing pelanggan_belum_lunas_list JSON:", e);
                pelangganBelumLunasList = [];
            }

            const tagihanData = pelangganBelumLunasList.find(
                t => t.pelanggan_id == initialPelangganId && t.id_tagihan == initialTagihanId
            );
            if (tagihanData) {
                prefillPaymentForm(
                    parseInt(tagihanData.pelanggan_id),
                    parseFloat(tagihanData.jumlah_tagihan_display),
                    parseInt(tagihanData.paket_id),
                    tagihanData.bulan_tagihan
                );
            }
        } else if (document.getElementById('pelanggan_id').value) {
            if (defaultTabId === 'catatPembayaran') {
                updatePaketInfo();
            }
        }

        document.getElementById('bulan_tagihan').addEventListener('change', updatePaketInfo);
        document.getElementById('pelanggan_id').addEventListener('change', updatePaketInfo);

        updateMetodePembayaranInput();

        const paymentForm = document.getElementById('paymentForm');
        const metodeCash = document.getElementById('metode_cash');
        const metodeTransfer = document.getElementById('metode_transfer');
        const metodePembayaranErrorDiv = document.getElementById('metodePembayaranError');

        paymentForm.addEventListener('submit', function(event) {
            updateMetodePembayaranInput();
            if (!metodeCash.checked && !metodeTransfer.checked) {
                event.preventDefault();
                metodePembayaranErrorDiv.style.display = 'block';
                metodePembayaranErrorDiv.scrollIntoView({ behavior: 'smooth', block: 'center' });
            } else {
                metodePembayaranErrorDiv.style.display = 'none';
            }
        });

        // Panggil showNotification dari PHP jika ada pesan
        <?php if (!empty($message_script)): ?>
            // Pastikan window.showNotification sudah tersedia dari header.php
            if (window.showNotification) {
                // Panggil script pesan yang sudah disiapkan PHP
                <?php echo $message_script; ?>
            } else {
                // Fallback jika showNotification belum siap (misal, DOMContentLoaded di header belum jalan)
                document.addEventListener('DOMContentLoaded', function() {
                    <?php echo $message_script; ?>
                });
            }
        <?php endif; ?>
        // Hapus parameter msg_original dari URL agar notifikasi tidak muncul lagi saat refresh
        // Ini akan selalu dijalankan pada DOMContentLoaded
        if (window.history.replaceState) {
            const url = new URL(window.location.href);
            url.searchParams.delete('msg_original');
            url.searchParams.delete('new_status_original');
            url.searchParams.delete('count_original');
            url.searchParams.delete('err_original');
            url.searchParams.delete('detail_original');
            window.history.replaceState({path: url.href}, '', url.href);
        }
    });
   </script>

    </div>
</div>

<?php include '../includes/footer.php'; ?>
