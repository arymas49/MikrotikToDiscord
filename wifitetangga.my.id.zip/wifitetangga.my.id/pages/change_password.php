<?php
// C:\xampp\htdocs\billing_isp_app\pages\change_password.php
ob_start();
ini_set('session.use_strict_mode', 1);
ini_set('session.cookie_httponly', 1);
ini_set('session.cookie_samesite', 'Lax');
if (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on') {
    ini_set('session.cookie_secure', 1);
}
session_start();
include '../config/koneksi.php';
include '../includes/header.php';

// Ambil nama halaman saat ini untuk judul
$page_name = ucwords(str_replace('_', ' ', basename(__FILE__, '.php')));

$message = ''; // Untuk pesan sukses/error
$user_id = $_SESSION['user_id'];

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $current_password = $_POST['current_password'];
    $new_password = $_POST['new_password'];
    $confirm_password = $_POST['confirm_password'];

    // 1. Ambil password lama dari database
    $stmt = $koneksi->prepare("SELECT password FROM users WHERE id = ?");
    $stmt->bind_param("i", $user_id);
    $stmt->execute();
    $result = $stmt->get_result();
    $user = $result->fetch_assoc();
    $stmt->close();

    if ($user) {
        // 2. Verifikasi password lama
        if (password_verify($current_password, $user['password'])) {
            // 3. Pastikan password baru dan konfirmasi cocok
            if ($new_password === $confirm_password) {
                // 4. Hash password baru dan update ke database
                $hashed_new_password = password_hash($new_password, PASSWORD_DEFAULT);
                $stmt_update = $koneksi->prepare("UPDATE users SET password = ? WHERE id = ?");
                $stmt_update->bind_param("si", $hashed_new_password, $user_id);
                if ($stmt_update->execute()) {
                    $message = '<div class="alert alert-success">Password berhasil diubah.</div>';
                } else {
                    $message = '<div class="alert alert-danger">Gagal mengubah password: ' . $stmt_update->error . '</div>';
                }
                $stmt_update->close();
            } else {
                $message = '<div class="alert alert-danger">Password baru dan konfirmasi tidak cocok.</div>';
            }
        } else {
            $message = '<div class="alert alert-danger">Password lama salah.</div>';
        }
    } else {
        $message = '<div class="alert alert-danger">Pengguna tidak ditemukan.</div>';
    }
}
?>

<div class="main-content">
    <div class="top-header">
        <div class="alert-message">
            Pemberitahuan: Ubah password secara berkala untuk keamanan.
        </div>
        <div class="welcome-message">
            <span>Selamat datang, <?php echo htmlspecialchars($_SESSION['username'] ?? 'User'); ?>!</span>
            <a href="../logout.php" class="btn-logout">Logout</a> 
        </div>
    </div>

    <div class="container">
        <h2><?php echo htmlspecialchars($page_name); ?></h2>
        
        <?php echo htmlspecialchars($message, ENT_QUOTES, "UTF-8"); ?>

        <div class="card">
            <div class="card-header">
                <h3>Form Ubah Password</h3>
            </div>
            <div class="card-body">
                <form method="POST"><?php if (!isset($_SESSION['csrf_token'])) { $_SESSION['csrf_token'] = bin2hex(random_bytes(32)); } ?><input type='hidden' name='csrf_token' value='<?php echo $_SESSION['csrf_token']; ?>'>
                    <div class="form-group">
                        <label for="current_password">Password Lama:</label>
                        <input type="password" id="current_password" name="current_password" required>
                    </div>
                    <div class="form-group">
                        <label for="new_password">Password Baru:</label>
                        <input type="password" id="new_password" name="new_password" required>
                    </div>
                    <div class="form-group">
                        <label for="confirm_password">Konfirmasi Password Baru:</label>
                        <input type="password" id="confirm_password" name="confirm_password" required>
                    </div>
                    <button type="submit" class="btn btn-primary">Ubah Password</button>
                </form>
            </div>
        </div>

    </div>
</div>

<?php include '../includes/footer.php'; ?>