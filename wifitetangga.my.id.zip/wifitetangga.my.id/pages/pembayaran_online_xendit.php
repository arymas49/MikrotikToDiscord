<?php
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!isset($_POST['csrf_token']) || $_POST['csrf_token'] !== $_SESSION['csrf_token']) {
        die('CSRF validation failed.');
    }
}
?>
<?php
// C:\xampp\htdocs\billing_isp_app\pages\pembayaran_online_xendit.php

// --- PENTING: Mulai Output Buffering SEBAGAI BARIS PERTAMA. ---
// Pastikan TIDAK ADA spasi, baris kosong, atau karakter lain sebelum <?php tag ini.
ob_start();

// Pastikan pelaporan error diaktifkan untuk debugging
// Di production, ini harus 0
ini_set('display_errors', 1); // Set ke 0 di Production
ini_set('display_startup_errors', 1); // Set ke 0 di Production
error_reporting(E_ALL);

// Sertakan file autoload.php
$autoloadPath = dirname(__DIR__, 1) . '/vendor/autoload.php';

if (!file_exists($autoloadPath)) {
    // Jika autoloader tidak ditemukan, kirim respons error JSON dan keluar.
    // ob_clean() sudah dipanggil di bagian POST, tapi untuk kondisi fatal ini, 
    // kita pastikan buffer bersih sebelum respons.
    ob_clean(); 
    http_response_code(500);
    header('Content-Type: application/json');
    echo json_encode(['status' => 'error', 'message' => 'Fatal error: Composer autoload file not found.']);
    exit();
}

require_once $autoloadPath; 

ini_set('session.use_strict_mode', 1);
ini_set('session.cookie_httponly', 1);
ini_set('session.cookie_samesite', 'Lax');
if (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on') {
    ini_set('session.cookie_secure', 1);
}
session_start(); 

// Sertakan koneksi database
include '../config/koneksi.php';

// PENTING: Include header.php di sini HANYA UNTUK GET request (ketika halaman dirender).
// Jika ini adalah POST request AJAX, kita tidak perlu header HTML.
if ($_SERVER['REQUEST_METHOD'] === 'GET') {
    include '../includes/header.php'; 
}


// --- Proses Aksi dari Form atau AJAX (Membuat/Mengirim Ulang/Menghapus Invoice) ---
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action'])) {
    ob_clean(); 
    header('Content-Type: application/json'); 

    include_once '../includes/xendit_utils.php'; 
    $xenditConfig = include '../config/xendit_config.php';
    \Xendit\Configuration::setXenditKey($xenditConfig['xendit_secret_key']);

    $response = ['status' => 'error', 'message' => 'Invalid request.'];
    $tagihan_id = $_POST['tagihan_id'] ?? null;
    
    // MODIFIKASI BARIS INI: Tambahkan pengecekan is_array()
    $tagihan_ids = []; // Inisialisasi default
    if (isset($_POST['tagihan_ids'])) {
        $decoded_ids = json_decode($_POST['tagihan_ids'], true);
        if (is_array($decoded_ids)) {
            $tagihan_ids = $decoded_ids;
        } else {
            // Log this for debugging if it happens
            error_log("Invalid JSON for tagihan_ids received: " . $_POST['tagihan_ids']);
            $response = ['status' => 'error', 'message' => 'Data tagihan terpilih tidak valid.'];
            echo json_encode($response);
            exit(); // Penting untuk keluar jika data tidak valid
        }
    }

    // Fallback hasRole()
    if (!function_exists('hasRole')) {
        function hasRole($required_role) {
            return isset($_SESSION['role']) && (is_array($required_role) ? in_array($_SESSION['role'], $required_role) : $_SESSION['role'] === $required_role || $_SESSION['role'] === 'superadmin');
        }
    }

    // Fungsi pembantu untuk mengambil data tagihan
    function getTagihanData($koneksi, $id) {
        $query_data = "
            SELECT t.id_tagihan, t.total_tagihan, t.bulan_tagihan, t.xendit_invoice_id, t.payment_link, t.tanggal_jatuh_tempo,
                   p.nama_pelanggan, p.email AS email_pelanggan, p.telepon AS telepon_pelanggan,
                   pk.nama_paket
            FROM tagihan t
            JOIN pelanggan p ON t.pelanggan_id = p.id_pelanggan
            LEFT JOIN paket_layanan pk ON t.paket_id = pk.id_paket
            WHERE t.id_tagihan = ?
        ";
        if ($stmt_data = $koneksi->prepare($query_data)) {
            $stmt_data->bind_param("i", $id);
            $stmt_data->execute();
            $result_data = $stmt_data->get_result();
            $tagihan = $result_data->fetch_assoc();
            $stmt_data->close();
            return $tagihan;
        }
        return false;
    }

    if ($_POST['action'] === 'create_xendit_invoice') { // Aksi Individual
        if ($tagihan_id) {
            $tagihan_data = getTagihanData($koneksi, $tagihan_id);
            if ($tagihan_data) {
                if (empty($tagihan_data['email_pelanggan'])) {
                    $response = ['status' => 'error', 'message' => 'Email pelanggan tidak ditemukan. Xendit memerlukan email untuk mengirim invoice. Harap lengkapi data pelanggan.'];
                } elseif (empty($tagihan_data['xendit_invoice_id'])) {
                    $description = "Pembayaran Tagihan ISP " . date('F Y', strtotime($tagihan_data['bulan_tagihan'])) . " untuk " . htmlspecialchars($tagihan_data['nama_pelanggan']);
                    
                    $xenditResponse = createXenditInvoice(
                        $xenditConfig,
                        $tagihan_data['id_tagihan'],
                        $tagihan_data['total_tagihan'],
                        $tagihan_data['nama_pelanggan'],
                        $tagihan_data['email_pelanggan'],
                        $description,
                        $tagihan_data['tanggal_jatuh_tempo']
                    );

                    if ($xenditResponse['success']) {
                        $update_query = "UPDATE tagihan SET xendit_invoice_id = ?, payment_link = ? WHERE id_tagihan = ?";
                        if ($stmt_update = $koneksi->prepare($update_query)) {
                            $stmt_update->bind_param("ssi", $xenditResponse['invoice_id'], $xenditResponse['payment_link'], $tagihan_id);
                            $stmt_update->execute();
                            $stmt_update->close();
                            $response = ['status' => 'success', 'message' => 'Invoice Xendit berhasil dibuat!', 'payment_link' => $xenditResponse['payment_link']];
                        } else {
                            $response = ['status' => 'error', 'message' => 'Gagal update database dengan link pembayaran Xendit: ' . $koneksi->error];
                        }
                    } else {
                        $response = ['status' => 'error', 'message' => 'Gagal membuat invoice Xendit: ' . ($xenditResponse['message'] ?? 'Unknown error.')];
                    }
                } else {
                    $response = ['status' => 'info', 'message' => 'Invoice Xendit sudah ada untuk tagihan ini.'];
                }
            } else {
                $response = ['status' => 'error', 'message' => 'Tagihan tidak ditemukan.'];
            }
        }
    } elseif ($_POST['action'] === 'resend_xendit_invoice_email') { // Aksi Individual (Info Link)
        if ($tagihan_id) {
            $tagihan_data = getTagihanData($koneksi, $tagihan_id);
            if (!empty($tagihan_data['xendit_invoice_id'])) {
                try {
                    $invoice = \Xendit\Invoice::retrieve($tagihan_data['xendit_invoice_id']);
                    if ($invoice && ($invoice['status'] == 'PENDING' || $invoice['status'] == 'UNPAID' || $invoice['status'] == 'EXPIRED')) { 
                        $response = ['status' => 'info', 'message' => 'Tautan pembayaran sudah tersedia. Silakan bagikan link ini ke pelanggan: ' . $tagihan_data['payment_link']];
                    } else if ($invoice && ($invoice['status'] == 'PAID' || $invoice['status'] == 'SETTLED')) {
                        $response = ['status' => 'info', 'message' => 'Invoice Xendit sudah lunas, tidak perlu kirim ulang.'];
                    } else {
                        $response = ['status' => 'error', 'message' => 'Gagal mengambil detail invoice dari Xendit atau status tidak valid.'];
                    }
                } catch (\Xendit\Exceptions\ApiException $e) {
                    $response = ['status' => 'error', 'message' => 'Xendit API Error (resend email check): ' . $e->getMessage()];
                    error_log("Xendit API Error (resend email check): " . $e->getMessage());
                } catch (Exception $e) {
                    $response = ['status' => 'error', 'message' => 'Terjadi kesalahan umum saat mengecek invoice Xendit: ' . $e->getMessage()];
                    error_log("General Error checking Xendit Invoice: " . $e->getMessage());
                }
            } else {
                $response = ['status' => 'error', 'message' => 'Tidak ada invoice Xendit untuk dikirim ulang.'];
            }
        }
    } elseif ($_POST['action'] === 'delete_xendit_invoice') { // Aksi Individual
        if (!hasRole('superadmin')) { 
            $response = ['status' => 'error', 'message' => 'Anda tidak memiliki izin untuk menghapus invoice Xendit.'];
        } else {
            if ($tagihan_id) {
                $tagihan_data = getTagihanData($koneksi, $tagihan_id);
                if (!empty($tagihan_data['xendit_invoice_id'])) {
                    $update_query = "UPDATE tagihan SET xendit_invoice_id = NULL, payment_link = NULL WHERE id_tagihan = ?";
                    if ($stmt_update = $koneksi->prepare($update_query)) {
                        $stmt_update->bind_param("i", $tagihan_id);
                        if ($stmt_update->execute()) {
                            $response = ['status' => 'success', 'message' => 'Referensi Invoice Xendit berhasil dihapus dari database lokal!'];
                        } else {
                            $response = ['status' => 'error', 'message' => 'Gagal menghapus referensi Invoice Xendit dari database: ' . $koneksi->error];
                        }
                        $stmt_update->close();
                    } else {
                        $response = ['status' => 'error', 'message' => 'Error preparing delete Xendit invoice reference query: ' . $koneksi->error];
                    }
                } else {
                    $response = ['status' => 'info', 'message' => 'Tidak ada invoice Xendit yang terkait dengan tagihan ini untuk dihapus.'];
                }
            }
        }
    } elseif ($_POST['action'] === 'mass_create_xendit_invoice') { // Aksi Massal: Buat Invoice
        if (!hasRole(['superadmin', 'admin'])) {
            $response = ['status' => 'error', 'message' => 'Anda tidak memiliki izin untuk membuat invoice Xendit secara massal.'];
        } else {
            $success_count = 0;
            $fail_count = 0;
            $info_count = 0;
            $detailed_results = [];

            if (empty($tagihan_ids)) {
                $response = ['status' => 'warning', 'message' => 'Tidak ada tagihan yang dipilih untuk dibuat invoice.'];
            } else {
                foreach ($tagihan_ids as $id) {
                    $tagihan_data = getTagihanData($koneksi, $id);
                    if ($tagihan_data) {
                        if (empty($tagihan_data['email_pelanggan'])) {
                            $detailed_results[] = ['id' => $id, 'status' => 'failed', 'message' => 'Email pelanggan tidak ditemukan.'];
                            $fail_count++;
                            continue;
                        }
                        if (empty($tagihan_data['xendit_invoice_id'])) {
                            $description = "Pembayaran Tagihan ISP " . date('F Y', strtotime($tagihan_data['bulan_tagihan'])) . " untuk " . htmlspecialchars($tagihan_data['nama_pelanggan']);
                            $xenditResponse = createXenditInvoice(
                                $xenditConfig,
                                $tagihan_data['id_tagihan'],
                                $tagihan_data['total_tagihan'],
                                $tagihan_data['nama_pelanggan'],
                                $tagihan_data['email_pelanggan'],
                                $description,
                                $tagihan_data['tanggal_jatuh_tempo']
                            );

                            if ($xenditResponse['success']) {
                                $update_query = "UPDATE tagihan SET xendit_invoice_id = ?, payment_link = ? WHERE id_tagihan = ?";
                                if ($stmt_update = $koneksi->prepare($update_query)) {
                                    $stmt_update->bind_param("ssi", $xenditResponse['invoice_id'], $xenditResponse['payment_link'], $id);
                                    $stmt_update->execute();
                                    $stmt_update->close();
                                    $detailed_results[] = ['id' => $id, 'status' => 'success', 'message' => 'Invoice Xendit berhasil dibuat.'];
                                    $success_count++;
                                } else {
                                    $detailed_results[] = ['id' => $id, 'status' => 'failed', 'message' => 'Gagal update database: ' . $koneksi->error];
                                    $fail_count++;
                                }
                            } else {
                                $detailed_results[] = ['id' => $id, 'status' => 'failed', 'message' => 'Gagal membuat invoice Xendit: ' . ($xenditResponse['message'] ?? 'Unknown error.')];
                                $fail_count++;
                            }
                        } else {
                            $detailed_results[] = ['id' => $id, 'status' => 'info', 'message' => 'Invoice sudah ada.'];
                            $info_count++;
                        }
                    } else {
                        $detailed_results[] = ['id' => $id, 'status' => 'failed', 'message' => 'Tagihan tidak ditemukan.'];
                        $fail_count++;
                    }
                }
                $response = [
                    'status' => 'success',
                    'message' => "Proses selesai. Berhasil: {$success_count}, Gagal: {$fail_count}, Sudah ada: {$info_count}.",
                    'detailed_results' => $detailed_results
                ];
            }
        }
    } elseif ($_POST['action'] === 'mass_delete_xendit_invoice') { // Aksi Massal: Hapus Invoice (lokal)
        if (!hasRole('superadmin')) {
            $response = ['status' => 'error', 'message' => 'Anda tidak memiliki izin untuk menghapus invoice Xendit secara massal.'];
        } else {
            $success_count = 0;
            $info_count = 0; // Untuk yang memang tidak punya invoice Xendit ID
            $fail_count = 0;
            $detailed_results = [];

            if (empty($tagihan_ids)) {
                $response = ['status' => 'warning', 'message' => 'Tidak ada tagihan yang dipilih untuk dihapus.'];
            } else {
                foreach ($tagihan_ids as $id) {
                    $tagihan_data = getTagihanData($koneksi, $id);
                    if ($tagihan_data && !empty($tagihan_data['xendit_invoice_id'])) {
                        $update_query = "UPDATE tagihan SET xendit_invoice_id = NULL, payment_link = NULL WHERE id_tagihan = ?";
                        if ($stmt_update = $koneksi->prepare($update_query)) {
                            $stmt_update->bind_param("i", $id);
                            if ($stmt_update->execute()) {
                                $detailed_results[] = ['id' => $id, 'status' => 'success', 'message' => 'Referensi Invoice Xendit berhasil dihapus.'];
                                $success_count++;
                            } else {
                                $detailed_results[] = ['id' => $id, 'status' => 'failed', 'message' => 'Gagal menghapus referensi dari database: ' . $koneksi->error];
                                $fail_count++;
                            }
                            $stmt_update->close();
                        } else {
                            $detailed_results[] = ['id' => $id, 'status' => 'failed', 'message' => 'Error menyiapkan query hapus: ' . $koneksi->error];
                            $fail_count++;
                        }
                    } else {
                        $detailed_results[] = ['id' => $id, 'status' => 'info', 'message' => 'Tidak ada invoice Xendit terkait.'];
                        $info_count++;
                    }
                }
                $response = [
                    'status' => 'success',
                    'message' => "Proses selesai. Berhasil dihapus: {$success_count}, Tidak ada terkait: {$info_count}, Gagal: {$fail_count}.",
                    'detailed_results' => $detailed_results
                ];
            }
        }
    }

    echo json_encode($response);
    exit; 
}

// --- Bagian HTML untuk tampilan halaman (hanya untuk GET request) ---
// ob_end_flush() dipanggil di sini untuk mengeluarkan output buffering.
ob_end_flush(); 

$search_query = $_GET['search'] ?? '';
$filter_status = $_GET['status'] ?? 'Belum Lunas';

// Query untuk Menampilkan Data Tagihan
$query = "
    SELECT t.id_tagihan, t.bulan_tagihan, t.total_tagihan, t.sisa_tagihan, t.status_tagihan,
           t.tanggal_jatuh_tempo, t.xendit_invoice_id, t.payment_link,
           p.nama_pelanggan, p.id_pelanggan, p.email AS email_pelanggan, p.telepon AS telepon_pelanggan,
           pk.nama_paket
    FROM tagihan t
    JOIN pelanggan p ON t.pelanggan_id = p.id_pelanggan
    LEFT JOIN paket_layanan pk ON t.paket_id = pk.id_paket
    WHERE (t.status_tagihan = 'Belum Lunas' OR t.status_tagihan = 'Jatuh Tempo' OR t.status_tagihan = 'Menunggu Verifikasi')
";

$params = [];
$types = '';

if (!empty($search_query)) {
    $query .= " AND (p.nama_pelanggan LIKE ? OR t.id_tagihan LIKE ?)";
    $params[] = '%' . $search_query . '%';
    $params[] = '%' . $search_query . '%';
    $types .= 'ss';
}

if (!empty($filter_status) && $filter_status !== 'all') {
    $query = "
        SELECT t.id_tagihan, t.bulan_tagihan, t.total_tagihan, t.sisa_tagihan, t.status_tagihan,
               t.tanggal_jatuh_tempo, t.xendit_invoice_id, t.payment_link,
               p.nama_pelanggan, p.id_pelanggan, p.email AS email_pelanggan, p.telepon AS telepon_pelanggan,
               pk.nama_paket
        FROM tagihan t
        JOIN pelanggan p ON t.pelanggan_id = p.id_pelanggan
        LEFT JOIN paket_layanan pk ON t.paket_id = pk.id_paket
        WHERE t.status_tagihan = ?
    ";
    $params = [$filter_status];
    $types = 's';
}

$query .= " ORDER BY t.tanggal_jatuh_tempo ASC, t.id_tagihan DESC";

$stmt_tagihan = $koneksi->prepare($query);

if ($stmt_tagihan === false) {
    die("Error preparing statement: " . $koneksi->error);
}

if (!empty($params)) {
    $stmt_tagihan->bind_param($types, ...$params);
}

$stmt_tagihan->execute();
$result_tagihan = $stmt_tagihan->get_result();
$tagihan_list = [];
while ($row = $result_tagihan->fetch_assoc()) {
    $tagihan_list[] = $row;
}
$stmt_tagihan->close();

?>

<style>
    /* Mengatur warna teks default untuk seluruh body */
    body {
        color: #FFFFFF; /* Putih */
    }

    /* Mengatur warna teks untuk semua elemen di dalam main-content */
    .main-content,
    .main-content h1,
    .main-content h2,
    .main-content h3,
    .main-content p,
    .main-content span,
    .main-content label,
    .main-content th,
    .main-content td {
        color: #FFFFFF; /* Putih */
    }

    /* Menyesuaikan input field agar teksnya tetap terlihat */
    .main-content input[type="text"],
    .main-content select {
        color:rgb(231, 231, 231); /* Warna teks gelap agar terbaca di dalam input */
        background-color: #FFFFFF; /* Latar belakang putih untuk input */
        border: 1px solid #CCCCCC;
    }

    /* Menyesuaikan warna teks untuk link agar terlihat di latar belakang gelap */
    .main-content a {
        color: #ADD8E6; /* Contoh warna biru muda untuk link, atau bisa disesuaikan */
    }

    /* Jika ada elemen alert, sesuaikan teksnya agar tetap terbaca */
    .alert {
        color:rgb(10, 10, 10); /* Teks gelap di dalam alert */
    }

    .alert.alert-info,
    .alert.alert-success,
    .alert.alert-error,
    .alert.alert-warning {
        color:rgb(10, 10, 10); /* Pastikan teks di dalam alert juga gelap */
    }

    /* Menyesuaikan teks pada modal jika ada */
    .modal-content,
    .modal-content h3,
    .modal-content p {
        color:rgb(255, 250, 250); /* Warna teks gelap di dalam modal content */
    }

    /* Mengatur badge status (jika latar belakangnya gelap, teksnya harus terang) */
    .status-badge {
        color: #FFFFFF; /* Default teks putih untuk badge */
    }
    /* Contoh: jika ada badge dengan latar belakang terang, bisa override */
    .status-badge.status-default,
    .status-badge.status-lunas { /* Contoh status yang mungkin punya latar belakang terang */
        color:rgb(236, 236, 236); /* Atau warna teks gelap lainnya */
    }

    /* Styles for the Xendit Status Modal (to make it cleaner) */
    #xenditStatusModal .modal-content {
        background-color: #2c3e50; /* Darker background for consistency */
        color: #ecf0f1; /* Light text */
        padding: 25px;
        border-radius: 8px;
        box-shadow: 0 4px 10px rgba(0,0,0,0.5);
        max-width: 450px; /* Lebar maksimum modal */
        width: 90%; /* Pastikan responsif */
        word-wrap: break-word; /* Memastikan teks panjang pecah baris */
        overflow-wrap: break-word; /* Alternatif untuk word-wrap */
    }

    #xenditStatusModal .modal-content h3 {
        color: #ffffff;
        margin-bottom: 20px;
        font-size: 1.5em;
        border-bottom: 1px solid rgba(255,255,255,0.1);
        padding-bottom: 10px;
        text-align: center; /* Rata tengah judul */
    }

    #xenditStatusModal .modal-content #xenditModalBody p {
        margin-bottom: 8px; /* Sedikit lebih rapat antar baris */
        font-size: 1em; /* Ukuran font standar */
        line-height: 1.3;
        display: flex; /* Gunakan flexbox untuk alignment label-value */
        align-items: flex-start; /* Align ke atas jika teks panjang */
        flex-wrap: wrap; /* Memungkinkan wrap pada layar kecil */
    }
    
    #xenditStatusModal .modal-content #xenditModalBody strong {
        color: #3498db; /* Highlight labels */
        flex: 0 0 120px; /* Berikan lebar tetap untuk label (dikecilkan sedikit) */
        text-align: left; /* Rata kiri untuk label */
        margin-right: 10px; /* Jarak antara label dan nilai */
        word-wrap: break-word; /* Ensure label breaks if long */
        white-space: normal; /* Pastikan tidak nowrap */
    }

    #xenditStatusModal .modal-content #xenditModalBody span,
    #xenditStatusModal .modal-content #xenditModalBody a {
        flex: 1; /* Biarkan nilai mengambil sisa ruang */
        text-align: left; /* Rata kiri untuk nilai */
        word-wrap: break-word; /* Memastikan nilai pecah baris */
        overflow-wrap: break-word;
        white-space: normal; /* Pastikan tidak nowrap */
    }

    /* Khusus untuk link, pastikan pecah baris */
    #xenditStatusModal .modal-content #xenditModalBody a {
        word-break: break-all; /* Lebih agresif untuk URL */
    }

    #xenditStatusModal .modal-footer {
        margin-top: 25px;
        border-top: 1px solid rgba(255,255,255,0.1);
        padding-top: 15px;
        text-align: right;
    }

    #xenditStatusModal .close-button {
        color: #ecf0f1;
        opacity: 0.7;
        font-size: 30px;
        top: 10px;
        right: 15px;
    }

    #xenditStatusModal .close-button:hover {
        opacity: 1;
        color: #e74c3c;
    }

    /* Adjust status badge colors inside modal for better contrast */
    #xenditStatusModal .status-badge.status-pending { background-color: #f39c12; } /* Orange */
    #xenditStatusModal .status-badge.status-paid { background-color: #2ecc71; } /* Emerald Green */
    #xenditStatusModal .status-badge.status-settled { background-color: #27ae60; } /* Darker Emerald */
    #xenditStatusModal .status-badge.status-expired { background-color: #e74c3c; } /* Red */
    #xenditStatusModal .status-badge.status-unknown { background-color: #95a5a6; } /* Gray */

    /* NEW: Styles for the Action Menu Modal */
    .action-menu-modal-overlay {
        position: fixed;
        top: 0;
        left: 0;
        width: 100%;
        height: 100%;
        background-color: rgba(0, 0, 0, 0.6);
        display: flex;
        justify-content: center;
        align-items: center;
        z-index: 2000; /* Higher than other modals like customConfirmModal (1000) */
        opacity: 0;
        visibility: hidden;
        transition: opacity 0.3s ease, visibility 0.3s ease;
    }

    .action-menu-modal-overlay.show {
        opacity: 1;
        visibility: visible;
    }

    .action-menu-modal-content {
        background-color: #2c3e50; /* Darker background for consistency */
        padding: 25px;
        border-radius: 8px;
        box-shadow: 0 5px 15px rgba(0, 0, 0, 0.4);
        text-align: center;
        max-width: 350px;
        width: 90%;
        color: #ecf0f1;
        transform: translateY(-20px);
        transition: transform 0.3s ease;
        position: relative; /* Needed for close button positioning */
    }

    .action-menu-modal-overlay.show .action-menu-modal-content {
        transform: translateY(0);
    }

    .action-menu-modal-content h3 {
        margin-top: 0;
        margin-bottom: 20px;
        color: #ffffff;
        font-size: 1.2em;
    }

    .action-menu-modal-content .close-button-modal {
        position: absolute;
        top: 10px;
        right: 15px;
        font-size: 24px;
        color: #ecf0f1;
        cursor: pointer;
        transition: color 0.2s ease;
    }
    .action-menu-modal-content .close-button-modal:hover {
        color: #3498db;
    }

    .action-menu-list {
        display: flex;
        flex-direction: column; /* Stack buttons vertically */
        gap: 10px; /* Space between buttons */
    }

    .action-menu-list .btn-action-modal {
        display: flex; /* Make buttons flex items */
        align-items: center;
        justify-content: flex-start; /* Align text to left */
        padding: 10px 15px;
        border-radius: 6px;
        font-size: 0.95em;
        text-decoration: none;
        color: #ecf0f1;
        background-color: #34495e; /* Slightly darker background for buttons */
        border: 1px solid #4a6a8a;
        transition: background-color 0.2s ease, color 0.2s ease, border-color 0.2s ease;
    }

    .action-menu-list .btn-action-modal i {
        margin-right: 10px;
        color: #bdc3c7; /* Icon color */
        font-size: 1.1em;
        transition: color 0.2s ease;
    }

    .action-menu-list .btn-action-modal:hover {
        background-color: #4a6a8a; /* Hover background */
        color: #ffffff; /* Hover text color */
        border-color: #3498db;
    }
    .action-menu-list .btn-action-modal:hover i {
        color: #3498db; /* Hover icon color */
    }

    /* Specific colors for action buttons (optional) */
    .action-menu-list .btn-action-modal.delete-modal {
        color: #e74c3c;
    }
    .action-menu-list .btn-action-modal.delete-modal:hover {
        background-color: rgba(231, 76, 60, 0.2);
    }
    .action-menu-list .btn-action-modal.warning-modal {
        color: #f39c12;
    }
    .action-menu-list .btn-action-modal.warning-modal:hover {
        background-color: rgba(243, 156, 18, 0.2);
    }
    .action-menu-list .btn-action-modal.success-modal {
        color: #2ecc71;
    }
    .action-menu-list .btn-action-modal.success-modal:hover {
        background-color: rgba(46, 204, 113, 0.2);
    }
    .action-menu-list .btn-action-modal.info-modal {
        color: #3498db;
    }
    .action-menu-list .btn-action-modal.info-modal:hover {
        background-color: rgba(52, 152, 219, 0.2);
    }

    /* Styles for the new custom confirm modal in this file */
    .custom-modal-overlay {
        position: fixed;
        top: 0;
        left: 0;
        width: 100%;
        height: 100%;
        background-color: rgba(0, 0, 0, 0.5);
        display: flex;
        justify-content: center;
        align-items: center;
        z-index: 1000; /* Below action menu modal */
        opacity: 0;
        visibility: hidden;
        transition: opacity 0.3s ease, visibility 0.3s ease;
    }

    .custom-modal-overlay.show {
        opacity: 1;
        visibility: visible;
    }

    .custom-modal-content {
        background-color: #2c3e50; /* Darker background for consistency */
        padding: 30px;
        border-radius: 8px;
        box-shadow: 0 5px 15px rgba(0, 0, 0, 0.3);
        text-align: center;
        max-width: 400px;
        width: 90%;
        transform: translateY(-20px);
        transition: transform 0.3s ease;
        color: #ecf0f1;
    }

    .custom-modal-overlay.show .custom-modal-content {
        transform: translateY(0);
    }

    .custom-modal-content h3 {
        margin-top: 0;
        margin-bottom: 20px;
        color: #ffffff;
    }

    .custom-modal-buttons {
        display: flex;
        justify-content: center;
        gap: 15px;
        margin-top: 25px;
    }

    .custom-modal-buttons .btn {
        padding: 10px 25px;
        border-radius: 5px;
        cursor: pointer;
        font-size: 1em;
        border: none;
        transition: background-color 0.2s ease;
        color: #fff;
    }

    .custom-modal-buttons .btn-confirm {
        background-color: #e74c3c; /* Merah untuk konfirmasi aksi berbahaya */
    }

    .custom-modal-buttons .btn-confirm:hover {
        background-color: #c0392b;
    }

    .custom-modal-buttons .btn-cancel {
        background-color: #7f8c8d; /* Abu-abu untuk batal */
    }

    .custom-modal-buttons .btn-cancel:hover {
        background-color: #95a5a6;
    }


</style>

<div class="main-content">
    <div class="container">
        <h2>Pembayaran Online (Xendit)</h2>

        <div class="card">
            <div class="card-header">
                <h3>Daftar Tagihan Menunggu Pembayaran Xendit</h3>
                <form method="GET" action="" class="search-form-group">
                    <input type="text" name="search" placeholder="Cari nama/ID tagihan..." value="<?php echo htmlspecialchars($search_query); ?>">
                    <select name="status">
                        <option value="Belum Lunas" <?php echo ($filter_status == 'Belum Lunas') ? 'selected' : ''; ?>>Belum Lunas</option>
                        <option value="Jatuh Tempo" <?php echo ($filter_status == 'Jatuh Tempo') ? 'selected' : ''; ?>>Jatuh Tempo</option>
                        <option value="Menunggu Verifikasi" <?php echo ($filter_status == 'Menunggu Verifikasi') ? 'selected' : ''; ?>>Menunggu Verifikasi</option>
                        <option value="all" <?php echo ($filter_status == 'all') ? 'selected' : ''; ?>>Semua Status Non-Lunas</option>
                    </select>
                    <button type="submit" class="btn btn-primary">Filter</button>
                    <a href="pembayaran_online_xendit.php" class="btn btn-secondary">Reset</a>
                </form>
            </div>
            <div class="card-body">
                <?php if (hasRole(['superadmin', 'admin'])): ?>
                <div style="margin-bottom: 15px;">
                    <button id="massCreateInvoiceBtn" class="btn btn-primary" disabled><i class="fas fa-plus"></i> Buat Invoice Terpilih (<span id="selectedCreateCount">0</span>)</button>
                    <?php if (hasRole('superadmin')): ?>
                        <button id="massDeleteInvoiceBtn" class="btn btn-danger" disabled style="margin-left: 10px;"><i class="fas fa-trash-alt"></i> Hapus Invoice Terpilih (<span id="selectedDeleteCount">0</span>)</button>
                    <?php endif; ?>
                </div>
                <?php endif; ?>

                <?php if (empty($tagihan_list)): ?>
                    <div class="alert alert-info">Tidak ada tagihan yang cocok dengan filter yang dipilih.</div>
                <?php else: ?>
                    <div class="table-responsive">
                        <table class="data-table">
                            <thead>
                                <tr>
                                    <?php if (hasRole(['superadmin', 'admin'])): ?>
                                    <th style="width: 20px;"><input type="checkbox" id="selectAllInvoices"></th>
                                    <?php endif; ?>
                                    <th>ID Tagihan</th>
                                    <th>Pelanggan</th>
                                    <th>Email</th>
                                    <th>No. Telepon</th>
                                    <th>Bulan</th>
                                    <th>Total Tagihan</th>
                                    <th>Sisa Tagihan</th>
                                    <th>Jatuh Tempo</th>
                                    <th>Status Lokal</th>
                                    <th>Status Xendit</th>
                                    <th>Aksi</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($tagihan_list as $tagihan): ?>
                                    <tr>
                                        <?php if (hasRole(['superadmin', 'admin'])): ?>
                                        <td><input type="checkbox" name="selected_invoices[]" value="<?php echo htmlspecialchars($tagihan['id_tagihan']); ?>" class="invoice-checkbox"></td>
                                        <?php endif; ?>
                                        <td><?php echo htmlspecialchars($tagihan['id_tagihan']); ?></td>
                                        <td>
                                            <?php echo htmlspecialchars($tagihan['nama_pelanggan']); ?> <br>
                                            <small>(<?php echo htmlspecialchars($tagihan['nama_paket'] ?? 'N/A'); ?>)</small>
                                        </td>
                                        <td><?php echo htmlspecialchars($tagihan['email_pelanggan'] ?? 'N/A'); ?></td>
                                        <td><?php echo htmlspecialchars($tagihan['telepon_pelanggan'] ?? 'N/A'); ?></td>
                                        <td><?php echo date('d F Y', strtotime($tagihan['bulan_tagihan'])); ?></td>
                                        <td><?php echo "Rp " . number_format($tagihan['total_tagihan'], 0, ',', '.'); ?></td>
                                        <td><?php echo "Rp " . number_format($tagihan['sisa_tagihan'], 0, ',', '.'); ?></td>
                                        <td><?php echo date('d F Y', strtotime($tagihan['tanggal_jatuh_tempo'])); ?></td>
                                        <td>
                                            <span class="status-badge 
                                                <?php 
                                                    if ($tagihan['status_tagihan'] == 'Lunas') echo 'status-lunas';
                                                    else if ($tagihan['status_tagihan'] == 'Belum Lunas') echo 'status-pending';
                                                    else if ($tagihan['status_tagihan'] == 'Jatuh Tempo') echo 'status-kadaluarsa';
                                                    else if ($tagihan['status_tagihan'] == 'Menunggu Verifikasi') echo 'status-warning';
                                                    else echo 'status-default';
                                                ?>">
                                                <?php echo htmlspecialchars($tagihan['status_tagihan']); ?>
                                            </span>
                                        </td>
                                        <td>
                                            <?php if (!empty($tagihan['xendit_invoice_id'])): ?>
                                                <a href="<?php echo htmlspecialchars($tagihan['payment_link']); ?>" target="_blank" class="btn-action btn-info btn-sm">Lihat Xendit Invoice</a>
                                            <?php else: ?>
                                                <span class="status-badge status-default">Belum Dibuat</span>
                                            <?php endif; ?>
                                        </td>
                                        <td>
                                            <button type="button" class="btn-action btn-secondary open-action-modal-btn" 
                                                    data-id="<?php echo $tagihan['id_tagihan']; ?>" 
                                                    data-name="<?php echo htmlspecialchars($tagihan['nama_pelanggan']); ?>"
                                                    data-email="<?php echo htmlspecialchars($tagihan['email_pelanggan'] ?? ''); ?>"
                                                    data-xendit-id="<?php echo htmlspecialchars($tagihan['xendit_invoice_id'] ?? ''); ?>"
                                                    data-payment-link="<?php echo htmlspecialchars($tagihan['payment_link'] ?? ''); ?>">
                                                <i class="fas fa-ellipsis-h"></i> Aksi
                                            </button>
                                        </td>
                                    </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
</div>

<div id="actionMenuModal" class="action-menu-modal-overlay">
    <div class="action-menu-modal-content">
        <span class="close-button-modal" id="closeActionMenuModal">&times;</span>
        <h3 id="actionMenuModalTitle">Aksi untuk Tagihan ID: <span id="actionTagihanId"></span></h3>
        <div class="action-menu-list" id="actionMenuButtons">
            </div>
    </div>
</div>

<div id="xenditStatusModal" class="modal">
    <div class="modal-content">
        <span class="close-button" onclick="closeXenditStatusModal()">&times;</span>
        <h3>Detail Status Invoice Xendit</h3>
        <div id="xenditModalBody">
            <p>Memuat...</p>
        </div>
        <div class="modal-footer">
            <button class="btn btn-secondary" onclick="closeXenditStatusModal()">Tutup</button>
        </div>
    </div>
</div>

<div id="customConfirmModal" class="custom-modal-overlay">
    <div class="custom-modal-content">
        <h3 id="confirmModalTitle">Konfirmasi Aksi</h3>
        <p id="confirmModalMessage"></p>
        <div class="custom-modal-buttons">
            <button class="btn btn-confirm" id="confirmModalYes">Oke</button>
            <button class="btn btn-cancel" id="confirmModalNo">Batal</button>
        </div>
    </div>
</div>

<script>
document.addEventListener('DOMContentLoaded', function() {
    console.log('DOM Content Loaded in pembayaran_online_xendit.php');

    // --- FALLBACK FUNCTIONS (Untuk memastikan ketersediaan jika tidak dimuat dari header.php) ---
    if (typeof window.showNotification !== 'function') {
        console.warn('showNotification function not found in global scope, defining fallback.');
        window.showNotification = function(message, type = 'info', duration = 3000) {
            let notificationContainer = document.getElementById('notificationContainer');
            if (!notificationContainer) {
                notificationContainer = document.createElement('div');
                notificationContainer.id = 'notificationContainer';
                notificationContainer.style.cssText = `
                    position: fixed; top: 20px; right: 20px; z-index: 10000;
                    display: flex; flex-direction: column; gap: 10px;
                `;
                document.body.appendChild(notificationContainer);
            }

            const notification = document.createElement('div');
            notification.className = `alert alert-${type}`;
            notification.style.cssText = `
                padding: 15px; border-radius: 5px; box-shadow: 0 2px 10px rgba(0,0,0,0.1);
                opacity: 0; transform: translateY(-20px); transition: all 0.3s ease-out;
                color: white;
            `;
            if (type === 'success') { notification.style.backgroundColor = '#28a745'; }
            else if (type === 'error') { notification.style.backgroundColor = '#dc3545'; }
            else if (type === 'info') { notification.style.backgroundColor = '#17a2b8'; }
            else if (type === 'warning') { notification.style.backgroundColor = '#ffc107'; notification.style.color = '#333'; }

            notification.innerHTML = message;
            notificationContainer.prepend(notification);

            setTimeout(() => {
                notification.style.opacity = '1';
                notification.style.transform = 'translateY(0)';
            }, 10);

            setTimeout(() => {
                notification.style.opacity = '0';
                notification.style.transform = 'translateY(-20px)';
                notification.addEventListener('transitionend', () => notification.remove());
            }, duration);
        };
    }

    if (typeof window.showLoadingOverlay !== 'function') {
        console.warn('showLoadingOverlay function not found in global scope, defining fallback.');
        window.showLoadingOverlay = function() {
            let overlay = document.getElementById('loadingOverlay');
            if (!overlay) {
                overlay = document.createElement('div');
                overlay.id = 'loadingOverlay';
                overlay.style.cssText = `
                    position: fixed; top: 0; left: 0; width: 100%; height: 100%;
                    background: rgba(0,0,0,0.7); display: flex; justify-content: center;
                    align-items: center; z-index: 9999; color: white; font-size: 2em;
                `;
                overlay.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Memproses...';
                document.body.appendChild(overlay);
            }
            overlay.style.display = 'flex';
        };
    }

    if (typeof window.hideLoadingOverlay !== 'function') {
        console.warn('hideLoadingOverlay function not found in global scope, defining fallback.');
        window.hideLoadingOverlay = function() {
            const overlay = document.getElementById('loadingOverlay');
            if (overlay) {
                overlay.style.display = 'none';
            }
        };
    }
    // Note: The customConfirm functionality is now directly implemented below for this file,
    // not relying on a global showCustomConfirm, to keep it self-contained if needed.
    // --- AKHIR FALLBACK FUNCTIONS ---

    // Custom Confirm Modal Elements for this file (specific to this page)
    const customConfirmModal = document.getElementById('customConfirmModal');
    const confirmModalTitle = document.getElementById('confirmModalTitle');
    const confirmModalMessage = document.getElementById('confirmModalMessage');
    const confirmModalYes = document.getElementById('confirmModalYes');
    const confirmModalNo = document.getElementById('confirmModalNo');
    let confirmCallback = null;

    // Function to show the custom confirm modal
    function showCustomConfirm(title, message, callback) {
        confirmModalTitle.textContent = title;
        confirmModalMessage.textContent = message;
        confirmCallback = callback;
        customConfirmModal.classList.add('show');
    }

    // Function to hide the custom confirm modal
    function hideCustomConfirm() {
        customConfirmModal.classList.remove('show');
        confirmCallback = null;
    }

    // Event listener for custom confirm modal "Oke" button
    confirmModalYes.addEventListener('click', function() {
        if (confirmCallback) {
            confirmCallback(true);
        }
        hideCustomConfirm();
    });

    // Event listener for custom confirm modal "Batal" button
    confirmModalNo.addEventListener('click', function() {
        if (confirmCallback) {
            confirmCallback(false);
        }
        hideCustomConfirm();
    });

    // Close modal if clicked outside of content
    customConfirmModal.addEventListener('click', function(event) {
        if (event.target === customConfirmModal) {
            if (confirmCallback) {
                confirmCallback(false); // Treat outside click as cancel
            }
            hideCustomConfirm();
        }
    });

    // --- Action Menu Modal Logic ---
    const actionMenuModal = document.getElementById('actionMenuModal');
    const closeActionMenuModalBtn = document.getElementById('closeActionMenuModal');
    const actionTagihanIdSpan = document.getElementById('actionTagihanId');
    const actionMenuButtonsDiv = document.getElementById('actionMenuButtons');

    function showActionMenuModal(tagihanId, pelangganName, pelangganEmail, xenditInvoiceId, paymentLink) {
        actionTagihanIdSpan.textContent = tagihanId;
        actionMenuButtonsDiv.innerHTML = ''; // Clear previous buttons

        // Buat Invoice Button
        if (!xenditInvoiceId) {
            let createBtn = document.createElement('button');
            createBtn.type = 'button';
            createBtn.className = 'btn-action-modal btn-primary';
            createBtn.innerHTML = '<i class="fas fa-plus"></i> Buat Invoice';
            createBtn.addEventListener('click', function() {
                hideActionMenuModal();
                if (!pelangganEmail || pelangganEmail.trim() === '') {
                    showNotification("Email pelanggan tidak terdaftar. Xendit memerlukan email untuk mengirim invoice. Harap lengkapi data pelanggan.", "error");
                    return;
                }
                showCustomConfirm('Konfirmasi Buat Invoice Xendit', `Apakah Anda yakin ingin membuat invoice Xendit untuk tagihan ID ${tagihanId} (${pelangganName})?`, async function(confirmed) {
                    if (confirmed) {
                        showLoadingOverlay();
                        try {
                            const response = await fetch('pembayaran_online_xendit.php', {
                                method: 'POST',
                                headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
                                body: new URLSearchParams({ action: 'create_xendit_invoice', tagihan_id: tagihanId })
                            });
                            const data = await response.json();
                            hideLoadingOverlay();
                            if (data.status === 'success') {
                                showNotification(data.message, 'success');
                                setTimeout(() => location.reload(), 1500); 
                            } else {
                                showNotification(data.message, 'error');
                            }
                        } catch (error) {
                            hideLoadingOverlay();
                            console.error('Error:', error);
                            showNotification('Terjadi kesalahan jaringan atau server saat membuat invoice Xendit. (Lihat konsol untuk detail)', 'error');
                        }
                    }
                });
            });
            actionMenuButtonsDiv.appendChild(createBtn);
        }

        // Info Link / Resend Email Button
        if (xenditInvoiceId) {
            let infoLinkBtn = document.createElement('button');
            infoLinkBtn.type = 'button';
            infoLinkBtn.className = 'btn-action-modal btn-info';
            infoLinkBtn.innerHTML = '<i class="fas fa-link"></i> Info Link';
            infoLinkBtn.addEventListener('click', function() {
                hideActionMenuModal();
                if (!paymentLink || paymentLink.trim() === '') {
                    showNotification("Tautan pembayaran Xendit belum tersedia.", "info");
                    return;
                }
                showCustomConfirm('Informasi Link Pembayaran Xendit', `Tautan pembayaran untuk tagihan ID ${tagihanId} adalah:\n\n${paymentLink}\n\nApakah Anda ingin membuka link ini di tab baru?`, function(confirmed) {
                    if (confirmed) {
                        window.open(paymentLink, '_blank');
                    }
                });
            });
            actionMenuButtonsDiv.appendChild(infoLinkBtn);

            // Cek Status Button
            let checkStatusBtn = document.createElement('button');
            checkStatusBtn.type = 'button';
            checkStatusBtn.className = 'btn-action-modal btn-warning-modal'; // Use warning-modal for contrast
            checkStatusBtn.innerHTML = '<i class="fas fa-sync-alt"></i> Cek Status';
            checkStatusBtn.addEventListener('click', function() {
                hideActionMenuModal(); // Hide action menu before opening status modal
                if (!xenditInvoiceId || xenditInvoiceId.trim() === '') {
                    showNotification("Invoice Xendit belum dibuat untuk tagihan ini. Tidak dapat memeriksa status Xendit.", "info");
                    return;
                }
                openXenditStatusModal();
                xenditModalBody.innerHTML = '<p>Memuat status dari Xendit...</p>';
                showLoadingOverlay();

                fetch('fetch_xendit_invoice_status.php', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
                    body: new URLSearchParams({ invoice_id: xenditInvoiceId })
                })
                .then(response => {
                    if (!response.ok) {
                        return response.json().then(errorData => {
                            throw new Error(errorData.message || `HTTP error! status: ${response.status}`);
                        });
                    }
                    return response.json();
                })
                .then(data => {
                    hideLoadingOverlay();
                    let content = '';
                    if (data.status === 'success') {
                        const invoice = data.invoice_data;
                        if (invoice && typeof invoice === 'object') {
                            const userLocale = navigator.language || navigator.languages[0] || 'id-ID';
                            const options = { year: 'numeric', month: 'long', day: 'numeric', hour: '2-digit', minute: '2-digit', second: '2-digit', timeZoneName: 'short' };
                            const createdDate = invoice.created ? new Date(invoice.created * (String(invoice.created).length === 10 ? 1000 : 1)) : null;
                            const expiryDate = invoice.expiry_date ? new Date(invoice.expiry_date) : null;
                            const paidAtDate = invoice.paid_at ? new Date(invoice.paid_at) : null;

                            content += `<p><strong>Xendit Invoice ID:</strong> <span>${invoice.id}</span></p>`;
                            content += `<p><strong>External ID:</strong> <span>${invoice.external_id}</span></p>`;
                            content += `<p><strong>Status:</strong> <span><span class="status-badge status-${invoice.status.toLowerCase()}">${invoice.status}</span></span></p>`;
                            content += `<p><strong>Jumlah:</strong> <span>Rp ${number_format(invoice.amount, 0, ',', '.')}</span></p>`;
                            content += `<p><strong>Jumlah Dibayar:</strong> <span>Rp ${number_format(invoice.paid_amount || 0, 0, ',', '.')}</span></p>`;
                            content += `<p><strong>Dibuat:</strong> <span>${createdDate ? createdDate.toLocaleString(userLocale, options) : 'N/A'}</span></p>`;
                            content += `<p><strong>Jatuh Tempo:</strong> <span>${expiryDate ? expiryDate.toLocaleString(userLocale, options) : 'N/A'}</span></p>`;
                            
                            if (paidAtDate) {
                                content += `<p><strong>Dibayar Pada:</strong> <span>${paidAtDate.toLocaleString(userLocale, options)}</span></p>`; 
                            }
                            if (invoice.payment_channel) {
                                content += `<p><strong>Channel:</strong> <span>${invoice.payment_channel} (${invoice.payment_method})</span></p>`; 
                            } else {
                                if (invoice.available_payment_channels && invoice.available_payment_channels.length > 0) {
                                    let availableChannels = invoice.available_payment_channels.map(channel => {
                                        if (channel.channel_code) return channel.channel_code;
                                        if (channel.channel_category) return channel.channel_category;
                                        return 'Unknown';
                                    }).join(', ');
                                    content += `<p><strong>Metode Tersedia:</strong> <span>${availableChannels}</span></p>`;
                                }
                            }
                            content += `<p><strong>Link Pembayaran:</strong> <span><a href="${invoice.invoice_url}" target="_blank" style="word-break: break-all;">${invoice.invoice_url}</a></span></p>`;

                            if (invoice.status === 'PAID' || invoice.status === 'SETTLED') {
                                content += `<div class="alert alert-success mt-3"><i class="fas fa-check-circle"></i> Pembayaran sudah lunas di Xendit. Halaman akan dimuat ulang.</div>`;
                                setTimeout(() => location.reload(), 2000);
                            } else if (invoice.status === 'EXPIRED') {
                                    content += `<div class="alert alert-warning mt-3"><i class="fas fa-exclamation-triangle"></i> Invoice ini sudah kadaluarsa di Xendit.</div>`;
                            }
                        } else {
                            content = `<div class="alert alert-danger"><i class="fas fa-exclamation-circle"></i> Data invoice tidak valid atau tidak ditemukan.</div>`;
                        }
                    } else {
                        content = `<div class="alert alert-danger"><i class="fas fa-times-circle"></i> Gagal mengambil status invoice dari Xendit: ${data.message}</div>`;
                    }
                    xenditModalBody.innerHTML = content;
                })
                .catch(error => {
                    hideLoadingOverlay();
                    console.error('Error fetching Xendit status:', error);
                    xenditModalBody.innerHTML = `<div class="alert alert-danger"><i class="fas fa-times-circle"></i> Terjadi kesalahan jaringan atau server: ${error.message}</div>`;
                });
            });
            actionMenuButtonsDiv.appendChild(checkStatusBtn);

            // Hapus Xendit (lokal) Button - hanya untuk superadmin
            <?php if (hasRole('superadmin')): ?>
                let deleteXenditBtn = document.createElement('button');
                deleteXenditBtn.type = 'button';
                deleteXenditBtn.className = 'btn-action-modal btn-danger-modal';
                deleteXenditBtn.innerHTML = '<i class="fas fa-trash-alt"></i> Hapus Xendit';
                deleteXenditBtn.addEventListener('click', function() {
                    hideActionMenuModal();
                    showCustomConfirm('Konfirmasi Hapus Referensi Invoice Xendit', `Apakah Anda yakin ingin MENGHAPUS REFERENSI invoice Xendit (ID: ${xenditInvoiceId}) untuk tagihan ID ${tagihanId} dari database lokal? Ini TIDAK membatalkan invoice di Xendit.`, async function(confirmed) {
                        if (confirmed) {
                            showLoadingOverlay();
                            try {
                                const response = await fetch('pembayaran_online_xendit.php', {
                                    method: 'POST',
                                    headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
                                    body: new URLSearchParams({ action: 'delete_xendit_invoice', tagihan_id: tagihanId })
                                });
                                const data = await response.json();
                                hideLoadingOverlay();
                                if (data.status === 'success') {
                                    showNotification(data.message, 'success');
                                    setTimeout(() => location.reload(), 1500);
                                } else {
                                    showNotification(data.message, 'error');
                                }
                            } catch (error) {
                                hideLoadingOverlay();
                                console.error('Error:', error);
                                showNotification('Terjadi kesalahan jaringan atau server saat menghapus referensi invoice Xendit.', 'error');
                            }
                        }
                    });
                });
                actionMenuButtonsDiv.appendChild(deleteXenditBtn);
            <?php endif; ?>
        }

        actionMenuModal.classList.add('show');
    }

    function hideActionMenuModal() {
        actionMenuModal.classList.remove('show');
    }

    document.querySelectorAll('.open-action-modal-btn').forEach(button => {
        button.addEventListener('click', function(event) {
            event.stopPropagation();
            const tagihanId = this.getAttribute('data-id');
            const pelangganName = this.getAttribute('data-name');
            const pelangganEmail = this.getAttribute('data-email');
            const xenditInvoiceId = this.getAttribute('data-xendit-id');
            const paymentLink = this.getAttribute('data-payment-link');
            showActionMenuModal(tagihanId, pelangganName, pelangganEmail, xenditInvoiceId, paymentLink);
        });
    });

    closeActionMenuModalBtn.addEventListener('click', hideActionMenuModal);
    actionMenuModal.addEventListener('click', function(event) {
        if (event.target === actionMenuModal) {
            hideActionMenuModal();
        }
    });


    // --- Mass Action Logic ---
    const selectAllInvoices = document.getElementById('selectAllInvoices');
    const invoiceCheckboxes = document.querySelectorAll('.invoice-checkbox');
    const massCreateInvoiceBtn = document.getElementById('massCreateInvoiceBtn');
    const selectedCreateCountSpan = document.getElementById('selectedCreateCount');
    const massDeleteInvoiceBtn = document.getElementById('massDeleteInvoiceBtn');
    const selectedDeleteCountSpan = document.getElementById('selectedDeleteCount');

    function updateMassActionButtons() {
        let checkedCount = 0;
        invoiceCheckboxes.forEach(checkbox => {
            if (checkbox.checked) {
                checkedCount++;
            }
        });
        selectedCreateCountSpan.textContent = checkedCount;
        massCreateInvoiceBtn.disabled = checkedCount === 0;

        // Only update delete button if it exists
        if (massDeleteInvoiceBtn) {
            selectedDeleteCountSpan.textContent = checkedCount;
            massDeleteInvoiceBtn.disabled = checkedCount === 0;
        }
    }

    if (selectAllInvoices) { // Only run if the selectAll checkbox exists (i.e., user has role)
        selectAllInvoices.addEventListener('change', function() {
            invoiceCheckboxes.forEach(checkbox => {
                checkbox.checked = this.checked;
            });
            updateMassActionButtons();
        });

        invoiceCheckboxes.forEach(checkbox => {
            checkbox.addEventListener('change', function() {
                if (!this.checked) {
                    selectAllInvoices.checked = false;
                }
                updateMassActionButtons();
            });
        });

        massCreateInvoiceBtn.addEventListener('click', function() {
            const selectedIds = Array.from(invoiceCheckboxes)
                                .filter(cb => cb.checked)
                                .map(cb => cb.value);

            if (selectedIds.length === 0) {
                showNotification('Tidak ada tagihan yang dipilih untuk dibuat invoice.', 'warning');
                return;
            }

            showCustomConfirm('Konfirmasi Buat Invoice Massal', `Apakah Anda yakin ingin membuat invoice Xendit untuk ${selectedIds.length} tagihan terpilih?`, async function(confirmed) {
                if (confirmed) {
                    showLoadingOverlay();
                    try {
                        const response = await fetch('pembayaran_online_xendit.php', {
                            method: 'POST',
                            headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
                            body: new URLSearchParams({ action: 'mass_create_xendit_invoice', tagihan_ids: JSON.stringify(selectedIds) })
                        });
                        const data = await response.json();
                        hideLoadingOverlay();
                        if (data.status === 'success' || data.status === 'warning') {
                            showNotification(data.message, data.status);
                            setTimeout(() => location.reload(), 1500);
                        } else {
                            showNotification(data.message, 'error');
                        }
                    } catch (error) {
                        hideLoadingOverlay();
                        console.error('Error:', error);
                        showNotification('Terjadi kesalahan jaringan atau server saat memproses pembuatan invoice massal.', 'error');
                    }
                }
            });
        });

        if (massDeleteInvoiceBtn) {
            massDeleteInvoiceBtn.addEventListener('click', function() {
                const selectedIds = Array.from(invoiceCheckboxes)
                                    .filter(cb => cb.checked)
                                    .map(cb => cb.value);

                if (selectedIds.length === 0) {
                    showNotification('Tidak ada tagihan yang dipilih untuk dihapus.', 'warning');
                    return;
                }

                showCustomConfirm('Konfirmasi Hapus Invoice Massal (Lokal)', `Apakah Anda yakin ingin MENGHAPUS REFERENSI invoice Xendit untuk ${selectedIds.length} tagihan terpilih dari database lokal? Ini TIDAK membatalkan invoice di Xendit.`, async function(confirmed) {
                    if (confirmed) {
                        showLoadingOverlay();
                        try {
                            const response = await fetch('pembayaran_online_xendit.php', {
                                method: 'POST',
                                headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
                                body: new URLSearchParams({ action: 'mass_delete_xendit_invoice', tagihan_ids: JSON.stringify(selectedIds) })
                            });
                            const data = await response.json();
                            hideLoadingOverlay();
                            if (data.status === 'success' || data.status === 'warning') {
                                showNotification(data.message, data.status);
                                setTimeout(() => location.reload(), 1500);
                            } else {
                                showNotification(data.message, 'error');
                            }
                        } catch (error) {
                            hideLoadingOverlay();
                            console.error('Error:', error);
                            showNotification('Terjadi kesalahan jaringan atau server saat memproses penghapusan invoice massal.', 'error');
                        }
                    }
                });
            });
        }
        updateMassActionButtons(); // Initial update
    }


    // Fungsi untuk Cek Status Xendit (memanggil API Xendit langsung dari server)
    const xenditStatusModal = document.getElementById('xenditStatusModal');
    const xenditModalBody = document.getElementById('xenditModalBody');

    window.openXenditStatusModal = function() {
        if (xenditStatusModal) {
            xenditStatusModal.style.display = "block";
            console.log('Xendit status modal opened.');
        }
    }

    window.closeXenditStatusModal = function() {
        if (xenditStatusModal) {
            xenditStatusModal.style.display = "none";
            xenditModalBody.innerHTML = '<p>Memuat...</p>';
            console.log('Xendit status modal closed.');
        }
    }

    window.onclick = function(event) {
        if (xenditStatusModal && event.target == xenditStatusModal) {
            closeXenditStatusModal();
        }
        // Also ensure custom confirm modal closes if clicked outside
        if (customConfirmModal && event.target == customConfirmModal) {
            hideCustomConfirm();
        }
    }

    function number_format(number, decimals, decPoint, thousandsSeparator) {
        number = (number + '').replace(/[^0-9+\-Ee.]/g, '');
        var n = !isFinite(+number) ? 0 : +number,
            prec = !isFinite(+decimals) ? 0 : Math.abs(decimals),
            sep = (typeof thousandsSeparator === 'undefined') ? '.' : thousandsSeparator,
            dec = (typeof decPoint === 'undefined') ? ',' : decPoint,
            s = '',
            toFixedFix = function (n, prec) {
                var k = Math.pow(10, prec);
                return '' + Math.round(n * k) / k;
            };

        s = (prec ? toFixedFix(n, prec) : '' + Math.round(n)).split('.');
        if (s[0].length > 3) {
            s[0] = s[0].replace(/\B(?=(?:\d{3})+(?!\d))/g, sep);
        }
        if ((s[1] || '').length < prec) {
            s[1] = s[1] || '';
            s[1] += new Array(prec - s[1].length + 1).join('0');
        }
        return s.join(dec);
    }
});
</script>

<?php include '../includes/footer.php'; ?>