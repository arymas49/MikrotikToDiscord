<?php
// C:\xampp\htdocs\billing_isp_app\pages\search_pelanggan.php
header('Content-Type: application/json'); // Pastikan header adalah JSON

include '../config/koneksi.php'; // Sesuaikan path jika perlu

$search_query = $_GET['q'] ?? ''; // Ambil query pencarian dari parameter 'q'
$search_query = trim($search_query); // Hapus spasi di awal/akhir

$results = [];

if (strlen($search_query) > 1) { // Hanya proses jika query lebih dari 1 karakter
    // Query untuk mencari pelanggan berdasarkan nama, telepon, atau alamat
    // Hanya pelanggan aktif dan yang punya tagihan 'Belum Lunas' atau 'Jatuh Tempo'
    $query = "
        SELECT DISTINCT
            p.id_pelanggan,
            p.nama_pelanggan,
            p.telepon,
            p.alamat,
            pk.id_paket,
            pk.harga,
            p.uses_ppn
        FROM
            pelanggan p
        JOIN
            paket_layanan pk ON p.paket_id = pk.id_paket
        JOIN
            tagihan t ON p.id_pelanggan = t.pelanggan_id
        WHERE
            p.status_aktif = 'Aktif'
            AND t.status_tagihan IN ('Belum Lunas', 'Jatuh Tempo')
            AND (
                p.nama_pelanggan LIKE ? OR
                p.telepon LIKE ? OR
                p.alamat LIKE ?
            )
        ORDER BY
            p.nama_pelanggan ASC
        LIMIT 20
    ";

    $stmt = $koneksi->prepare($query);

    if ($stmt) {
        $param = '%' . $search_query . '%';
        $stmt->bind_param("sss", $param, $param, $param);
        $stmt->execute();
        $result = $stmt->get_result();

        while ($row = $result->fetch_assoc()) {
            $results[] = [
                'id_pelanggan' => $row['id_pelanggan'],
                'nama_pelanggan' => $row['nama_pelanggan'],
                'telepon' => $row['telepon'],
                'alamat' => $row['alamat'],
                'id_paket' => $row['id_paket'],
                'harga' => $row['harga'],
                'uses_ppn' => $row['uses_ppn']
            ];
        }
        $stmt->close();
    } else {
        // Log error untuk debugging
        error_log("Failed to prepare statement in search_pelanggan.php: " . $koneksi->error);
    }
}

echo json_encode($results);

$koneksi->close();
?>