<?php
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!isset($_POST['csrf_token']) || $_POST['csrf_token'] !== $_SESSION['csrf_token']) {
        die('CSRF validation failed');
    }
}

// C:\xampp\htdocs\billing_isp_app\pages\broadcast_message.php
ob_start();
session_set_cookie_params([
    'lifetime' => 0,
    'path' => '/',
    'domain' => '',
    'secure' => isset($_SERVER['HTTPS']),
    'httponly' => true,
    'samesite' => 'Lax'
]);
session_start();
if (!isset($_SESSION["initiated"])) { session_regenerate_id(true); $_SESSION["initiated"] = true; }
include '../config/koneksi.php';
include '../includes/header.php'; // Header akan meng-include sidebar dan fungsi hasRole()

// Batasi akses ke halaman ini: hanya superadmin dan admin
if (!hasRole(['superadmin', 'admin'])) {
    header('Location: dashboard.php'); // Redirect ke dashboard atau halaman akses ditolak
    exit();
}

$message = '';
$customer_count = 0;
$broadcast_history = []; // Akan menampilkan riwayat broadcast dari DB

// Ambil URL dasar dari konfigurasi
global $whatsapp_config;
if (!isset($whatsapp_config) || empty($whatsapp_config)) {
    $whatsapp_config_path = __DIR__ . '/../config/whatsapp_config.php';
    if (file_exists($whatsapp_config_path)) {
        $whatsapp_config = include $whatsapp_config_path;
    } else {
        $whatsapp_config = [];
    }
}
$app_base_url = $whatsapp_config['app_base_url'] ?? 'https://billing.tzn.my.id';
$api_endpoint = $app_base_url . '/pages/send_whatsapp_message.php'; // Endpoint tunggal untuk API


// --- Mulai Penanganan POST Request ---
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['action'])) {
    $action_performed = $_POST['action'];
    $response_status = 'error';
    $response_msg = 'Terjadi kesalahan tidak dikenal saat memproses permintaan.';

    // --- CASE 1: MENGIRIM PESAN BROADCAST BARU ---
    if ($action_performed == 'send_broadcast') {
        $broadcast_message = $koneksi->real_escape_string($_POST['broadcast_message'] ?? '');

        if (empty($broadcast_message)) {
            $response_msg = 'Pesan broadcast tidak boleh kosong.';
            $response_status = 'danger';
        } else {
            $customers_to_broadcast_phones = [];
            $query_get_customers = "SELECT telepon FROM pelanggan WHERE status_aktif = 'Aktif' AND telepon IS NOT NULL AND telepon != ''";
            $result_get_customers = $koneksi->query($query_get_customers);

            if ($result_get_customers && $result_get_customers->num_rows > 0) {
                while ($row = $result_get_customers->fetch_assoc()) {
                    $customers_to_broadcast_phones[] = $row['telepon'];
                }
            }

            if (empty($customers_to_broadcast_phones)) {
                $response_msg = 'Tidak ada pelanggan aktif dengan nomor telepon yang terdaftar untuk dikirim broadcast.';
                $response_status = 'warning';
            } else {
                $koneksi->begin_transaction();
                try {
                    $stmt_queue = $koneksi->prepare("INSERT INTO whatsapp_broadcast_queue (message_content, total_recipients) VALUES (?, ?)");
                    $stmt_queue->bind_param("si", $broadcast_message, $customer_count);
                    $stmt_queue->execute();
                    $broadcast_id = $koneksi->insert_id;
                    $stmt_queue->close();

                    $stmt_details = $koneksi->prepare("INSERT INTO whatsapp_broadcast_queue_details (broadcast_id, phone_number, status) VALUES (?, ?, 'pending')");
                    foreach ($customers_to_broadcast_phones as $phone) {
                        $stmt_details->bind_param("is", $broadcast_id, $phone);
                        $stmt_details->execute();
                    }
                    $stmt_details->close();

                    $koneksi->commit();
                    $response_msg = 'Pesan broadcast telah berhasil dimasukkan ke antrian. Proses pengiriman akan dimulai dalam beberapa saat.';
                    $response_status = 'info';

                } catch (mysqli_sql_exception $e) {
                    $koneksi->rollback();
                    $response_msg = 'Gagal memasukkan broadcast ke antrian: ' . htmlspecialchars($e->getMessage());
                    $response_status = 'danger';
                    error_log("ERROR: Gagal memasukkan broadcast ke antrian: " . $e->getMessage());
                }
            }
        }
    }
    // --- CASE 2: MENGHAPUS BROADCAST INDIVIDUAL ---
    elseif ($action_performed == 'delete_broadcast' && isset($_POST['broadcast_id'])) {
        $broadcast_id_to_delete = (int)$_POST['broadcast_id'];
        $payload = json_encode([
            'action' => 'delete_broadcast_history',
            'broadcast_id' => $broadcast_id_to_delete
        ]);
        // Tidak perlu confirm_msg di sini, sudah di JS

        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $api_endpoint); // Gunakan $api_endpoint
        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_POSTFIELDS, $payload);
        curl_setopt($ch, CURLOPT_HTTPHEADER, array(
            'Content-Type: application/json',
            'Content-Length: ' . strlen($payload)
        ));
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_TIMEOUT, 60);

        $response = curl_exec($ch);
        $http_code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        $curl_error = curl_error($ch);
        curl_close($ch);

        error_log("DEBUG: Delete Individual Broadcast - Payload: " . $payload);
        error_log("DEBUG: Delete Individual Broadcast - Raw Response: " . $response);
        error_log("DEBUG: Delete Individual Broadcast - HTTP Code: " . $http_code);
        error_log("DEBUG: Delete Individual Broadcast - cURL Error: " . $curl_error);

        if ($curl_error) {
            $response_msg = 'Error menghapus riwayat broadcast (cURL Error): ' . htmlspecialchars($curl_error);
            $response_status = 'danger';
        } else {
            $response_data = json_decode($response, true);
            if ($http_code == 200 && isset($response_data['status']) && $response_data['status'] == 'success') {
                $response_msg = htmlspecialchars($response_data['message']);
                $response_status = 'success';
            } else {
                $error_msg = $response_data['message'] ?? 'Respons tidak valid dari server.';
                $response_msg = 'Gagal menghapus riwayat broadcast: ' . htmlspecialchars($error_msg);
                $response_status = 'danger';
            }
        }
    }
    // --- CASE 3: MENGHAPUS SELURUH RIWAYAT BROADCAST ---
    elseif ($action_performed == 'clear_all_broadcasts') {
        $payload = json_encode([
            'action' => 'clear_all_broadcast_history'
        ]);

        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $api_endpoint); // Gunakan $api_endpoint
        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_POSTFIELDS, $payload);
        curl_setopt($ch, CURLOPT_HTTPHEADER, array(
            'Content-Type: application/json',
            'Content-Length: ' . strlen($payload)
        ));
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_TIMEOUT, 60);

        $response = curl_exec($ch);
        $http_code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        $curl_error = curl_error($ch);
        curl_close($ch);

        error_log("DEBUG: Clear All Broadcasts - Payload: " . $payload);
        error_log("DEBUG: Clear All Broadcasts - Raw Response: " . $response);
        error_log("DEBUG: Clear All Broadcasts - HTTP Code: " . $http_code);
        error_log("DEBUG: Clear All Broadcasts - cURL Error: " . $curl_error);

        if ($curl_error) {
            $response_msg = 'Error menghapus seluruh riwayat broadcast (cURL Error): ' . htmlspecialchars($curl_error);
            $response_status = 'danger';
        } else {
            $response_data = json_decode($response, true);
            if ($http_code == 200 && isset($response_data['status']) && $response_data['status'] == 'success') {
                $response_msg = htmlspecialchars($response_data['message']);
                $response_status = 'success';
            } else {
                $error_msg = $response_data['message'] ?? 'Respons tidak valid dari server.';
                $response_msg = 'Gagal menghapus seluruh riwayat broadcast: ' . htmlspecialchars($error_msg);
                $response_status = 'danger';
            }
        }
    }
    // --- KASUS: AKSI TIDAK DIKENAL ATAU TIDAK DITANGANI ---
    else {
        // Ini adalah bagian yang menyebabkan error "Aksi penghapusan tidak valid..." sebelumnya
        // saat tombol broadcast ditekan, karena action_performed tidak 'delete_broadcast'
        // dan tidak 'clear_all_broadcasts' (atau 'send_broadcast' sudah ditangani di atas).
        // Kita bisa menghapus ini atau biarkan sebagai fallback untuk aksi POST yang tidak dikenal.
        $response_msg = 'Aksi tidak dikenal atau tidak didukung.';
        $response_status = 'warning';
    }

    // Lakukan redirect setelah semua aksi POST selesai diproses
    header('Location: broadcast_message.php?message=' . urlencode($response_msg) . '&status=' . urlencode($response_status));
    exit();
}
// --- Akhir Penanganan POST Request ---


// Hitung jumlah pelanggan aktif untuk ditampilkan
$query_active_customers = "SELECT COUNT(id_pelanggan) AS total_active FROM pelanggan WHERE status_aktif = 'Aktif'";
$result_active_customers = $koneksi->query($query_active_customers);
if ($result_active_customers && $result_active_customers->num_rows > 0) {
    $customer_count = $result_active_customers->fetch_assoc()['total_active'];
}

// Ambil pesan dan status dari URL jika ada (setelah redirect)
if (isset($_GET['message']) && isset($_GET['status'])) {
    $message = '<div class="alert alert-' . htmlspecialchars($_GET['status']) . '">' . htmlspecialchars($_GET['message']) . '</div>';
}

// Ambil riwayat broadcast dari database untuk ditampilkan
$query_history = "SELECT * FROM whatsapp_broadcast_queue ORDER BY requested_at DESC LIMIT 10"; // Ambil 10 broadcast terbaru
$result_history = $koneksi->query($query_history);
if ($result_history && $result_history->num_rows > 0) {
    while ($row = $result_history->fetch_assoc()) {
        $broadcast_history[] = $row;
    }
}

// Dapatkan detail hasil broadcast jika ada broadcast_id yang dipilih dari URL atau sesi
$current_broadcast_details = [];
if (isset($_GET['view_broadcast_id']) && is_numeric($_GET['view_broadcast_id'])) {
    $view_broadcast_id = (int)$_GET['view_broadcast_id'];
    $query_details = $koneksi->prepare("SELECT phone_number, status, response_detail FROM whatsapp_broadcast_queue_details WHERE broadcast_id = ? ORDER BY status DESC, phone_number ASC");
    $query_details->bind_param("i", $view_broadcast_id);
    $query_details->execute();
    $result_details = $query_details->get_result();
    while ($row_detail = $result_details->fetch_assoc()) {
        $current_broadcast_details[] = $row_detail;
    }
    $query_details->close();
}


?>

<div class="main-content">
    <div class="top-header">
        <div class="alert-message">
            Kirim pesan broadcast ke semua pelanggan aktif Anda.
        </div>
        <div class="welcome-message">
            <span>Selamat datang, <?php echo htmlspecialchars($_SESSION['username'] ?? 'User'); ?>!</span>
            <a href="../logout.php" class="btn-logout">Logout</a>
        </div>
    </div>

    <div class="container">
        <h2>Broadcast Pesan WhatsApp</h2>

        <?php echo htmlspecialchars($message, ENT_QUOTES, "UTF-8"); // Tampilkan pesan feedback ?>

        <div class="card" style="margin-bottom: 20px;">
            <div class="card-header">
                <h3>Kirim Pesan Broadcast</h3>
            </div>
            <div class="card-body">
                <form method="POST">
                    <input type="hidden" name="action" value="send_broadcast">

                    <div class="form-group">
                        <label for="broadcast_message">Isi Pesan Broadcast:</label>
                        <textarea id="broadcast_message" name="broadcast_message" rows="6" placeholder="Tulis pesan Anda di sini. Pesan ini akan dikirim ke semua <?php echo htmlspecialchars($customer_count, ENT_QUOTES, "UTF-8"); ?> pelanggan aktif." required></textarea>
                    </div>

                    <button type="submit" class="btn btn-primary"><i class="fas fa-paper-plane"></i> Kirim Broadcast ke <?php echo htmlspecialchars($customer_count, ENT_QUOTES, "UTF-8"); ?> Pelanggan</button>
                </form>
            </div>
        </div>

        <div class="card" style="margin-top: 20px;">
            <div class="card-header">
                <h3>Riwayat Broadcast
                    <?php if (!empty($broadcast_history)): ?>
                        <form method="POST" style="display:inline-block; float:right;" onsubmit="return confirm('PERINGATAN! Anda akan menghapus SELURUH riwayat broadcast. Tindakan ini TIDAK dapat dibatalkan. Lanjutkan?');">
                            <input type="hidden" name="action" value="clear_all_broadcasts">
                            <button type="submit" class="btn btn-sm btn-warning"><i class="fas fa-eraser"></i> Hapus Seluruh Riwayat</button>
                        </form>
                    <?php endif; ?>
                </h3>
            </div>
            <div class="card-body">
                <?php if (empty($broadcast_history)): ?>
                    <p>Belum ada riwayat broadcast.</p>
                <?php else: ?>
                    <table class="data-table">
                        <thead>
                            <tr>
                                <th>ID</th>
                                <th>Pesan</th>
                                <th>Waktu Permintaan</th>
                                <th>Penerima</th>
                                <th>Terkirim</th>
                                <th>Gagal</th>
                                <th>Status</th>
                                <th>Aksi</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($broadcast_history as $item): ?>
                                <tr>
                                    <td><?php echo htmlspecialchars($item['id']); ?></td>
                                    <td><?php echo htmlspecialchars(substr($item['message_content'], 0, 50)); ?>...</td>
                                    <td><?php echo htmlspecialchars($item['requested_at']); ?></td>
                                    <td><?php echo htmlspecialchars($item['total_recipients']); ?></td>
                                    <td><?php echo htmlspecialchars($item['sent_count']); ?></td>
                                    <td><?php echo htmlspecialchars($item['failed_count']); ?></td>
                                    <td>
                                        <?php
                                            $status_class = '';
                                            if ($item['status'] == 'completed') {
                                                $status_class = 'status-success';
                                            } elseif ($item['status'] == 'failed') {
                                                $status_class = 'status-danger';
                                            } elseif ($item['status'] == 'processing') {
                                                $status_class = 'status-warning';
                                            } else {
                                                $status_class = 'status-info';
                                            }
                                        ?>
                                        <span class="<?php echo htmlspecialchars($status_class, ENT_QUOTES, "UTF-8"); ?>"><?php echo htmlspecialchars($item['status']); ?></span>
                                    </td>
                                    <td>
                                        <a href="?view_broadcast_id=<?php echo htmlspecialchars($item['id'], ENT_QUOTES, "UTF-8"); ?>" class="btn btn-sm btn-info">Lihat Detail</a>
                                        <form method="POST" style="display:inline-block;" onsubmit="return confirm('Apakah Anda yakin ingin menghapus riwayat broadcast ID <?php echo htmlspecialchars($item['id']); ?>? Tindakan ini tidak dapat dibatalkan.');">
                                            <input type="hidden" name="action" value="delete_broadcast">
                                            <input type="hidden" name="broadcast_id" value="<?php echo htmlspecialchars($item['id']); ?>">
                                            <button type="submit" class="btn btn-sm btn-danger"><i class="fas fa-trash"></i> Hapus</button>
                                        </form>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                <?php endif; ?>
            </div>
        </div>

        <?php if (!empty($current_broadcast_details)): ?>
        <div class="card" style="margin-top: 20px;">
            <div class="card-header">
                <h3>Detail Pengiriman Broadcast ID: <?php echo htmlspecialchars($view_broadcast_id); ?></h3>
            </div>
            <div class="card-body">
                <table class="data-table">
                    <thead>
                        <tr>
                            <th>Nomor Telepon</th>
                            <th>Status Pengiriman</th>
                            <th>Detail / Pesan Error</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($current_broadcast_details as $result_item): ?>
                            <tr>
                                <td><?php echo htmlspecialchars($result_item['phone_number']); ?></td>
                                <td class="<?php
                                    if ($result_item['status'] == 'sent') echo 'status-success';
                                    elseif ($result_item['status'] == 'failed') echo 'status-danger';
                                    else echo 'status-info';
                                ?>"><?php echo htmlspecialchars($result_item['status']); ?></td>
                                <td><?php echo htmlspecialchars($result_item['response_detail']); ?></td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>
        <?php endif; ?>

    </div>
</div>

<?php include '../includes/footer.php'; ?>