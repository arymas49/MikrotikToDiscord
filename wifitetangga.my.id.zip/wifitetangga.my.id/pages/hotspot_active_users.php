<?php
// C:\xampp\htdocs\billing_isp_app\pages\hotspot_active_users.php

ini_set('session.use_strict_mode', 1);
ini_set('session.cookie_httponly', 1);
ini_set('session.cookie_samesite', 'Lax');
if (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on') {
    ini_set('session.cookie_secure', 1);
}
session_start();
include '../config/koneksi.php';
include '../includes/header.php';

// Pastikan user memiliki role yang sesuai (misal: superadmin atau teknisi)
if (!hasRole(['superadmin', 'teknisi'])) {
    echo "<script>
            alert('Anda tidak memiliki akses ke halaman ini.');
            window.location.href = '../pages/dashboard.php';
          </script>";
    exit();
}
?>

<div class="main-content">
    <div class="page-header">
        <h1>Hotspot Aktif</h1>
        <p>Lihat daftar pengguna hotspot yang sedang aktif.</p>
    </div>

    <div class="container">
        <div class="card mb-4">
            <div class="card-header">
                <h3><i class="fas fa-wifi"></i> Pengguna Hotspot Aktif</h3>
                <div class="search-form-group">
                    <div class="form-group mb-0" style="max-width: 250px;">
                        <label for="mikrotikConfigSelect" class="sr-only">Pilih MikroTik:</label>
                        <select id="mikrotikConfigSelect" class="form-control form-control-sm">
                            <option value="">Memuat konfigurasi...</option>
                        </select>
                    </div>
                    <button id="refreshActiveUsersBtn" class="btn btn-info"><i class="fas fa-sync-alt"></i> Refresh</button>
                </div>
            </div>
            <div class="card-body">
                <div class="table-responsive">
                    <table class="table data-table table-hover" id="activeHotspotUsersTable">
                        <thead>
                            <tr>
                                <th>No</th>
                                <th>Server</th>
                                <th>Pengguna</th>
                                <th>IP Address</th>
                                <th>MAC Address</th>
                                <th>Uptime</th>
                                <th>Waktu Sisa</th>
                                <th>Bytes In</th>
                                <th>Bytes Out</th>
                                <th>Login By</th>
                                <th>Aksi</th>
                            </tr>
                        </thead>
                        <tbody>
                            </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>

<?php include '../includes/footer.php'; ?>

<script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
<script src="https://cdn.datatables.net/1.10.25/js/jquery.dataTables.min.js"></script>
<script src="https://cdn.datatables.net/1.10.25/js/dataTables.bootstrap4.min.js"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.bundle.min.js"></script>


<link rel="stylesheet" href="https://cdn.datatables.net/1.10.25/css/dataTables.bootstrap4.min.css">


<script>
document.addEventListener('DOMContentLoaded', function() {
    const refreshActiveUsersBtn = document.getElementById('refreshActiveUsersBtn');
    const activeHotspotUsersTableBody = document.querySelector('#activeHotspotUsersTable tbody');
    const mikrotikConfigSelect = document.getElementById('mikrotikConfigSelect'); // Dropdown pilihan MikroTik

    let dataTable = null; // Variabel untuk menyimpan instance DataTable

    // Variabel untuk menyimpan ID konfigurasi MikroTik yang saat ini dipilih
    let selectedMikrotikConfigId = localStorage.getItem('selectedMikrotikConfigId') || null;

    // Cache konfigurasi MikroTik yang dimuat (untuk mendapatkan nama dari ID)
    window.cachedMikrotikConfigs = [];

    // Inisialisasi DataTables segera setelah DOMContentLoaded
    // Ini memastikan DataTables hanya diinisialisasi sekali.
    if (typeof $ !== 'undefined' && $.fn.DataTable) {
        dataTable = $('#activeHotspotUsersTable').DataTable({
            "language": {
                // Ubah URL ini ke jalur lokal setelah mengunduh file
                "url": "../assets/datatables_i18n/Indonesian.json" 
            },
            "paging": true,
            "searching": true,
            "info": true,
            "order": [[1, 'asc']] // Urutkan berdasarkan kolom Server secara default
            // Jangan sertakan opsi 'data' di sini, data akan ditambahkan nanti
        });
    } else {
        console.error('jQuery or DataTables is not defined. Cannot initialize DataTable.');
        activeHotspotUsersTableBody.innerHTML = '<tr><td colspan="11" class="text-center">Error: jQuery atau DataTables tidak dimuat.</td></tr>';
        return; // Hentikan eksekusi jika pustaka tidak siap
    }

    // Fungsi helper untuk menampilkan notifikasi (asumsi sudah ada di header.php atau file lain)
    function showNotification(message, type = 'info') {
        const notificationArea = document.getElementById('notificationArea') || document.createElement('div');
        notificationArea.id = 'notificationArea';
        notificationArea.innerHTML = `<div class="alert alert-${type} alert-dismissible fade show" role="alert">
                                        ${message}
                                        <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                                            <span aria-hidden="true">&times;</span>
                                        </button>
                                    </div>`;
        document.body.prepend(notificationArea);
        setTimeout(() => {
            const alert = notificationArea.querySelector('.alert');
            if (alert) {
                $(alert).alert('close');
            }
        }, 5000);
    }

    // --- START: Helper functions for time parsing ---
    // Fungsi pembantu untuk menguraikan waktu RouterOS string (misal: "1d2h3m") menjadi detik
    function parseRouterOSTimeToSeconds(time_str) {
        if (!time_str || time_str === '0s' || typeof time_str !== 'string') {
            return 0;
        }
        let totalSeconds = 0;
        const matches = time_str.match(/(\d+)([wdhms])/g);
        if (matches) {
            matches.forEach(match => {
                const value = parseInt(match.slice(0, -1));
                const unit = match.slice(-1);
                switch (unit) {
                    case 'w': totalSeconds += value * 7 * 24 * 3600; break;
                    case 'd': totalSeconds += value * 24 * 3600; break;
                    case 'h': totalSeconds += value * 3600; break;
                    case 'm': totalSeconds += value * 60; break;
                    case 's': totalSeconds += value; break;
                }
            });
        }
        return totalSeconds;
    }

    // Fungsi helper untuk memformat durasi waktu RouterOS (menerima detik sebagai input)
    function formatRouterOSTime(seconds) {
        if (isNaN(seconds) || seconds < 0) {
            return 'N/A'; // Mengembalikan "N/A" jika input tidak valid
        }

        if (seconds === 0) {
            return '0 Detik'; // Mengembalikan "0 Detik" untuk nilai nol
        }

        const years = Math.floor(seconds / (365 * 24 * 3600));
        seconds %= (365 * 24 * 3600);
        const months = Math.floor(seconds / (30 * 24 * 3600)); // Approx month
        seconds %= (30 * 24 * 3600);
        const days = Math.floor(seconds / (24 * 3600));
        seconds %= (24 * 3600);
        const hours = Math.floor(seconds / 3600);
        seconds %= 3600;
        const minutes = Math.floor(seconds / 60);
        const secs = seconds % 60;

        const parts = [];
        if (years > 0) parts.push(years + ' Tahun');
        if (months > 0) parts.push(months + ' Bulan');
        if (days > 0) parts.push(days + ' Hari');
        if (hours > 0) parts.push(hours + ' Jam');
        if (minutes > 0) parts.push(minutes + ' Menit');
        if (secs > 0) parts.push(secs + ' Detik'); // Hanya tampilkan detik jika ada
        else if (parts.length === 0) parts.push('0 Detik'); // Tambahkan ini jika semua nol

        return parts.join(' ');
    }
    // --- END: Helper functions for time parsing ---


    // Helper function to format bytes
    function formatBytes(bytes, precision = 2) {
        const units = ['B', 'KB', 'MB', 'GB', 'TB'];
        bytes = Math.max(bytes, 0);
        const i = bytes === 0 ? 0 : Math.floor(Math.log(bytes) / Math.log(1024)); // Handle 0 bytes
        return parseFloat((bytes / Math.pow(1024, i)).toFixed(precision)) + ' ' + units[i];
    }

    // Fungsi untuk memuat daftar konfigurasi MikroTik
    async function loadMikrotikConfigs() {
        try {
            const response = await fetch('mikrotik_api.php?action=get_mikrotik_configs');
            const data = await response.json();

            mikrotikConfigSelect.innerHTML = ''; // Clear existing options

            // Tambahkan opsi "Tampilkan Semua" pertama kali
            const allOption = document.createElement('option');
            allOption.value = 'all';
            allOption.textContent = 'Tampilkan Semua';
            mikrotikConfigSelect.appendChild(allOption);

            if (data.status === 'success' && data.configs && Array.isArray(data.configs) && data.configs.length > 0) {
                window.cachedMikrotikConfigs = data.configs; // Cache konfigurasi
                
                data.configs.forEach(config => {
                    const option = document.createElement('option');
                    option.value = config.id;
                    option.textContent = `${config.name} (${config.ip_address})`;
                    mikrotikConfigSelect.appendChild(option);
                });

                // Set pilihan yang tersimpan di localStorage atau "all" sebagai default
                if (selectedMikrotikConfigId && data.configs.some(c => c.id == selectedMikrotikConfigId || selectedMikrotikConfigId === 'all')) {
                    mikrotikConfigSelect.value = selectedMikrotikConfigId;
                } else {
                    mikrotikConfigSelect.value = 'all'; // Default ke "all"
                    selectedMikrotikConfigId = 'all'; // Perbarui selected ID
                    localStorage.setItem('selectedMikrotikConfigId', selectedMikrotikConfigId);
                }
            } else {
                // Jika tidak ada konfigurasi, pastikan "Tampilkan Semua" tetap ada tapi nonaktif
                mikrotikConfigSelect.innerHTML = '';
                const noConfigOption = document.createElement('option');
                noConfigOption.value = '';
                noConfigOption.textContent = 'Tidak ada konfigurasi MikroTik';
                mikrotikConfigSelect.appendChild(noConfigOption);
                mikrotikConfigSelect.disabled = true;
                selectedMikrotikConfigId = null; // Reset selected ID jika tidak ada konfigurasi
                localStorage.removeItem('selectedMikrotikConfigId');
                showNotification('Tidak ada konfigurasi MikroTik yang tersimpan. Silakan tambahkan di Pengaturan API MikroTik.', 'warning');
            }
            // Setelah konfigurasi dimuat dan dipilih, muat pengguna aktif
            loadActiveHotspotUsers();

        } catch (error) {
            console.error('Error loading MikroTik configs:', error);
            mikrotikConfigSelect.innerHTML = '';
            const errorOption = document.createElement('option');
            errorOption.value = '';
            errorOption.textContent = 'Gagal memuat konfigurasi';
            mikrotikConfigSelect.appendChild(errorOption);
            mikrotikConfigSelect.disabled = true;
            selectedMikrotikConfigId = null;
            localStorage.removeItem('selectedMikrotikConfigId');
            showNotification('Terjadi kesalahan saat memuat daftar konfigurasi MikroTik.', 'error');
            // Tetap coba muat pengguna aktif, mungkin selectedMikrotikConfigId masih ada dari sebelumnya
            loadActiveHotspotUsers();
        }
    }


    // Fungsi untuk memuat pengguna hotspot aktif
    async function loadActiveHotspotUsers() { // Changed to async
        if (!selectedMikrotikConfigId) {
            dataTable.clear().draw();
            activeHotspotUsersTableBody.innerHTML = '<tr><td colspan="11" class="text-center">Tidak ada konfigurasi MikroTik yang dipilih.</td></tr>';
            return;
        }

        activeHotspotUsersTableBody.innerHTML = '<tr><td colspan="11" class="text-center">Memuat pengguna aktif...</td></tr>';

        // Clear existing DataTable data
        dataTable.clear();

        let allActiveUsers = [];

        try {
            if (selectedMikrotikConfigId === 'all') {
                if (window.cachedMikrotikConfigs.length === 0) {
                    showNotification('Tidak ada konfigurasi MikroTik yang tersedia untuk ditampilkan.', 'info');
                    // dataTable.draw() will show "No data available in table"
                    dataTable.draw();
                    return;
                }
                const fetchPromises = window.cachedMikrotikConfigs.map(async (config) => {
                    const response = await fetch(`mikrotik_api.php?action=get_hotspot_active_users&config_id=${config.id}`);
                    const data = await response.json();
                    if (data.status === 'success' && data.active_users && Array.isArray(data.active_users)) {
                        // Tambahkan mikrotik_name ke setiap pengguna untuk ditampilkan
                        return data.active_users.map(user => ({ ...user, mikrotik_name: config.name }));
                    } else {
                        console.warn(`Gagal memuat pengguna aktif dari MikroTik ${config.name}: ${data.message || 'Unknown error'}`);
                        return []; // Kembalikan array kosong jika ada error untuk MikroTik spesifik ini
                    }
                });
                const results = await Promise.all(fetchPromises);
                allActiveUsers = results.flat(); // Ratakan array dari array hasil fetch
            } else {
                // Ambil dari satu MikroTik yang dipilih
                const selectedConfig = window.cachedMikrotikConfigs.find(config => config.id == selectedMikrotikConfigId);
                const selectedMikrotikName = selectedConfig ? selectedConfig.name : 'N/A'; // Dapatkan nama untuk satu MikroTik

                const response = await fetch(`mikrotik_api.php?action=get_hotspot_active_users&config_id=${selectedMikrotikConfigId}`);
                const data = await response.json();

                if (data.status === 'success' && data.active_users && Array.isArray(data.active_users)) {
                    allActiveUsers = data.active_users.map(user => ({ ...user, mikrotik_name: selectedMikrotikName }));
                } else {
                    showNotification('Gagal memuat pengguna aktif: ' + data.message, 'error');
                }
            }

            // Setelah mengambil semua pengguna, render mereka ke DataTable
            if (allActiveUsers.length > 0) {
                const tableData = allActiveUsers.map((user, index) => [
                    index + 1,
                    // Gunakan mikrotik_name yang ditambahkan saat fetch
                    user.mikrotik_name || 'N/A', 
                    user.user || 'N/A',
                    user.address || 'N/A',
                    user['mac-address'] || 'N/A',
                    formatRouterOSTime(parseRouterOSTimeToSeconds(user.uptime || '0s')),
                    formatRouterOSTime(parseRouterOSTimeToSeconds(user['session-time-left'] || 'N/A')), 
                    formatBytes(user['bytes-in'] || 0),
                    formatBytes(user['bytes-out'] || 0),
                    user['login-by'] || 'N/A',
                    `<button class="btn btn-danger btn-sm remove-active-user-btn" data-id="${user['.id']}" data-username="${user.user}">
                        <i class="fas fa-trash"></i> Hapus
                    </button>`
                ]);
                
                dataTable.rows.add(tableData).draw(); // Tambahkan data baru dan gambar ulang tabel
                attachRemoveEventListeners(); // Lampirkan event listener setelah tabel diisi
            } else {
                activeHotspotUsersTableBody.innerHTML = '<tr><td colspan="11" class="text-center">Tidak ada pengguna hotspot aktif.</td></tr>';
                // dataTable.clear() sudah dipanggil di awal fungsi, jadi tidak perlu lagi di sini
                dataTable.draw(); // Gambar ulang untuk menampilkan pesan "No data available" dari DataTables
            }
        } catch (error) {
            console.error('Error loading active hotspot users:', error);
            showNotification('Terjadi kesalahan saat memuat pengguna aktif: ' + error.message, 'error');
            // Jika ada error, kosongkan DataTable dan tampilkan pesan error
            if (dataTable) {
                dataTable.clear().draw(); 
            }
            activeHotspotUsersTableBody.innerHTML = '<tr><td colspan="11" class="text-center">Gagal memuat data. Silakan coba refresh.</td></tr>';
        }
    }


    // Fungsi untuk melampirkan event listener ke tombol hapus
    function attachRemoveEventListeners() {
        document.querySelectorAll('.remove-active-user-btn').forEach(button => {
            button.addEventListener('click', function() {
                const userId = this.dataset.id;
                const username = this.dataset.username;
                if (confirm(`Apakah Anda yakin ingin menghapus pengguna aktif "${username}"?`)) {
                    removeActiveHotspotUser(userId);
                }
            });
        });
    }

    // Fungsi untuk menghapus pengguna aktif
    function removeActiveHotspotUser(id) {
        if (!selectedMikrotikConfigId) {
            showNotification('Pilih konfigurasi MikroTik untuk menghapus pengguna aktif.', 'warning');
            return;
        }
        // Jika mode "Tampilkan Semua" aktif, kita harus menggunakan config_id dari MikroTik tempat pengguna aktif berasal
        // Namun, data-id saat ini hanya berisi ID internal pengguna hotspot dari MikroTik, bukan config_id.
        // Jika Anda perlu menghapus pengguna aktif dari MikroTik spesifik saat di mode "Tampilkan Semua",
        // Anda harus menambahkan data-mikrotik-config-id ke tombol hapus di fungsi loadActiveHotspotUsers.
        // Untuk saat ini, kita akan asumsikan kita menghapus dari selectedMikrotikConfigId saat ini (yang berarti tidak akan berfungsi di mode "Tampilkan Semua" jika user bukan dari MikroTik yang sedang dipilih).
        // SOLUSI: passed selectedMikrotikConfigId (config_id) to the removeActiveHotspotUser in the button's data attribute.
        const mikrotikIdForRemoval = this ? this.dataset.mikrotikConfigId : selectedMikrotikConfigId; // Get from button data or current selection

        if (!mikrotikIdForRemoval || mikrotikIdForRemoval === 'all') {
             showNotification('Tidak dapat menghapus pengguna aktif di mode "Tampilkan Semua". Silakan pilih MikroTik spesifik.', 'warning');
             return;
        }

        fetch(`../pages/mikrotik_api.php?action=remove_hotspot_active_user&config_id=${mikrotikIdForRemoval}`, { // Kirim config_id yang benar
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'X-Requested-With': 'XMLHttpRequest' // Penting untuk validasi di PHP
            },
            body: JSON.stringify({
                action: 'remove_hotspot_active_user',
                id: id
            })
        })
        .then(response => {
            if (!response.ok) {
                throw new Error(`HTTP error! Status: ${response.status}`);
            }
            return response.json();
        })
        .then(data => {
            if (data.status === 'success') {
                showNotification(data.message, 'success');
                loadActiveHotspotUsers(); // Muat ulang daftar setelah penghapusan
            } else {
                showNotification('Gagal menghapus pengguna aktif: ' + data.message, 'error');
            }
        })
        .catch(error => {
            console.error('Error removing active user:', error);
            showNotification('Terjadi kesalahan saat menghapus pengguna aktif: ' + error.message, 'error');
        });
    }

    // Event Listeners
    if (mikrotikConfigSelect) {
        mikrotikConfigSelect.addEventListener('change', function() {
            selectedMikrotikConfigId = this.value;
            localStorage.setItem('selectedMikrotikConfigId', selectedMikrotikConfigId);
            loadActiveHotspotUsers(); // Muat ulang pengguna aktif dengan konfigurasi baru
        });
    }

    refreshActiveUsersBtn.addEventListener('click', loadActiveHotspotUsers);

    // Initial load - panggil loadMikrotikConfigs terlebih dahulu
    loadMikrotikConfigs(); 
});
</script>