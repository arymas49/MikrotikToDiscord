<?php
// C:\xampp\htdocs\billing_isp_app\pages\print_nota_manual.php
ini_set('session.use_strict_mode', 1);
ini_set('session.cookie_httponly', 1);
ini_set('session.cookie_samesite', 'Lax');
if (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on') {
    ini_set('session.cookie_secure', 1);
}
session_start();
include '../config/koneksi.php';

// Cek apakah user sudah login
if (!isset($_SESSION['user_id'])) {
    header('Location: ../index.php');
    exit();
}

// --- Fungsi untuk konversi angka ke terbilang (Indonesia) ---
function terbilang($angka) {
    $angka = abs($angka);
    $baca = array("", "satu", "dua", "tiga", "empat", "lima", "enam", "tujuh", "delapan", "sembilan", "sepuluh", "sebelas");
    $temp = "";
    if ($angka < 12) {
        $temp = " " . $baca[$angka];
    } else if ($angka < 20) {
        $temp = terbilang($angka - 10) . " belas";
    } else if ($angka < 100) {
        $temp = terbilang($angka / 10) . " puluh" . terbilang($angka % 10);
    } else if ($angka < 200) {
        $temp = " seratus" . terbilang($angka - 100);
    } else if ($angka < 1000) {
        $temp = terbilang($angka / 100) . " ratus" . terbilang($angka % 100);
    } else if ($angka < 2000) {
        $temp = " seribu" . terbilang($angka - 1000);
    } else if ($angka < 1000000) {
        $temp = terbilang($angka / 1000) . " ribu" . terbilang($angka % 1000);
    } else if ($angka < 1000000000) {
        $temp = terbilang($angka / 1000000) . " juta" . terbilang(fmod($angka, 1000000));
    } else if ($angka < 1000000000000) {
        $temp = terbilang($angka / 1000000000) . " milyar" . terbilang(fmod($angka, 1000000000));
    } else if ($angka < 1000000000000000) {
        $temp = terbilang($angka / 1000000000000) . " trilyun" . terbilang(fmod($angka, 1000000000000));
    }
    return $temp;
}

function format_terbilang_rupiah($angka) {
    if ($angka < 0) {
        return "Minus " . trim(terbilang($angka)) . " Rupiah";
    } elseif ($angka == 0) {
        return "Nol Rupiah";
    } else {
        return trim(terbilang($angka)) . " Rupiah";
    }
}

// --- Get Nota Data ---
$nota_id_param = $_GET['id'] ?? null;

$nota_data = [];
$customer_display_data = [];
$item_display_data = [];
$total_amount_display = 0;

$nota_title_text = "NOTA PEMBAYARAN JASA";
$nota_number_display = "N/A";

if ($nota_id_param) {
    $query = "
        SELECT 
            nm.*,
            u.username as dicatat_oleh_username
        FROM nota_manual nm
        LEFT JOIN users u ON nm.dicatat_oleh_user_id = u.id
        WHERE nm.id_nota_manual = ?
    ";
    $stmt = $koneksi->prepare($query);
    $stmt->bind_param("i", $nota_id_param);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        $nota_data = $result->fetch_assoc();

        $customer_display_data = [
            'nama'    => $nota_data['nama_penerima'],
            'alamat'  => $nota_data['alamat_penerima'],
            'telepon' => $nota_data['telepon_penerima'],
            'email'   => $nota_data['email_penerima']
        ];
        
        $item_display_data[] = [
            'item' => htmlspecialchars($nota_data['deskripsi_jasa']),
            'harga' => $nota_data['jumlah_biaya']
        ];
        $total_amount_display = $nota_data['jumlah_biaya'];

        $nota_number_display = "NOTA-" . date('Ymd', strtotime($nota_data['tanggal_nota'])) . "-" . str_pad($nota_data['id_nota_manual'], 5, '0', STR_PAD_LEFT);

    } else {
        die("Data nota manual tidak ditemukan.");
    }
    $stmt->close();

} else {
    die("Parameter nota tidak valid (id missing).");
}

// Data perusahaan (hardcoded sesuai gambar)
$company_name = "PT Triple Zhi Network";
$company_address = "Jl Gadarmun Hangkiho Kec Baoalan Kel Tuweley , Kabupaten Tolitoli Provinsi Sulawesi Tengah 94515";
$company_email = "adm@triplezhinetwork.id";
$company_phone = "082259438445";

$current_date_invoice_footer = date('F Y');


$koneksi->close();
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo htmlspecialchars($nota_title_text); ?> - <?php echo htmlspecialchars($customer_display_data['nama'] ?? 'Penerima'); ?></title>
    <link rel="stylesheet" href="../css/print.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
</head>
<body>
    <div class="invoice-container">
        <div class="invoice-top-section">
            <div class="logo">
                <img src="../assets/images/Logo-TZN.png" alt="PT Triple Zhi Network Logo"> 
            </div>
            <div class="invoice-meta">
                <p>Nota # <span class="font-bold"><?php echo htmlspecialchars($nota_number_display); ?></span></p>
                <p>Tanggal : <span class="font-bold"><?php echo htmlspecialchars(date('d F Y', strtotime($nota_data['tanggal_nota']))); ?></span></p>
                <p>Dicatat Oleh : <span class="font-bold"><?php echo htmlspecialchars($nota_data['dicatat_oleh_username'] ?? 'N/A'); ?></span></p>
            </div>
        </div>

        <div class="company-customer-details">
            <div class="company-info">
                <h3><?php echo htmlspecialchars($company_name); ?></h3>
                <p><?php echo nl2br(htmlspecialchars($company_address)); ?></p>
                <p><?php echo htmlspecialchars($company_email); ?></p>
                <p><?php echo htmlspecialchars($company_phone); ?></p>
            </div>
            <div class="customer-info">
                <h3><?php echo htmlspecialchars($customer_display_data['nama'] ?? 'N/A'); ?></h3>
                <?php if (!empty($customer_display_data['alamat'])): ?>
                    <p>Alamat: <?php echo nl2br(htmlspecialchars($customer_display_data['alamat'])); ?></p>
                <?php endif; ?>
                <?php if (!empty($customer_display_data['telepon'])): ?>
                    <p>Telepon: <?php echo htmlspecialchars($customer_display_data['telepon']); ?></p>
                <?php endif; ?>
                <?php if (!empty($customer_display_data['email'])): ?>
                    <p>Email: <?php echo htmlspecialchars($customer_display_data['email']); ?></p>
                <?php endif; ?>
            </div>
        </div>

        <table class="items-table">
            <thead>
                <tr>
                    <th>Deskripsi Jasa/Layanan</th>
                    <th class="text-right" style="width: 25%;">Biaya</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($item_display_data as $item): ?>
                    <tr>
                        <td><?php echo htmlspecialchars($item['item']); ?></td>
                        <td class="text-right">Rp <?php echo number_format($item['harga'], 0, ',', '.'); ?></td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
            <tfoot>
                <tr>
                    <td class="text-right font-bold">Total:</td>
                    <td class="text-right font-bold">Rp <?php echo number_format($total_amount_display, 0, ',', '.'); ?></td>
                </tr>
            </tfoot>
        </table>

        <div class="terbilang-section">
            <p>Terbilang: <span class="font-bold"><?php echo htmlspecialchars(format_terbilang_rupiah($total_amount_display)); ?></span></p>
        </div>

        <div class="bank-details-section">
            <h3>Pembayaran diterima melalui:</h3>
            <p><?php echo htmlspecialchars($nota_data['metode_pembayaran'] ?? 'N/A'); ?></p>
            <p>BNI A/N PT Triple Zhi Network 4949262629</p>
            <p>NPWP A/N PT Triple Zhi Network 62.352.426.1-834.000</p>
        </div>

        <div class="signature-section">
            <p class="date-right"><?php echo htmlspecialchars(date('d F Y', strtotime($nota_data['tanggal_nota']))); ?></p>
            <div style="height: 60px;"></div> 
            <p class="company-name-signature"><?php echo htmlspecialchars($company_name); ?></p>
        </div>

        <div class="no-print-btn-group">
            <button class="no-print-btn" onclick="window.print()"><i class="fas fa-print"></i> Cetak Nota</button>
            <button class="no-print-btn" onclick="window.close()" style="background-color: #6c757d; margin-left: 10px;"><i class="fas fa-times-circle"></i> Tutup</button>
        </div>
    </div>
</body>
</html>