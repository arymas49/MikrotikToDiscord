<?php
// C:\xampp\htdocs\billing_isp_app\pages\whatsapp_gateway_settings.php
ini_set('session.use_strict_mode', 1);
ini_set('session.cookie_httponly', 1);
ini_set('session.cookie_samesite', 'Lax');
if (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on') {
    ini_set('session.cookie_secure', 1);
}
session_start();
include '../config/koneksi.php';
include '../includes/header.php'; // Ini akan meng-include sidebar juga

// Definisi path log untuk debugging dari halaman settings
$log_file_settings_path = '/var/www/html/wifitetangga.my.id/php_logs/whatsapp_settings.log'; // Sesuaikan path ini jika perlu

// Fungsi log untuk settings
function log_settings_debug($message) {
    global $log_file_settings_path;
    $timestamp = date('Y-m-d H:i:s');
    $log_dir = dirname($log_file_settings_path);
    if (!is_dir($log_dir)) {
        if (!mkdir($log_dir, 0755, true) && !is_dir($log_dir)) {
            error_log("Failed to create log directory for settings: " . $log_dir);
            return;
        }
        chmod($log_dir, 0775); // Set permissions for newly created directory
    }
    file_put_contents($log_file_settings_path, "[$timestamp] [SETTINGS] $message\n", FILE_APPEND);
}

log_settings_debug("--- NEW REQUEST TO whatsapp_gateway_settings.php AT " . date('Y-m-d H:i:s') . " ---");

// Batasi akses ke halaman ini: hanya superadmin
if (!hasRole('superadmin')) {
    log_settings_debug("Unauthorized access attempt by user: " . ($_SESSION['username'] ?? 'N/A') . " (Role: " . ($_SESSION['role'] ?? 'N/A') . ")");
    header('Location: dashboard.php'); // Redirect ke dashboard atau halaman akses ditolak
    exit();
}

$message = '';
$whatsapp_config_path = __DIR__ . '/../config/whatsapp_config.php'; // Gunakan __DIR__ untuk path absolut yang lebih robust
log_settings_debug("WhatsApp config path: " . $whatsapp_config_path);

// Load existing config
if (file_exists($whatsapp_config_path)) {
    $whatsapp_config = include $whatsapp_config_path;
    log_settings_debug("Existing whatsapp_config loaded. API Key (first 5 chars): " . substr(($whatsapp_config['whatsapp_api_key'] ?? 'N/A'), 0, 5));
} else {
    $message = '<div class="alert alert-warning">File konfigurasi WhatsApp (whatsapp_config.php) belum ditemukan. Ini akan dibuat saat Anda menyimpan pengaturan.</div>';
    log_settings_debug("whatsapp_config.php not found. It will be created on save.");
}

// Handle form submission to save settings
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['action']) && $_POST['action'] == 'save_whatsapp_settings') {
    // CSRF Token Validation
    if (!isset($_POST['csrf_token']) || $_POST['csrf_token'] !== $_SESSION['csrf_token']) {
        $message = '<div class="alert alert-danger">Kesalahan CSRF: Permintaan tidak valid.</div>';
        log_settings_debug("CSRF validation failed for user: " . ($_SESSION['username'] ?? 'N/A'));
    } else {
        $new_api_url = $_POST['whatsapp_api_url'] ?? '';
        $new_api_key = $_POST['whatsapp_api_key'] ?? '';
        $new_instance_id = $_POST['instance_id'] ?? '';
        $new_device_id = $_POST['device_id'] ?? '';

        // Pastikan app_base_url dan api_access_token tetap ada jika sudah ada di config
        // Ini penting karena whatsapp_gateway_settings.php hanya mengelola subset dari config.
        // Jika Anda ingin mengelola semua, Anda perlu menambahkannya ke form.
        $app_base_url = $whatsapp_config['app_base_url'] ?? '';
        $api_access_token = $whatsapp_config['api_access_token'] ?? '';


        $updated_config = [
            'whatsapp_api_url' => $new_api_url,
            'whatsapp_api_key' => $new_api_key,
            'instance_id' => $new_instance_id,
            'device_id' => $new_device_id,
            'app_base_url' => $app_base_url, // Pertahankan nilai ini
            'api_access_token' => $api_access_token, // Pertahankan nilai ini
        ];

        // Format konten PHP untuk disimpan
        $config_content = "<?php\n\nreturn " . var_export($updated_config, true) . ";\n\n?>";

        log_settings_debug("Attempting to write config. New API Key (first 5 chars): " . substr($new_api_key, 0, 5));
        log_settings_debug("Content to write:\n" . $config_content); // Log konten yang akan ditulis

        // Coba tulis ke file
        // Gunakan @ untuk menyembunyikan peringatan PHP dan tangani secara manual
        $write_success = @file_put_contents($whatsapp_config_path, $config_content);

        if ($write_success !== false) { // file_put_contents mengembalikan jumlah byte yang ditulis atau false
            $message = '<div class="alert alert-success">Pengaturan WhatsApp Gateway berhasil disimpan!</div>';
            $whatsapp_config = $updated_config; // Update current config to display in form
            log_settings_debug("Config saved successfully. Bytes written: " . $write_success);
        } else {
            $last_error = error_get_last();
            $error_message = $last_error ? $last_error['message'] : 'Tidak ada pesan error spesifik.';
            $message = '<div class="alert alert-danger">Gagal menyimpan pengaturan. Pastikan file/folder `config` memiliki izin tulis (error: ' . htmlspecialchars($error_message) . ').</div>';
            log_settings_debug("Failed to save config. Error: " . $error_message);
        }
    }
}

// Initial values for the form (always load from $whatsapp_config, which is updated after save)
$current_api_url = $whatsapp_config['whatsapp_api_url'] ?? '';
$current_api_key = $whatsapp_config['whatsapp_api_key'] ?? '';
$current_instance_id = $whatsapp_config['instance_id'] ?? '';
$current_device_id = $whatsapp_config['device_id'] ?? '';
?>

<div class="main-content">
    <div class="top-header">
        <div class="alert-message">
            Kelola pengaturan integrasi WhatsApp Gateway Anda di sini.
        </div>
        <div class="welcome-message">
            <span>Selamat datang, <?php echo htmlspecialchars($_SESSION['username'] ?? 'User'); ?>!</span>
            <a href="../logout.php" class="btn-logout">Logout</a> 
        </div>
    </div>

    <div class="container"> 
        <h2>Pengaturan WhatsApp Gateway</h2>

        <?php echo $message; // $message sudah berisi HTML, tidak perlu htmlspecialchars lagi ?>

        <div class="card" style="margin-bottom: 20px;">
            <div class="card-header">
                <h3>Konfigurasi API</h3>
            </div>
            <div class="card-body">
                <form method="POST">
                    <?php if (!isset($_SESSION['csrf_token'])) { $_SESSION['csrf_token'] = bin2hex(random_bytes(32)); } ?>
                    <input type='hidden' name='csrf_token' value='<?php echo htmlspecialchars($_SESSION['csrf_token']); ?>'>
                    <input type="hidden" name="action" value="save_whatsapp_settings">
                    <div class="form-group">
                        <label for="whatsapp_api_url">URL API Gateway:</label>
                        <input type="url" id="whatsapp_api_url" name="whatsapp_api_url" value="<?php echo htmlspecialchars($current_api_url); ?>" placeholder="Contoh: https://api.namagateway.com/v1/send" required>
                        <small>URL endpoint untuk mengirim pesan atau mengelola perangkat.</small>
                    </div>
                    <div class="form-group">
                        <label for="whatsapp_api_key">Kunci API (API Key):</label>
                        <input type="text" id="whatsapp_api_key" name="whatsapp_api_key" value="<?php echo htmlspecialchars($current_api_key); ?>" placeholder="Masukkan kunci API Anda" required>
                        <small>Kunci autentikasi yang diberikan oleh penyedia WhatsApp Gateway Anda.</small>
                    </div>
                    <div class="form-group">
                        <label for="instance_id">Instance ID (Opsional):</label>
                        <input type="text" id="instance_id" name="instance_id" value="<?php echo htmlspecialchars($current_instance_id); ?>" placeholder="Jika diperlukan oleh Gateway Anda">
                        <small>Beberapa gateway memerlukan Instance ID atau Session ID.</small>
                    </div>
                    <div class="form-group">
                        <label for="device_id">Device ID (Opsional):</label>
                        <input type="text" id="device_id" name="device_id" value="<?php echo htmlspecialchars($current_device_id); ?>" placeholder="Jika diperlukan oleh Gateway Anda">
                        <small>Beberapa gateway memerlukan Device ID tertentu.</small>
                    </div>
                    <button type="submit" class="btn btn-primary">Simpan Pengaturan</button>
                </form>
            </div>
        </div>

        <div class="card">
            <div class="card-header">
                <h3>Status Perangkat WhatsApp <small>(Simulasi)</small></h3>
            </div>
            <div class="card-body">
                <div class="form-group">
                    <label>Status Koneksi API Key:</label>
                    <span id="apiKeyConnectionStatus" class="status-badge status-secondary">Memuat...</span>
                </div>
                <div class="form-group">
                    <label>Status Perangkat (QR Scan):</label>
                    <span id="deviceConnectionStatus" class="status-badge status-secondary">Memuat...</span>
                </div>
                <div id="qrCodeContainer" style="text-align: center; margin-top: 20px; display: none;">
                    <p>Pindai QR Code ini dengan aplikasi WhatsApp di ponsel Anda:</p>
                    <img id="qrCodeImage" src="" alt="QR Code" style="max-width: 250px; border: 1px solid #ddd; padding: 10px; border-radius: 5px;">
                    <p id="qrCodeTimer" style="font-size: 0.9em; color: #666;"></p>
                </div>
                <div id="connectionMessage" class="alert" style="display: none; margin-top: 15px;"></div>
                
                <button type="button" class="btn btn-info" onclick="getQrCodeFromSettings()">
                    <i class="fas fa-qrcode"></i> Dapatkan & Pindai QR Code
                </button>
                <button type="button" class="btn btn-secondary" onclick="checkAllStatusesFromSettings()">
                    <i class="fas fa-sync-alt"></i> Cek Semua Status
                </button>

                <hr style="margin: 20px 0;"> <p><b>Kontrol Status Perangkat Simulasi (untuk pengujian):</b></p>
                <button type="button" class="btn btn-success btn-sm" onclick="setSimulatedDeviceStatus('connected')">Set Connected</button>
                <button type="button" class="btn btn-warning btn-sm" onclick="setSimulatedDeviceStatus('scanning')">Set Scanning</button>
                <button type="button" class="btn btn-danger btn-sm" onclick="setSimulatedDeviceStatus('disconnected')">Set Disconnected</button>

            </div>
        </div>

    </div>
</div>

<script>
// PENTING: interval variables harus didefinisikan di scope global atau window
let qrCodeInterval;
let statusPollingInterval;

// Fungsi utilitas untuk memperbarui tampilan status (badge dan pesan)
function updateStatusDisplay(elementId, statusText, colorClass, messageText = '', messageType = '') {
    const statusElement = document.getElementById(elementId);
    // console.log("DEBUG: updateStatusDisplay called for", elementId, "with message:", messageText); // DEBUG
    const messageElement = document.getElementById('connectionMessage'); // Pesan umum

    if (statusElement) {
        statusElement.textContent = statusText;
        statusElement.className = 'status-badge'; // Reset classes
        statusElement.classList.add(colorClass); 
    }
    
    if (messageElement) { // Hanya update connectionMessage jika ada
        if (messageText) {
            messageElement.textContent = messageText;
            messageElement.className = 'alert ' + messageType; // Reset class & add new type
            messageElement.style.display = 'block';
        } else {
            messageElement.style.display = 'none'; // Sembunyikan pesan jika tidak ada teks
        }
    }
}

// Fungsi untuk mengecek validitas API Key
function checkApiKeyValidity() {
    const apiKey = document.getElementById('whatsapp_api_key').value;
    updateStatusDisplay('apiKeyConnectionStatus', 'Memuat...', 'status-secondary');
    updateStatusDisplay('', '', '', 'Mengecek validitas API Key...', 'alert-info'); // Pesan umum

    fetch('whatsapp_gateway_api_simulator.php', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ action: 'check_api_key_validity', api_key: apiKey }),
    })
    .then(response => response.json())
    .then(data => {
        if (data.status === 'valid') {
            updateStatusDisplay('apiKeyConnectionStatus', 'API Key Valid', 'status-success');
            updateStatusDisplay('', '', '', 'API Key valid.', 'alert-success');
        } else {
            updateStatusDisplay('apiKeyConnectionStatus', 'API Key Tidak Valid', 'status-danger');
            updateStatusDisplay('', '', '', 'Kunci API tidak valid atau kosong. Harap periksa pengaturan Anda.', 'alert-danger');
        }
    })
    .catch(error => {
        console.error('Error checking API Key validity:', error);
        updateStatusDisplay('apiKeyConnectionStatus', 'Error API Key', 'status-danger');
        updateStatusDisplay('', '', '', 'Terjadi kesalahan jaringan saat validasi API Key.', 'alert-danger');
    });
}

// Fungsi untuk mengecek status perangkat (QR scan)
function checkDeviceStatus() {
    const apiKey = document.getElementById('whatsapp_api_key').value;
    updateStatusDisplay('deviceConnectionStatus', 'Memuat...', 'status-secondary');
    // updateStatusDisplay('', '', '', 'Mengecek status perangkat...', 'alert-info'); // Pesan umum, bisa konflik dengan API Key message

    clearInterval(statusPollingInterval); // Pastikan tidak ada polling lama berjalan

    fetch('whatsapp_gateway_api_simulator.php', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ action: 'check_device_status', api_key: apiKey }), // Kirim API Key
    })
    .then(response => response.json())
    .then(data => {
        if (data.status === 'connected') {
            updateStatusDisplay('deviceConnectionStatus', 'Perangkat Tersambung', 'status-success');
            // updateStatusDisplay('', '', '', 'Perangkat WhatsApp Gateway berhasil terhubung.', 'alert-success');
            document.getElementById('qrCodeContainer').style.display = 'none';
            clearInterval(qrCodeInterval); // Hentikan refresh QR jika tersambung
        } else if (data.status === 'disconnected') {
            updateStatusDisplay('deviceConnectionStatus', 'Perangkat Terputus', 'status-danger');
            // updateStatusDisplay('', '', '', 'Perangkat WhatsApp Gateway terputus. Dapatkan QR Code baru.', 'alert-danger');
            document.getElementById('qrCodeContainer').style.display = 'none';
        } else if (data.status === 'scanning') {
            updateStatusDisplay('deviceConnectionStatus', 'Menunggu Pemindaian...', 'status-info');
            // updateStatusDisplay('', '', '', 'QR Code aktif, menunggu pemindaian.', 'alert-info');
            // Jika status scanning, kita bisa mulai polling otomatis
            if (!statusPollingInterval) { // Mencegah interval ganda
                statusPollingInterval = setInterval(() => {
                    checkDeviceStatus(); // Polling menggunakan fungsi ini
                }, 5000); // Polling setiap 5 detik
            }
        } else {
            updateStatusDisplay('deviceConnectionStatus', 'Tidak Diketahui', 'status-warning');
            // updateStatusDisplay('', '', '', 'Status perangkat tidak diketahui.', 'alert-warning');
        }
    })
    .catch(error => {
        console.error('Error checking device status:', error);
        updateStatusDisplay('deviceConnectionStatus', 'Error Perangkat', 'status-danger');
        // updateStatusDisplay('', '', '', 'Terjadi kesalahan jaringan saat memeriksa status perangkat.', 'alert-danger');
    });
}

// Fungsi utama untuk mengecek kedua status (dipanggil dari tombol "Cek Semua Status")
function checkAllStatusesFromSettings() {
    checkApiKeyValidity(); // Cek validitas API Key
    checkDeviceStatus();   // Cek status perangkat
}


// Fungsi untuk mendapatkan QR Code (dipanggil dari tombol "Dapatkan & Pindai QR Code")
function getQrCodeFromSettings() {
    const qrCodeImage = document.getElementById('qrCodeImage');
    const qrCodeContainer = document.getElementById('qrCodeContainer');
    const qrCodeTimer = document.getElementById('qrCodeTimer');
    const apiKey = document.getElementById('whatsapp_api_key').value;

    // Fix: Declare messageElement here
    const messageElement = document.getElementById('connectionMessage'); 

    if (!apiKey) {
        updateStatusDisplay('apiKeyConnectionStatus', 'API Key Kosong', 'status-danger');
        messageElement.textContent = 'Harap masukkan API Key terlebih dahulu untuk mendapatkan QR Code.';
        messageElement.className = 'alert alert-danger';
        messageElement.style.display = 'block';
        return;
    }
    
    updateStatusDisplay('deviceConnectionStatus', 'Memuat...', 'status-info');
    messageElement.textContent = 'Meminta QR Code dari Gateway...';
    messageElement.className = 'alert alert-info';
    messageElement.style.display = 'block'; // Pastikan pesan umum terlihat

    qrCodeImage.src = ''; // Clear previous QR
    clearInterval(qrCodeInterval); // Clear any existing QR refresh interval
    clearInterval(statusPollingInterval); // Clear any existing status polling interval

    fetch('whatsapp_gateway_api_simulator.php', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ action: 'get_qr', api_key: apiKey }),
    })
    .then(response => response.json())
    .then(data => {
        if (data.status === 'success' && data.qr_code_url) {
            qrCodeImage.src = data.qr_code_url;
            qrCodeContainer.style.display = 'block';
            updateStatusDisplay('deviceConnectionStatus', 'Menunggu Pemindaian...', 'status-info');
            messageElement.textContent = 'Pindai QR Code di atas dengan ponsel Anda. QR akan refresh otomatis.';
            messageElement.className = 'alert alert-info';
            messageElement.style.display = 'block';

            let timer = data.valid_until || 30; // Default 30s
            qrCodeTimer.textContent = `QR ini akan refresh dalam ${timer} detik`;
            qrCodeInterval = setInterval(() => {
                timer--;
                qrCodeTimer.textContent = `QR ini akan refresh dalam ${timer} detik`;
                if (timer <= 0) {
                    clearInterval(qrCodeInterval);
                    getQrCodeFromSettings(); // Refresh QR code automatically
                }
            }, 1000);
            
            // Mulai polling status perangkat setelah QR didapatkan
            if (!statusPollingInterval) { // Mencegah interval ganda
                 statusPollingInterval = setInterval(() => {
                     checkDeviceStatus(); // Panggil checkDeviceStatus untuk polling status perangkat
                 }, 5000); // Polling setiap 5 detik
            }

        } else if (data.status === 'failed') { // Data status failed, periksa pesan lebih lanjut
            updateStatusDisplay('deviceConnectionStatus', 'Gagal Mendapatkan QR', 'status-danger');
            messageElement.textContent = data.message || 'Gagal mendapatkan QR Code: Error tidak diketahui.';
            messageElement.className = 'alert alert-danger';
            messageElement.style.display = 'block';
            document.getElementById('qrCodeContainer').style.display = 'none';
            // Jika API Key tidak valid saat mencoba QR, perbarui juga status API Key
            if (data.message.includes('API Key harus valid')) {
                updateStatusDisplay('apiKeyConnectionStatus', 'API Key Tidak Valid', 'status-danger');
            }

        } else { // Handle unexpected status
            updateStatusDisplay('deviceConnectionStatus', 'Status Tidak Diketahui', 'status-warning');
            messageElement.textContent = data.message || 'Gagal mendapatkan QR Code: Respons tak terduga.';
            messageElement.className = 'alert alert-warning';
            messageElement.style.display = 'block';
            document.getElementById('qrCodeContainer').style.display = 'none';
        }
    })
    .catch(error => {
        console.error('Error getting QR code:', error);
        updateStatusDisplay('deviceConnectionStatus', 'Error Koneksi', 'status-danger');
        messageElement.textContent = 'Terjadi kesalahan jaringan saat mendapatkan QR Code.';
        messageElement.className = 'alert alert-danger';
        messageElement.style.display = 'block';
        document.getElementById('qrCodeContainer').style.display = 'none';
    });
}

// Fungsi baru untuk mengatur status perangkat simulasi (untuk pengujian)
function setSimulatedDeviceStatus(newStatus) {
    const apiKey = document.getElementById('whatsapp_api_key').value;
    if (!apiKey) {
        alert('Harap masukkan API Key terlebih dahulu.');
        return;
    }
    fetch('whatsapp_gateway_api_simulator.php', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ action: 'set_device_status', api_key: apiKey, status: newStatus }),
    })
    .then(response => response.json())
    .then(data => {
        if (data.status === 'success') {
            alert('Status simulasi perangkat berhasil diatur ke: ' + newStatus);
            checkAllStatusesFromSettings(); // Refresh semua status setelah setting simulasi
        } else {
            alert('Gagal mengatur status simulasi: ' + (data.message || 'Error.'));
        }
    })
    .catch(error => {
        console.error('Error setting simulated status:', error);
        alert('Terjadi kesalahan jaringan saat mengatur status simulasi.');
    });
}


document.addEventListener('DOMContentLoaded', function() {
    // Inisialisasi status saat halaman dimuat
    checkAllStatusesFromSettings();
});
</script>

<style>
    /* Status Badges */
    .status-badge {
        display: inline-block;
        padding: 5px 10px;
        border-radius: 4px;
        font-weight: bold;
        color: white;
        background-color: #6c757d; /* Default secondary */
    }
    .status-success {
        background-color: #28a745; /* Green */
    }
    .status-danger {
        background-color: #dc3545; /* Red */
    }
    .status-warning {
        background-color: #ffc107; /* Yellow */
        color: #343a40; /* Dark text for readability */
    }
    .status-info {
        background-color: #17a2b8; /* Blue-green */
    }

    /* Alert messages inside card body */
    .alert {
        padding: 10px;
        margin-bottom: 15px;
        border: 1px solid transparent;
        border-radius: .25rem;
    }
    .alert-success {
        color: #155724;
        background-color: #d4edda;
        border-color: #c3e6cb;
    }
    .alert-danger {
        color: #721c24;
        background-color: #f8d7da;
        border-color: #f5c6cb;
    }
    .alert-info {
        color: #0c5460;
        background-color: #d1ecf1;
        border-color: #bee5eb;
    }
    .alert-warning {
        color: #856404;
        background-color: #fff3cd;
        border-color: #ffeeba;
    }
</style>

<?php include '../includes/footer.php'; ?>