<?php
include '../../config/koneksi.php';
include '../../includes/header.php';

$query = "SELECT * FROM paket ORDER BY nama_paket ASC";
$result = $koneksi->query($query);
?>

<div class="container">
    <h2>Manajemen Paket Internet</h2>
    <?php if (isset($_SESSION['message'])): ?>
        <div class="alert alert-<?php echo $_SESSION['message_type']; ?>">
            <?php echo $_SESSION['message']; unset($_SESSION['message']); unset($_SESSION['message_type']); ?>
        </div>
    <?php endif; ?>

    <div class="add-button-container">
        <a href="tambah.php" class="btn">Tambah Paket Baru</a>
    </div>

    <table>
        <thead>
            <tr>
                <th>ID</th>
                <th>Nama Paket</th>
                <th>Kecepatan</th>
                <th>Harga</th>
                <th>Aksi</th>
            </tr>
        </thead>
        <tbody>
            <?php if ($result->num_rows > 0): ?>
                <?php while ($row = $result->fetch_assoc()): ?>
                    <tr>
                        <td><?php echo htmlspecialchars($row['id']); ?></td>
                        <td><?php echo htmlspecialchars($row['nama_paket']); ?></td>
                        <td><?php echo htmlspecialchars($row['kecepatan']); ?></td>
                        <td>Rp <?php echo number_format($row['harga'], 0, ',', '.'); ?></td>
                        <td class="action-buttons">
                            <a href="edit.php?id=<?php echo $row['id']; ?>" class="btn btn-warning btn-edit">Edit</a>
                            <a href="hapus.php?id=<?php echo $row['id']; ?>" class="btn btn-danger btn-delete" onclick="return confirm('Yakin ingin menghapus paket ini?');">Hapus</a>
                        </td>
                    </tr>
                <?php endwhile; ?>
            <?php else: ?>
                <tr>
                    <td colspan="5" class="text-center">Belum ada data paket.</td>
                </tr>
            <?php endif; ?>
        </tbody>
    </table>
</div>

<?php include '../../includes/footer.php'; ?>