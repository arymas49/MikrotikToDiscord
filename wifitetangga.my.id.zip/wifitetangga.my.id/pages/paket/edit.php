<?php
include '../../config/koneksi.php';
include '../../includes/header.php';

$id = isset($_GET['id']) ? (int)$_GET['id'] : 0;

if ($id === 0) {
    $_SESSION['message'] = "ID Paket tidak valid.";
    $_SESSION['message_type'] = "danger";
    header('Location: index.php');
    exit;
}

// Ambil data paket yang akan diedit
$query_select = "SELECT * FROM paket WHERE id = ?";
$stmt_select = $koneksi->prepare($query_select);
$stmt_select->bind_param("i", $id);
$stmt_select->execute();
$result_select = $stmt_select->get_result();

if ($result_select->num_rows === 0) {
    $_SESSION['message'] = "Paket tidak ditemukan.";
    $_SESSION['message_type'] = "danger";
    header('Location: index.php');
    exit;
}
$paket = $result_select->fetch_assoc();

if (isset($_POST['submit'])) {
    $nama_paket = $koneksi->real_escape_string($_POST['nama_paket']);
    $kecepatan = $koneksi->real_escape_string($_POST['kecepatan']);
    $harga = $koneksi->real_escape_string($_POST['harga']);

    // Validasi sederhana
    if (empty($nama_paket) || empty($kecepatan) || empty($harga)) {
        $_SESSION['message'] = "Semua field harus diisi!";
        $_SESSION['message_type'] = "danger";
    } else {
        $query_update = "UPDATE paket SET nama_paket = ?, kecepatan = ?, harga = ? WHERE id = ?";
        $stmt_update = $koneksi->prepare($query_update);
        $stmt_update->bind_param("ssdi", $nama_paket, $kecepatan, $harga, $id);

        if ($stmt_update->execute()) {
            $_SESSION['message'] = "Paket berhasil diperbarui!";
            $_SESSION['message_type'] = "success";
            header('Location: index.php');
            exit;
        } else {
            $_SESSION['message'] = "Gagal memperbarui paket: " . $stmt_update->error;
            $_SESSION['message_type'] = "danger";
        }
    }
}
?>

<div class="container form-container">
    <h2>Edit Paket Internet</h2>
    <?php if (isset($_SESSION['message'])): ?>
        <div class="alert alert-<?php echo $_SESSION['message_type']; ?>">
            <?php echo $_SESSION['message']; unset($_SESSION['message']); unset($_SESSION['message_type']); ?>
        </div>
    <?php endif; ?>

    <form action="" method="POST"><?php if (!isset($_SESSION['csrf_token'])) { $_SESSION['csrf_token'] = bin2hex(random_bytes(32)); } ?><input type='hidden' name='csrf_token' value='<?php echo $_SESSION['csrf_token']; ?>'>
        <div class="form-group">
            <label for="nama_paket">Nama Paket:</label>
            <input type="text" id="nama_paket" name="nama_paket" value="<?php echo htmlspecialchars($paket['nama_paket']); ?>" required>
        </div>
        <div class="form-group">
            <label for="kecepatan">Kecepatan:</label>
            <input type="text" id="kecepatan" name="kecepatan" value="<?php echo htmlspecialchars($paket['kecepatan']); ?>" placeholder="Contoh: 10 Mbps" required>
        </div>
        <div class="form-group">
            <label for="harga">Harga (Rp):</label>
            <input type="number" id="harga" name="harga" step="0.01" min="0" value="<?php echo htmlspecialchars($paket['harga']); ?>" required>
        </div>
        <button type="submit" name="submit">Update Paket</button>
        <a href="index.php" class="btn btn-danger">Batal</a>
    </form>
</div>

<?php include '../../includes/footer.php'; ?>