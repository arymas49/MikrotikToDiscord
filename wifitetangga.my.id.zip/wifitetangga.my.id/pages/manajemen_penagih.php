<?php
// C:\xampp\htdocs\billing_isp_app\pages\manajemen_penagih.php
ob_start();
ini_set('session.use_strict_mode', 1);
ini_set('session.cookie_httponly', 1);
ini_set('session.cookie_samesite', 'Lax');
if (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on') {
    ini_set('session.cookie_secure', 1);
}
session_start();
include '../config/koneksi.php';
include '../includes/header.php'; // Header akan meng-include sidebar dan fungsi hasRole()

// Batasi akses ke halaman ini: hanya superadmin
if (!hasRole(['superadmin', 'admin'])) {
    header('Location: dashboard.php'); // Redirect ke dashboard atau halaman akses ditolak
    exit();
}

$message = '';
$penagih_id_to_edit = null;
$penagih_data = [];

// --- Menampilkan Pesan Setelah Redirect (GET) ---
if (isset($_GET['msg'])) {
    if ($_GET['msg'] == 'add_success') {
        $message = '<div class="alert alert-success">Data penagih berhasil ditambahkan.</div>';
    } elseif ($_GET['msg'] == 'edit_success') {
        $message = '<div class="alert alert-success">Data penagih berhasil diperbarui.</div>';
    } elseif ($_GET['msg'] == 'delete_success') {
        $message = '<div class="alert alert-success">Data penagih berhasil dihapus.</div>';
    } elseif ($_GET['msg'] == 'delete_fail') {
        $error_detail = $_GET['err'] ?? 'Terjadi kesalahan tidak diketahui.';
        $message = '<div class="alert alert-danger">Gagal menghapus penagih: ' . htmlspecialchars($error_detail) . '</div>';
    }
}

// --- Logika Hapus Penagih ---
if (isset($_GET['action']) && $_GET['action'] == 'delete' && isset($_GET['id'])) {
    $id_penagih_to_delete = $koneksi->real_escape_string($_GET['id']);

    $koneksi->begin_transaction(); // Mulai transaksi
    try {
        // SET penagih_id di tabel pelanggan menjadi NULL untuk pelanggan yang terkait
        $stmt_update_pelanggan = $koneksi->prepare("UPDATE pelanggan SET penagih_id = NULL WHERE penagih_id = ?");
        $stmt_update_pelanggan->bind_param("i", $id_penagih_to_delete);
        if (!$stmt_update_pelanggan->execute()) {
            throw new Exception("Gagal mengupdate pelanggan terkait: " . $stmt_update_pelanggan->error);
        }
        $stmt_update_pelanggan->close();

        // SET penagih_id di tabel tagihan menjadi NULL untuk tagihan yang terkait
        $stmt_update_tagihan = $koneksi->prepare("UPDATE tagihan SET penagih_id = NULL WHERE penagih_id = ?");
        $stmt_update_tagihan->bind_param("i", $id_penagih_to_delete);
        if (!$stmt_update_tagihan->execute()) {
            throw new Exception("Gagal mengupdate tagihan terkait: " . $stmt_update_tagihan->error);
        }
        $stmt_update_tagihan->close();

        // Sekarang, hapus penagih itu sendiri
        $stmt_del_penagih = $koneksi->prepare("DELETE FROM penagih WHERE id_penagih = ?");
        $stmt_del_penagih->bind_param("i", $id_penagih_to_delete);
        if ($stmt_del_penagih->execute()) {
            $koneksi->commit(); // Commit transaksi jika semua berhasil
            logActivity('Delete', 'Menghapus penagih ID ' . $id_penagih_to_delete . '.');
            header('Location: manajemen_penagih.php?msg=delete_success');
            exit();
        } else {
            throw new Exception("Gagal menghapus data penagih: " . $stmt_del_penagih->error);
        }
        $stmt_del_penagih->close();

    } catch (Exception $e) {
        $koneksi->rollback(); // Rollback jika ada error
        header('Location: manajemen_penagih.php?msg=delete_fail&err=' . urlencode($e->getMessage()));
        exit();
    }
}

// --- Logika Tambah/Edit Penagih ---
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $nama_penagih = $koneksi->real_escape_string($_POST['nama_penagih']);
    $telepon_penagih = $koneksi->real_escape_string($_POST['telepon_penagih'] ?? '');
    $email_penagih = $koneksi->real_escape_string($_POST['email_penagih'] ?? '');
    $status_aktif = $koneksi->real_escape_string($_POST['status_aktif'] ?? 'Aktif');
    $tanggal_bergabung = $koneksi->real_escape_string($_POST['tanggal_bergabung'] ?? date('Y-m-d'));
    $penagih_id = $koneksi->real_escape_string($_POST['penagih_id'] ?? '');

    if (empty($penagih_id)) { // Tambah Penagih Baru
        $stmt = $koneksi->prepare("INSERT INTO penagih (nama_penagih, telepon_penagih, email_penagih, status_aktif, tanggal_bergabung) VALUES (?, ?, ?, ?, ?)");
        $stmt->bind_param("sssss", $nama_penagih, $telepon_penagih, $email_penagih, $status_aktif, $tanggal_bergabung);

        if ($stmt->execute()) {
            logActivity('Create', 'Menambah penagih baru: ' . htmlspecialchars($nama_penagih) . '.');
            header('Location: manajemen_penagih.php?msg=add_success');
            exit();
        } else {
            $message = '<div class="alert alert-danger">Gagal menambahkan penagih: ' . $stmt->error . '</div>';
        }
    } else { // Edit Penagih
        $stmt = $koneksi->prepare("UPDATE penagih SET nama_penagih = ?, telepon_penagih = ?, email_penagih = ?, status_aktif = ?, tanggal_bergabung = ? WHERE id_penagih = ?");
        $stmt->bind_param("sssssi", $nama_penagih, $telepon_penagih, $email_penagih, $status_aktif, $tanggal_bergabung, $penagih_id);

        if ($stmt->execute()) {
            logActivity('Update', 'Mengubah data penagih ID ' . $penagih_id . ': ' . htmlspecialchars($nama_penagih) . '.');
            header('Location: manajemen_penagih.php?msg=edit_success');
            exit();
        } else {
            $message = '<div class="alert alert-danger">Gagal memperbarui penagih: ' . $stmt->error . '</div>';
        }
    }
    if (isset($stmt) && $stmt instanceof mysqli_stmt) {
        $stmt->close();
    }
}

// --- Logika Ambil Data Untuk Form Edit ---
if (isset($_GET['action']) && $_GET['action'] == 'edit' && isset($_GET['id'])) {
    $penagih_id_to_edit = $koneksi->real_escape_string($_GET['id']);
    $query_edit = $koneksi->query("SELECT * FROM penagih WHERE id_penagih = '$penagih_id_to_edit'");
    if ($query_edit->num_rows > 0) {
        $penagih_data = $query_edit->fetch_assoc();
    } else {
        $message = '<div class="alert alert-danger">Data penagih tidak ditemukan.</div>';
        $penagih_id_to_edit = null;
    }
    $form_should_be_visible = true;
} else {
    $form_should_be_visible = false;
}

// --- Logika Pencarian dan Filter Penagih ---
$search_query = $_GET['search'] ?? '';
$filter_status_aktif = $_GET['status_aktif_filter'] ?? '';

$where_clauses = [];
$params = [];
$param_types = "";

if (!empty($search_query)) {
    $search_term = '%' . $search_query . '%';
    $where_clauses[] = "(nama_penagih LIKE ? OR telepon_penagih LIKE ? OR email_penagih LIKE ?)";
    $params[] = $search_term;
    $params[] = $search_term;
    $params[] = $search_term;
    $param_types .= "sss";
}

if (!empty($filter_status_aktif)) {
    $where_clauses[] = "status_aktif = ?";
    $params[] = $filter_status_aktif;
    $param_types .= "s";
}

$final_where_clause = count($where_clauses) > 0 ? " WHERE " . implode(" AND ", $where_clauses) : "";

// Ambil semua data penagih untuk ditampilkan
$query_penagih_list = "SELECT * FROM penagih " . $final_where_clause . " ORDER BY nama_penagih ASC";

$stmt_penagih_list = $koneksi->prepare($query_penagih_list);
if ($stmt_penagih_list === false) {
    die('Prepare failed: ' . htmlspecialchars($koneksi->error));
}

if (count($params) > 0) {
    $stmt_penagih_list->bind_param($param_types, ...$params);
}
$stmt_penagih_list->execute();
$result_penagih_list = $stmt_penagih_list->get_result();
$stmt_penagih_list->close();

?>

<div class="main-content">
    <div class="top-header">
        <div class="alert-message">
            Kelola data penagih Anda di sini.
        </div>
        <div class="welcome-message">
            <span>Selamat datang, <?php echo htmlspecialchars($_SESSION['username'] ?? 'User'); ?>!</span>
            <a href="../logout.php" class="btn-logout">Logout</a>
        </div>
    </div>

    <div class="container">
        <h2>Manajemen Penagih</h2>

        <?php echo htmlspecialchars($message, ENT_QUOTES, "UTF-8"); ?>

        <button id="toggleFormBtn" class="btn btn-primary" style="margin-bottom: 20px;">
            <?php echo ($penagih_id_to_edit ? 'Kembali ke Form Edit' : 'Tambah Penagih Baru'); ?>
        </button>

        <div id="formPenagihCard" class="card <?php echo $form_should_be_visible ? '' : 'hide-form'; ?>" style="margin-bottom: 20px;">
            <div class="card-header">
                <h3><?php echo ($penagih_id_to_edit ? 'Edit' : 'Tambah'); ?> Penagih</h3>
            </div>
            <div class="card-body">
                <form method="POST"><?php if (!isset($_SESSION['csrf_token'])) { $_SESSION['csrf_token'] = bin2hex(random_bytes(32)); } ?><input type='hidden' name='csrf_token' value='<?php echo $_SESSION['csrf_token']; ?>'>
                    <?php if ($penagih_id_to_edit): ?>
                        <input type="hidden" name="penagih_id" value="<?php echo htmlspecialchars($penagih_data['id_penagih']); ?>">
                    <?php endif; ?>
                    <div class="form-group">
                        <label for="nama_penagih">Nama Penagih:</label>
                        <input type="text" id="nama_penagih" name="nama_penagih" value="<?php echo htmlspecialchars($penagih_data['nama_penagih'] ?? ''); ?>" required>
                    </div>
                    <div class="form-group">
                        <label for="telepon_penagih">Telepon Penagih:</label>
                        <input type="text" id="telepon_penagih" name="telepon_penagih" value="<?php echo htmlspecialchars($penagih_data['telepon_penagih'] ?? ''); ?>">
                    </div>
                    <div class="form-group">
                        <label for="email_penagih">Email Penagih:</label>
                        <input type="email" id="email_penagih" name="email_penagih" value="<?php echo htmlspecialchars($penagih_data['email_penagih'] ?? ''); ?>">
                    </div>
                    <div class="form-group">
                        <label for="status_aktif">Status Aktif:</label>
                        <select id="status_aktif" name="status_aktif" required>
                            <option value="Aktif" <?php echo (isset($penagih_data['status_aktif']) && $penagih_data['status_aktif'] == 'Aktif') ? 'selected' : ''; ?>>Aktif</option>
                            <option value="Tidak Aktif" <?php echo (isset($penagih_data['status_aktif']) && $penagih_data['status_aktif'] == 'Tidak Aktif') ? 'selected' : ''; ?>>Tidak Aktif</option>
                        </select>
                    </div>
                    <div class="form-group">
                        <label for="tanggal_bergabung">Tanggal Bergabung:</label>
                        <input type="date" id="tanggal_bergabung" name="tanggal_bergabung" value="<?php echo htmlspecialchars($penagih_data['tanggal_bergabung'] ?? date('Y-m-d')); ?>" required>
                    </div>
                    <button type="submit" class="btn btn-primary"><?php echo ($penagih_id_to_edit ? 'Update' : 'Tambah'); ?> Penagih</button>
                    <?php if ($penagih_id_to_edit): ?>
                        <a href="manajemen_penagih.php" class="btn btn-secondary">Batal Edit</a>
                    <?php endif; ?>
                </form>
            </div>
        </div>

        <div class="card">
            <div class="card-header">
                <h3>Daftar Penagih</h3>
                <div class="search-form-group">
                    <form method="GET" action="manajemen_penagih.php">
                        <input type="text" name="search" placeholder="Cari penagih..." value="<?php echo htmlspecialchars($search_query); ?>">
                        <select name="status_aktif_filter">
                            <option value="">Semua Status</option>
                            <option value="Aktif" <?php echo ($filter_status_aktif == 'Aktif') ? 'selected' : ''; ?>>Aktif</option>
                            <option value="Tidak Aktif" <?php echo ($filter_status_aktif == 'Tidak Aktif') ? 'selected' : ''; ?>>Tidak Aktif</option>
                        </select>
                        <button type="submit" class="btn btn-primary btn-sm"><i class="fas fa-filter"></i> Filter</button>
                        <?php if (!empty($search_query) || !empty($filter_status_aktif)): ?>
                            <a href="manajemen_penagih.php" class="btn btn-secondary btn-sm"><i class="fas fa-redo"></i> Reset</a>
                        <?php endif; ?>
                    </form>
                </div>
            </div>
            <div class="card-body">
                <table class="data-table">
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>Nama Penagih</th>
                            <th>Telepon</th>
                            <th>Email</th>
                            <th>Status Aktif</th>
                            <th>Tanggal Bergabung</th>
                            <th>Aksi</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if ($result_penagih_list->num_rows > 0): ?>
                            <?php while($row = $result_penagih_list->fetch_assoc()): ?>
                                <tr>
                                    <td><?php echo htmlspecialchars($row['id_penagih']); ?></td>
                                    <td><?php echo htmlspecialchars($row['nama_penagih']); ?></td>
                                    <td><?php echo htmlspecialchars($row['telepon_penagih'] ?? 'N/A'); ?></td>
                                    <td><?php echo htmlspecialchars($row['email_penagih'] ?? 'N/A'); ?></td>
                                    <td><span class="status-badge status-<?php echo strtolower(str_replace(' ', '-', $row['status_aktif'])); ?>"><?php echo htmlspecialchars($row['status_aktif']); ?></span></td>
                                    <td><?php echo htmlspecialchars(date('d-m-Y', strtotime($row['tanggal_bergabung']))); ?></td>
                                    <td>
                                        <a href="manajemen_penagih.php?action=edit&id=<?php echo $row['id_penagih']; ?>" class="btn-action btn-edit"><i class="fas fa-edit"></i> Edit</a>
                                        <a href="manajemen_penagih.php?action=delete&id=<?php echo $row['id_penagih']; ?>" class="btn-action btn-delete" onclick="return confirm('Apakah Anda yakin ingin menghapus penagih ini? Ini akan memutuskan kaitan pelanggan yang terkait dengan penagih ini.');"><i class="fas fa-trash-alt"></i> Hapus</a>
                                    </td>
                                </tr>
                            <?php endwhile; ?>
                        <?php else: ?>
                            <tr><td colspan="7" style="text-align: center;">Tidak ada data penagih yang ditemukan.</td></tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>

    </div>
</div>

<script>
document.addEventListener('DOMContentLoaded', function() {
    var formCard = document.getElementById('formPenagihCard');
    var toggleBtn = document.getElementById('toggleFormBtn');

    if (!formCard || !toggleBtn) {
        console.error("Error: formPenagihCard or toggleFormBtn not found. Script cannot proceed.");
        return;
    }

    var urlParams = new URLSearchParams(window.location.search);
    var isEditMode = urlParams.get('action') === 'edit';

    if (formCard.classList.contains('hide-form')) {
        toggleBtn.textContent = 'Tambah Penagih Baru';
    } else {
        toggleBtn.textContent = 'Sembunyikan Form';
    }

    if (!toggleBtn._hasClickListener) {
        toggleBtn.addEventListener('click', function() {
            if (formCard.classList.contains('hide-form')) {
                formCard.classList.remove('hide-form'); // Tampilkan form
                toggleBtn.textContent = 'Sembunyikan Form';
                formCard.scrollIntoView({ behavior: 'smooth', block: 'start' });
            } else {
                formCard.classList.add('hide-form'); // Sembunyikan form
                toggleBtn.textContent = 'Tambah Penagih Baru';
                if (!isEditMode) {
                    var form = formCard.querySelector('form');
                    if (form) {
                        form.reset();
                        var dateInputs = form.querySelectorAll('input[type="date"]');
                        dateInputs.forEach(input => {
                            input.value = new Date().toISOString().slice(0,10);
                        });
                        var selects = form.querySelectorAll('select');
                        selects.forEach(s => s.value = s.options[0].value);
                    }
                }
                if (isEditMode) {
                    window.location.href = 'manajemen_penagih.php';
                }
            }
        });
        toggleBtn._hasClickListener = true;
    }

    <?php if (isset($_GET['msg'])): ?>
        window.scrollTo({ top: 0, behavior: 'smooth' });
    <?php endif; ?>
});
</script>

<?php include '../includes/footer.php'; ?>