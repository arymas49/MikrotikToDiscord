<?php
// C:\xampp\htdocs\billing_isp_app\pages\edit_hotspot_user.php

ini_set('session.use_strict_mode', 1);
ini_set('session.cookie_httponly', 1);
ini_set('session.cookie_samesite', 'Lax');
if (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on') {
    ini_set('session.cookie_secure', 1);
}
session_start();
include '../config/koneksi.php';
include '../includes/header.php';

// Pastikan user memiliki role yang sesuai (misal: superadmin atau teknisi)
if (!hasRole(['superadmin', 'teknisi'])) {
    echo "<script>
            alert('Anda tidak memiliki akses ke halaman ini.');
            window.location.href = '../pages/dashboard.php';
          </script>";
    exit();
}

$user_id = $_GET['id'] ?? null;
if (!$user_id) {
    echo "<script>
            alert('ID Pengguna tidak ditemukan.');
            window.location.href = '../pages/cetak_voucher.php'; // Redirect ke daftar pengguna
          </script>";
    exit();
}
?>

<div class="main-content">
    <div class="page-header">
        <h1>Edit Pengguna Hotspot</h1>
        <p>Ubah detail pengguna hotspot.</p>
    </div>

    <div class="container">
        <div class="card mb-4">
            <div class="card-header">
                <h3><i class="fas fa-edit"></i> Edit Pengguna: <span id="userNameDisplay">Memuat...</span></h3>
            </div>
            <div class="card-body">
                <form id="editHotspotUserForm">
                    <input type="hidden" id="userId" name="id" value="<?php echo htmlspecialchars($user_id); ?>">

                    <div class="form-group">
                        <label for="server">Server:</label>
                        <select id="server" name="server" class="form-control" required>
                            <option value="all">all</option>
                            </select>
                    </div>
                    <div class="form-group">
                        <label for="name">Username:</label>
                        <input type="text" id="name" name="name" class="form-control" required>
                    </div>
                    <div class="form-group">
                        <label for="password">Password:</label>
                        <div class="input-group">
                            <input type="password" id="password" name="password" class="form-control" required>
                            <button type="button" class="btn btn-secondary" id="togglePassword"><i class="fas fa-eye"></i></button>
                        </div>
                    </div>
                    <div class="form-group">
                        <label for="profile">Profile:</label>
                        <select id="profile" name="profile" class="form-control" required>
                            </select>
                    </div>
                    <div class="form-group">
                        <label for="mac_address">MAC Address:</label>
                        <input type="text" id="mac_address" name="mac-address" class="form-control" placeholder="XX:XX:XX:XX:XX:XX">
                    </div>
                    <div class="form-group">
                        <label for="limit_uptime">Uptime Limit (misal: 1h, 1d):</label>
                        <input type="text" id="limit_uptime" name="limit-uptime" class="form-control" placeholder="Biarkan kosong untuk tidak terbatas">
                    </div>
                    <div class="form-group">
                        <label for="limit_bytes_total">Bytes Total Limit (misal: 100MB, 1GB):</label>
                        <input type="text" id="limit_bytes_total" name="limit-bytes-total" class="form-control" placeholder="Biarkan kosong untuk tidak terbatas">
                    </div>
                    <div class="form-group">
                        <label for="comment">Comment:</label>
                        <textarea id="comment" name="comment" class="form-control" rows="3"></textarea>
                    </div>
                    <div class="form-group">
                        <label for="disabled_status">Status:</label>
                        <select id="disabled_status" name="disabled" class="form-control">
                            <option value="no">Aktif</option>
                            <option value="yes">Dinonaktifkan</option>
                        </select>
                    </div>

                    <div class="btn-group-flex mt-4">
                        <button type="submit" class="btn btn-primary"><i class="fas fa-save"></i> Simpan Perubahan</button>
                        <button type="button" class="btn btn-danger" id="deleteUserBtn"><i class="fas fa-trash"></i> Hapus Pengguna</button>
                        <button type="button" class="btn btn-info" id="resetCountersBtn"><i class="fas fa-redo"></i> Reset Counters</button>
                        <a href="../pages/cetak_voucher.php" class="btn btn-secondary"><i class="fas fa-arrow-left"></i> Kembali ke Daftar</a>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>

<script>
document.addEventListener('DOMContentLoaded', function() {
    const userId = document.getElementById('userId').value;
    const userNameDisplay = document.getElementById('userNameDisplay');
    const editHotspotUserForm = document.getElementById('editHotspotUserForm');
    const togglePasswordBtn = document.getElementById('togglePassword');
    const passwordInput = document.getElementById('password');
    const deleteUserBtn = document.getElementById('deleteUserBtn');
    const resetCountersBtn = document.getElementById('resetCountersBtn');

    const serverSelect = document.getElementById('server');
    const profileSelect = document.getElementById('profile');

    // Load user detail
    function loadUserDetail() {
        showLoadingOverlay();
        fetch(`mikrotik_api.php?action=get_hotspot_user_detail&id=${userId}`)
            .then(response => response.json())
            .then(data => {
                hideLoadingOverlay();
                if (data.status === 'success' && data.user) {
                    const user = data.user;
                    userNameDisplay.textContent = user.name || 'N/A';
                    document.getElementById('name').value = user.name || '';
                    document.getElementById('password').value = user.password || ''; // Password bisa kosong jika tidak diatur
                    document.getElementById('mac_address').value = user['mac-address'] || '';
                    document.getElementById('limit_uptime').value = user['limit-uptime'] || '';
                    document.getElementById('limit_bytes_total').value = user['limit-bytes-total'] || '';
                    document.getElementById('comment').value = user.comment || '';
                    document.getElementById('disabled_status').value = user.disabled === 'true' ? 'yes' : 'no';

                    // Set server dan profile setelah options dimuat
                    loadServersAndProfiles(user.server, user.profile);

                } else {
                    showNotification('Pengguna tidak ditemukan: ' + data.message, 'error');
                    // Redirect back or show error
                    setTimeout(() => {
                        window.location.href = '../pages/cetak_voucher.php';
                    }, 2000);
                }
            })
            .catch(error => {
                hideLoadingOverlay();
                console.error('Error loading user detail:', error);
                showNotification('Terjadi kesalahan saat memuat detail pengguna.', 'error');
                setTimeout(() => {
                    window.location.href = '../pages/cetak_voucher.php';
                }, 2000);
            });
    }

    // Load servers and profiles, then set selected values
    function loadServersAndProfiles(selectedServer = 'all', selectedProfile = '') {
        // Load Servers
        fetch('mikrotik_api.php?action=get_hotspot_servers')
            .then(response => response.json())
            .then(data => {
                if (data.status === 'success') {
                    serverSelect.innerHTML = '<option value="all">all</option>';
                    data.servers.forEach(server => {
                        const option = document.createElement('option');
                        option.value = server.name;
                        option.textContent = server.name;
                        serverSelect.appendChild(option);
                    });
                    if (selectedServer) {
                        serverSelect.value = selectedServer;
                    }
                } else {
                    showNotification('Gagal memuat daftar server: ' + data.message, 'error');
                }
            })
            .catch(error => console.error('Error loading servers:', error));

        // Load Profiles
        fetch('mikrotik_api.php?action=get_hotspot_profiles')
            .then(response => response.json())
            .then(data => {
                if (data.status === 'success') {
                    profileSelect.innerHTML = ''; // Clear default option
                    data.profiles.forEach(profile => {
                        const option = document.createElement('option');
                        option.value = profile;
                        option.textContent = profile;
                        profileSelect.appendChild(option);
                    });
                    if (selectedProfile) {
                        profileSelect.value = selectedProfile;
                    }
                } else {
                    showNotification('Gagal memuat profil hotspot: ' + data.message, 'error');
                }
            })
            .catch(error => console.error('Error loading profiles:', error));
    }


    // Toggle password visibility
    togglePasswordBtn.addEventListener('click', function() {
        if (passwordInput.type === 'password') {
            passwordInput.type = 'text';
            togglePasswordBtn.innerHTML = '<i class="fas fa-eye-slash"></i>';
        } else {
            passwordInput.type = 'password';
            togglePasswordBtn.innerHTML = '<i class="fas fa-eye"></i>';
        }
    });

    // Handle form submission
    editHotspotUserForm.addEventListener('submit', function(e) {
        e.preventDefault();
        showLoadingOverlay();

        const formData = new FormData(this);
        const jsonData = {};
        formData.forEach((value, key) => {
            // Trim values unless it's a password (to allow leading/trailing spaces if intended)
            jsonData[key] = key === 'password' ? value : value.trim();
        });

        // Convert empty string for limit-uptime/limit-bytes-total to null or "0" if Mikrotik expects it
        if (jsonData['limit-uptime'] === '') jsonData['limit-uptime'] = '0s'; // Or null, check Mikrotik API behavior
        if (jsonData['limit-bytes-total'] === '') jsonData['limit-bytes-total'] = '0'; // Or null

        fetch('mikrotik_api.php?action=update_hotspot_user', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify(jsonData)
        })
        .then(response => response.json())
        .then(data => {
            hideLoadingOverlay();
            if (data.status === 'success') {
                showNotification(data.message, 'success');
                // Optionally redirect or refresh page
                // window.location.reload();
                // Or simply stay on page, data is saved
            } else {
                showNotification('Gagal menyimpan perubahan: ' + data.message, 'error');
            }
        })
        .catch(error => {
            hideLoadingOverlay();
            console.error('Error updating user:', error);
            showNotification('Terjadi kesalahan jaringan atau server saat menyimpan perubahan: ' + error.message, 'error');
        });
    });

    // Delete User
    deleteUserBtn.addEventListener('click', function() {
        showCustomConfirm('Konfirmasi Hapus', `Apakah Anda yakin ingin menghapus pengguna hotspot "${userNameDisplay.textContent}" ini?`, (result) => {
            if (result) {
                showLoadingOverlay();
                fetch('mikrotik_api.php?action=remove_hotspot_user', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({ id: userId })
                })
                .then(response => response.json())
                .then(data => {
                    hideLoadingOverlay();
                    if (data.status === 'success') {
                        showNotification(data.message, 'success');
                        setTimeout(() => {
                            window.location.href = '../pages/cetak_voucher.php'; // Redirect after deletion
                        }, 1000);
                    } else {
                        showNotification('Gagal menghapus user: ' + data.message, 'error');
                    }
                })
                .catch(error => {
                    hideLoadingOverlay();
                    console.error('Error deleting user:', error);
                    showNotification('Terjadi kesalahan jaringan atau server saat menghapus user: ' + error.message, 'error');
                });
            }
        });
    });

    // Reset Counters
    resetCountersBtn.addEventListener('click', function() {
        showCustomConfirm('Konfirmasi Reset', `Apakah Anda yakin ingin mereset uptime dan data pengguna "${userNameDisplay.textContent}" ini?`, (result) => {
            if (result) {
                showLoadingOverlay();
                fetch('mikrotik_api.php?action=reset_hotspot_user_uptime_data', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({ id: userId })
                })
                .then(response => response.json())
                .then(data => {
                    hideLoadingOverlay();
                    if (data.status === 'success') {
                        showNotification(data.message, 'success');
                        loadUserDetail(); // Reload detail to show updated counters
                    } else {
                        showNotification('Gagal mereset counters: ' + data.message, 'error');
                    }
                })
                .catch(error => {
                    hideLoadingOverlay();
                    console.error('Error resetting counters:', error);
                    showNotification('Terjadi kesalahan jaringan atau server saat mereset counters: ' + error.message, 'error');
                });
            }
        });
    });


    // Initial load
    loadUserDetail();
});
</script>

<?php include '../includes/footer.php'; ?>