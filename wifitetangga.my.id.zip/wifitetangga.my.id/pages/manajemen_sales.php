<?php
// C:\xampp\htdocs\billing_isp_app\pages\manajemen_sales.php
ob_start();
ini_set('session.use_strict_mode', 1);
ini_set('session.cookie_httponly', 1);
ini_set('session.cookie_samesite', 'Lax');
if (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on') {
    ini_set('session.cookie_secure', 1);
}
session_start();
include '../config/koneksi.php';
include '../includes/header.php'; // Header akan meng-include sidebar dan fungsi hasRole()

// Batasi akses ke halaman ini: hanya superadmin
if (!hasRole(['superadmin', 'admin'])) {
    header('Location: dashboard.php'); // Redirect ke dashboard atau halaman akses ditolak
    exit();
}

$message = '';
$sales_id_to_edit = null;
$sales_data = [];

// --- Menampilkan Pesan Setelah Redirect (GET) ---
if (isset($_GET['msg'])) {
    if ($_GET['msg'] == 'add_success') {
        $message = '<div class="alert alert-success">Sales berhasil ditambahkan.</div>';
    } elseif ($_GET['msg'] == 'edit_success') {
        $message = '<div class="alert alert-success">Sales berhasil diperbarui.</div>';
    } elseif ($_GET['msg'] == 'delete_success') {
        $message = '<div class="alert alert-success">Sales berhasil dihapus. Pelanggan terkait diatur ke NULL.</div>';
    } elseif ($_GET['msg'] == 'delete_fail') {
        $error_detail = $_GET['err'] ?? 'Terjadi kesalahan tidak diketahui.';
        $message = '<div class="alert alert-danger">Gagal menghapus sales: ' . htmlspecialchars($error_detail) . '</div>';
    }
}

// --- Logika Hapus Sales ---
if (isset($_GET['action']) && $_GET['action'] == 'delete' && isset($_GET['id'])) {
    $id_sales_to_delete = $koneksi->real_escape_string($_GET['id']);

    $koneksi->begin_transaction(); // Mulai transaksi
    try {
        $stmt_update_pelanggan = $koneksi->prepare("UPDATE pelanggan SET sales_id = NULL WHERE sales_id = ?");
        $stmt_update_pelanggan->bind_param("i", $id_sales_to_delete);
        if (!$stmt_update_pelanggan->execute()) {
            throw new Exception("Gagal memperbarui pelanggan terkait: " . $stmt_update_pelanggan->error);
        }
        $stmt_update_pelanggan->close();

        $stmt_del_sales = $koneksi->prepare("DELETE FROM sales WHERE id_sales = ?");
        $stmt_del_sales->bind_param("i", $id_sales_to_delete);
        if ($stmt_del_sales->execute()) {
            $koneksi->commit(); // Komit transaksi jika semua berhasil
            logActivity('Delete', 'Menghapus sales ID ' . $id_sales_to_delete . '.');
            header('Location: manajemen_sales.php?msg=delete_success');
            exit();
        } else {
            throw new Exception("Gagal menghapus data sales: " . $stmt_del_sales->error);
        }
        $stmt_del_sales->close();

    } catch (Exception $e) {
        $koneksi->rollback(); // Rollback jika ada error
        header('Location: manajemen_sales.php?msg=delete_fail&err=' . urlencode($e->getMessage()));
        exit();
    }
}

// --- Logika Tambah/Edit Sales ---
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $nama_sales = $koneksi->real_escape_string($_POST['nama_sales']);
    $email = $koneksi->real_escape_string($_POST['email']);
    $telepon = $koneksi->real_escape_string($_POST['telepon']);
    $tanggal_bergabung = $koneksi->real_escape_string($_POST['tanggal_bergabung']);
    $status_aktif = $koneksi->real_escape_string($_POST['status_aktif']);
    $sales_id = $koneksi->real_escape_string($_POST['sales_id'] ?? '');

    if (empty($sales_id)) { // Tambah Sales Baru
        $stmt = $koneksi->prepare("INSERT INTO sales (nama_sales, email, telepon, tanggal_bergabung, status_aktif) VALUES (?, ?, ?, ?, ?)");
        $stmt->bind_param("sssss", $nama_sales, $email, $telepon, $tanggal_bergabung, $status_aktif);
        if ($stmt->execute()) {
            logActivity('Create', 'Menambah sales baru: ' . htmlspecialchars($nama_sales) . '.');
            header('Location: manajemen_sales.php?msg=add_success');
            exit();
        } else {
            $message = '<div class="alert alert-danger">Gagal menambahkan sales: ' . $stmt->error . '</div>';
        }
    } else { // Edit Sales
        $stmt = $koneksi->prepare("UPDATE sales SET nama_sales = ?, email = ?, telepon = ?, tanggal_bergabung = ?, status_aktif = ? WHERE id_sales = ?");
        $stmt->bind_param("sssssi", $nama_sales, $email, $telepon, $tanggal_bergabung, $status_aktif, $sales_id);
        if ($stmt->execute()) {
            logActivity('Update', 'Mengubah data sales ID ' . $sales_id . ': ' . htmlspecialchars($nama_sales) . '.');
            header('Location: manajemen_sales.php?msg=edit_success');
            exit();
        } else {
            $message = '<div class="alert alert-danger">Gagal memperbarui sales: ' . $stmt->error . '</div>';
        }
    }
    if (isset($stmt) && $stmt instanceof mysqli_stmt) {
        $stmt->close();
    }
}

// --- Logika Ambil Data Untuk Form Edit ---
if (isset($_GET['action']) && $_GET['action'] == 'edit' && isset($_GET['id'])) {
    $sales_id_to_edit = $koneksi->real_escape_string($_GET['id']);
    $query_edit = $koneksi->query("SELECT * FROM sales WHERE id_sales = '$sales_id_to_edit'");
    if ($query_edit->num_rows > 0) {
        $sales_data = $query_edit->fetch_assoc();
    } else {
        $message = '<div class="alert alert-danger">Data sales tidak ditemukan.</div>';
        $sales_id_to_edit = null;
    }
    $form_should_be_visible = true; // Form akan terlihat jika dalam mode edit
} else {
    $form_should_be_visible = false; // Form tersembunyi secara default jika bukan mode edit
}

// --- Logika Pencarian, Filter, dan Pengurutan Sales ---
$search_query = $_GET['search'] ?? '';
$filter_status_aktif_dropdown = $_GET['status_aktif_dropdown'] ?? '';

// Sorting parameters
$sort_column = $_GET['sort_column'] ?? 'nama_sales'; // Default sort column
$sort_order = $_GET['sort_order'] ?? 'ASC'; // Default sort order

// Validate sort column
$allowed_sort_columns = [
    'id_sales',
    'nama_sales',
    'email',
    'telepon',
    'tanggal_bergabung',
    'status_aktif'
];
if (!in_array($sort_column, $allowed_sort_columns)) {
    $sort_column = 'nama_sales';
}

// Validate sort order
if (!in_array(strtoupper($sort_order), ['ASC', 'DESC'])) {
    $sort_order = 'ASC';
}

$where_clauses_sales = [];
$params_sales = [];
$param_types_sales = "";

if (!empty($search_query)) {
    $search_term = '%' . $search_query . '%';
    $where_clauses_sales[] = "(nama_sales LIKE ? OR email LIKE ? OR telepon LIKE ?)";
    $params_sales[] = $search_term;
    $params_sales[] = $search_term;
    $params_sales[] = $search_term;
    $param_types_sales .= "sss";
}

if (!empty($filter_status_aktif_dropdown)) {
    $where_clauses_sales[] = "status_aktif = ?";
    $params_sales[] = $filter_status_aktif_dropdown;
    $param_types_sales .= "s";
}

$final_where_clause_sales = count($where_clauses_sales) > 0 ? " WHERE " . implode(" AND ", $where_clauses_sales) : "";

// Ambil semua data sales untuk ditampilkan
$query_sales_list = "SELECT * FROM sales" . $final_where_clause_sales . " ORDER BY " . $sort_column . " " . $sort_order;

$stmt_sales_list = $koneksi->prepare($query_sales_list);
if ($stmt_sales_list === false) {
    die('Prepare failed: ' . htmlspecialchars($koneksi->error));
}

if (count($params_sales) > 0) {
    $bind_args = array($param_types_sales);
    foreach ($params_sales as $key => $value) {
        $bind_args[] = &$params_sales[$key];
    }
    call_user_func_array(array($stmt_sales_list, 'bind_param'), $bind_args);
}
$stmt_sales_list->execute();
$result_sales_list = $stmt_sales_list->get_result();
$stmt_sales_list->close();

?>

<div class="main-content">
    <div class="top-header">
        <div class="alert-message">
            Pemberitahuan: Kelola data sales untuk melacak performa penjualan.
        </div>
        <div class="welcome-message">
            <span>Selamat datang, <?php echo htmlspecialchars($_SESSION['username'] ?? 'User'); ?>!</span>
            <a href="../logout.php" class="btn-logout">Logout</a>
        </div>
    </div>

    <div class="container">
        <h2>Manajemen Data Sales</h2>

        <?php echo htmlspecialchars($message, ENT_QUOTES, "UTF-8"); ?>

        <button id="toggleFormBtn" class="btn btn-primary" style="margin-bottom: 20px;">
            <?php echo ($sales_id_to_edit ? 'Kembali ke Form Edit' : 'Tambah Sales Baru'); ?>
        </button>

        <div id="formSalesCard" class="card <?php echo $form_should_be_visible ? '' : 'hide-form'; ?>" 
             style="margin-bottom: 20px; <?php echo $form_should_be_visible ? '' : 'display: none;'; ?>">
            <div class="card-header">
                <h3><?php echo ($sales_id_to_edit ? 'Edit' : 'Tambah'); ?> Sales</h3>
            </div>
            <div class="card-body">
                <form method="POST"><?php if (!isset($_SESSION['csrf_token'])) { $_SESSION['csrf_token'] = bin2hex(random_bytes(32)); } ?><input type='hidden' name='csrf_token' value='<?php echo $_SESSION['csrf_token']; ?>'>
                    <?php if ($sales_id_to_edit): ?>
                        <input type="hidden" name="sales_id" value="<?php echo htmlspecialchars($sales_data['id_sales']); ?>">
                    <?php endif; ?>
                    <div class="form-group">
                        <label for="nama_sales">Nama Sales:</label>
                        <input type="text" id="nama_sales" name="nama_sales" value="<?php echo htmlspecialchars($sales_data['nama_sales'] ?? ''); ?>" required>
                    </div>
                    <div class="form-group">
                        <label for="email">Email:</label>
                        <input type="email" id="email" name="email" value="<?php echo htmlspecialchars($sales_data['email'] ?? ''); ?>">
                    </div>
                    <div class="form-group">
                        <label for="telepon">Telepon:</label>
                        <input type="text" id="telepon" name="telepon" value="<?php echo htmlspecialchars($sales_data['telepon'] ?? ''); ?>">
                    </div>
                    <div class="form-group">
                        <label for="tanggal_bergabung">Tanggal Bergabung:</label>
                        <input type="date" id="tanggal_bergabung" name="tanggal_bergabung" value="<?php echo htmlspecialchars($sales_data['tanggal_bergabung'] ?? date('Y-m-d')); ?>" required>
                    </div>
                    <div class="form-group">
                        <label for="status_aktif">Status Aktif:</label>
                        <select id="status_aktif" name="status_aktif" required>
                            <option value="Aktif" <?php echo (isset($sales_data['status_aktif']) && $sales_data['status_aktif'] == 'Aktif') ? 'selected' : ''; ?>>Aktif</option>
                            <option value="Tidak Aktif" <?php echo (isset($sales_data['status_aktif']) && $sales_data['status_aktif'] == 'Tidak Aktif') ? 'selected' : ''; ?>>Tidak Aktif</option>
                        </select>
                    </div>
                    <button type="submit" class="btn btn-primary"><?php echo ($sales_id_to_edit ? 'Update' : 'Tambah'); ?> Sales</button>
                    <?php if ($sales_id_to_edit): ?>
                        <a href="manajemen_sales.php" class="btn btn-secondary">Batal Edit</a>
                    <?php endif; ?>
                </form>
            </div>
        </div>

        <div class="card">
            <div class="card-header">
                <h3>Daftar Sales</h3>
                <div class="search-form-group">
                    <form method="GET" action="manajemen_sales.php">
                        <input type="text" name="search" placeholder="Cari sales..." value="<?php echo htmlspecialchars($search_query); ?>">
                        <select name="status_aktif_dropdown">
                            <option value="">Semua Status</option>
                            <option value="Aktif" <?php echo ($filter_status_aktif_dropdown == 'Aktif') ? 'selected' : ''; ?>>Aktif</option>
                            <option value="Tidak Aktif" <?php echo ($filter_status_aktif_dropdown == 'Tidak Aktif') ? 'selected' : ''; ?>>Tidak Aktif</option>
                        </select>
                        <button type="submit" class="btn btn-primary btn-sm"><i class="fas fa-filter"></i> Filter</button>
                        <?php if (!empty($search_query) || !empty($filter_status_aktif_dropdown)): ?>
                            <a href="manajemen_sales.php" class="btn btn-secondary btn-sm"><i class="fas fa-redo"></i> Reset</a>
                        <?php endif; ?>
                    </form>
                </div>
            </div>
            <div class="card-body">
                <table class="data-table">
                    <thead>
                        <tr>
                            <th><a href="?<?php echo http_build_query(array_merge($_GET, ['sort_column' => 'id_sales', 'sort_order' => ($sort_column == 'id_sales' && $sort_order == 'ASC') ? 'DESC' : 'ASC'])); ?>">ID <?php if ($sort_column == 'id_sales') echo ($sort_order == 'ASC' ? '&#9650;' : '&#9660;'); ?></a></th>
                            <th><a href="?<?php echo http_build_query(array_merge($_GET, ['sort_column' => 'nama_sales', 'sort_order' => ($sort_column == 'nama_sales' && $sort_order == 'ASC') ? 'DESC' : 'ASC'])); ?>">Nama Sales <?php if ($sort_column == 'nama_sales') echo ($sort_order == 'ASC' ? '&#9650;' : '&#9660;'); ?></a></th>
                            <th><a href="?<?php echo http_build_query(array_merge($_GET, ['sort_column' => 'email', 'sort_order' => ($sort_column == 'email' && $sort_order == 'ASC') ? 'DESC' : 'ASC'])); ?>">Email <?php if ($sort_column == 'email') echo ($sort_order == 'ASC' ? '&#9650;' : '&#9660;'); ?></a></th>
                            <th><a href="?<?php echo http_build_query(array_merge($_GET, ['sort_column' => 'telepon', 'sort_order' => ($sort_column == 'telepon' && $sort_order == 'ASC') ? 'DESC' : 'ASC'])); ?>">Telepon <?php if ($sort_column == 'telepon') echo ($sort_order == 'ASC' ? '&#9650;' : '&#9660;'); ?></a></th>
                            <th><a href="?<?php echo http_build_query(array_merge($_GET, ['sort_column' => 'tanggal_bergabung', 'sort_order' => ($sort_column == 'tanggal_bergabung' && $sort_order == 'ASC') ? 'DESC' : 'ASC'])); ?>">Tgl Bergabung <?php if ($sort_column == 'tanggal_bergabung') echo ($sort_order == 'ASC' ? '&#9650;' : '&#9660;'); ?></a></th>
                            <th><a href="?<?php echo http_build_query(array_merge($_GET, ['sort_column' => 'status_aktif', 'sort_order' => ($sort_column == 'status_aktif' && $sort_order == 'ASC') ? 'DESC' : 'ASC'])); ?>">Status Aktif <?php if ($sort_column == 'status_aktif') echo ($sort_order == 'ASC' ? '&#9650;' : '&#9660;'); ?></a></th>
                            <th>Aksi</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if ($result_sales_list->num_rows > 0): ?>
                            <?php while($row = $result_sales_list->fetch_assoc()): ?>
                                <tr>
                                    <td><?php echo htmlspecialchars($row['id_sales']); ?></td>
                                    <td><?php echo htmlspecialchars($row['nama_sales']); ?></td>
                                    <td><?php echo htmlspecialchars($row['email']); ?></td>
                                    <td><?php echo htmlspecialchars($row['telepon']); ?></td>
                                    <td><?php echo htmlspecialchars(date('d-m-Y', strtotime($row['tanggal_bergabung']))); ?></td>
                                    <td><span class="status-badge status-<?php echo strtolower(str_replace(' ', '-', $row['status_aktif'])); ?>"><?php echo htmlspecialchars($row['status_aktif']); ?></span></td>
                                    <td>
                                        <a href="manajemen_sales.php?action=edit&id=<?php echo $row['id_sales']; ?>" class="btn-action btn-edit"><i class="fas fa-edit"></i> Edit</a>
                                        <a href="manajemen_sales.php?action=delete&id=<?php echo $row['id_sales']; ?>" class="btn-action btn-delete" onclick="return confirm('Apakah Anda yakin ingin menghapus sales ini? Tindakan ini akan melepaskan sales dari semua pelanggan terkait.');"><i class="fas fa-trash-alt"></i> Hapus</a>
                                    </td>
                                </tr>
                            <?php endwhile; ?>
                        <?php else: ?>
                            <tr><td colspan="7" style="text-align: center;">Tidak ada data sales yang ditemukan.</td></tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>

    </div>
</div>

<script>
document.addEventListener('DOMContentLoaded', function() {
    var formCard = document.getElementById('formSalesCard');
    var toggleBtn = document.getElementById('toggleFormBtn');

    // Debugging: Cek apakah elemen ditemukan saat DOMContentLoaded
    // console.log("DEBUG: formSalesCard element on load:", formCard);
    // console.log("DEBUG: toggleFormBtn element on load:", toggleBtn);

    if (!formCard || !toggleBtn) {
        // console.error("ERROR: formSalesCard or toggleFormBtn not found. Script cannot proceed.");
        return; // Hentikan eksekusi skrip jika elemen tidak ditemukan
    }

    var urlParams = new URLSearchParams(window.location.search);
    var isEditMode = urlParams.get('action') === 'edit';
    // console.log("DEBUG: Is in Edit Mode on load:", isEditMode);

    // ************* INISIALISASI VISIBILITAS FORM DAN TEKS TOMBOL *************
    // Ini adalah bagian penting untuk memastikan state awal UI benar.
    // Jika ada parameter 'edit' di URL, form harus terlihat.
    // Jika tidak ada 'edit' dan form secara default tersembunyi, set teks tombol 'Tambah'.
    if (isEditMode) {
        formCard.classList.remove('hide-form'); // Pastikan form terlihat saat edit mode
        formCard.style.display = ''; // Hapus inline display none jika ada
        toggleBtn.textContent = 'Sembunyikan Form';
        // console.log("DEBUG: Initializing in Edit Mode: Form visible, button 'Sembunyikan Form'.");
    } else {
        // Jika bukan edit mode, pastikan form tersembunyi baik melalui kelas maupun inline style
        formCard.classList.add('hide-form'); // Tambahkan kelas hide-form
        formCard.style.display = 'none'; // Tambahkan inline display none sebagai fallback kuat
        toggleBtn.textContent = 'Tambah Sales Baru';
        // console.log("DEBUG: Initializing in Add Mode (hidden): Form hidden, button 'Tambah Sales Baru'.");
    }
    // *************************************************************************

    // Add event listener only once
    // '_hasClickListener' adalah properti kustom untuk mencegah duplikasi listener
    if (!toggleBtn._hasClickListener) {
        toggleBtn.addEventListener('click', function() {
            // console.log("DEBUG: Toggle button clicked!");
            // console.log("DEBUG: Current formCard classes before toggle:", formCard.classList.value);
            // console.log("DEBUG: Current formCard inline style display before toggle:", formCard.style.display);


            if (formCard.classList.contains('hide-form')) {
                // Jika form tersembunyi, tampilkan
                formCard.classList.remove('hide-form'); // Hapus class untuk menampilkan
                formCard.style.display = ''; // Hapus inline display none
                toggleBtn.textContent = 'Sembunyikan Form';
                formCard.scrollIntoView({ behavior: 'smooth', block: 'start' });
                // console.log("DEBUG: Form is now visible. Button text changed.");
            } else {
                // Jika form terlihat, sembunyikan
                formCard.classList.add('hide-form'); // Tambahkan class untuk menyembunyikan
                formCard.style.display = 'none'; // Tambahkan inline display none
                toggleBtn.textContent = 'Tambah Sales Baru';
                // console.log("DEBUG: Form is now hidden. Button text changed.");
                
                // Jika sedang dalam mode edit, redirect ke halaman tanpa parameter edit
                if (isEditMode) {
                    // console.log("DEBUG: In edit mode, redirecting to reset form/URL.");
                    window.location.href = 'manajemen_sales.php'; // Ini akan merefresh halaman dan keluar dari mode edit
                } else {
                    // Jika tidak dalam mode edit (misal: mode tambah baru), reset form setelah disembunyikan
                    // console.log("DEBUG: Not in edit mode, resetting form.");
                    var form = formCard.querySelector('form');
                    if (form) {
                        form.reset();
                        // Pastikan dropdown kembali ke nilai default atau kosong
                        var selects = form.querySelectorAll('select');
                        selects.forEach(s => {
                            let defaultOption = s.querySelector('option[selected]');
                            if (defaultOption) {
                                s.value = defaultOption.value;
                            } else if (s.options.length > 0 && s.querySelector('option[value=""]')) { // Jika ada opsi kosong
                                s.value = ''; // Pilih opsi kosong
                            } else if (s.options.length > 0) { // Jika tidak ada opsi kosong, pilih yang pertama
                                s.value = s.options[0].value;
                            }
                        });
                        // Reset date inputs to current date
                        var dateInputs = form.querySelectorAll('input[type="date"]');
                        dateInputs.forEach(input => {
                            input.value = new Date().toISOString().slice(0,10);
                        });
                    }
                }
            }
        });
        toggleBtn._hasClickListener = true; // Menandai bahwa event listener sudah ditambahkan
    } else {
        // console.log("DEBUG: Event listener already attached. Skipping re-attachment.");
    }

    // JavaScript untuk menampilkan pesan setelah redirect
    <?php if (isset($_GET['msg'])): ?>
        // console.log("DEBUG: Message from GET param detected: <?php echo htmlspecialchars($_GET['msg']); ?>");
        window.scrollTo({ top: 0, behavior: 'smooth' });
    <?php endif; ?>
});
</script>

<?php include '../includes/footer.php'; ?>