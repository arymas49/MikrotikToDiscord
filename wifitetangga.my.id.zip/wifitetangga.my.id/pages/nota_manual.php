<?php
// C:\xampp\htdocs\billing_isp_app\pages\nota_manual.php
ob_start(); // Aktifkan output buffering
ini_set('session.use_strict_mode', 1);
ini_set('session.cookie_httponly', 1);
ini_set('session.cookie_samesite', 'Lax');
if (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on') {
    ini_set('session.cookie_secure', 1);
}
session_start();
include '../config/koneksi.php';
include '../includes/header.php'; // Header akan meng-include sidebar dan fungsi hasRole()

// Batasi akses: hanya superadmin dan admin yang bisa mengakses halaman ini
if (!hasRole(['superadmin', 'admin'])) {
    header('Location: dashboard.php');
    ob_end_clean();
    exit();
}

$message = '';
$nota_id_to_edit = null;
$nota_data = [];

// --- Logika Hapus Nota Manual ---
if (isset($_GET['action']) && $_GET['action'] == 'delete' && isset($_GET['id'])) {
    if (!hasRole('superadmin')) { // Hanya superadmin yang bisa menghapus
        $message = '<div class="alert alert-danger">Anda tidak memiliki izin untuk menghapus nota. Hanya Superadmin yang dapat melakukan aksi ini.</div>';
    } else {
        $id_nota_to_delete = $koneksi->real_escape_string($_GET['id']);
        $stmt = $koneksi->prepare("DELETE FROM nota_manual WHERE id_nota_manual = ?");
        $stmt->bind_param("i", $id_nota_to_delete);
        if ($stmt->execute()) {
            $message = '<div class="alert alert-success">Nota pembayaran berhasil dihapus.</div>';
        } else {
            $message = '<div class="alert alert-danger">Gagal menghapus nota: ' . $stmt->error . '</div>';
        }
        $stmt->close();
    }
}

// --- Logika Tambah/Edit Nota Manual ---
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $tanggal_nota = $koneksi->real_escape_string($_POST['tanggal_nota']);
    $nama_penerima = $koneksi->real_escape_string($_POST['nama_penerima']);
    $alamat_penerima = $koneksi->real_escape_string($_POST['alamat_penerima']);
    $telepon_penerima = $koneksi->real_escape_string($_POST['telepon_penerima']);
    $email_penerima = $koneksi->real_escape_string($_POST['email_penerima'] ?? null);
    $deskripsi_jasa = $koneksi->real_escape_string($_POST['deskripsi_jasa']);
    $jumlah_biaya = $koneksi->real_escape_string($_POST['jumlah_biaya']);
    $metode_pembayaran = $koneksi->real_escape_string($_POST['metode_pembayaran']);
    $nota_id = $koneksi->real_escape_string($_POST['nota_id'] ?? '');
    $dicatat_oleh_user_id = $_SESSION['user_id'] ?? null; // ID user yang sedang login

    // Validasi dasar
    $errors = [];
    if (empty($tanggal_nota) || empty($nama_penerima) || empty($deskripsi_jasa) || empty($jumlah_biaya) || !is_numeric($jumlah_biaya) || $jumlah_biaya <= 0 || empty($metode_pembayaran)) {
        $errors[] = "Tanggal, Nama Penerima, Deskripsi Jasa, Jumlah Biaya, dan Metode Pembayaran harus diisi.";
    }

    if (!empty($errors)) {
        $message = '<div class="alert alert-danger">' . implode('<br>', $errors) . '</div>';
    } else {
        if (empty($nota_id)) { // Tambah Nota Baru
            $stmt = $koneksi->prepare("INSERT INTO nota_manual (tanggal_nota, nama_penerima, alamat_penerima, telepon_penerima, email_penerima, deskripsi_jasa, jumlah_biaya, metode_pembayaran, dicatat_oleh_user_id) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)");
            $stmt->bind_param("ssssssdsi", $tanggal_nota, $nama_penerima, $alamat_penerima, $telepon_penerima, $email_penerima, $deskripsi_jasa, $jumlah_biaya, $metode_pembayaran, $dicatat_oleh_user_id);
            if ($stmt->execute()) {
                $message = '<div class="alert alert-success">Nota pembayaran berhasil ditambahkan.</div>';
            } else {
                $message = '<div class="alert alert-danger">Gagal menambahkan nota: ' . $stmt->error . '</div>';
            }
        } else { // Edit Nota
            $stmt = $koneksi->prepare("UPDATE nota_manual SET tanggal_nota = ?, nama_penerima = ?, alamat_penerima = ?, telepon_penerima = ?, email_penerima = ?, deskripsi_jasa = ?, jumlah_biaya = ?, metode_pembayaran = ? WHERE id_nota_manual = ?");
            $stmt->bind_param("ssssssdsi", $tanggal_nota, $nama_penerima, $alamat_penerima, $telepon_penerima, $email_penerima, $deskripsi_jasa, $jumlah_biaya, $metode_pembayaran, $nota_id);
            if ($stmt->execute()) {
                $message = '<div class="alert alert-success">Nota pembayaran berhasil diperbarui.</div>';
            } else {
                $message = '<div class="alert alert-danger">Gagal memperbarui nota: ' . $stmt->error . '</div>';
            }
        }
        if (isset($stmt) && $stmt instanceof mysqli_stmt) { 
            $stmt->close();
        }
    }
}

// --- Logika Ambil Data Untuk Form Edit ---
if (isset($_GET['action']) && $_GET['action'] == 'edit' && isset($_GET['id'])) {
    $nota_id_to_edit = $koneksi->real_escape_string($_GET['id']);
    $query_edit = $koneksi->query("SELECT * FROM nota_manual WHERE id_nota_manual = '$nota_id_to_edit'");
    if ($query_edit->num_rows > 0) {
        $nota_data = $query_edit->fetch_assoc();
    } else {
        $message = '<div class="alert alert-danger">Data nota tidak ditemukan.</div>';
        $nota_id_to_edit = null;
    }
    $show_form_default = true;
} else {
    $show_form_default = false;
}

// Ambil semua data nota manual untuk ditampilkan
$query_nota_list = "SELECT nm.*, u.username as dicatat_oleh_username FROM nota_manual nm LEFT JOIN users u ON nm.dicatat_oleh_user_id = u.id ORDER BY tanggal_nota DESC";
$result_nota_list = $koneksi->query($query_nota_list);
?>

<div class="main-content">
    <div class="top-header">
        <div class="alert-message">
            Pemberitahuan: Catat setiap nota pembayaran manual untuk layanan di luar tagihan reguler.
        </div>
        <div class="welcome-message">
            <span>Selamat datang, <?php echo htmlspecialchars($_SESSION['username'] ?? 'User'); ?>!</span>
            <a href="../logout.php" class="btn-logout">Logout</a> 
        </div>
    </div>

    <div class="container">
        <h2>Manajemen Nota Pembayaran Manual</h2>

        <?php echo htmlspecialchars($message, ENT_QUOTES, "UTF-8"); ?>

        <button id="toggleFormBtn" class="btn btn-primary" style="margin-bottom: 20px;">
            <?php echo ($nota_id_to_edit ? 'Kembali ke Form Edit' : 'Tambah Nota Baru'); ?>
        </button>

        <div id="formNotaManualCard" class="card" style="margin-bottom: 20px; <?php echo $show_form_default ? '' : 'display: none;'; ?>">
            <div class="card-header">
                <h3><?php echo ($nota_id_to_edit ? 'Edit' : 'Tambah'); ?> Nota Pembayaran</h3>
            </div>
            <div class="card-body">
                <form method="POST"><?php if (!isset($_SESSION['csrf_token'])) { $_SESSION['csrf_token'] = bin2hex(random_bytes(32)); } ?><input type='hidden' name='csrf_token' value='<?php echo $_SESSION['csrf_token']; ?>'>
                    <?php if ($nota_id_to_edit): ?>
                        <input type="hidden" name="nota_id" value="<?php echo htmlspecialchars($nota_data['id_nota_manual']); ?>">
                    <?php endif; ?>
                    <div class="form-group">
                        <label for="tanggal_nota">Tanggal Nota:</label>
                        <input type="date" id="tanggal_nota" name="tanggal_nota" value="<?php echo htmlspecialchars($nota_data['tanggal_nota'] ?? date('Y-m-d')); ?>" required>
                    </div>
                    <div class="form-group">
                        <label for="nama_penerima">Nama Penerima:</label>
                        <input type="text" id="nama_penerima" name="nama_penerima" value="<?php echo htmlspecialchars($nota_data['nama_penerima'] ?? ''); ?>" required>
                    </div>
                    <div class="form-group">
                        <label for="alamat_penerima">Alamat Penerima (Opsional):</label>
                        <textarea id="alamat_penerima" name="alamat_penerima"><?php echo htmlspecialchars($nota_data['alamat_penerima'] ?? ''); ?></textarea>
                    </div>
                    <div class="form-group">
                        <label for="telepon_penerima">Telepon Penerima (Opsional):</label>
                        <input type="text" id="telepon_penerima" name="telepon_penerima" value="<?php echo htmlspecialchars($nota_data['telepon_penerima'] ?? ''); ?>">
                    </div>
                    <div class="form-group">
                        <label for="email_penerima">Email Penerima (Opsional):</label>
                        <input type="email" id="email_penerima" name="email_penerima" value="<?php echo htmlspecialchars($nota_data['email_penerima'] ?? ''); ?>">
                    </div>
                    <div class="form-group">
                        <label for="deskripsi_jasa">Deskripsi Jasa/Layanan:</label>
                        <textarea id="deskripsi_jasa" name="deskripsi_jasa" required><?php echo htmlspecialchars($nota_data['deskripsi_jasa'] ?? ''); ?></textarea>
                    </div>
                    <div class="form-group">
                        <label for="jumlah_biaya">Jumlah Biaya (Rp):</label>
                        <input type="number" id="jumlah_biaya" name="jumlah_biaya" step="0.01" value="<?php echo htmlspecialchars($nota_data['jumlah_biaya'] ?? ''); ?>" required>
                    </div>
                    <div class="form-group">
                        <label for="metode_pembayaran">Metode Pembayaran:</label>
                        <input type="text" id="metode_pembayaran" name="metode_pembayaran" value="<?php echo htmlspecialchars($nota_data['metode_pembayaran'] ?? ''); ?>" required>
                    </div>
                    <button type="submit" class="btn btn-primary"><?php echo ($nota_id_to_edit ? 'Update' : 'Tambah'); ?> Nota</button>
                    <?php if ($nota_id_to_edit): ?>
                        <a href="nota_manual.php" class="btn btn-secondary">Batal Edit</a>
                    <?php endif; ?>
                </form>
            </div>
        </div>

        <div class="card">
            <div class="card-header">
                <h3>Daftar Nota Pembayaran Manual</h3>
            </div>
            <div class="card-body">
                <table class="data-table">
                    <thead>
                        <tr>
                            <th>ID Nota</th>
                            <th>Tanggal</th>
                            <th>Penerima</th>
                            <th>Deskripsi Jasa</th>
                            <th>Jumlah</th>
                            <th>Metode Bayar</th>
                            <th>Dicatat Oleh</th>
                            <th>Aksi</th>
                            <th>Cetak</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if ($result_nota_list->num_rows > 0): ?>
                            <?php while($row = $result_nota_list->fetch_assoc()): ?>
                                <tr>
                                    <td><?php echo htmlspecialchars($row['id_nota_manual']); ?></td>
                                    <td><?php echo htmlspecialchars(date('d-m-Y', strtotime($row['tanggal_nota']))); ?></td>
                                    <td><?php echo htmlspecialchars($row['nama_penerima']); ?></td>
                                    <td><?php echo htmlspecialchars($row['deskripsi_jasa']); ?></td>
                                    <td>Rp <?php echo number_format($row['jumlah_biaya'], 0, ',', '.'); ?></td>
                                    <td><?php echo htmlspecialchars($row['metode_pembayaran']); ?></td>
                                    <td><?php echo htmlspecialchars($row['dicatat_oleh_username'] ?? 'N/A'); ?></td>
                                    <td>
                                        <a href="nota_manual.php?action=edit&id=<?php echo $row['id_nota_manual']; ?>" class="btn-action btn-edit"><i class="fas fa-edit"></i> Edit</a>
                                        <?php if (hasRole('superadmin')): // Hanya superadmin yang bisa menghapus ?>
                                        <a href="nota_manual.php?action=delete&id=<?php echo $row['id_nota_manual']; ?>" class="btn-action btn-delete" onclick="return confirm('Apakah Anda yakin ingin menghapus nota ini?');"><i class="fas fa-trash-alt"></i> Hapus</a>
                                        <?php endif; ?>
                                    </td>
                                    <td>
                                        <a href="print_nota_manual.php?id=<?php echo htmlspecialchars($row['id_nota_manual']); ?>" target="_blank" class="btn-action btn-secondary"><i class="fas fa-print"></i> Cetak</a>
                                    </td>
                                </tr>
                            <?php endwhile; ?>
                        <?php else: ?>
                            <tr><td colspan="9" style="text-align: center;">Belum ada nota pembayaran manual.</td></tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>

    </div>
</div>

<script>
document.addEventListener('DOMContentLoaded', function() {
    var formCard = document.getElementById('formNotaManualCard');
    var toggleBtn = document.getElementById('toggleFormBtn');
    
    // Safety check
    if (!formCard || !toggleBtn) {
        console.error("Error: formNotaManualCard or toggleFormBtn not found. Script cannot proceed.");
        return; 
    }

    var urlParams = new URLSearchParams(window.location.search);
    var isEditMode = urlParams.get('action') === 'edit';

    // Set teks tombol default dan visibilitas form
    if (formCard.classList.contains('hide-form')) {
        toggleBtn.textContent = 'Tambah Nota Baru';
    } else {
        toggleBtn.textContent = 'Sembunyikan Form';
    }

    // Add event listener only once
    if (!toggleBtn._hasClickListener) { 
        toggleBtn.addEventListener('click', function() {
            console.log("Toggle button clicked. Current classes:", formCard.classList); 
            if (formCard.classList.contains('hide-form')) {
                formCard.classList.remove('hide-form'); // Tampilkan form
                toggleBtn.textContent = 'Sembunyikan Form';
                formCard.scrollIntoView({ behavior: 'smooth', block: 'start' });
            } else {
                formCard.classList.add('hide-form'); // Sembunyikan form
                toggleBtn.textContent = 'Tambah Nota Baru';
                if (!isEditMode) { // Hanya reset form jika bukan mode edit
                    var form = formCard.querySelector('form');
                    if (form) {
                        form.reset();
                        // Reset date inputs to current date
                        var dateInputs = form.querySelectorAll('input[type="date"]');
                        dateInputs.forEach(input => {
                            input.value = new Date().toISOString().slice(0,10);
                        });
                        // Clear text/number/email/textarea inputs
                        var textInputs = form.querySelectorAll('input[type="text"], input[type="number"], input[type="email"], textarea');
                        textInputs.forEach(input => {
                            input.value = '';
                        });
                    }
                }
                if (isEditMode) {
                    window.location.href = 'nota_manual.php'; 
                }
            }
        });
        toggleBtn._hasClickListener = true; 
    }

    // JavaScript untuk menampilkan pesan setelah redirect
    <?php if (isset($_GET['msg'])): ?>
        console.log("Message from GET param:", "<?php echo htmlspecialchars($_GET['msg']); ?>"); 
        window.scrollTo({ top: 0, behavior: 'smooth' });
    <?php endif; ?>

});
</script>

<?php include '../includes/footer.php'; ?>
<?php ob_end_flush(); ?>