<?php
// C:\xampp\htdocs\billing_isp_app\pages\print_invoice.php

// PENTING: Mulai output buffering secepat mungkin untuk menangkap semua HTML
ob_start();
ini_set('session.use_strict_mode', 1);
ini_set('session.cookie_httponly', 1);
ini_set('session.cookie_samesite', 'Lax');
if (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on') {
    ini_set('session.cookie_secure', 1);
}
session_start();

// Sertakan file koneksi database
include '../config/koneksi.php';

// --- Dapatkan konfigurasi aplikasi (termasuk app_base_url dan token API untuk akses) ---
$whatsapp_config_path = '../config/whatsapp_config.php';
$whatsapp_config = [];
if (file_exists($whatsapp_config_path)) {
    $whatsapp_config = include $whatsapp_config_path;
}
// PENTING: Ambil API Access Token dari konfigurasi, BUKAN HARDCODE DI SINI
$configured_api_access_token = $whatsapp_config['api_access_token'] ?? 'tzn1426'; // Ini adalah fallback, pastikan token di whatsapp_config.php sudah benar
$app_base_url = $whatsapp_config['app_base_url'] ?? 'https://billing.tzn.my.id'; // Ini adalah fallback, pastikan base URL di whatsapp_config.php sudah benar


// --- Cek apakah user sudah login atau request datang dengan API token yang valid ---
// Jika tidak, tampilkan pesan error atau redirect (dan HENTIKAN eksekusi)
$is_authenticated_via_session = isset($_SESSION['user_id']);
$is_authenticated_via_api_token = (isset($_GET['api_access_token']) && $_GET['api_access_token'] === $configured_api_access_token);

if (!$is_authenticated_via_session && !$is_authenticated_via_api_token) {
    // Tangkap output buffering sebelum exit agar tidak ada output HTML yang tidak diinginkan
    ob_end_clean();
    error_log("Access denied to print_invoice.php. Session: " . ($is_authenticated_via_session ? 'true' : 'false') . ", API Token Valid: " . ($is_authenticated_via_api_token ? 'true' : 'false') . " - Expected token: " . $configured_api_access_token . ", Received token: " . ($_GET['api_access_token'] ?? 'N/A'));
    echo "<!DOCTYPE html><html><head><title>Akses Ditolak</title></head><body><h1>Akses Ditolak</h1><p>Anda tidak memiliki izin untuk melihat invoice ini atau token akses API tidak valid.</p><p>Jika Anda mencoba melampirkan invoice melalui WhatsApp Gateway, pastikan `app_base_url` di `config/whatsapp_config.php` adalah URL publik dan `api_access_token` sudah cocok.</p></body></html>";
    exit();
}


// --- Fungsi untuk konversi angka ke terbilang (Indonesia) ---
function terbilang($angka) {
    $angka = abs($angka);
    $baca = array("", "satu", "dua", "tiga", "empat", "lima", "enam", "tujuh", "delapan", "sembilan", "sepuluh", "sebelas");
    $temp = "";
    if ($angka < 12) {
        $temp = " " . $baca[$angka];
    } else if ($angka < 20) {
        $temp = terbilang($angka - 10) . " belas";
    } else if ($angka < 100) {
        $temp = terbilang($angka / 10) . " puluh" . terbilang($angka % 10);
    } else if ($angka < 200) {
        $temp = " seratus" . terbilang($angka - 100);
    } else if ($angka < 1000) {
        $temp = terbilang($angka / 100) . " ratus" . terbilang($angka % 100);
    } else if ($angka < 2000) {
        $temp = " seribu" . terbilang($angka - 1000);
    } else if ($angka < 1000000) {
        $temp = terbilang($angka / 1000) . " ribu" . terbilang($angka % 1000);
    } else if ($angka < 2000000000) { // Diperbaiki agar sesuai dengan milyar
        $temp = terbilang($angka / 1000000) . " juta" . terbilang(fmod($angka, 1000000));
    } else if ($angka < 1000000000000) {
        $temp = terbilang($angka / 1000000000) . " milyar" . terbilang(fmod($angka, 1000000000));
    } else if ($angka < 1000000000000000) {
        $temp = terbilang($angka / 1000000000000) . " trilyun" . terbilang(fmod($angka, 1000000000000));
    }
    return $temp;
}

function format_terbilang_rupiah($angka) {
    if ($angka < 0) {
        return "Minus " . trim(terbilang($angka)) . " Rupiah";
    } elseif ($angka == 0) {
        return "Nol Rupiah";
    } else {
        return trim(terbilang($angka)) . " Rupiah";
    }
}

// --- Get Invoice Data ---
$invoice_source_table = $_GET['source_table'] ?? ''; // 'tagihan' or 'tagihan_manual' or 'payment'
$invoice_id_param = $_GET['id'] ?? null; // ID of the invoice/payment in the respective table

$invoice_details = [];
$customer_display_data = [];
$item_display_data = [];
$total_amount_display = 0; // Ini akan menjadi SISA tagihan yang harus dibayar
$ppn_amount = 0; // Variabel untuk jumlah PPN
$sisa_tagihan_sekarang = 0; // Variabel untuk sisa tagihan jika ada
$total_tagihan_penuh = 0; // Variabel untuk total tagihan penuh (harga paket + PPN)

$invoice_title_text = "INVOICE";
$invoice_number_display = "N/A";
$periode_display = "N/A";
$jatuh_tempo_display = "N/A";
$id_pelanggan_display_on_invoice = "N/A";
$payment_method_display = "N/A";
$current_invoice_status = 'Belum Lunas'; // Default status

// Variabel untuk menyimpan HTML konten error, jika ada
$error_html_content = "";

if (empty($invoice_source_table) || empty($invoice_id_param)) {
    $error_html_content = "<!DOCTYPE html><html><head><title>Parameter Tidak Valid</title></head><body><h1>Parameter Tidak Valid</h1><p>Parameter invoice tidak valid (source_table atau id missing).</p></body></html>";
} elseif ($invoice_source_table == 'tagihan') {
    // Ambil semua pembayaran terkait untuk menghitung total sudah bayar
    $query_tagihan = "
        SELECT
            t.*,
            p.nama_pelanggan, p.alamat, p.telepon, p.email, p.uses_ppn,
            pk.nama_paket, pk.kecepatan, pk.harga
        FROM tagihan t
        LEFT JOIN pelanggan p ON t.pelanggan_id = p.id_pelanggan
        LEFT JOIN paket_layanan pk ON p.paket_id = pk.id_paket
        WHERE t.id_tagihan = ?
    ";
    $stmt_tagihan = $koneksi->prepare($query_tagihan);
    $stmt_tagihan->bind_param("i", $invoice_id_param);
    $stmt_tagihan->execute();
    $result_tagihan = $stmt_tagihan->get_result();

    if ($result_tagihan->num_rows > 0) {
        $invoice_details = $result_tagihan->fetch_assoc();
        $stmt_tagihan->close();

        $customer_display_data = [
            'nama'      => $invoice_details['nama_pelanggan'],
            'alamat'    => $invoice_details['alamat'],
            'telepon'   => $invoice_details['telepon'],
            'email'     => $invoice_details['email'],
        ];
        $id_pelanggan_display_on_invoice = htmlspecialchars($invoice_details['pelanggan_id']);

        $item_description = htmlspecialchars($invoice_details['nama_paket'] . ' (' . $invoice_details['kecepatan'] . ')');
        if (!empty($invoice_details['deskripsi_tagihan_manual'])) {
            $item_description = htmlspecialchars($invoice_details['deskripsi_tagihan_manual']);
        }

        $base_harga_paket = $invoice_details['harga']; // Harga paket dasar
        $jumlah_tagihan_dari_db = $invoice_details['jumlah_tagihan']; // Jumlah yang sudah tersimpan di tabel tagihan (harga bersih)
        $uses_ppn = $invoice_details['uses_ppn'] ?? 0;
        $ppn_percentage = 0.11;

        // --- LOGIKA PERHITUNGAN TOTAL TAGIHAN PENUH DAN SISA TAGIHAN ---
        $harga_pokok_tagihan_bersih = $jumlah_tagihan_dari_db; // Asumsi jumlah_tagihan di DB adalah harga bersih
        $ppn_amount = 0;
        $total_tagihan_penuh_awal = $harga_pokok_tagihan_bersih; // Ini adalah total yang seharusnya jika dibayar penuh (harga paket bersih)

        if ($uses_ppn == 1) {
            $ppn_amount = $harga_pokok_tagihan_bersih * $ppn_percentage;
            $total_tagihan_penuh_awal += $ppn_amount; // Ini adalah total TERMASUK PPN
        }

        // Dapatkan sisa tagihan dari tabel tagihan
        $sisa_tagihan_sekarang = $invoice_details['sisa_tagihan'];
        if (is_null($sisa_tagihan_sekarang)) {
            // Fallback jika kolom sisa_tagihan belum diisi
            $sisa_tagihan_sekarang = $total_tagihan_penuh_awal;
        }

        // Jumlah yang sudah dibayar (total tagihan penuh dikurangi sisa tagihan)
        $jumlah_sudah_dibayar = $total_tagihan_penuh_awal - $sisa_tagihan_sekarang;

        // Tentukan status berdasarkan sisa_tagihan_sekarang
        if ($sisa_tagihan_sekarang <= 0.01) { // Toleransi floating point
            $current_invoice_status = 'Lunas';
            $total_amount_display = $total_tagihan_penuh_awal; // Jika lunas, tampilkan total penuh yang dibayar
            $payment_method_display = $invoice_details['metode_pembayaran']; // Ambil metode pembayaran terakhir jika lunas
        } elseif ($sisa_tagihan_sekarang < $total_tagihan_penuh_awal - 0.01 && $jumlah_sudah_dibayar > 0.01) {
            $current_invoice_status = 'Pembayaran Parsial';
            $total_amount_display = $sisa_tagihan_sekarang; // Jika parsial, tampilkan sisa yang harus dibayar
        } else {
            $current_invoice_status = 'Belum Lunas';
            $total_amount_display = $total_tagihan_penuh_awal; // Jika belum lunas, tampilkan total penuh yang harus dibayar
        }
        // --- AKHIR LOGIKA PERHITUNGAN ---


        // Menambahkan item ke daftar tampilan
        $item_display_data[] = [
            'item' => $item_description,
            'harga' => $harga_pokok_tagihan_bersih // Tampilkan harga bersih paket
        ];

        // Jika PPN ada, tambahkan sebagai baris terpisah
        if ($ppn_amount > 0) {
            $item_display_data[] = [
                'item' => "Pajak PPN (11%)",
                'harga' => $ppn_amount
            ];
        }

        // JATUH TEMPO
        $periode_display = date('F Y', strtotime($invoice_details['bulan_tagihan'] . '-01'));
        $jatuh_tempo_display = date('d F Y', strtotime($invoice_details['tanggal_jatuh_tempo']));

        // Tentukan judul invoice dan nomor invoice berdasarkan status aktual
        if ($current_invoice_status == 'Lunas') {
            $invoice_title_text = "BUKTI PEMBAYARAN";
            $tanggal_untuk_nomor_invoice = $invoice_details['tanggal_bayar'] ?? date('Y-m-d');
            $invoice_number_display = "REC-" . date('Ymd', strtotime($tanggal_untuk_nomor_invoice)) . "-" . str_pad($invoice_details['id_tagihan'], 5, '0', STR_PAD_LEFT);
        } else { // Termasuk Belum Lunas dan Parsial
            $invoice_title_text = "INVOICE TAGIHAN";
            $invoice_number_display = "TAG-" . date('Ymd', strtotime($invoice_details['tanggal_terbit'])) . "-" . str_pad($invoice_details['id_tagihan'], 5, '0', STR_PAD_LEFT);
            $payment_method_display = "N/A"; // Untuk tagihan yang belum lunas (termasuk parsial), payment method tidak relevan pada invoice awal
        }

    } else {
        $error_html_content = "<!DOCTYPE html><html><head><title>Invoice Tidak Ditemukan</title></head><body><h1>Invoice Tidak Ditemukan</h1><p>Data tagihan (registered) dengan ID " . htmlspecialchars($invoice_id_param) . " tidak ditemukan.</p></body></html>";
    }

} elseif ($invoice_source_table == 'tagihan_manual') {
    // Logika untuk tagihan_manual tetap sama, asumsikan tidak ada PPN di sini
    $query = "
        SELECT
            tm.*,
            py.tanggal_bayar, py.metode_pembayaran
        FROM tagihan_manual tm
        LEFT JOIN pembayaran py ON tm.id_pembayaran_terkait = py.id_pembayaran
        WHERE tm.id_tagihan_manual = ?
    ";
    $stmt = $koneksi->prepare($query);
    $stmt->bind_param("i", $invoice_id_param);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        $invoice_details = $result->fetch_assoc();

        $customer_display_data = [
            'nama'      => $invoice_details['nama_pelanggan_manual'],
            'alamat'    => $invoice_details['alamat_manual'],
            'telepon'   => $invoice_details['telepon_manual'],
            'email'     => $invoice_details['email_manual'],
            'tip'       => $invoice_details['tip_pelanggan_manual'] ?? ''
        ];
        $id_pelanggan_display_on_invoice = "N/A (Manual)";

        $item_description = htmlspecialchars($invoice_details['nama_paket_manual']);
        if (!empty($invoice_details['deskripsi_tagihan_manual'])) {
            $item_description = htmlspecialchars($invoice_details['deskripsi_tagihan_manual']);
        }

        $item_display_data[] = [
            'item' => $item_description,
            'harga' => $invoice_details['jumlah_tagihan']
        ];
        $total_amount_display = $invoice_details['jumlah_tagihan'];
        $current_invoice_status = $invoice_details['status_tagihan'] ?? 'Belum Lunas'; // Status dari DB

        $periode_display = date('F Y', strtotime($invoice_details['tanggal_terbit']));
        $jatuh_tempo_display = date('d F Y', strtotime($invoice_details['tanggal_jatuh_tempo']));

        if ($current_invoice_status == 'Lunas') {
            $invoice_title_text = "BUKTI PEMBAYARAN MANUAL";
            $tanggal_bayar_for_invoice = $invoice_details['tanggal_bayar_manual'] ?? ($invoice_details['tanggal_terbit'] ?? date('Y-m-d'));
            $invoice_number_display = "REC-" . date('Ymd', strtotime($tanggal_bayar_for_invoice)) . "-" . str_pad($invoice_details['id_tagihan_manual'], 5, '0', STR_PAD_LEFT);
            $payment_method_display = $invoice_details['metode_pembayaran_manual'] ?? 'N/A';
            $total_amount_display = $invoice_details['jumlah_bayar_manual'] ?? $invoice_details['jumlah_tagihan'];
            $item_display_data[0]['harga'] = $total_amount_display;

        } else {
            $invoice_title_text = "INVOICE TAGIHAN MANUAL";
            $invoice_number_display = "TAG-" . date('Ymd', strtotime($invoice_details['tanggal_terbit'])) . "-" . str_pad($invoice_details['id_tagihan_manual'], 5, '0', STR_PAD_LEFT);
        }

    } else {
        $error_html_content = "<!DOCTYPE html><html><head><title>Nota Manual Tidak Ditemukan</title></head><body><h1>Nota Manual Tidak Ditemukan</h1><p>Data nota manual dengan ID " . htmlspecialchars($invoice_id_param) . " tidak ditemukan.</p></body></html>";
    }
    $stmt->close(); // Tutup statement

} elseif ($invoice_source_table == 'payment') {
    // Logika untuk payment tetap sama, asumsikan tidak ada PPN di sini
    $query = "
        SELECT
            py.*,
            p.nama_pelanggan, p.alamat, p.telepon, p.email,
            pk.nama_paket, pk.kecepatan, pk.harga
        FROM pembayaran py
        JOIN pelanggan p ON py.pelanggan_id = p.id_pelanggan
        JOIN paket_layanan pk ON py.paket_id = pk.id_paket
        WHERE py.id_pembayaran = ?
    ";
    $stmt = $koneksi->prepare($query);
    $stmt->bind_param("i", $invoice_id_param);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        $invoice_details = $result->fetch_assoc();

        $customer_display_data = [
            'nama'      => $invoice_details['nama_pelanggan'],
            'alamat'    => $invoice_details['alamat'],
            'telepon'   => $invoice_details['telepon'],
            'email'     => $invoice_details['email'],
        ];
        $id_pelanggan_display_on_invoice = htmlspecialchars($invoice_details['pelanggan_id']);

        $item_description = htmlspecialchars($invoice_details['nama_paket'] . ' (' . ($invoice_details['kecepatan'] ?? '') . ')');
        $item_display_data[] = [
            'item' => $item_description,
            'harga' => $invoice_details['jumlah_bayar']
        ];
        $total_amount_display = $invoice_details['jumlah_bayar'];
        $current_invoice_status = $invoice_details['status_pembayaran'] ?? 'Lunas'; // Status pembayaran

        $periode_display = date('F Y', strtotime($invoice_details['bulan_tagihan'] . '-01'));
        $jatuh_tempo_display = "N/A";

        $invoice_title_text = "BUKTI PEMBAYARAN";
        $invoice_number_display = "REC-" . date('Ymd', strtotime($invoice_details['tanggal_bayar'])) . "-" . str_pad($invoice_details['id_pembayaran'], 5, '0', STR_PAD_LEFT);
        $payment_method_display = $invoice_details['metode_pembayaran'];

    } else {
        $error_html_content = "<!DOCTYPE html><html><head><title>Pembayaran Tidak Ditemukan</title></head><body><h1>Pembayaran Tidak Ditemukan</h1><p>Data pembayaran dengan ID " . htmlspecialchars($invoice_id_param) . " tidak ditemukan.</p></body></html>";
    }
    $stmt->close(); // Tutup statement
} else {
    $error_html_content = "<!DOCTYPE html><html><head><title>Parameter Tidak Valid</title></head><body><h1>Parameter Tidak Valid</h1><p>Parameter invoice tidak valid (source_table atau id missing).</p></body></html>";
}

// Data perusahaan (hardcoded sesuai gambar)
$company_name = "PT Triple Zhi Network";
$company_address = "Jl Gadarmun Hangkiho Kec Baoalan Kel Tuweley , Kabupaten Tolitoli Provinsi Sulawesi Tengah 94515";
$company_email = "adm@triplezhinetwork.id";
$company_phone = "082259438445";

$current_date_invoice_footer = date('F Y');

// Tutup koneksi database
$koneksi->close();

// --- Konten HTML yang akan dirender ---
if (!empty($error_html_content)) {
    echo $error_html_content;
} else {
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo htmlspecialchars($invoice_title_text); ?> - <?php echo htmlspecialchars($customer_display_data['nama'] ?? 'Pelanggan'); ?></title>
    <style>
        body { font-family: 'sans-serif'; margin: 0; padding: 20px; font-size: 12px; }
        .invoice-container { width: 100%; margin: 0 auto; border: 1px solid #eee; padding: 20px; box-sizing: border-box; }
        .invoice-top-section { display: table; width: 100%; border-spacing: 0; margin-bottom: 20px; }
        .invoice-top-section > div { display: table-cell; vertical-align: middle; }
        .invoice-top-section .logo { width: 50%; text-align: left; }
        .invoice-top-section .invoice-meta { width: 50%; text-align: right; }
        .logo img { max-width: 150px; height: auto; }
        .invoice-meta p { margin: 2px 0; }
        .font-bold { font-weight: bold; }

        .company-customer-details { display: table; width: 100%; border-spacing: 0; margin-bottom: 20px; }
        .company-customer-details > div { display: table-cell; vertical-align: top; width: 48%; }
        .company-info { text-align: left; }
        .customer-info { text-align: right; }
        .company-info h3, .customer-info h3 { margin-top: 0; margin-bottom: 5px; font-size: 1.1em; }
        .company-info p, .customer-info p { margin: 2px 0; }

        .items-table { width: 100%; border-collapse: collapse; margin-bottom: 20px; }
        .items-table th, .items-table td { border: 1px solid #ddd; padding: 8px; text-align: left; }
        .items-table th { background-color: #f2f2f2; }
        .text-right { text-align: right; }
        .terbilang-section { margin-bottom: 20px; font-size: 1.1em; }
        .bank-details-section { margin-bottom: 20px; }
        .bank-details-section h3 { font-size: 1em; margin-bottom: 5px; }
        .payment-status-section { text-align: center; margin-top: 30px; padding: 10px; border: 1px solid; border-radius: 5px;}
        .payment-status-section p { margin: 5px 0; }
        .status-badge { display: inline-block; padding: 3px 8px; border-radius: 3px; font-weight: bold; }
        .status-lunas { background-color: #e8f5e9; color: #155724; border-color: #c3e6cb; }
        .status-belum-lunas { background-color: #ffebee; color: #a94442; border-color: #f5c6cb; }
        .status-parsial { background-color: #fff3cd; color: #856404; border-color: #ffeeba; } /* NEW STYLE */
        .signature-section { text-align: right; margin-top: 50px; }
        .signature-section .date-right { margin-bottom: 50px; }
        .signature-section .company-name-signature { font-weight: bold; }
        /* Tombol ini akan muncul di browser dan bisa digunakan untuk print langsung */
        @media print {
            .no-print-btn-group { display: none; }
        }
        .no-print-btn-group { text-align: center; margin-top: 30px; }
        .no-print-btn { padding: 10px 15px; background-color: #007bff; color: white; border: none; border-radius: 5px; cursor: pointer; }
    </style>
</head>
<body>
    <div class="invoice-container">
        <div class="invoice-top-section">
            <div class="logo">
                <img src="<?php echo htmlspecialchars($app_base_url); ?>/assets/images/Logo-TZN.png" alt="PT Triple Zhi Network Logo" style="max-width: 150px; height: auto;">
            </div>
            <div class="invoice-meta">
                <p>Invoice # <span class="font-bold"><?php echo htmlspecialchars($invoice_number_display); ?></span></p>
                <p>Periode : <span class="font-bold"><?php echo htmlspecialchars($periode_display); ?></span></p>
                <p>Jatuh Tempo : <span class="font-bold"><?php echo htmlspecialchars($jatuh_tempo_display); ?></span></p>
                <p>ID Pelanggan : <span class="font-bold"><?php echo htmlspecialchars($id_pelanggan_display_on_invoice); ?></span></p>
            </div>
        </div>

        <div class="company-customer-details">
            <div class="company-info">
                <h3><?php echo htmlspecialchars($company_name); ?></h3>
                <p><?php echo nl2br(htmlspecialchars($company_address)); ?></p>
                <p><?php echo htmlspecialchars($company_email); ?></p>
                <p><?php echo htmlspecialchars($company_phone); ?></p>
            </div>
            <div class="customer-info">
                <h3><?php echo htmlspecialchars($customer_display_data['nama'] ?? 'N/A'); ?></h3>
                <p><?php echo nl2br(htmlspecialchars($customer_display_data['alamat'] ?? 'N/A')); ?></p>
                <p>Telepon: <?php echo htmlspecialchars($customer_display_data['telepon'] ?? 'N/A'); ?></p>
                <?php if (!empty($customer_display_data['email'])): ?>
                    <p>Email: <?php echo htmlspecialchars($customer_display_data['email']); ?></p>
                <?php endif; ?>
                <?php if (!empty($customer_display_data['tip'])): ?>
                    <p>Tip Pelanggan: <?php echo htmlspecialchars($customer_display_data['tip']); ?></p>
                <?php endif; ?>
            </div>
        </div>

        <table class="items-table">
            <thead>
                <tr>
                    <th>Item</th>
                    <th class="text-right" style="width: 25%;">Harga</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($item_display_data as $item): ?>
                    <tr>
                        <td><?php echo htmlspecialchars($item['item']); ?></td>
                        <td class="text-right">Rp <?php echo number_format($item['harga'], 0, ',', '.'); ?></td>
                    </tr>
                <?php endforeach; ?>
                <?php if ($ppn_amount > 0): ?>
                    <tr>
                        <td>Pajak PPN (11%)</td>
                        <td class="text-right">Rp <?php echo number_format($ppn_amount, 0, ',', '.'); ?></td>
                    </tr>
                <?php endif; ?>
                <?php if ($invoice_source_table == 'tagihan' && $current_invoice_status != 'Lunas' && $jumlah_sudah_dibayar > 0.01): // Hanya tampilkan jika ada pembayaran parsial dan belum lunas penuh ?>
                    <tr>
                        <td class="text-right font-bold">Sudah Dibayar:</td>
                        <td class="text-right font-bold">Rp <?php echo number_format($jumlah_sudah_dibayar, 0, ',', '.'); ?></td>
                    </tr>
                <?php endif; ?>
            </tbody>
            <tfoot>
                <tr>
                    <td class="text-right font-bold">
                        <?php
                            if ($current_invoice_status == 'Lunas') {
                                echo "Total Dibayar:";
                            } elseif ($current_invoice_status == 'Pembayaran Parsial') {
                                echo "Sisa yang Harus Dibayar:";
                            } else { // Belum Lunas
                                echo "Total yang Harus Dibayar:";
                            }
                        ?>
                    </td>
                    <td class="text-right font-bold">Rp <?php echo number_format($total_amount_display, 0, ',', '.'); ?></td>
                </tr>
            </tfoot>
        </table>

        <div class="terbilang-section">
            <p>Terbilang: <span class="font-bold"><?php echo htmlspecialchars(format_terbilang_rupiah($total_amount_display)); ?></span></p>
        </div>

        <div class="bank-details-section">
            <h3>Metode Pembayaran Via Cash atau Transfer Ke:</h3>
            <p>BNI A/N PT Triple Zhi Network 4949262629</p>
            <p>NPWP A/N PT Triple Zhi Network 62.352.426.1-834.000</p>
            <?php if (!empty($payment_method_display) && $current_invoice_status == 'Lunas'): ?>
                <p>Pembayaran dilakukan melalui: <strong><?php echo htmlspecialchars($payment_method_display); ?></strong></p>
            <?php endif; ?>
        </div>

        <?php if ($current_invoice_status == 'Lunas'): ?>
            <div class="payment-status-section status-lunas">
                <p class="font-bold" style="color: inherit; margin: 0;">STATUS: LUNAS</p>
                <p style="margin: 5px 0 0;">Terima kasih atas pembayaran Anda.</p>
            </div>
        <?php elseif ($current_invoice_status == 'Pembayaran Parsial'): ?>
            <div class="payment-status-section status-parsial">
                <p class="font-bold" style="color: inherit; margin: 0;">STATUS: PEMBAYARAN PARSIAL</p>
                <p style="margin: 5px 0 0;">Sisa tagihan yang harus dibayar: Rp <?php echo number_format($sisa_tagihan_sekarang, 0, ',', '.'); ?></p>
                <p style="margin: 5px 0 0;">Mohon segera lunasi sisa tagihan Anda untuk menghindari blokir layanan.</p>
            </div>
        <?php else: // $current_invoice_status == 'Belum Lunas' ?>
            <div class="payment-status-section status-belum-lunas">
                <p class="font-bold" style="color: inherit; margin: 0;">STATUS: BELUM LUNAS</p>
                <p style="margin: 5px 0 0;">Mohon segera lakukan pembayaran sebelum tanggal jatuh tempo untuk menghindari blokir layanan.</p>
            </div>
        <?php endif; ?>


        <div class="signature-section">
            <p class="date-right"><?php echo htmlspecialchars(date('d F Y')); ?></p> <div style="height: 60px;"></div>
            <p class="company-name-signature"><?php echo htmlspecialchars($company_name); ?></p>
        </div>

        <div class="no-print-btn-group">
            <button class="no-print-btn" onclick="window.print()"><i class="fas fa-print"></i> Cetak Invoice</button>
            <button class="no-print-btn" onclick="window.close()" style="background-color: #6c757d; margin-left: 10px;"><i class="fas fa-times-circle"></i> Tutup</button>
        </div>
    </div>
</body>
</html>

<?php
}
// Flush (tampilkan) semua output buffering
ob_end_flush();
?>