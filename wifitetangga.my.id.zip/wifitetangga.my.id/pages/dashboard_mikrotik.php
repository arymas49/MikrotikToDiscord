<?php
// C:\xampp\htdocs\billing_isp_app\pages\dashboard_mikrotik.php

ini_set('session.use_strict_mode', 1);
ini_set('session.cookie_httponly', 1);
ini_set('session.cookie_samesite', 'Lax');
if (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on') {
    ini_set('session.cookie_secure', 1);
}
session_start();
include '../config/koneksi.php';
include '../includes/header.php';

// Pastikan user memiliki role yang sesuai (misal: superadmin atau teknisi)
if (!hasRole(['superadmin', 'teknisi'])) {
    echo "<script>
            alert('Anda tidak memiliki akses ke halaman ini.');
            window.location.href = '../pages/dashboard.php';
          </script>";
    exit();
}
?>

<div class="main-content">
    <div class="page-header">
        <h1>Dashboard MikroTik</h1>
    </div>

    <div class="container">
        <div class="card mb-4">
            <div class="card-header">
                <h3><i class="fa fa-info-circle"></i> Informasi Sistem MikroTik</h3>
                <div class="form-group mb-0" style="max-width: 250px;">
                    <label for="mikrotikConfigSelect" class="sr-only">Pilih MikroTik:</label>
                    <select id="mikrotikConfigSelect" class="form-control form-control-sm">
                        <option value="">Memuat konfigurasi...</option>
                    </select>
                </div>
            </div>
            <div class="card-body">
                <div id="mikrotikInfo" class="mikrotik-info-grid">
                    <div class="info-item">
                        <strong>Status Koneksi:</strong> <span id="connectionStatusText" class="text-info">Memuat...</span>
                    </div>
                    <div class="info-item">
                        <strong>Uptime:</strong> <span id="uptime">N/A</span>
                    </div>
                    <div class="info-item">
                        <strong>Memori Bebas:</strong> <span id="freeMemory">N/A</span>
                    </div>
                    <div class="info-item">
                        <strong>Total Memori:</strong> <span id="totalMemory">N/A</span>
                    </div>
                    <div class="info-item">
                        <strong>Beban CPU:</strong> <span id="cpuLoad">N/A</span>
                    </div>
                    <div class="info-item">
                        <strong>Nama Board:</strong> <span id="boardName">N/A</span>
                    </div>
                    <div class="info-item">
                        <strong>Versi:</strong> <span id="version">N/A</span>
                    </div>
                </div>
                <button id="refreshStatusBtn" class="btn btn-primary mt-3"><i class="fas fa-sync-alt"></i> Refresh Status Sistem</button>
            </div>
        </div>

        <div class="card mb-4">
            <div class="card-header">
                <h3><i class="fa fa-wifi"></i> Hotspot Overview</h3>
            </div>
            <div class="card-body">
                <div class="hotspot-overview-grid">
                    <div class="hotspot-overview-card active-hotspot">
                        <div class="icon"><i class="fa fa-laptop"></i></div>
                        <h1 id="hotspotActiveCount">0 <span style="font-size: 15px;">items</span></h1>
                        <p>Hotspot Aktif</p>
                        <div class="card-footer" style="width:100%; text-align:center; border-top: none; padding-top:10px;">
                            <a href="../pages/hotspot_active_users.php" style="color:white; text-decoration:none; font-size:0.85em;">Selengkapnya <i class="fas fa-arrow-right"></i></a>
                        </div>
                    </div>
                    <div class="hotspot-overview-card total-users">
                        <div class="icon"><i class="fa fa-users"></i></div>
                        <h1 id="hotspotUsersCount">0 <span style="font-size: 15px;">items</span></h1>
                        <p>Pengguna Hotspot</p>
                        <div class="card-footer" style="width:100%; text-align:center; border-top: none; padding-top:10px;">
                            <a href="../pages/cetak_voucher.php#hotspotUsersTable" style="color:white; text-decoration:none; font-size:0.85em;">Selengkapnya <i class="fas fa-arrow-right"></i></a>
                        </div>
                    </div>
                    <div class="hotspot-overview-card create-voucher">
                        <div class="icon"><i class="fa fa-user-plus"></i></div>
                        <h1>Buat</h1>
                        <p>Voucher Hotspot</p>
                        <div class="card-footer" style="width:100%; text-align:center; border-top: none; padding-top:10px;">
                            <a href="../pages/cetak_voucher.php#generateVoucherForm" style="color:white; text-decoration:none; font-size:0.85em;">Selengkapnya <i class="fas fa-arrow-right"></i></a>
                        </div>
                    </div>
                    <div class="hotspot-overview-card financial-overview-card">
                        <div class="icon"><i class="fa fa-money-bill-wave"></i></div>
                        <h1>Pendapatan</h1>
                        <p>Voucher</p>
                        <div class="income-details" style="font-size: 0.8em; margin-top: 10px; color: white;">
                            <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 5px;">
                                <span>Hari Ini:</span> <strong id="todayIncome" style="font-size: 1em;">Rp0</strong>
                            </div>
                            <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 5px;">
                                <span>Bulan Ini:</span> <strong id="monthIncome" style="font-size: 1em;">Rp0</strong>
                            </div>
                            <div style="display: flex; justify-content: space-between; align-items: center;">
                                <span>Total:</span> <strong id="allTimeIncome" style="font-size: 1em;">Rp0</strong>
                            </div>
                        </div>
                        <div class="card-footer" style="width:100%; text-align:center; border-top: none; padding-top:10px;">
                            <a href="../pages/laporan_penjualan_voucher.php" style="color:white; text-decoration:none; font-size:0.85em;">Selengkapnya <i class="fas fa-arrow-right"></i></a>
                            <button id="refreshFinancialBtnSmall" class="btn btn-sm btn-outline-light mt-2" style="font-size: 0.7em;"><i class="fas fa-sync-alt"></i> Refresh</button>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<script>
document.addEventListener('DOMContentLoaded', function() {
    // Elements for Mikrotik Status
    const connectionStatusText = document.getElementById('connectionStatusText');
    const uptimeElem = document.getElementById('uptime');
    const freeMemoryElem = document.getElementById('freeMemory');
    const totalMemoryElem = document.getElementById('totalMemory');
    const cpuLoadElem = document.getElementById('cpuLoad');
    const boardNameElem = document.getElementById('boardName');
    const versionElem = document.getElementById('version');
    const refreshStatusBtn = document.getElementById('refreshStatusBtn');

    // Element for MikroTik config selection
    const mikrotikConfigSelect = document.getElementById('mikrotikConfigSelect');

    // Elements for Hotspot Overview
    const hotspotActiveCount = document.getElementById('hotspotActiveCount');
    const hotspotUsersCount = document.getElementById('hotspotUsersCount');

    // Elements for Financial Overview (now inside the "Pendapatan Voucher" card)
    const todayIncomeElem = document.getElementById('todayIncome');
    const monthIncomeElem = document.getElementById('monthIncome');
    const allTimeIncomeElem = document.getElementById('allTimeIncome');
    const refreshFinancialBtnSmall = document.getElementById('refreshFinancialBtnSmall'); // New ID for the smaller refresh button

    // Variabel untuk menyimpan ID konfigurasi MikroTik yang saat ini dipilih
    let selectedMikrotikConfigId = localStorage.getItem('selectedMikrotikConfigId');

    // Fungsi helper untuk menampilkan notifikasi (asumsi sudah ada di header.php atau file lain)
    function showNotification(message, type = 'info') {
        const notificationArea = document.getElementById('notificationArea') || document.createElement('div');
        notificationArea.id = 'notificationArea';
        notificationArea.innerHTML = `<div class="alert alert-${type} alert-dismissible fade show" role="alert">
                                        ${message}
                                        <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                                            <span aria-hidden="true">&times;</span>
                                        </button>
                                    </div>`;
        document.body.prepend(notificationArea);
        setTimeout(() => {
            const alert = notificationArea.querySelector('.alert');
            if (alert) {
                $(alert).alert('close');
            }
        }, 5000);
    }

    // Helper function to format currency (replicated from cetak_voucher.php)
    function formatCurrency(amount) {
        const numAmount = parseFloat(amount);
        if (isNaN(numAmount)) {
            return 'Rp0';
        }
        return new Intl.NumberFormat('id-ID', {
            style: 'currency',
            currency: 'IDR',
            minimumFractionDigits: 0,
            maximumFractionDigits: 0
        }).format(numAmount);
    }

    // --- Load MikroTik Configurations ---
    async function loadMikrotikConfigs() {
        try {
            const response = await fetch('mikrotik_api.php?action=get_mikrotik_configs');
            const data = await response.json();

            mikrotikConfigSelect.innerHTML = ''; // Clear existing options

            if (data.status === 'success' && data.configs && Array.isArray(data.configs) && data.configs.length > 0) {
                data.configs.forEach(config => {
                    const option = document.createElement('option');
                    option.value = config.id;
                    option.textContent = `${config.name} (${config.ip_address})`;
                    mikrotikConfigSelect.appendChild(option);
                });

                // Set pilihan sebelumnya atau yang pertama sebagai default
                if (selectedMikrotikConfigId && data.configs.some(c => c.id == selectedMikrotikConfigId)) {
                    mikrotikConfigSelect.value = selectedMikrotikConfigId;
                } else {
                    mikrotikConfigSelect.value = data.configs[0].id;
                    selectedMikrotikConfigId = data.configs[0].id; // Update selected ID
                    localStorage.setItem('selectedMikrotikConfigId', selectedMikrotikConfigId);
                }
            } else {
                mikrotikConfigSelect.innerHTML = '<option value="">Tidak ada konfigurasi MikroTik</option>';
                mikrotikConfigSelect.disabled = true;
                selectedMikrotikConfigId = null; // Reset selected ID if no configs
                localStorage.removeItem('selectedMikrotikConfigId');
                showNotification('Tidak ada konfigurasi MikroTik yang tersimpan. Silakan tambahkan di Pengaturan API MikroTik.', 'warning');
            }
            // Setelah konfigurasi dimuat dan dipilih, muat data dashboard
            loadDashboardData();

        } catch (error) {
            console.error('Error loading MikroTik configs:', error);
            mikrotikConfigSelect.innerHTML = '<option value="">Gagal memuat konfigurasi</option>';
            mikrotikConfigSelect.disabled = true;
            selectedMikrotikConfigId = null;
            localStorage.removeItem('selectedMikrotikConfigId');
            showNotification('Terjadi kesalahan saat memuat daftar konfigurasi MikroTik.', 'error');
            // Tetap coba muat data dashboard, mungkin ada default MikroTik yang berfungsi
            loadDashboardData();
        }
    }

    // Fungsi untuk memuat semua data dashboard yang bergantung pada MikroTik
    function loadDashboardData() {
        if (!selectedMikrotikConfigId) {
            connectionStatusText.textContent = 'Tidak ada MikroTik yang dipilih.';
            connectionStatusText.className = 'text-warning';
            hotspotActiveCount.innerHTML = `N/A <span style="font-size: 15px;">items</span>`;
            hotspotUsersCount.innerHTML = `N/A <span style="font-size: 15px;">items</span>`;
            todayIncomeElem.textContent = 'N/A';
            monthIncomeElem.textContent = 'N/A';
            allTimeIncomeElem.textContent = 'N/A';
            return;
        }
        fetchMikrotikStatus();
        loadHotspotOverviewCounts();
        loadFinancialSummary();
    }


    // --- Load Mikrotik System Status ---
    function fetchMikrotikStatus() {
        connectionStatusText.textContent = 'Memuat...';
        connectionStatusText.className = 'text-info';

        fetch(`mikrotik_api.php?action=check_status&config_id=${selectedMikrotikConfigId}`)
            .then(response => {
                if (!response.ok) {
                    throw new Error(`HTTP error! Status: ${response.status}`);
                }
                return response.json();
            })
            .then(data => {
                if (data.status === 'success') {
                    connectionStatusText.textContent = 'Terhubung';
                    connectionStatusText.className = 'text-success';
                    uptimeElem.textContent = data.uptime;
                    freeMemoryElem.textContent = data.free_memory;
                    totalMemoryElem.textContent = data.total_memory;
                    cpuLoadElem.textContent = data.cpu_load;
                    boardNameElem.textContent = data.board_name;
                    versionElem.textContent = data.version;
                } else {
                    connectionStatusText.textContent = `Gagal (${data.message})`;
                    connectionStatusText.className = 'text-danger';
                    uptimeElem.textContent = 'N/A';
                    freeMemoryElem.textContent = 'N/A';
                    totalMemoryElem.textContent = 'N/A';
                    cpuLoadElem.textContent = 'N/A';
                    boardNameElem.textContent = 'N/A';
                    versionElem.textContent = 'N/A';
                    // Using a general notification function if available
                    if (typeof showNotification === 'function') {
                        showNotification(data.message, 'error');
                    } else {
                        console.error('Notification function not found:', data.message);
                    }
                }
            })
            .catch(error => {
                console.error('Error fetching Mikrotik status:', error);
                connectionStatusText.textContent = `Error Koneksi: ${error.message}`;
                connectionStatusText.className = 'text-danger';
                uptimeElem.textContent = 'N/A';
                freeMemoryElem.textContent = 'N/A';
                totalMemoryElem.textContent = 'N/A';
                cpuLoadElem.textContent = 'N/A';
                boardNameElem.textContent = 'N/A';
                versionElem.textContent = 'N/A';
                 if (typeof showNotification === 'function') {
                    showNotification('Terjadi kesalahan saat mengambil status Mikrotik.', 'error');
                }
            });
    }

    // --- Load Hotspot Overview Counts (Active Users & Total Users) ---
    function loadHotspotOverviewCounts() {
        // Fetch active users count
        fetch(`mikrotik_api.php?action=get_hotspot_active_count&config_id=${selectedMikrotikConfigId}`)
            .then(response => response.json())
            .then(data => {
                if (data.status === 'success') {
                    hotspotActiveCount.innerHTML = `${data.count} <span style="font-size: 15px;">${data.count < 2 ? 'item' : 'items'}</span>`;
                } else {
                    hotspotActiveCount.innerHTML = `N/A <span style="font-size: 15px;">items</span>`;
                    console.error('Failed to load active hotspot users count:', data.message);
                }
            })
            .catch(error => {
                hotspotActiveCount.innerHTML = `N/A <span style="font-size: 15px;">items</span>`;
                console.error('Error fetching active hotspot users count:', error);
            });

        // Fetch total hotspot users count
        fetch(`mikrotik_api.php?action=get_hotspot_users_count&config_id=${selectedMikrotikConfigId}`)
            .then(response => response.json())
            .then(data => {
                if (data.status === 'success') {
                    hotspotUsersCount.innerHTML = `${data.count} <span style="font-size: 15px;">${data.count < 2 ? 'item' : 'items'}</span>`;
                } else {
                    hotspotUsersCount.innerHTML = `N/A <span style="font-size: 15px;">items</span>`;
                    console.error('Failed to load total hotspot users count:', data.message);
                }
            })
            .catch(error => {
                hotspotUsersCount.innerHTML = `N/A <span style="font-size: 15px;">items</span>`;
                console.error('Error fetching total hotspot users count:', error);
            });
    }

    // Function to load Financial Summary
    function loadFinancialSummary() {
        todayIncomeElem.textContent = 'Memuat...';
        monthIncomeElem.textContent = 'Memuat...';
        allTimeIncomeElem.textContent = 'Memuat...';

        // Data keuangan tidak bergantung pada MikroTik tertentu, jadi tidak perlu config_id
        fetch('mikrotik_api.php?action=get_financial_summary')
            .then(response => {
                if (!response.ok) {
                    throw new Error(`HTTP error! Status: ${response.status}`);
                }
                return response.json();
            })
            .then(data => {
                if (data.status === 'success') {
                    todayIncomeElem.textContent = formatCurrency(data.today_income);
                    monthIncomeElem.textContent = formatCurrency(data.month_income);
                    allTimeIncomeElem.textContent = formatCurrency(data.all_time_income);
                } else {
                    todayIncomeElem.textContent = 'N/A';
                    monthIncomeElem.textContent = 'N/A';
                    allTimeIncomeElem.textContent = 'N/A';
                    console.error('Failed to load financial summary:', data.message);
                    if (typeof showNotification === 'function') {
                        showNotification(data.message, 'error');
                    }
                }
            })
            .catch(error => {
                todayIncomeElem.textContent = 'Error';
                monthIncomeElem.textContent = 'Error';
                allTimeIncomeElem.textContent = 'Error';
                console.error('Error fetching financial summary:', error);
                if (typeof showNotification === 'function') {
                    showNotification('Terjadi kesalahan saat mengambil ringkasan keuangan.', 'error');
                }
            });
    }

    // Event Listeners
    if (mikrotikConfigSelect) {
        mikrotikConfigSelect.addEventListener('change', function() {
            selectedMikrotikConfigId = this.value;
            localStorage.setItem('selectedMikrotikConfigId', selectedMikrotikConfigId);
            loadDashboardData(); // Muat ulang semua data dashboard dengan konfigurasi baru
        });
    }

    if (refreshStatusBtn) {
        refreshStatusBtn.addEventListener('click', fetchMikrotikStatus);
    }
    
    if (refreshFinancialBtnSmall) {
        refreshFinancialBtnSmall.addEventListener('click', loadFinancialSummary);
    }

    // Hapus baris auto-refresh di sini:
    // setInterval(fetchMikrotikStatus, 10000);
    // setInterval(loadHotspotOverviewCounts, 15000);
    // setInterval(loadFinancialSummary, 30000);

    // Initial load of configurations
    loadMikrotikConfigs();
});
</script>

<?php include '../includes/footer.php'; ?>