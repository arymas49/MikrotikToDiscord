<?php
// C:\xampp\htdocs\billing_isp_app\pages\mikrotik_hotspot_users.php

ini_set('session.use_strict_mode', 1);
ini_set('session.cookie_httponly', 1);
ini_set('session.cookie_samesite', 'Lax');
if (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on') {
    ini_set('session.cookie_secure', 1);
}
session_start();
include '../config/koneksi.php';
include '../includes/header.php';

// Pastikan user memiliki role yang sesuai (misal: superadmin atau teknisi)
if (!hasRole(['superadmin', 'teknisi'])) {
    echo "<script>
            alert('Anda tidak memiliki akses ke halaman ini.');
            window.location.href = '../pages/dashboard.php';
          </script>";
    exit();
}
?>

<div class="main-content">
    <div class="page-header">
        <h1>Manajemen Hotspot Users</h1>
        <p>Kelola pengguna hotspot Mikrotik dan buat voucher.</p>
    </div>

    <div class="container">
        <div class="card mb-4">
            <div class="card-header">
                <h3>Buat Voucher Hotspot Baru</h3>
            </div>
            <div class="card-body">
                <form id="generateVoucherForm">
                    <div class="form-group">
                        <label for="voucher_count">Jumlah Voucher:</label>
                        <input type="number" id="voucher_count" name="jumlah" class="form-control" value="1" min="1" required>
                    </div>
                    <div class="form-group">
                        <label for="voucher_profile">Profile Hotspot:</label>
                        <select id="voucher_profile" name="profile" class="form-control" required>
                            <option value="">Pilih Profile</option>
                            <!-- Options will be loaded via JavaScript -->
                        </select>
                    </div>
                    <div class="form-group">
                        <label for="char_length">Panjang Karakter (Username/Password):</label>
                        <input type="number" id="char_length" name="panjang_karakter" class="form-control" value="5" min="3" max="10" required>
                    </div>
                    <div class="form-group">
                        <label for="voucher_prefix">Awalan Voucher (Opsional):</label>
                        <input type="text" id="voucher_prefix" name="awalan" class="form-control" placeholder="Contoh: VC-">
                    </div>
                    <button type="submit" class="btn btn-primary"><i class="fas fa-plus-circle"></i> Buat Voucher</button>
                </form>
                <div id="voucherOutput" class="mt-4" style="display: none;">
                    <h4>Voucher yang Dibuat:</h4>
                    <table class="table table-bordered table-striped">
                        <thead>
                            <tr>
                                <th>Username</th>
                                <th>Password</th>
                                <th>Profile</th>
                            </tr>
                        </thead>
                        <tbody id="voucherTableBody">
                            <!-- Vouchers will be inserted here -->
                        </tbody>
                    </table>
                    <button class="btn btn-secondary mt-3" onclick="printVouchers()"><i class="fas fa-print"></i> Cetak Voucher</button>
                </div>
            </div>
        </div>

        <div class="card">
            <div class="card-header">
                <h3>Daftar Pengguna Hotspot</h3>
            </div>
            <div class="card-body">
                <button id="refreshUsersBtn" class="btn btn-info mb-3"><i class="fas fa-sync-alt"></i> Refresh Daftar Pengguna</button>
                <div class="table-responsive">
                    <table class="table table-bordered table-striped" id="hotspotUsersTable">
                        <thead>
                            <tr>
                                <th>No</th>
                                <th>Username</th>
                                <th>Password</th>
                                <th>Profile</th>
                                <th>Uptime</th>
                                <th>Bytes In/Out</th>
                                <th>Comment</th>
                                <th>Aksi</th>
                            </tr>
                        </thead>
                        <tbody id="hotspotUsersTableBody">
                            <!-- Hotspot users will be loaded here -->
                            <tr><td colspan="8" class="text-center">Memuat pengguna hotspot...</td></tr>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>

<script>
document.addEventListener('DOMContentLoaded', function() {
    const generateVoucherForm = document.getElementById('generateVoucherForm');
    const voucherProfileSelect = document.getElementById('voucher_profile');
    const voucherOutputDiv = document.getElementById('voucherOutput');
    const voucherTableBody = document.getElementById('voucherTableBody');
    const refreshUsersBtn = document.getElementById('refreshUsersBtn');
    const hotspotUsersTableBody = document.getElementById('hotspotUsersTableBody');

    // --- Load Hotspot Profiles ---
    function loadHotspotProfiles() {
        fetch('mikrotik_api.php?action=get_hotspot_profiles')
            .then(response => response.json())
            .then(data => {
                if (data.status === 'success') {
                    voucherProfileSelect.innerHTML = '<option value="">Pilih Profile</option>';
                    data.profiles.forEach(profile => {
                        const option = document.createElement('option');
                        option.value = profile;
                        option.textContent = profile;
                        voucherProfileSelect.appendChild(option);
                    });
                } else {
                    showNotification('Gagal memuat profil hotspot: ' + data.message, 'error');
                }
            })
            .catch(error => {
                console.error('Error loading hotspot profiles:', error);
                showNotification('Terjadi kesalahan saat memuat profil hotspot.', 'error');
            });
    }

    // --- Load Hotspot Users ---
    function loadHotspotUsers() {
        hotspotUsersTableBody.innerHTML = '<tr><td colspan="8" class="text-center"><i class="fas fa-spinner fa-spin"></i> Memuat pengguna hotspot...</td></tr>';
        fetch('mikrotik_api.php?action=get_hotspot_users')
            .then(response => response.json())
            .then(data => {
                if (data.status === 'success') {
                    hotspotUsersTableBody.innerHTML = ''; // Clear existing rows
                    if (data.users.length > 0) {
                        data.users.forEach((user, index) => {
                            const row = document.createElement('tr');
                            row.innerHTML = `
                                <td>${index + 1}</td>
                                <td>${user.name || 'N/A'}</td>
                                <td>${user.password || 'N/A'}</td>
                                <td>${user.profile || 'N/A'}</td>
                                <td>${user.uptime || 'N/A'}</td>
                                <td>${formatBytes(user['bytes-in'] || 0)} / ${formatBytes(user['bytes-out'] || 0)}</td>
                                <td>${user.comment || ''}</td>
                                <td>
                                    <button class="btn btn-danger btn-sm delete-user-btn" data-id="${user['.id']}"><i class="fas fa-trash"></i> Hapus</button>
                                </td>
                            `;
                            hotspotUsersTableBody.appendChild(row);
                        });
                        attachDeleteListeners();
                    } else {
                        hotspotUsersTableBody.innerHTML = '<tr><td colspan="8" class="text-center">Tidak ada pengguna hotspot.</td></tr>';
                    }
                } else {
                    hotspotUsersTableBody.innerHTML = `<tr><td colspan="8" class="text-center text-danger">Gagal memuat pengguna: ${data.message}</td></tr>`;
                    showNotification('Gagal memuat pengguna hotspot: ' + data.message, 'error');
                }
            })
            .catch(error => {
                console.error('Error loading hotspot users:', error);
                hotspotUsersTableBody.innerHTML = `<tr><td colspan="8" class="text-center text-danger">Terjadi kesalahan saat memuat pengguna hotspot: ${error.message}</td></tr>`;
                showNotification('Terjadi kesalahan saat memuat pengguna hotspot.', 'error');
            });
    }

    // --- Generate Voucher Form Submission ---
    if (generateVoucherForm) {
        generateVoucherForm.addEventListener('submit', function(e) {
            e.preventDefault();
            showLoadingOverlay();

            const formData = new FormData(this);
            const jsonData = {};
            formData.forEach((value, key) => {
                jsonData[key] = value;
            });

            fetch('mikrotik_api.php?action=generate_voucher', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify(jsonData)
            })
            .then(response => response.json())
            .then(data => {
                hideLoadingOverlay();
                if (data.status === 'success') {
                    showNotification(data.message, 'success');
                    voucherOutputDiv.style.display = 'block';
                    voucherTableBody.innerHTML = '';
                    data.vouchers.forEach(voucher => {
                        const row = document.createElement('tr');
                        row.innerHTML = `
                            <td>${voucher.username}</td>
                            <td>${voucher.password}</td>
                            <td>${voucher.profile}</td>
                        `;
                        voucherTableBody.appendChild(row);
                    });
                    loadHotspotUsers(); // Refresh the user list after generating
                } else {
                    showNotification('Gagal membuat voucher: ' + data.message, 'error');
                    voucherOutputDiv.style.display = 'none';
                }
            })
            .catch(error => {
                hideLoadingOverlay();
                console.error('Error generating voucher:', error);
                showNotification('Terjadi kesalahan jaringan atau server saat membuat voucher: ' + error.message, 'error');
                voucherOutputDiv.style.display = 'none';
            });
        });
    }

    // --- Delete User Functionality ---
    function attachDeleteListeners() {
        document.querySelectorAll('.delete-user-btn').forEach(button => {
            button.addEventListener('click', function() {
                const userId = this.dataset.id;
                showCustomConfirm('Konfirmasi Hapus', 'Apakah Anda yakin ingin menghapus pengguna hotspot ini?', (result) => {
                    if (result) {
                        showLoadingOverlay();
                        fetch('mikrotik_api.php?action=remove_hotspot_user', {
                            method: 'POST',
                            headers: {
                                'Content-Type': 'application/json'
                            },
                            body: JSON.stringify({ id: userId })
                        })
                        .then(response => response.json())
                        .then(data => {
                            hideLoadingOverlay();
                            if (data.status === 'success') {
                                showNotification(data.message, 'success');
                                loadHotspotUsers(); // Refresh the user list
                            } else {
                                showNotification('Gagal menghapus user: ' + data.message, 'error');
                            }
                        })
                        .catch(error => {
                            hideLoadingOverlay();
                            console.error('Error deleting user:', error);
                            showNotification('Terjadi kesalahan jaringan atau server saat menghapus user: ' + error.message, 'error');
                        });
                    }
                });
            });
        });
    }

    // --- Print Vouchers Function ---
    window.printVouchers = function() {
        const printContent = document.getElementById('voucherTableBody').outerHTML;
        const printWindow = window.open('', '_blank');
        printWindow.document.write('<html><head><title>Cetak Voucher Hotspot</title>');
        printWindow.document.write('<style>');
        printWindow.document.write(`
            body { font-family: 'Inter', sans-serif; margin: 20px; }
            table { width: 100%; border-collapse: collapse; margin-bottom: 20px; }
            th, td { border: 1px solid #ddd; padding: 8px; text-align: left; }
            th { background-color: #f2f2f2; }
            h4 { text-align: center; margin-bottom: 20px; }
            .voucher-card {
                border: 1px solid #ccc;
                padding: 15px;
                margin: 10px;
                width: calc(33% - 20px); /* 3 cards per row */
                display: inline-block;
                box-sizing: border-box;
                vertical-align: top;
                text-align: center;
                border-radius: 8px;
                box-shadow: 0 2px 4px rgba(0,0,0,0.1);
            }
            @media print {
                .voucher-card {
                    width: calc(50% - 20px); /* 2 cards per row on print */
                }
            }
        `);
        printWindow.document.write('</style></head><body>');
        printWindow.document.write('<h4>Daftar Voucher Hotspot</h4>');
        printWindow.document.write('<div style="display: flex; flex-wrap: wrap; justify-content: flex-start;">');

        const voucherRows = voucherTableBody.querySelectorAll('tr');
        voucherRows.forEach(row => {
            const username = row.cells[0].textContent;
            const password = row.cells[1].textContent;
            const profile = row.cells[2].textContent;
            printWindow.document.write(`
                <div class="voucher-card">
                    <h3>Voucher Hotspot</h3>
                    <p><strong>Username:</strong> ${username}</p>
                    <p><strong>Password:</strong> ${password}</p>
                    <p><strong>Profile:</strong> ${profile}</p>
                </div>
            `);
        });

        printWindow.document.write('</div>');
        printWindow.document.write('</body></html>');
        printWindow.document.close();
        printWindow.print();
    };


    // Helper function to format bytes (replicated from mikrotik_api.php for client-side display)
    function formatBytes(bytes, precision = 2) {
        const units = ['B', 'KB', 'MB', 'GB', 'TB'];
        bytes = Math.max(bytes, 0);
        const pow = Math.floor((bytes ? Math.log(bytes) : 0) / Math.log(1024));
        const p = Math.min(pow, units.length - 1);
        bytes /= (1 << (10 * p));
        return Math.round(bytes, precision) + ' ' + units[p];
    }

    // Initial loads
    loadHotspotProfiles();
    loadHotspotUsers();

    // Refresh users button listener
    if (refreshUsersBtn) {
        refreshUsersBtn.addEventListener('click', loadHotspotUsers);
    }
});
</script>

<style>
/* Add any specific styles for this page here */
.mikrotik-info-grid {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
    gap: 15px;
}
.mikrotik-info-grid .info-item {
    padding: 10px 0;
    border-bottom: 1px solid #eee;
    display: flex;
    justify-content: space-between;
    align-items: center;
}
.mikrotik-info-grid .info-item:last-child {
    border-bottom: none;
}
</style>

<?php include '../includes/footer.php'; ?>