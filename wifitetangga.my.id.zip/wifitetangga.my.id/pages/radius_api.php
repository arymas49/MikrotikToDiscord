<?php
// C:\xampp\htdocs\billing_isp_app\api\radius_api.php
// Ini adalah endpoint API yang akan dihubungi oleh Mikrotik Anda.

// Error reporting untuk debugging
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

// Sertakan file konfigurasi database dan fungsi
require_once __DIR__ . '/../config/koneksi.php';
// require_once __DIR__ . '/../includes/functions.php'; // Baris ini dikomentari jika fungsi sudah di header.php

// Ambil IP address dari Mikrotik yang melakukan request
$request_ip = $_SERVER['REMOTE_ADDR'];

// Dapatkan shared secret dari database berdasarkan IP yang melakukan request
$current_mikrotik_config = null;
try {
    // Menggunakan tabel 'radius_configs' dan mencari berdasarkan 'ip_address'
    $stmt = $koneksi->prepare("SELECT id, name, ip_address, shared_secret FROM radius_configs WHERE ip_address = ? LIMIT 1");
    if ($stmt) {
        $stmt->bind_param("s", $request_ip);
        $stmt->execute();
        $result = $stmt->get_result();
        $current_mikrotik_config = $result->fetch_assoc();
        $stmt->close();
    }
} catch (Exception $e) {
    error_log("Error fetching RADIUS config for API (IP: {$request_ip}): " . $e->getMessage());
    // Lanjutkan, tapi tidak akan bisa memverifikasi shared secret dengan benar
}

// Jika konfigurasi Mikrotik tidak ditemukan, tolak akses
if (!$current_mikrotik_config) {
    error_log("RADIUS API: Unauthorized access from IP: {$request_ip}. Configuration not found.");
    http_response_code(403); // Forbidden
    die("UNAUTHORIZED_ACCESS");
}

$stored_shared_secret = $current_mikrotik_config['shared_secret'];
$mikrotik_id_for_session = $current_mikrotik_config['id']; // ID konfigurasi MikroTik


header('Content-Type: text/plain');

// ==============================================================================
// PENTING: Implementasi RADIUS sesungguhnya memerlukan pemahaman protokol RADIUS (RFC 2865, 2866).
// Ini melibatkan:
// 1. Mendengarkan port UDP 1812 (Authentication) dan 1813 (Accounting).
// 2. Mem-parsing paket RADIUS (termasuk atribut, authenticator, shared secret hashing).
// 3. Merespons dengan Access-Accept, Access-Reject, atau Access-Challenge.
// 4. Memproses paket Accounting (Start, Stop, Interim-Update).
// 5. Menggunakan Shared Secret untuk memverifikasi Authenticator.
//
// CONTOH INI HANYA UNTUK DEMONSTRASI HTTP POST. Untuk RADIUS UDP sesungguhnya, Anda
// memerlukan library PHP yang menangani protokol RADIUS.
// ==============================================================================

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Asumsi data datang dari body JSON (seperti sebelumnya)
    $input = file_get_contents('php://input');
    $data = json_decode($input, true);

    if (json_last_error() !== JSON_ERROR_NONE) {
        error_log("RADIUS API: Invalid JSON received from {$request_ip}. Error: " . json_last_error_msg());
        echo "INVALID_JSON";
        exit();
    }

    $username = $data['username'] ?? '';
    $password = $data['password'] ?? '';
    $action = $data['action'] ?? ''; // 'authenticate' atau 'accounting_start', 'accounting_stop', 'accounting_update'
    $caller_id = $data['caller_id'] ?? ''; // MAC Address atau IP client
    $session_id = $data['session_id'] ?? ''; // ID sesi untuk akuntansi
    $input_octets = $data['input_octets'] ?? 0;
    $output_octets = $data['output_octets'] ?? 0;
    $session_time = $data['session_time'] ?? 0;

    // Log permintaan untuk debugging
    error_log("RADIUS API Request from {$request_ip} ({$current_mikrotik_config['name']}): " . json_encode($data));

    // Anda mungkin ingin memverifikasi shared secret di sini jika Anda menerapkan mekanisme khusus
    // di atas HTTP POST, tetapi untuk RADIUS UDP sebenarnya, ini adalah bagian dari parsing paket.
    // Untuk tujuan ini, kita berasumsi akses ke endpoint ini sudah diverifikasi oleh IP.
    // Jika Anda ingin shared secret juga dikirim via POST body dan diverifikasi:
    /*
    $received_secret = $data['secret'] ?? '';
    if ($received_secret !== $stored_shared_secret) {
        error_log("RADIUS API: Invalid shared secret from IP: {$request_ip}.");
        echo "AUTH_FAIL";
        exit();
    }
    */

    switch ($action) {
        case 'authenticate':
            // Cari pengguna di database Anda
            try {
                // Asumsi 'users' tabel adalah tempat menyimpan kredensial pelanggan
                $stmt = $koneksi->prepare("SELECT id, username FROM users WHERE username = ? AND password = ? AND role = 'customer' LIMIT 1");
                if ($stmt) {
                    $hashed_password = md5($password); // Asumsi password di-hash MD5
                    $stmt->bind_param("ss", $username, $hashed_password);
                    $stmt->execute();
                    $result = $stmt->get_result();
                    $user = $result->fetch_assoc();
                    $stmt->close();

                    if ($user) {
                        echo "AUTH_OK"; // Mikrotik akan menganggap ini sebagai Access-Accept
                        error_log("Authentication successful for user: " . $username . " from IP: " . $request_ip);
                        // Anda bisa menambahkan logika untuk mengembalikan atribut RADIUS lainnya jika diperlukan
                    } else {
                        echo "AUTH_FAIL"; // Mikrotik akan menganggap ini sebagai Access-Reject
                        error_log("Authentication failed for user: " . $username . " from IP: " . $request_ip);
                    }
                } else {
                    throw new Exception("Failed to prepare statement for authentication: " . $koneksi->error);
                }
            } catch (Exception $e) {
                error_log("Database error during authentication (IP: {$request_ip}): " . $e->getMessage());
                echo "AUTH_ERROR";
            }
            break;

        case 'accounting_start':
            try {
                // Pastikan mikrotik_config_id ada di tabel radius_sessions
                $stmt = $koneksi->prepare("INSERT INTO radius_sessions (username, session_id, ip_address, mikrotik_config_id, start_time) VALUES (?, ?, ?, ?, NOW())");
                if ($stmt) {
                    $stmt->bind_param("sssi", $username, $session_id, $caller_id, $mikrotik_id_for_session);
                    $stmt->execute();
                    $stmt->close();
                    error_log("Accounting Start for user: " . $username . " session: " . $session_id . " from Mikrotik ID: " . $mikrotik_id_for_session);
                    echo "ACC_OK";
                } else {
                    throw new Exception("Failed to prepare statement for accounting start: " . $koneksi->error);
                }
            } catch (Exception $e) {
                error_log("Database error during accounting start (IP: {$request_ip}): " . $e->getMessage());
                echo "ACC_ERROR";
            }
            break;

        case 'accounting_stop':
        case 'accounting_update':
            try {
                $stmt = $koneksi->prepare("UPDATE radius_sessions SET end_time = NOW(), input_octets = ?, output_octets = ?, session_time = ? WHERE session_id = ? AND username = ? AND mikrotik_config_id = ?");
                if ($stmt) {
                    $stmt->bind_param("iiissi", $input_octets, $output_octets, $session_time, $session_id, $username, $mikrotik_id_for_session);
                    $stmt->execute();
                    $stmt->close();
                    error_log("Accounting Update/Stop for user: " . $username . " session: " . $session_id . " octets: " . $input_octets . "/" . $output_octets . " from Mikrotik ID: " . $mikrotik_id_for_session);
                    echo "ACC_OK";
                } else {
                    throw new Exception("Failed to prepare statement for accounting update/stop: " . $koneksi->error);
                }
            } catch (Exception $e) {
                error_log("Database error during accounting update/stop (IP: {$request_ip}): " . $e->getMessage());
                echo "ACC_ERROR";
            }
            break;

        default:
            echo "INVALID_REQUEST";
            error_log("Invalid RADIUS API action received from {$request_ip}: " . $action);
            break;
    }
} else {
    echo "This endpoint requires POST requests with specific parameters. (Simulated RADIUS API)";
}
?>