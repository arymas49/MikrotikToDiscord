<?php
// C:\xampp\htdocs\billing_isp_app\pages\whatsapp_gateway_api_simulator.php
header('Content-Type: application/json');

// --- PENTING: Inisialisasi Sesi di Awal ---
// Ini harus ada di awal file untuk memastikan status perangkat simulasi bisa disimpan antar request.
ini_set('session.use_strict_mode', 1);
ini_set('session.cookie_httponly', 1);
ini_set('session.cookie_samesite', 'Lax');
if (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on') {
    ini_set('session.cookie_secure', 1);
}
session_start();

// --- Konfigurasi API Key Simulasi ---
// PASTIKAN NILAI INI SAMA PERSIS dengan API Key yang Anda masukkan
// dan simpan di halaman pengaturan WhatsApp Gateway Anda.
// Contoh: 'gainl_1zxza1ZbgzkAY9zH' berdasarkan screenshot Anda.
$valid_api_key_for_simulation = 'gainL1zxa1ZbgzkAY9zH'; 

// Ambil status perangkat simulasi dari sesi.
// Jika belum ada di sesi, inisialisasi sebagai 'disconnected'.
$simulated_device_status = $_SESSION['simulated_device_status'] ?? 'disconnected';

// Ambil data POST
$input = json_decode(file_get_contents('php://input'), true);
$action = $input['action'] ?? '';
$received_api_key = $input['api_key'] ?? ''; // Tangkap API Key yang dikirim dari JS

// --- Logika Simulasi ---

// 1. Aksi untuk memeriksa validitas API Key saja
if ($action === 'check_api_key_validity') {
    if (!empty($received_api_key) && $received_api_key === $valid_api_key_for_simulation) {
        echo json_encode(['status' => 'valid', 'message' => 'API Key valid.']);
    } else {
        echo json_encode(['status' => 'invalid', 'message' => 'API Key tidak valid atau kosong.']);
    }
} 
// 2. Aksi untuk memeriksa status perangkat (terpisah dari validitas API Key)
elseif ($action === 'check_device_status') {
    // Pertama, cek apakah API Key yang diterima valid
    if ($received_api_key !== $valid_api_key_for_simulation) {
        // Jika API Key tidak valid, perangkat dianggap terputus
        echo json_encode(['status' => 'disconnected', 'message' => 'Perangkat terputus: API Key tidak valid.']);
    } else {
        // Jika API Key valid, kembalikan status yang disimpan di sesi
        echo json_encode(['status' => $simulated_device_status, 'message' => 'Status perangkat dari simulasi sesi.']);
    }
}
// 3. Aksi untuk mendapatkan QR Code
elseif ($action === 'get_qr') {
    // Validasi API Key dulu
    if ($received_api_key !== $valid_api_key_for_simulation) {
        echo json_encode(['status' => 'failed', 'message' => 'Untuk mendapatkan QR Code, API Key harus valid terlebih dahulu.']);
    } 
    // Lalu cek status perangkat yang disimulasikan
    elseif ($simulated_device_status === 'connected') { 
        echo json_encode(['status' => 'failed', 'message' => 'Perangkat sudah terhubung. Tidak perlu QR Code baru.']);
    } else {
        // Set status simulasi di sesi menjadi 'scanning' saat QR diminta
        $_SESSION['simulated_device_status'] = 'scanning';
        $_SESSION['qr_time'] = time(); // Simpan waktu QR diminta untuk potensi otomatis connect

        echo json_encode([
            'status' => 'success',
            // URL QR Code simulasi. Anda bisa ganti dengan URL QR code sungguhan jika Fonnte menyediakannya.
            // Saya menggunakan api.qrserver.com untuk menghasilkan QR code dinamis.
            'qr_code_url' => 'https://api.qrserver.com/v1/create-qr-code/?size=200x200&data=https://wa.me/qr/SIMULATED_DATA_'.uniqid(), 
            'message' => 'Pindai QR code ini.',
            'valid_until' => 30 // QR code ini valid 30 detik
        ]);
    }
} 
// 4. Aksi untuk mengirim pesan tes
elseif ($action === 'test_message') {
    $phone_number = $input['phoneNumber'] ?? '';
    $message_content = $input['message_content'] ?? '';

    // Hanya bisa kirim pesan jika API Key valid dan perangkat terhubung (simulasi)
    if ($received_api_key === $valid_api_key_for_simulation && $simulated_device_status === 'connected' && !empty($phone_number) && !empty($message_content)) {
        echo json_encode(['status' => 'sent', 'message' => 'Pesan simulasi berhasil dikirim.']);
    } else {
        echo json_encode(['status' => 'failed', 'message' => 'Pesan simulasi gagal dikirim. Pastikan API Key valid dan perangkat tersambung.']);
    }
}
// 5. Aksi untuk mengatur status perangkat simulasi secara manual (untuk pengujian)
elseif ($action === 'set_device_status') {
    $new_status = $input['status'] ?? '';
    $allowed_statuses = ['connected', 'scanning', 'disconnected'];

    // Pastikan API Key valid sebelum mengizinkan perubahan status simulasi
    if ($received_api_key !== $valid_api_key_for_simulation) {
        echo json_encode(['status' => 'failed', 'message' => 'Akses ditolak: API Key tidak valid.']);
    } elseif (in_array($new_status, $allowed_statuses)) {
        $_SESSION['simulated_device_status'] = $new_status;
        echo json_encode(['status' => 'success', 'message' => 'Status perangkat simulasi diatur ke ' . $new_status]);
    } else {
        echo json_encode(['status' => 'failed', 'message' => 'Status yang diminta tidak valid.']);
    }
}
// Default jika aksi tidak dikenal
else {
    echo json_encode(['status' => 'error', 'message' => 'Aksi tidak dikenal.']);
}