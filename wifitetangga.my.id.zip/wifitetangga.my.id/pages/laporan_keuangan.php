<?php
// C:\xampp\htdocs\billing_isp_app\pages\laporan_keuangan.php

// PENTING: Aktifkan error reporting secara agresif untuk debugging di hosting
error_reporting(E_ALL);
ini_set('display_errors', 1);

ob_start(); // Mulai output buffering untuk menangkap output yang tidak diinginkan
ini_set('session.use_strict_mode', 1);
ini_set('session.cookie_httponly', 1);
ini_set('session.cookie_samesite', 'Lax');
if (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on') {
    ini_set('session.cookie_secure', 1);
}
session_start();
include '../config/koneksi.php';
include '../includes/header.php'; // Meng-include sidebar dan fungsi hasRole()

// Sertakan Dompdf Autoloader
require_once __DIR__ . '/../vendor/autoload.php';
use Dompdf\Dompdf;
use Dompdf\Options;

// Batasi akses ke halaman ini: hanya superadmin dan admin
if (!hasRole(['superadmin', 'admin'])) {
    header('Location: dashboard.php');
    exit();
}

$message = '';
$report_data = [];
$report_type = $_GET['report_type'] ?? 'bulanan'; // Default: bulanan
$filter_date_daily = $_GET['filter_date_daily'] ?? date('Y-m-d');
$filter_month_monthly = $_GET['filter_month_monthly'] ?? date('m');
$filter_year_monthly = $_GET['filter_year_monthly'] ?? date('Y');
$filter_year_yearly = $_GET['filter_year_yearly'] ?? date('Y');

// Dapatkan app_base_url untuk logo di PDF
$whatsapp_config_path = '../config/whatsapp_config.php';
$whatsapp_config = [];
if (file_exists($whatsapp_config_path)) {
    $whatsapp_config = include $whatsapp_config_path;
}

// ==============================================================================
// === BAGIAN KRUSIAL: URL INI DISESUAIKAN DENGAN DOMAIN ANDA ================
// ==============================================================================
// Domain Anda adalah pay.triplezhinetwork.id
// Asumsi aplikasi Anda berada langsung di root domain ini, atau di subfolder "billing_isp_app".
// Jika aplikasi Anda diakses dari: https://pay.triplezhinetwork.id/
$app_base_url = 'https://pay.triplezhinetwork.id';

// Jika aplikasi Anda diakses dari: https://pay.triplezhinetwork.id/billing_isp_app/
// $app_base_url = 'https://pay.triplezhinetwork.id/billing_isp_app';


// Mendefinisikan jalur fisik (server-side path) ke root aplikasi
// realpath(__DIR__ . '/../') akan menunjuk ke direktori 'billing_isp_app'
$app_root_physical_path = realpath(__DIR__ . '/../');
// Mendefinisikan jalur fisik lengkap ke file logo
$logo_full_physical_path = $app_root_physical_path . '/assets/images/Logo-TZN.png';


// Logika untuk mengambil data laporan berdasarkan tipe
function getFinancialData($koneksi, $report_type, $filter_params) {
    $data = [];
    
    $query_pemasukan_isp_base = "SELECT SUM(jumlah_bayar) AS total_amount FROM pembayaran WHERE status_pembayaran = 'Lunas'";
    $query_pemasukan_manual_base = "SELECT SUM(jumlah_bayar_manual) AS total_amount FROM tagihan_manual WHERE status_tagihan = 'Lunas'";
    $query_pengeluaran_base = "SELECT SUM(jumlah) AS total_amount FROM pengeluaran WHERE 1=1";

    $pemasukan_isp = 0;
    $pemasukan_manual = 0;
    $pengeluaran = 0;

    $stmt_isp = null;
    $stmt_manual = null;
    $stmt_pengeluaran = null;

    if ($report_type === 'harian') {
        $date = $filter_params['date'];
        $period_label = date('d F Y', strtotime($date));

        // Pemasukan ISP
        $stmt_isp = $koneksi->prepare($query_pemasukan_isp_base . " AND tanggal_bayar = ?");
        $stmt_isp->bind_param("s", $date);
        $stmt_isp->execute();
        $res_isp = $stmt_isp->get_result()->fetch_assoc();
        $pemasukan_isp = $res_isp['total_amount'] ?? 0;

        // Pemasukan Manual
        $stmt_manual = $koneksi->prepare($query_pemasukan_manual_base . " AND tanggal_bayar_manual = ?");
        $stmt_manual->bind_param("s", $date);
        $stmt_manual->execute();
        $res_manual = $stmt_manual->get_result()->fetch_assoc();
        $pemasukan_manual = $res_manual['total_amount'] ?? 0;

        // Pengeluaran
        $stmt_pengeluaran = $koneksi->prepare($query_pengeluaran_base . " AND tanggal_pengeluaran = ?");
        $stmt_pengeluaran->bind_param("s", $date);
        $stmt_pengeluaran->execute();
        $res_pengeluaran = $stmt_pengeluaran->get_result()->fetch_assoc();
        $pengeluaran = $res_pengeluaran['total_amount'] ?? 0;

        $data[] = [
            'period' => $period_label,
            'pemasukan_isp' => $pemasukan_isp,
            'pemasukan_manual' => $pemasukan_manual,
            'pengeluaran' => $pengeluaran,
            'total_pemasukan' => $pemasukan_isp + $pemasukan_manual,
            'balance' => ($pemasukan_isp + $pemasukan_manual) - $pengeluaran
        ];

    } elseif ($report_type === 'mingguan') {
        $start_date = $filter_params['start_date'] ?? date('Y-m-d');
        $end_date = date('Y-m-d', strtotime($start_date . ' +6 days'));
        $period_label = date('d M Y', strtotime($start_date)) . ' - ' . date('d M Y', strtotime($end_date));

        // Pemasukan ISP
        $stmt_isp = $koneksi->prepare($query_pemasukan_isp_base . " AND tanggal_bayar BETWEEN ? AND ?");
        $stmt_isp->bind_param("ss", $start_date, $end_date);
        $stmt_isp->execute();
        $res_isp = $stmt_isp->get_result()->fetch_assoc();
        $pemasukan_isp = $res_isp['total_amount'] ?? 0;

        // Pemasukan Manual
        $stmt_manual = $koneksi->prepare($query_pemasukan_manual_base . " AND tanggal_bayar_manual BETWEEN ? AND ?");
        $stmt_manual->bind_param("ss", $start_date, $end_date);
        $stmt_manual->execute();
        $res_manual = $stmt_manual->get_result()->fetch_assoc();
        $pemasukan_manual = $res_manual['total_amount'] ?? 0;

        // Pengeluaran
        $stmt_pengeluaran = $koneksi->prepare($query_pengeluaran_base . " AND tanggal_pengeluaran BETWEEN ? AND ?");
        $stmt_pengeluaran->bind_param("ss", $start_date, $end_date);
        $stmt_pengeluaran->execute();
        $res_pengeluaran = $stmt_pengeluaran->get_result()->fetch_assoc();
        $pengeluaran = $res_pengeluaran['total_amount'] ?? 0;

        $data[] = [
            'period' => $period_label,
            'pemasukan_isp' => $pemasukan_isp,
            'pemasukan_manual' => $pemasukan_manual,
            'pengeluaran' => $pengeluaran,
            'total_pemasukan' => $pemasukan_isp + $pemasukan_manual,
            'balance' => ($pemasukan_isp + $pemasukan_manual) - $pengeluaran
        ];

    } elseif ($report_type === 'bulanan') {
        $month = $filter_params['month'];
        $year = $filter_params['year'];
        $period_label = date('F Y', mktime(0, 0, 0, $month, 1, $year));

        // Pemasukan ISP
        $stmt_isp = $koneksi->prepare($query_pemasukan_isp_base . " AND MONTH(tanggal_bayar) = ? AND YEAR(tanggal_bayar) = ?");
        $stmt_isp->bind_param("ii", $month, $year);
        $stmt_isp->execute();
        $res_isp = $stmt_isp->get_result()->fetch_assoc();
        $pemasukan_isp = $res_isp['total_amount'] ?? 0;

        // Pemasukan Manual
        $stmt_manual = $koneksi->prepare($query_pemasukan_manual_base . " AND MONTH(tanggal_bayar_manual) = ? AND YEAR(tanggal_bayar_manual) = ?");
        $stmt_manual->bind_param("ii", $month, $year);
        $stmt_manual->execute();
        $res_manual = $stmt_manual->get_result()->fetch_assoc();
        $pemasukan_manual = $res_manual['total_amount'] ?? 0;

        // Pengeluaran
        $stmt_pengeluaran = $koneksi->prepare($query_pengeluaran_base . " AND MONTH(tanggal_pengeluaran) = ? AND YEAR(tanggal_pengeluaran) = ?");
        $stmt_pengeluaran->bind_param("ii", $month, $year);
        $stmt_pengeluaran->execute();
        $res_pengeluaran = $stmt_pengeluaran->get_result()->fetch_assoc();
        $pengeluaran = $res_pengeluaran['total_amount'] ?? 0;

        $data[] = [
            'period' => $period_label,
            'pemasukan_isp' => $pemasukan_isp,
            'pemasukan_manual' => $pemasukan_manual,
            'pengeluaran' => $pengeluaran,
            'total_pemasukan' => $pemasukan_isp + $pemasukan_manual,
            'balance' => ($pemasukan_isp + $pemasukan_manual) - $pengeluaran
        ];

    } elseif ($report_type === 'tahunan') {
        $year = $filter_params['year'];
        $period_label = $year;

        // Pemasukan ISP
        $stmt_isp = $koneksi->prepare($query_pemasukan_isp_base . " AND YEAR(tanggal_bayar) = ?");
        $stmt_isp->bind_param("i", $year);
        $stmt_isp->execute();
        $res_isp = $stmt_isp->get_result()->fetch_assoc();
        $pemasukan_isp = $res_isp['total_amount'] ?? 0;

        // Pemasukan Manual
        $stmt_manual = $koneksi->prepare($query_pemasukan_manual_base . " AND YEAR(tanggal_bayar_manual) = ?");
        $stmt_manual->bind_param("i", $year);
        $stmt_manual->execute();
        $res_manual = $stmt_manual->get_result()->fetch_assoc();
        $pemasukan_manual = $res_manual['total_amount'] ?? 0;

        // Pengeluaran
        $stmt_pengeluaran = $koneksi->prepare($query_pengeluaran_base . " AND YEAR(tanggal_pengeluaran) = ?");
        $stmt_pengeluaran->bind_param("i", $year);
        $stmt_pengeluaran->execute();
        $res_pengeluaran = $stmt_pengeluaran->get_result()->fetch_assoc();
        $pengeluaran = $res_pengeluaran['total_amount'] ?? 0;

        $data[] = [
            'period' => $period_label,
            'pemasukan_isp' => $pemasukan_isp,
            'pemasukan_manual' => $pemasukan_manual,
            'pengeluaran' => $pengeluaran,
            'total_pemasukan' => $pemasukan_isp + $pemasukan_manual,
            'balance' => ($pemasukan_isp + $pemasukan_manual) - $pengeluaran
        ];
    }

    $stmt_isp?->close();
    $stmt_manual?->close();
    $stmt_pengeluaran?->close();

    return $data;
}


// Ambil parameter filter
$filter_params = [];
switch ($report_type) {
    case 'harian':
        $filter_params['date'] = $_GET['filter_date_daily'] ?? date('Y-m-d');
        break;
    case 'mingguan':
        $filter_params['start_date'] = $_GET['filter_date_weekly'] ?? date('Y-m-d');
        break;
    case 'bulanan':
        $filter_params['month'] = $_GET['filter_month_monthly'] ?? date('m');
        $filter_params['year'] = $_GET['filter_year_monthly'] ?? date('Y');
        break;
    case 'tahunan':
        $filter_params['year'] = $_GET['filter_year_yearly'] ?? date('Y');
        break;
}

$report_data = getFinancialData($koneksi, $report_type, $filter_params);


// Logic to handle PDF printing
$is_pdf_request = isset($_GET['action']) && $_GET['action'] === 'print_pdf';
$pdf_access_token = $whatsapp_config['api_access_token'] ?? 'DEFAULT_TOKEN'; // Ambil dari config

if ($is_pdf_request) {
    // Verifikasi token akses API untuk permintaan PDF
    if (!isset($_GET['token']) || $_GET['token'] !== $pdf_access_token) {
        ob_end_clean(); // Hentikan dan bersihkan buffering
        die("Akses ditolak. Token tidak valid atau tidak ada.");
    }

    $options = new Options();
    $options->set('isHtml5ParserEnabled', true);
    $options->set('isRemoteEnabled', true); // Penting untuk memuat gambar dari URL
    // Set chroot ke root aplikasi Anda (folder 'billing_isp_app')
    $options->set('chroot', $app_root_physical_path); // Menggunakan variabel yang sudah didefinisikan di atas

    $dompdf = new Dompdf($options);

    // Tambahkan callback untuk logging error gambar Dompdf
    $dompdf->setCallbacks(['event' => function ($event, $dompdf) {
        if ($event instanceof \Dompdf\Event\ImageNotFoundEvent) {
            // Ini akan mencatat error ke log server PHP (misalnya: error_log di folder Anda)
            error_log("Dompdf Image Error (Callback): " . $event->getMessage() . " Path: " . $event->getPath());
            // Anda bisa juga menampilkan pesan error di PDF itu sendiri untuk debugging visual (opsional)
            // $dompdf->output_html .= "<div style='color:red; text-align:center; font-size: 8px;'>Error loading logo: " . htmlspecialchars($event->getMessage()) . "</div>";
        }
    }]);

    // Render HTML bagian laporan ke PDF
    ob_start(); // Mulai output buffering untuk template PDF
    // Variabel $logo_full_physical_path akan tersedia untuk template
    include 'laporan_keuangan_pdf_template.php'; // Template khusus untuk PDF
    $html = ob_get_clean();

    // --- DEBUGGING HTML (UNCOMMENT UNTUK MELIHAT HTML MENTAH) ---
    // Jika Anda ingin melihat HTML yang di-render Dompdf di browser:
    // echo $html;
    // exit;
    // --- END DEBUGGING HTML ---

    $dompdf->loadHtml($html);
    $dompdf->setPaper('A4', 'portrait');

    try {
        $dompdf->render();
    } catch (Exception $e) {
        // Tangkap dan tampilkan error render Dompdf
        ob_end_clean();
        die("Dompdf rendering error: " . $e->getMessage() . "<br> Trace: " . $e->getTraceAsString());
    }

    // Pastikan tidak ada output lain setelah ini
    ob_end_clean(); // Bersihkan semua buffer output sebelum stream PDF

    $dompdf->stream("Laporan_Keuangan_" . $report_type . "_" . date('Ymd') . ".pdf", array("Attachment" => false));
    exit();
}
// End of PDF printing logic


// --- HTML Report Display (Bagian ini tidak berubah, hanya untuk tampilan di browser) ---
?>

<div class="main-content">
    <div class="top-header">
        <div class="alert-message">
            Lihat laporan keuangan terperinci berdasarkan periode yang Anda pilih.
        </div>
        <div class="welcome-message">
            <span>Selamat datang, <?php echo htmlspecialchars($_SESSION['username'] ?? 'User'); ?>!</span>
            <a href="../logout.php" class="btn-logout">Logout</a> 
        </div>
    </div>

    <div class="container"> 
        <h2>Laporan Keuangan</h2>

        <div class="card" style="margin-bottom: 20px;">
            <div class="card-header">
                <h3>Filter Laporan</h3>
            </div>
            <div class="card-body">
                <form method="GET" action="laporan_keuangan.php" id="reportFilterForm">
                    <div class="form-group">
                        <label for="report_type">Tipe Laporan:</label>
                        <select id="report_type" name="report_type" onchange="toggleReportFilters()">
                            <option value="harian" <?php echo ($report_type === 'harian') ? 'selected' : ''; ?>>Harian</option>
                            <option value="mingguan" <?php echo ($report_type === 'mingguan') ? 'selected' : ''; ?>>Mingguan</option>
                            <option value="bulanan" <?php echo ($report_type === 'bulanan') ? 'selected' : ''; ?>>Bulanan</option>
                            <option value="tahunan" <?php echo ($report_type === 'tahunan') ? 'selected' : ''; ?>>Tahunan</option>
                        </select>
                    </div>

                    <div id="filter_harian" class="report-filter-group" style="display: <?php echo ($report_type === 'harian') ? 'block' : 'none'; ?>;">
                        <div class="form-group">
                            <label for="filter_date_daily">Tanggal:</label>
                            <input type="date" id="filter_date_daily" name="filter_date_daily" value="<?php echo htmlspecialchars($filter_params['date'] ?? date('Y-m-d')); ?>">
                        </div>
                    </div>

                    <div id="filter_mingguan" class="report-filter-group" style="display: <?php echo ($report_type === 'mingguan') ? 'block' : 'none'; ?>;">
                        <div class="form-group">
                            <label for="filter_date_weekly">Tanggal Mulai Minggu:</label>
                            <input type="date" id="filter_date_weekly" name="filter_date_weekly" value="<?php echo htmlspecialchars($filter_params['start_date'] ?? date('Y-m-d')); ?>">
                            <small>Laporan akan mencakup 7 hari dari tanggal ini.</small>
                        </div>
                    </div>

                    <div id="filter_bulanan" class="report-filter-group" style="display: <?php echo ($report_type === 'bulanan') ? 'block' : 'none'; ?>;">
                        <div class="form-group">
                            <label for="filter_month_monthly">Bulan:</label>
                            <select id="filter_month_monthly" name="filter_month_monthly">
                                <?php 
                                $bulan_array = [1=>'Januari','Februari','Maret','April','Mei','Juni','Juli','Agustus','September','Oktober','November','Desember'];
                                foreach ($bulan_array as $num => $nama) {
                                    $selected = ((int)($filter_params['month'] ?? date('m')) === $num) ? 'selected' : '';
                                    echo "<option value='{$num}' {$selected}>{$nama}</option>";
                                }
                                ?>
                            </select>
                        </div>
                        <div class="form-group">
                            <label for="filter_year_monthly">Tahun:</label>
                            <select id="filter_year_monthly" name="filter_year_monthly">
                                <?php 
                                $current_year = date('Y');
                                for ($year = $current_year; $year >= $current_year - 5; $year--) { 
                                    $selected = ((int)($filter_params['year'] ?? date('Y')) === $year) ? 'selected' : '';
                                    echo "<option value='{$year}' {$selected}>{$year}</option>";
                                }
                                ?>
                            </select>
                        </div>
                    </div>

                    <div id="filter_tahunan" class="report-filter-group" style="display: <?php echo ($report_type === 'tahunan') ? 'block' : 'none'; ?>;">
                        <div class="form-group">
                            <label for="filter_year_yearly">Tahun:</label>
                            <select id="filter_year_yearly" name="filter_year_yearly">
                                <?php 
                                $current_year = date('Y');
                                for ($year = $current_year; $year >= $current_year - 5; $year--) { 
                                    $selected = ((int)($filter_params['year'] ?? date('Y')) === $year) ? 'selected' : '';
                                    echo "<option value='{$year}' {$selected}>{$year}</option>";
                                }
                                ?>
                            </select>
                        </div>
                    </div>
                    
                    <button type="submit" class="btn btn-primary"><i class="fas fa-filter"></i> Tampilkan Laporan</button>
                    <a href="laporan_keuangan.php" class="btn btn-secondary"><i class="fas fa-redo"></i> Reset Filter</a>
                    <button type="button" class="btn btn-info" onclick="printReport()"><i class="fas fa-print"></i> Cetak Laporan (PDF)</button>
                </form>
            </div>
        </div>

        <div class="card">
            <div class="card-header">
                <h3>Hasil Laporan Keuangan <?php echo htmlspecialchars($report_data[0]['period'] ?? ''); ?></h3>
            </div>
            <div class="card-body">
                <table class="data-table">
                    <thead>
                        <tr>
                            <th>Periode</th>
                            <th>Pemasukan ISP</th>
                            <th>Pemasukan Manual</th>
                            <th>Total Pemasukan</th>
                            <th>Pengeluaran</th>
                            <th>Balance</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if (!empty($report_data)): ?>
                            <?php foreach ($report_data as $row): ?>
                                <tr>
                                    <td><?php echo htmlspecialchars($row['period']); ?></td>
                                    <td>Rp <?php echo number_format($row['pemasukan_isp'], 0, ',', '.'); ?></td>
                                    <td>Rp <?php echo number_format($row['pemasukan_manual'], 0, ',', '.'); ?></td>
                                    <td>Rp <?php echo number_format($row['total_pemasukan'], 0, ',', '.'); ?></td>
                                    <td>Rp <?php echo number_format($row['pengeluaran'], 0, ',', '.'); ?></td>
                                    <td>Rp <?php echo number_format($row['balance'], 0, ',', '.'); ?></td>
                                </tr>
                            <?php endforeach; ?>
                        <?php else: ?>
                            <tr><td colspan="6" style="text-align: center;">Tidak ada data laporan untuk periode ini.</td></tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>

    </div>
</div>

<script>
document.addEventListener('DOMContentLoaded', function() {
    toggleReportFilters(); // Set initial filter visibility

    // Function to toggle filter groups based on selected report type
    function toggleReportFilters() {
        const reportType = document.getElementById('report_type').value;
        document.querySelectorAll('.report-filter-group').forEach(group => {
            group.style.display = 'none';
        });
        document.getElementById(`filter_${reportType}`).style.display = 'block';
    }

    // Function to handle printing/exporting report as PDF
    function printReport() {
        const reportType = document.getElementById('report_type').value;
        const currentForm = document.getElementById('reportFilterForm');
        const urlParams = new URLSearchParams(new FormData(currentForm));
        
        // Add action for PDF and API token
        urlParams.set('action', 'print_pdf');
        urlParams.set('token', '<?php echo htmlspecialchars($whatsapp_config['api_access_token'] ?? 'DEFAULT_TOKEN'); ?>'); // Pastikan token valid

        const printUrl = `laporan_keuangan.php?${urlParams.toString()}`;
        window.open(printUrl, '_blank');
    }

    // Expose printReport to global scope for onclick event
    window.printReport = printReport;
});
</script>

<?php include '../includes/footer.php'; ?>