<?php
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!isset($_POST['csrf_token']) || $_POST['csrf_token'] !== $_SESSION['csrf_token']) {
        die('CSRF validation failed.');
    }
}
?>
<?php
// C:\xampp\htdocs\billing_isp_app\pages\delete_invoice.php

ini_set('session.use_strict_mode', 1);
ini_set('session.cookie_httponly', 1);
ini_set('session.cookie_samesite', 'Lax');
if (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on') {
    ini_set('session.cookie_secure', 1);
}
session_start();
// Sertakan koneksi database
include '../config/koneksi.php';

// Set header agar responsnya JSON
header('Content-Type: application/json');

$response = ['status' => 'error', 'message' => 'Invalid request.'];

// Hanya izinkan POST request
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $tagihan_id = $_POST['id'] ?? null;

    if ($tagihan_id && is_numeric($tagihan_id)) {
        // Mulai transaksi database
        $koneksi->begin_transaction();
        try {
            // Opsional: Hapus entri terkait di tabel pembayaran terlebih dahulu (jika ada foreign key CASCADE DELETE)
            // Jika foreign key di tabel pembayaran ke tagihan diset ON DELETE CASCADE, ini tidak perlu manual
            // Contoh: DELETE FROM pembayaran WHERE id_tagihan = ?;

            // Dapatkan Xendit Invoice ID terkait sebelum menghapus tagihan
            $stmt_xid = $koneksi->prepare("SELECT xendit_invoice_id FROM tagihan WHERE id_tagihan = ?");
            $stmt_xid->bind_param("i", $tagihan_id);
            $stmt_xid->execute();
            $result_xid = $stmt_xid->get_result();
            $tagihan_data = $result_xid->fetch_assoc();
            $stmt_xid->close();

            $xendit_invoice_id = $tagihan_data['xendit_invoice_id'] ?? null;

            // Hapus tagihan dari tabel 'tagihan'
            $stmt = $koneksi->prepare("DELETE FROM tagihan WHERE id_tagihan = ?");
            $stmt->bind_param("i", $tagihan_id);

            if ($stmt->execute()) {
                $koneksi->commit();
                $response = ['status' => 'success', 'message' => 'Invoice ID ' . $tagihan_id . ' berhasil dihapus dari database lokal.', 'xendit_invoice_id' => $xendit_invoice_id];
            } else {
                throw new Exception('Gagal menghapus invoice dari database: ' . $stmt->error);
            }
            $stmt->close();
        } catch (Exception $e) {
            $koneksi->rollback();
            $response = ['status' => 'error', 'message' => 'Kesalahan database: ' . $e->getMessage()];
        }
    } else {
        $response = ['status' => 'error', 'message' => 'ID invoice tidak valid.'];
    }
}

echo json_encode($response);
$koneksi->close();
exit();
?>