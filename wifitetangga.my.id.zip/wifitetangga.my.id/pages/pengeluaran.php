<?php
// C:\xampp\htdocs\billing_isp_app\pages\pengeluaran.php
ini_set('display_errors', 1); // Aktifkan pelaporan error untuk debugging
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

ob_start();
ini_set('session.use_strict_mode', 1);
ini_set('session.cookie_httponly', 1);
ini_set('session.cookie_samesite', 'Lax');
if (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on') {
    ini_set('session.cookie_secure', 1);
}
session_start();
include '../config/koneksi.php';
include '../includes/header.php'; // Header akan meng-include sidebar dan fungsi hasRole()

// Batasi akses: hanya superadmin dan admin yang bisa mengakses halaman ini
if (!hasRole(['superadmin', 'admin'])) {
    header('Location: dashboard.php'); // Redirect ke dashboard atau halaman akses ditolak
    exit();
}

$message = '';
$pengeluaran_id_to_edit = null;
$pengeluaran_data = [];

// --- Menampilkan Pesan Setelah Redirect (GET) ---
if (isset($_GET['msg'])) {
    if ($_GET['msg'] == 'add_success') {
        $message = '<div class="alert alert-success">Pengeluaran berhasil ditambahkan.</div>';
    } elseif ($_GET['msg'] == 'edit_success') {
        $message = '<div class="alert alert-success">Pengeluaran berhasil diperbarui.</div>';
    } elseif ($_GET['msg'] == 'delete_success') {
        $message = '<div class="alert alert-success">Pengeluaran berhasil dihapus.</div>';
    } elseif ($_GET['msg'] == 'delete_fail') {
        $error_detail = $_GET['err'] ?? 'Terjadi kesalahan tidak diketahui.';
        $message = '<div class="alert alert-danger">Gagal menghapus pengeluaran: ' . htmlspecialchars($error_detail) . '</div>';
    }
}


// --- Logika Hapus Pengeluaran ---
if (isset($_GET['action']) && $_GET['action'] == 'delete' && isset($_GET['id'])) {
    if (!hasRole('superadmin')) { // Hanya superadmin yang bisa menghapus
        $message = '<div class="alert alert-danger">Anda tidak memiliki izin untuk menghapus pengeluaran. Hanya Superadmin yang dapat melakukan aksi ini.</div>';
    } else {
        $id_pengeluaran_to_delete = $koneksi->real_escape_string($_GET['id']);
        $stmt = $koneksi->prepare("DELETE FROM pengeluaran WHERE id_pengeluaran = ?");
        $stmt->bind_param("i", $id_pengeluaran_to_delete);
        if ($stmt->execute()) {
            $message = '<div class="alert alert-success">Pengeluaran berhasil dihapus.</div>';
            header('Location: pengeluaran.php?msg=delete_success'); // Redirect setelah hapus
            exit();
        } else {
            $message = '<div class="alert alert-danger">Gagal menghapus pengeluaran: ' . $stmt->error . '</div>';
            header('Location: pengeluaran.php?msg=delete_fail&err=' . urlencode($stmt->error)); // Redirect dengan pesan error
            exit();
        }
        $stmt->close();
    }
}

// --- Logika Tambah/Edit Pengeluaran ---
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $tanggal_pengeluaran = $koneksi->real_escape_string($_POST['tanggal_pengeluaran']);
    $deskripsi = $koneksi->real_escape_string($_POST['deskripsi']);
    $jumlah = $koneksi->real_escape_string($_POST['jumlah']);
    $kategori = $koneksi->real_escape_string($_POST['kategori']);
    $pengeluaran_id = $koneksi->real_escape_string($_POST['pengeluaran_id'] ?? '');
    $dicatat_oleh_user_id = $_SESSION['user_id'] ?? null; // ID user yang sedang login, bisa null jika sesi tidak ada

    // Validasi dasar
    if (empty($tanggal_pengeluaran) || empty($deskripsi) || empty($jumlah)) {
        $message = '<div class="alert alert-danger">Tanggal, Deskripsi, dan Jumlah harus diisi.</div>';
    } elseif (!is_numeric($jumlah) || $jumlah < 0) {
        $message = '<div class="alert alert-danger">Jumlah harus berupa angka positif.</div>';
    } else {
        if (empty($pengeluaran_id)) { // Tambah Pengeluaran Baru
            $stmt = $koneksi->prepare("INSERT INTO pengeluaran (tanggal_pengeluaran, deskripsi, jumlah, kategori, dicatat_oleh_user_id) VALUES (?, ?, ?, ?, ?)");
            $stmt->bind_param("ssdsi", $tanggal_pengeluaran, $deskripsi, $jumlah, $kategori, $dicatat_oleh_user_id); // 'd' for DECIMAL, 'i' for INT
            if ($stmt->execute()) {
                $message = '<div class="alert alert-success">Pengeluaran berhasil ditambahkan.</div>';
                header('Location: pengeluaran.php?msg=add_success'); // Redirect setelah sukses
                exit();
            } else {
                $message = '<div class="alert alert-danger">Gagal menambahkan pengeluaran: ' . $stmt->error . '</div>';
            }
        } else { // Edit Pengeluaran
            $stmt = $koneksi->prepare("UPDATE pengeluaran SET tanggal_pengeluaran = ?, deskripsi = ?, jumlah = ?, kategori = ? WHERE id_pengeluaran = ?");
            $stmt->bind_param("ssdsi", $tanggal_pengeluaran, $deskripsi, $jumlah, $kategori, $pengeluaran_id); // 'd' for DECIMAL, 'i' for INT
            if ($stmt->execute()) {
                $message = '<div class="alert alert-success">Pengeluaran berhasil diperbarui.</div>';
                header('Location: pengeluaran.php?msg=edit_success'); // Redirect setelah sukses
                exit();
            } else {
                $message = '<div class="alert alert-danger">Gagal memperbarui pengeluaran: ' . $stmt->error . '</div>';
            }
        }
        if (isset($stmt) && $stmt instanceof mysqli_stmt) { // Pastikan $stmt terdefinisi sebelum close
            $stmt->close();
        }
    }
}

// --- Logika Ambil Data Untuk Form Edit ---
if (isset($_GET['action']) && $_GET['action'] == 'edit' && isset($_GET['id'])) {
    $pengeluaran_id_to_edit = $koneksi->real_escape_string($_GET['id']);
    $query_edit = $koneksi->query("SELECT * FROM pengeluaran WHERE id_pengeluaran = '$pengeluaran_id_to_edit'");
    if ($query_edit->num_rows > 0) {
        $pengeluaran_data = $query_edit->fetch_assoc();
    } else {
        $message = '<div class="alert alert-danger">Data pengeluaran tidak ditemukan.</div>';
        $pengeluaran_id_to_edit = null;
    }
    $form_should_be_visible = true;
} else {
    $form_should_be_visible = false;
}

// Ambil semua data pengeluaran untuk ditampilkan
$query_pengeluaran_list = "SELECT p.*, u.username as dicatat_oleh_username FROM pengeluaran p LEFT JOIN users u ON p.dicatat_oleh_user_id = u.id ORDER BY tanggal_pengeluaran DESC";
$result_pengeluaran_list = $koneksi->query($query_pengeluaran_list);
?>

<div class="main-content">
    <div class="top-header">
        <div class="alert-message">
            Pemberitahuan: Catat setiap pengeluaran untuk menjaga akurasi laporan keuangan.
        </div>
        <div class="welcome-message">
            <span>Selamat datang, <?php echo htmlspecialchars($_SESSION['username'] ?? 'User'); ?>!</span>
            <a href="../logout.php" class="btn-logout">Logout</a> 
        </div>
    </div>

    <div class="container">
        <h2>Manajemen Pengeluaran</h2>

        <?php echo htmlspecialchars($message, ENT_QUOTES, "UTF-8"); ?>

        <button id="toggleFormBtn" class="btn btn-primary" style="margin-bottom: 20px;">
            <?php echo ($pengeluaran_id_to_edit ? 'Kembali ke Form Edit' : 'Tambah Pengeluaran Baru'); ?>
        </button>

        <div id="formPengeluaranCard" class="card <?php echo $form_should_be_visible ? '' : 'hide-form'; ?>" 
             style="margin-bottom: 20px; <?php echo $form_should_be_visible ? '' : 'display: none;'; ?>">
            <div class="card-header">
                <h3><?php echo ($pengeluaran_id_to_edit ? 'Edit' : 'Tambah'); ?> Pengeluaran</h3>
            </div>
            <div class="card-body">
                <form method="POST"><?php if (!isset($_SESSION['csrf_token'])) { $_SESSION['csrf_token'] = bin2hex(random_bytes(32)); } ?><input type='hidden' name='csrf_token' value='<?php echo $_SESSION['csrf_token']; ?>'>
                    <?php if ($pengeluaran_id_to_edit): ?>
                        <input type="hidden" name="pengeluaran_id" value="<?php echo htmlspecialchars($pengeluaran_data['id_pengeluaran']); ?>">
                    <?php endif; ?>
                    <div class="form-group">
                        <label for="tanggal_pengeluaran">Tanggal Pengeluaran:</label>
                        <input type="date" id="tanggal_pengeluaran" name="tanggal_pengeluaran" value="<?php echo htmlspecialchars($pengeluaran_data['tanggal_pengeluaran'] ?? date('Y-m-d')); ?>" required>
                    </div>
                    <div class="form-group">
                        <label for="deskripsi">Deskripsi:</label>
                        <textarea id="deskripsi" name="deskripsi" required><?php echo htmlspecialchars($pengeluaran_data['deskripsi'] ?? ''); ?></textarea>
                    </div>
                    <div class="form-group">
                        <label for="jumlah">Jumlah (Rp):</label>
                        <input type="number" id="jumlah" name="jumlah" step="0.01" value="<?php echo htmlspecialchars($pengeluaran_data['jumlah'] ?? ''); ?>" required>
                    </div>
                    <div class="form-group">
                        <label for="kategori">Kategori:</label>
                        <input type="text" id="kategori" name="kategori" value="<?php echo htmlspecialchars($pengeluaran_data['kategori'] ?? ''); ?>" placeholder="Contoh: Gaji, Listrik, Hardware">
                    </div>
                    <button type="submit" class="btn btn-primary"><?php echo ($pengeluaran_id_to_edit ? 'Update' : 'Tambah'); ?> Pengeluaran</button>
                    <?php if ($pengeluaran_id_to_edit): ?>
                        <a href="pengeluaran.php" class="btn btn-secondary">Batal Edit</a>
                    <?php endif; ?>
                </form>
            </div>
        </div>

        <div class="card">
            <div class="card-header">
                <h3>Daftar Pengeluaran</h3>
            </div>
            <div class="card-body">
                <table class="data-table">
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>Tanggal</th>
                            <th>Deskripsi</th>
                            <th>Jumlah</th>
                            <th>Kategori</th>
                            <th>Dicatat Oleh</th>
                            <th>Aksi</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if ($result_pengeluaran_list->num_rows > 0): ?>
                            <?php while($row = $result_pengeluaran_list->fetch_assoc()): ?>
                                <tr>
                                    <td><?php echo htmlspecialchars($row['id_pengeluaran']); ?></td>
                                    <td><?php echo htmlspecialchars(date('d-m-Y', strtotime($row['tanggal_pengeluaran']))); ?></td>
                                    <td><?php echo htmlspecialchars($row['deskripsi']); ?></td>
                                    <td>Rp <?php echo number_format($row['jumlah'], 0, ',', '.'); ?></td>
                                    <td><?php echo htmlspecialchars($row['kategori']); ?></td>
                                    <td><?php echo htmlspecialchars($row['dicatat_oleh_username'] ?? 'N/A'); ?></td>
                                    <td>
                                        <a href="pengeluaran.php?action=edit&id=<?php echo $row['id_pengeluaran']; ?>" class="btn-action btn-edit"><i class="fas fa-edit"></i> Edit</a>
                                        <?php if (hasRole('superadmin')): // Tombol Hapus hanya untuk superadmin ?>
                                        <a href="pengeluaran.php?action=delete&id=<?php echo $row['id_pengeluaran']; ?>" class="btn-action btn-delete" onclick="return confirm('Apakah Anda yakin ingin menghapus pengeluaran ini?');"><i class="fas fa-trash-alt"></i> Hapus</a>
                                        <?php endif; ?>
                                    </td>
                                </tr>
                            <?php endwhile; ?>
                        <?php else: ?>
                            <tr><td colspan="7" style="text-align: center;">Belum ada data pengeluaran.</td></tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>

    </div>
</div>

<script>
document.addEventListener('DOMContentLoaded', function() {
    var formCard = document.getElementById('formPengeluaranCard'); 
    var toggleBtn = document.getElementById('toggleFormBtn');
    
    // Safety check: ensure both elements exist
    if (!formCard || !toggleBtn) {
        console.error("Error: formPengeluaranCard or toggleBtn not found. Script cannot proceed.");
        return; 
    }

    var urlParams = new URLSearchParams(window.location.search);
    var isEditMode = urlParams.get('action') === 'edit';

    // ************* INISIALISASI VISIBILITAS FORM DAN TEKS TOMBOL *************
    // Jika ada parameter 'edit' di URL, form harus terlihat.
    // Jika tidak ada 'edit', form harus tersembunyi (baik dari kelas maupun inline style).
    if (isEditMode) {
        formCard.classList.remove('hide-form'); // Pastikan kelas hide-form dihapus
        formCard.style.display = ''; // Hapus inline display none
        toggleBtn.textContent = 'Sembunyikan Form';
    } else {
        formCard.classList.add('hide-form'); // Tambahkan kelas hide-form
        formCard.style.display = 'none'; // Tambahkan inline display none sebagai fallback kuat
        toggleBtn.textContent = 'Tambah Pengeluaran Baru';
    }
    // *************************************************************************

    // Add event listener only once
    if (!toggleBtn._hasClickListener) { 
        toggleBtn.addEventListener('click', function() {
            if (formCard.classList.contains('hide-form')) {
                formCard.classList.remove('hide-form'); // Tampilkan form
                formCard.style.display = ''; // Hapus inline display none
                toggleBtn.textContent = 'Sembunyikan Form';
                formCard.scrollIntoView({ behavior: 'smooth', block: 'start' });
            } else {
                formCard.classList.add('hide-form'); // Sembunyikan form
                formCard.style.display = 'none'; // Tambahkan inline display none
                toggleBtn.textContent = 'Tambah Pengeluaran Baru';
                
                if (!isEditMode) { // Hanya reset form jika bukan mode edit
                    var form = formCard.querySelector('form');
                    if (form) {
                        form.reset();
                        // Reset input date to current date for new entry
                        var tanggalPengeluaranInput = form.querySelector('#tanggal_pengeluaran');
                        if (tanggalPengeluaranInput) {
                            tanggalPengeluaranInput.value = new Date().toISOString().slice(0,10); // Set ke tanggal hari ini
                        }
                        // Reset kategori
                        var kategoriInput = form.querySelector('#kategori');
                        if (kategoriInput) {
                            kategoriInput.value = '';
                        }
                    }
                }
                if (isEditMode) {
                    window.location.href = 'pengeluaran.php'; 
                }
            }
        });
        toggleBtn._hasClickListener = true; 
    }

    // JavaScript untuk menampilkan pesan setelah redirect
    <?php if (isset($_GET['msg'])): ?>
        window.scrollTo({ top: 0, behavior: 'smooth' });
    <?php endif; ?>

});
</script>

<?php include '../includes/footer.php'; ?>