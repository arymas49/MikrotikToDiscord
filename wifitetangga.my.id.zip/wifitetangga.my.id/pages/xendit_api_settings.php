<?php
// C:\xampp\htdocs\billing_isp_app\pages\xendit_api_settings.php

// Pastikan output buffering dimulai di sini sebagai baris pertama
ob_start();

// Aktifkan pelaporan error untuk debugging (atur ke 0 di production)
ini_set('display_errors', 1); // Set to 0 in Production
ini_set('display_startup_errors', 1); // Set to 0 in Production
error_reporting(E_ALL);

ini_set('session.use_strict_mode', 1);
ini_set('session.cookie_httponly', 1);
ini_set('session.cookie_samesite', 'Lax');
if (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on') {
    ini_set('session.cookie_secure', 1);
}
session_start();

// Sertakan file koneksi database
include '../config/koneksi.php';

// Sertakan header (untuk fungsi hasRole, dsb.)
include '../includes/header.php';

// Pastikan hanya superadmin yang bisa mengakses halaman ini
if (!hasRole('superadmin')) {
    header('Location: ' . $base_url_pages . 'dashboard.php'); // Redirect ke dashboard jika tidak punya akses
    exit();
}

$config_file = '../config/xendit_config.php';
$xendit_config = [];

// Baca konfigurasi yang ada
if (file_exists($config_file)) {
    $xendit_config = include $config_file;
} else {
    // Beri nilai default jika file tidak ditemukan
    $xendit_config = [
        'xendit_secret_key' => '',
        'xendit_public_key' => '',
        'xendit_callback_token' => '',
        'base_url' => 'http://localhost/billing_isp_app' // Default, harap sesuaikan
    ];
}

$message = '';
$message_type = ''; // success, error, warning, info

// Tangani POST request untuk menyimpan konfigurasi
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $new_secret_key = $_POST['xendit_secret_key'] ?? '';
    $new_public_key = $_POST['xendit_public_key'] ?? '';
    $new_callback_token = $_POST['xendit_callback_token'] ?? '';
    $new_base_url = $_POST['base_url'] ?? '';

    // Sanitize inputs (basic example, consider more robust sanitization)
    $new_secret_key = htmlspecialchars(trim($new_secret_key), ENT_QUOTES, 'UTF-8');
    $new_public_key = htmlspecialchars(trim($new_public_key), ENT_QUOTES, 'UTF-8');
    $new_callback_token = htmlspecialchars(trim($new_callback_token), ENT_QUOTES, 'UTF-8');
    $new_base_url = htmlspecialchars(trim($new_base_url), ENT_QUOTES, 'UTF-8');

    // Update the config array
    $xendit_config['xendit_secret_key'] = $new_secret_key;
    $xendit_config['xendit_public_key'] = $new_public_key;
    $xendit_config['xendit_callback_token'] = $new_callback_token;
    $xendit_config['base_url'] = $new_base_url;

    // Persiapkan konten file PHP baru
    $file_content = "<?php\n";
    $file_content .= "// " . basename($config_file) . "\n\n";
    $file_content .= "return [\n";
    $file_content .= "    'xendit_secret_key' => '" . $new_secret_key . "',\n";
    $file_content .= "    'xendit_public_key' => '" . $new_public_key . "',\n";
    $file_content .= "    'xendit_callback_token' => '" . $new_callback_token . "',\n";
    $file_content .= "    'base_url' => '" . $new_base_url . "'\n";
    $file_content .= "];\n";
    $file_content .= "?>";

    // Tulis kembali file konfigurasi
    if (file_put_contents($config_file, $file_content) !== false) {
        $message = 'Pengaturan Xendit API berhasil diperbarui!';
        $message_type = 'success';
    } else {
        $message = 'Gagal menyimpan pengaturan Xendit API. Pastikan folder config memiliki izin tulis.';
        $message_type = 'error';
    }
}

// Flush output buffer
ob_end_flush();
?>

<div class="main-content">
    <div class="container">
        <h2><i class="fas fa-cogs"></i> Pengaturan Xendit API</h2>

        <?php if (!empty($message)): ?>
            <div class="alert alert-<?php echo htmlspecialchars($message_type, ENT_QUOTES, "UTF-8"); ?>">
                <?php echo htmlspecialchars($message); ?>
            </div>
        <?php endif; ?>

        <div class="card">
            <div class="card-header">
                <h3>Form Pengaturan Xendit</h3>
            </div>
            <div class="card-body">
                <form action="" method="POST"><?php if (!isset($_SESSION['csrf_token'])) { $_SESSION['csrf_token'] = bin2hex(random_bytes(32)); } ?><input type='hidden' name='csrf_token' value='<?php echo $_SESSION['csrf_token']; ?>'>
                    <div class="form-group">
                        <label for="xendit_secret_key">Xendit Secret Key:</label>
                        <input type="text" id="xendit_secret_key" name="xendit_secret_key"
                               value="<?php echo htmlspecialchars($xendit_config['xendit_secret_key'] ?? ''); ?>"
                               class="form-control" placeholder="sk_test_xxxx atau sk_live_xxxx" required>
                        <small class="form-text text-muted">Gunakan Secret Key Xendit Anda (sk_test_xxxx untuk Development, sk_live_xxxx untuk Production).</small>
                    </div>

                    <div class="form-group">
                        <label for="xendit_public_key">Xendit Public Key:</label>
                        <input type="text" id="xendit_public_key" name="xendit_public_key"
                               value="<?php echo htmlspecialchars($xendit_config['xendit_public_key'] ?? ''); ?>"
                               class="form-control" placeholder="xnd_public_xxxx" required>
                        <small class="form-text text-muted">Public Key Xendit Anda (biasanya dimulai dengan xnd_public_xxxx).</small>
                    </div>

                    <div class="form-group">
                        <label for="xendit_callback_token">Xendit Callback Verification Token:</label>
                        <input type="text" id="xendit_callback_token" name="xendit_callback_token"
                               value="<?php echo htmlspecialchars($xendit_config['xendit_callback_token'] ?? ''); ?>"
                               class="form-control" placeholder="Token acak yang kuat" required>
                        <small class="form-text text-muted">Token acak yang kuat untuk memverifikasi callback dari Xendit. Harus sama dengan yang dikonfigurasi di Dashboard Xendit Anda.</small>
                    </div>

                    <div class="form-group">
                        <label for="base_url">Base URL Aplikasi (untuk Callback):</label>
                        <input type="url" id="base_url" name="base_url"
                               value="<?php echo htmlspecialchars($xendit_config['base_url'] ?? ''); ?>"
                               class="form-control" placeholder="https://yourdomain.com/billing_isp_app" required>
                        <small class="form-text text-muted">URL dasar aplikasi Anda, digunakan oleh Xendit untuk mengirim callback. Contoh: <code>https://yourdomain.com</code></small>
                    </div>

                    <button type="submit" class="btn btn-primary"><i class="fas fa-save"></i> Simpan Pengaturan</button>
                </form>
            </div>
        </div>
    </div>
</div>

<style>
    .main-content input[type="text"],
    .main-content input[type="url"],
    .main-content select,
    .main-content textarea {
        color: #333; /* Warna teks gelap agar terbaca di dalam input */
        background-color: #FFFFFF; /* Latar belakang putih untuk input */
        border: 1px solid #CCCCCC;
        padding: 8px 12px;
        border-radius: 4px;
        width: 100%; /* Lebar penuh */
        box-sizing: border-box; /* Pastikan padding tidak menambah lebar total */
        margin-top: 5px; /* Sedikit jarak dari label */
    }

    .form-group {
        margin-bottom: 20px;
    }

    .form-group label {
        display: block;
        margin-bottom: 5px;
        font-weight: bold;
        color: #FFFFFF; /* Warna label putih */
    }

    .form-text.text-muted {
        font-size: 0.85em;
        color: #b0bec5; /* Warna abu-abu terang untuk teks bantuan */
        margin-top: 5px;
        display: block;
    }

    .btn-primary {
        background-color: #3498db;
        color: white;
        padding: 10px 20px;
        border: none;
        border-radius: 5px;
        cursor: pointer;
        font-size: 1em;
        transition: background-color 0.2s ease;
    }

    .btn-primary:hover {
        background-color: #2980b9;
    }

    .alert {
        padding: 15px;
        margin-bottom: 20px;
        border-radius: 5px;
        font-weight: bold;
        color: #333; /* Default text color for alerts */
    }

    .alert-success {
        background-color: #d4edda;
        border-color: #c3e6cb;
        color: #155724;
    }

    .alert-error {
        background-color: #f8d7da;
        border-color: #f5c6cb;
        color: #721c24;
    }
</style>

<?php include '../includes/footer.php'; // Sertakan footer ?>