<?php
// C:\xampp\htdocs\billing_isp_app\pages\manajemen_radius_pelanggan.php
ini_set('session.use_strict_mode', 1);
ini_set('session.cookie_httponly', 1);
ini_set('session.cookie_samesite', 'Lax');
if (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on') {
    ini_set('session.cookie_secure', 1);
}
session_start();
include '../config/koneksi.php';
include '../includes/header.php';

// Pastikan hanya superadmin yang bisa mengakses
if (!hasRole('superadmin')) {
    header('Location: ' . $base_url_pages . 'dashboard.php');
    exit();
}

$search_query = $_GET['search'] ?? '';
$pelanggan_data = null;
$message = '';
$message_type = '';

// Proses form jika ada data yang dikirim (POST request)
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $pelanggan_id = $_POST['pelanggan_id'] ?? null;
    $username_radius = trim($_POST['username_radius'] ?? '');
    $password_radius_plain = $_POST['password_radius_plain'] ?? '';

    if ($pelanggan_id && !empty($username_radius) && !empty($password_radius_plain)) {
        // Cek apakah username_radius sudah ada untuk pelanggan lain
        $check_stmt = $koneksi->prepare("SELECT id_pelanggan FROM pelanggan WHERE username_radius = ? AND id_pelanggan != ?");
        $check_stmt->bind_param("si", $username_radius, $pelanggan_id);
        $check_stmt->execute();
        $check_result = $check_stmt->get_result();

        if ($check_result->num_rows > 0) {
            $message = "Username RADIUS '" . htmlspecialchars($username_radius) . "' sudah digunakan oleh pelanggan lain. Harap gunakan username yang unik.";
            $message_type = "error";
            // Setel ulang pelanggan_data agar form terisi dengan data yang tidak valid
            $search_stmt = $koneksi->prepare("SELECT id_pelanggan, nama_pelanggan, telepon, email, username_radius, password_radius_plain, paket_id, status_aktif FROM pelanggan WHERE id_pelanggan = ?");
            $search_stmt->bind_param("i", $pelanggan_id);
            $search_stmt->execute();
            $search_result = $search_stmt->get_result();
            if ($search_result->num_rows > 0) {
                $pelanggan_data = $search_result->fetch_assoc();
                $pelanggan_data['username_radius'] = $username_radius; // Pertahankan nilai yang dimasukkan user
                $pelanggan_data['password_radius_plain'] = $password_radius_plain; // Pertahankan nilai yang dimasukkan user
            }
            $search_stmt->close();
        } else {
            // Update data pelanggan di database
            $update_stmt = $koneksi->prepare("UPDATE pelanggan SET username_radius = ?, password_radius_plain = ? WHERE id_pelanggan = ?");
            $update_stmt->bind_param("ssi", $username_radius, $password_radius_plain, $pelanggan_id);

            if ($update_stmt->execute()) {
                $message = "Kredensial RADIUS pelanggan '" . htmlspecialchars($username_radius) . "' berhasil diperbarui.";
                $message_type = "success";
                // Ambil data terbaru untuk ditampilkan setelah update
                $search_stmt = $koneksi->prepare("SELECT id_pelanggan, nama_pelanggan, telepon, email, username_radius, password_radius_plain, paket_id, status_aktif FROM pelanggan WHERE id_pelanggan = ?");
                $search_stmt->bind_param("i", $pelanggan_id);
                $search_stmt->execute();
                $search_result = $search_stmt->get_result();
                $pelanggan_data = $search_result->fetch_assoc();
                $search_stmt->close();

                // Log aktivitas
                log_activity($_SESSION['user_id'], $_SESSION['username'], $_SESSION['role'], 'Update', "Memperbarui kredensial RADIUS untuk pelanggan ID " . $pelanggan_id . " (Username: " . $username_radius . ").");

            } else {
                $message = "Gagal memperbarui kredensial RADIUS: " . $update_stmt->error;
                $message_type = "error";
            }
            $update_stmt->close();
        }
        $check_stmt->close();
    } else {
        $message = "ID Pelanggan, Username, dan Password RADIUS tidak boleh kosong.";
        $message_type = "error";
    }
}

// Logika pencarian pelanggan
if (!empty($search_query)) {
    // Cari pelanggan berdasarkan ID, nama, telepon, atau email
    $query = "SELECT id_pelanggan, nama_pelanggan, alamat, telepon, email, username_radius, password_radius_plain, paket_id, status_aktif FROM pelanggan WHERE id_pelanggan = ? OR nama_pelanggan LIKE ? OR telepon LIKE ? OR email LIKE ?";
    $stmt = $koneksi->prepare($query);
    $param_search = '%' . $search_query . '%';
    $stmt->bind_param("isss", $search_query, $param_search, $param_search, $param_search); // Bind string untuk ID juga
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        $pelanggan_data = $result->fetch_assoc();
        // Jika hasil lebih dari satu, perlu penanganan khusus (misal: tampilkan daftar pilihan)
        if ($result->num_rows > 1) {
            $message = "Ditemukan beberapa pelanggan. Mohon spesifikasi pencarian Anda atau pilih dari daftar.";
            $message_type = "info";
            $pelanggan_data = null; // Reset data jika ada multiple match untuk menghindari kebingungan
            // Anda bisa tambahkan logika untuk menampilkan daftar pilihan di sini
        }
    } else {
        $message = "Pelanggan tidak ditemukan dengan kata kunci: " . htmlspecialchars($search_query);
        $message_type = "info";
    }
    $stmt->close();
}

?>

<div class="main-content">
    <div class="container">
        <h1>Manajemen Kredensial RADIUS Pelanggan</h1>
        <p>Kelola username dan password RADIUS untuk autentikasi Mikrotik.</p>

        <?php if (!empty($message)): ?>
            <div class="alert alert-<?php echo htmlspecialchars($message_type, ENT_QUOTES, "UTF-8"); ?>"><?php echo htmlspecialchars($message, ENT_QUOTES, "UTF-8"); ?></div>
        <?php endif; ?>

        <div class="card">
            <div class="card-header">
                <h3>Cari Pelanggan</h3>
            </div>
            <div class="card-body">
                <form method="GET" action="">
                    <div class="form-group">
                        <label for="search_input">Cari berdasarkan ID, Nama, Telepon, atau Email:</label>
                        <input type="text" id="search_input" name="search" class="form-control" value="<?php echo htmlspecialchars($search_query); ?>" placeholder="Masukkan ID, Nama, Telepon, atau Email pelanggan">
                    </div>
                    <button type="submit" class="btn btn-primary">Cari</button>
                    <?php if (!empty($search_query)): ?>
                        <a href="manajemen_radius_pelanggan.php" class="btn btn-secondary">Clear Search</a>
                    <?php endif; ?>
                </form>
            </div>
        </div>

        <?php if ($pelanggan_data): ?>
            <div class="card mt-4">
                <div class="card-header">
                    <h3>Detail Pelanggan: <?php echo htmlspecialchars($pelanggan_data['nama_pelanggan']); ?> (ID: <?php echo htmlspecialchars($pelanggan_data['id_pelanggan']); ?>)</h3>
                </div>
                <div class="card-body">
                    <form method="POST" action=""><?php if (!isset($_SESSION['csrf_token'])) { $_SESSION['csrf_token'] = bin2hex(random_bytes(32)); } ?><input type='hidden' name='csrf_token' value='<?php echo $_SESSION['csrf_token']; ?>'>
                        <input type="hidden" name="pelanggan_id" value="<?php echo htmlspecialchars($pelanggan_data['id_pelanggan']); ?>">
                        <input type="hidden" name="search" value="<?php echo htmlspecialchars($search_query); ?>">
                        
                        <div class="form-group">
                            <label>Nama Pelanggan:</label>
                            <p class="form-control-static"><?php echo htmlspecialchars($pelanggan_data['nama_pelanggan']); ?></p>
                        </div>
                        <div class="form-group">
                            <label>Telepon:</label>
                            <p class="form-control-static"><?php echo htmlspecialchars($pelanggan_data['telepon']); ?></p>
                        </div>
                        <div class="form-group">
                            <label>Email:</label>
                            <p class="form-control-static"><?php echo htmlspecialchars($pelanggan_data['email']); ?></p>
                        </div>
                        <div class="form-group">
                            <label>Status Aktif:</label>
                            <p class="form-control-static"><?php echo htmlspecialchars($pelanggan_data['status_aktif']); ?></p>
                        </div>

                        <hr>

                        <h4>Kredensial RADIUS</h4>
                        <div class="form-group">
                            <label for="username_radius">Username RADIUS:</label>
                            <input type="text" id="username_radius" name="username_radius" class="form-control" value="<?php echo htmlspecialchars($pelanggan_data['username_radius'] ?? ''); ?>" required>
                        </div>
                        <div class="form-group">
                            <label for="password_radius_plain">Password RADIUS:</label>
                            <input type="text" id="password_radius_plain" name="password_radius_plain" class="form-control" value="<?php echo htmlspecialchars($pelanggan_data['password_radius_plain'] ?? ''); ?>" required>
                            <small>Password ini akan digunakan untuk autentikasi di Mikrotik (disimpan dalam teks biasa di database).</small>
                        </div>

                        <button type="submit" class="btn btn-success">Simpan Perubahan RADIUS</button>
                    </form>
                </div>
            </div>
        <?php elseif (!empty($search_query) && !$pelanggan_data): ?>
            <?php endif; ?>

    </div>
</div>

<?php include '../includes/footer.php'; ?>