<?php
// C:\xampp\htdocs\billing_isp_app\pages\cetak_voucher.php

ini_set('session.use_strict_mode', 1);
ini_set('session.cookie_httponly', 1);
ini_set('session.cookie_samesite', 'Lax');
if (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on') {
    ini_set('session.cookie_secure', 1);
}
session_start();
include '../config/koneksi.php'; // This will provide the database connection ($koneksi)
include '../includes/header.php';

// Ensure the user has the appropriate role
if (!hasRole(['superadmin', 'teknisi'])) {
    echo "<script>
            alert('Anda tidak memiliki akses ke halaman ini.');
            window.location.href = '../pages/dashboard.php';
          </script>";
    exit();
}

// --- GET VOUCHER DATA FROM THE DATABASE WHEN THE PAGE LOADS ---
// This data will be JSON-encoded and injected directly into JavaScript
// This is the "initial data" that JavaScript will use
$vouchers_from_db = [];
// Ensure $koneksi is a valid connection object from koneksi.php
if (isset($koneksi) && $koneksi->ping()) {
    // Query to retrieve vouchers, ordered from newest
    // Initially, we don't filter by mikrotik_id here, as JavaScript will handle the filtering dynamically.
    // The PHP on initial load just gets all, then JS filters based on selectedMikrotikConfigId.
    $sql = "SELECT id, username, password, profile, comment, price, mikrotik_id FROM vouchers ORDER BY created_at DESC";
    $result = mysqli_query($koneksi, $sql);

    if ($result) {
        while ($row = mysqli_fetch_assoc($result)) {
            $vouchers_from_db[] = [
                'db_id' => $row['id'], // Add ID from the database
                'name' => $row['username'],
                'password' => $row['password'],
                'profile' => $row['profile'],
                'comment' => $row['comment'] ?? '', // This is the original comment from DB, without expiration date from Mikrotik
                'server' => 'all', // Default for display
                'mac-address' => 'N/A', // Default for display
                'uptime' => '0s', // Default for display (new voucher has no uptime yet)
                'session-time-left' => 'N/A', // Default for display
                'bytes-in' => 0, // Default for display
                'bytes-out' => 0, // Default for display
                'disabled' => 'false', // Default for display
                'mikrotik_id' => $row['mikrotik_id'], // Get mikrotik_id from DB
                'price' => $row['price'] ?? '0', // Pass the price from DB
            ];
        }
    } else {
        error_log("Error retrieving vouchers from DB in cetak_voucher.php: " . mysqli_error($koneksi));
    }
} else {
    error_log("Database connection not available or invalid in cetak_voucher.php.");
}
?>

<style>
    /* Custom styles for filter inputs and selects */
    #searchVoucher,
    #filterProfile,
    #filterStatus,
    #mikrotikConfigSelectFilter {
        background-color: #34495E; /* Dark blue background */
        color: #ECF0F1; /* Light text color */
        border: 1px solid #2C3E50; /* Slightly darker border */
        box-shadow: inset 0 1px 1px rgba(0, 0, 0, 0.075);
    }

    #searchVoucher::placeholder {
        color: #BDC3C7; /* Lighter placeholder text */
        opacity: 1; /* Ensure placeholder is visible */
    }

    #filterProfile option,
    #filterStatus option,
    #mikrotikConfigSelectFilter option {
        background-color: #34495E; /* Dark background for options */
        color: #ECF0F1; /* Light text for options */
    }

    /* Style for focus state */
    #searchVoucher:focus,
    #filterProfile:focus,
    #filterStatus:focus,
    #mikrotikConfigSelectFilter:focus {
        border-color: #5DADE2; /* A brighter blue border on focus */
        box-shadow: 0 0 0 0.25rem rgba(93, 173, 226, 0.25); /* Light blue shadow on focus */
        background-color: #3B536B; /* Slightly lighter dark blue on focus */
        color: #FFFFFF; /* White text on focus */
    }

    /* Modal styles for add profile modal */
    #addProfileModal { /* Use ID to make it specific */
        display: none;
        position: fixed;
        z-index: 1000;
        left: 0;
        top: 0;
        width: 100%;
        height: 100%;
        overflow: auto;
        background-color: rgba(0,0,0,0.4);
        justify-content: center;
        align-items: center;
        opacity: 0;
        transition: opacity 0.4s ease-in-out;
        pointer-events: none;
    }

    #addProfileModal.show {
        opacity: 1;
        pointer-events: auto;
    }

    #addProfileModal .modal-content { /* Specific for add profile modal's content */
        background-color: #fefefe;
        margin: auto;
        padding: 20px;
        border: 1px solid #888;
        width: 80%;
        max-width: 500px;
        border-radius: 8px;
        position: relative;
        transform: translateY(-50px);
        transition: transform 0.4s ease-in-out;
    }

    #addProfileModal.show .modal-content {
        transform: translateY(0);
    }

    /* Common close button style */
    .close-button {
        color: #aaa;
        float: right;
        font-size: 28px;
        font-weight: bold;
        transition: color 0.3s ease;
    }

    .close-button:hover,
    .close-button:focus {
        color: black;
        text-decoration: none;
        cursor: pointer;
    }

    /* Smooth transition for buttons */
    .btn {
        transition: all 0.3s ease;
    }

    .btn:hover {
        transform: translateY(-2px);
        box-shadow: 0 4px 8px rgba(0,0,0,0.2);
    }

    /* Status Badges */
    .status-badge {
        display: inline-block;
        padding: .25em .4em;
        font-size: 75%;
        font-weight: 700;
        line-height: 1;
        text-align: center;
        white-space: nowrap;
        vertical-align: baseline;
        border-radius: .25rem;
        color: #fff;
    }

    .status-aktif {
        background-color: #28a745; /* Green */
    }

    .status-tidak-aktif {
        background-color: #6c757d; /* Gray */
    }

    .status-kedaluwarsa {
        background-color: #dc3545; /* Red */
    }

    .user-type-badge {
        display: inline-block;
        padding: .25em .4em;
        font-size: 75%;
        font-weight: 700;
        line-height: 1;
        text-align: center;
        white-space: nowrap;
        vertical-align: baseline;
        border-radius: .25rem;
        background-color: #007bff; /* Blue */
        color: #fff;
    }

    /* Logo upload specific styles */
    #logoPreview {
        max-width: 100px;
        max-height: 100px;
        margin-top: 10px;
        border: 1px solid #ddd;
        border-radius: 4px;
        display: none; /* Hidden by default */
    }
    .logo-buttons button {
        margin-right: 5px; /* Spacing between logo buttons */
    }
    .voucher-logo {
        max-width: 80px; /* Adjust as needed */
        max-height: 80px; /* Adjust as needed */
        margin: 0 auto 10px auto;
        display: block;
    }

    /* Styles for pagination controls */
    .pagination-controls {
        display: flex;
        justify-content: flex-end; /* Aligns to the right */
        align-items: center;
        margin-top: 15px;
        flex-wrap: wrap; /* Allow wrapping on smaller screens */
        gap: 10px; /* Space between elements */
    }

    .pagination-controls .form-group {
        margin-right: 15px;
        margin-bottom: 0; /* Remove default bottom margin */
        display: flex;
        align-items: center;
    }

    .pagination-controls .form-group label {
        margin-right: 8px;
        white-space: nowrap; /* Prevent label from wrapping */
    }

    .pagination-controls .pagination {
        margin-bottom: 0; /* Remove default bottom margin from Bootstrap pagination */
    }

    .pagination .page-item.active .page-link {
        background-color: #007bff;
        border-color: #007bff;
        color: #fff;
    }

    .pagination .page-link {
        color: #007bff;
    }

    .pagination .page-link:hover {
        color: #0056b3;
    }

    /* Specific styles for table headers to reduce width */
    #voucherTableBody th, #voucherTableBody td {
        white-space: nowrap; /* Prevent text wrapping in cells */
        padding: 0.25rem 0.5rem; /* Reduced padding */
    }

    /* Adjust specific column widths if needed, using CSS instead of HTML width attribute */
    /* Removed specific width adjustments for the removed columns */


</style>

<div class="main-content">
    <div class="page-header">
        <h1>Cetak Voucher Hotspot</h1>
        <p>Buat dan kelola voucher hotspot Anda.</p>
    </div>

    <div class="container">
        <div class="card mb-4">
            <div class="card-header">
                <h3><i class="fas fa-ticket-alt"></i> Buat Voucher Hotspot Baru</h3>
            </div>
            <div class="card-body">
                <form id="generateVoucherForm">
                    <div class="form-group">
                        <label for="mikrotikConfigSelectCreate">Pilih MikroTik:</label>
                        <select id="mikrotikConfigSelectCreate" class="form-control" required>
                            <option value="">Memuat konfigurasi...</option>
                        </select>
                    </div>
                    <div class="form-group">
                        <label for="voucher_count">Jumlah Voucher:</label>
                        <input type="number" id="voucher_count" name="jumlah" class="form-control" value="1" min="1" required>
                    </div>
                    <div class="form-group">
                        <label for="voucher_profile">Profil Hotspot:</label>
                        <select id="voucher_profile" name="profile" class="form-control" required>
                            <option value="">Pilih Profil</option>
                            </select>
                    </div>
                    <div class="form-group">
                        <button type="button" class="btn btn-secondary mt-2" id="addHotspotProfileBtn">
                            <i class="fas fa-plus"></i> Tambah Profil Hotspot Baru
                        </button>
                    </div>
                    <div class="form-group">
                        <label for="char_length">Panjang Karakter (Username/Password):</label>
                        <input type="number" id="char_length" name="panjang_karakter" class="form-control" value="5" min="3" max="10" required>
                    </div>
                    <div class="form-group">
                        <label for="voucher_prefix">Awalan Voucher (Opsional):</label>
                        <input type="text" id="voucher_prefix" name="awalan" class="form-control" placeholder="Contoh: VC-">
                    </div>
                    <div class="form-group">
                        <label for="voucher_comment">Komentar Voucher (Opsional):</label>
                        <input type="text" id="voucher_comment" name="comment" class="form-control" placeholder="Contoh: Voucher Harian">
                    </div>
                    <div class="form-group">
                        <label for="logoUpload">Logo Voucher (Opsional):</label>
                        <input type="file" id="logoUpload" name="logo" class="form-control-file" accept="image/*">
                        <img id="logoPreview" src="#" alt="Pratinjau Logo" style="display: none;">
                        <div class="logo-buttons mt-2">
                            <button type="button" class="btn btn-info btn-sm" id="saveLogoBtn"><i class="fas fa-save"></i> Simpan Logo</button>
                            <button type="button" class="btn btn-danger btn-sm" id="deleteLogoBtn"><i class="fas fa-trash"></i> Hapus Logo</button>
                        </div>
                    </div>

                    <input type="hidden" id="validity_gen_input" name="validity_gen" value="">
                    <input type="hidden" id="price_gen_input" name="price_gen" value="">
                    <button type="submit" class="btn btn-primary"><i class="fas fa-plus-circle"></i> Buat Voucher</button>
                </form>

                <div id="voucherOutput" class="mt-4" style="display: <?php echo !empty($vouchers_from_db) ? 'block' : 'none'; ?>;">
                    <h4>Daftar Voucher:</h4>
                    <!-- Mengatur layout filter dan tombol agar responsif dan ringkas -->
                    <div class="d-flex flex-column flex-md-row align-items-md-center justify-content-between mb-3 gap-2">
                        <div class="d-flex align-items-center flex-wrap gap-2 mb-2 mb-md-0">
                            <input type="text" id="searchVoucher" class="form-control rounded-pill" placeholder="Cari Username/Profile..." style="min-width: 180px;">
                            <select id="filterProfile" class="form-control rounded-pill" style="min-width: 120px;">
                                <option value="">Semua Profil</option>
                            </select>
                            <select id="filterStatus" class="form-control rounded-pill" style="min-width: 120px;">
                                <option value="">Semua Status</option>
                                <option value="enabled">Aktif</option>
                                <option value="disabled">Dinonaktifkan</option>
                                <option value="expired">Kedaluwarsa</option>
                            </select>
                            <!-- Removed the mikrotikConfigSelectFilter dropdown from here as requested -->
                        </div>
                        <div class="d-flex align-items-center flex-wrap gap-2">
                            <button class="btn btn-success rounded-pill" id="refreshBtn"><i class="fas fa-sync-alt"></i> Refresh</button>
                            <button class="btn btn-secondary rounded-pill" onclick="printVouchers()"><i class="fas fa-print"></i> Cetak Voucher</button>
                            <button class="btn btn-danger rounded-pill" id="deleteExpiredUsersBtn">
                                <i class="fas fa-user-times"></i> Hapus User Kedaluwarsa
                            </button>
                        </div>
                        <!-- Bagian paginasi tetap di luar flex ini jika ingin di kanan atas -->
                    </div>
                    <!-- Paginasi diatur di luar flex di atas untuk penempatan yang lebih mudah -->
                    <div class="pagination-controls d-flex justify-content-end mb-2">
                        <div class="form-group me-2">
                            <label for="rowsPerPageTop">Baris per halaman:</label>
                            <select id="rowsPerPageTop" class="form-control form-control-sm rounded-pill">
                                <option value="10">10</option>
                                <option value="20">20</option>
                                <option value="30" selected>30</option>
                                <option value="50">50</option>
                                <option value="100">100</option>
                            </select>
                        </div>
                        <ul class="pagination mb-0" id="paginationTop"></ul>
                    </div>
                    <div class="d-flex justify-content-end mb-2">
                        <div class="form-check me-3">
                            <input class="form-check-input" type="checkbox" id="checkAllVouchers">
                            <label class="form-check-label" for="checkAllVouchers">Pilih Semua</label>
                        </div>
                        <button class="btn btn-danger btn-sm" id="deleteSelectedVouchersBtn" style="display: none;">
                            <i class="fas fa-trash"></i> Hapus yang Dipilih
                        </button>
                    </div>

                    <div class="table-responsive">
                        <table class="table table-bordered table-striped table-sm"> <!-- Ditambahkan class table-sm -->
                            <thead>
                                <tr>
                                    <th style="width: 30px;"></th>
                                    <th>No</th>
                                    <!-- Removed Server column -->
                                    <th>Username</th>
                                    <th>Password</th>
                                    <th>Profil</th>
                                    <th>Alamat MAC</th>
                                    <th>Uptime</th>
                                    <!-- Removed Waktu Tersisa column -->
                                    <th>Bytes In/Out</th>
                                    <th>Harga</th>
                                    <th>Status</th>
                                    <!-- Removed Tanggal Kedaluwarsa column -->
                                    <th>Tipe</th>
                                </tr>
                            </thead>
                            <tbody id="voucherTableBody">
                            </tbody>
                        </table>
                    </div>
                    <div class="pagination-controls mt-3"> <div class="form-group me-2">
                            <label for="rowsPerPageBottom">Baris per halaman:</label>
                            <select id="rowsPerPageBottom" class="form-control form-control-sm rounded-pill">
                                <option value="10">10</option>
                                <option value="20">20</option>
                                <option value="30" selected>30</option>
                                <option value="50">50</option>
                                <option value="100">100</option>
                            </select>
                        </div>
                        <ul class="pagination mb-0" id="paginationBottom"></ul>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<div id="addProfileModal" class="modal">
    <div class="modal-content">
        <span class="close-button">&times;</span>
        <h4><i class="fas fa-user-plus"></i> Tambah Profil Hotspot Baru</h4>
        <form id="addProfileForm">
            <div class="form-group">
                <label for="mikrotikConfigSelectProfile">Pilih MikroTik:</label>
                <select id="mikrotikConfigSelectProfile" class="form-control" required>
                    <option value="">Memuat konfigurasi...</option>
                </select>
            </div>
            <div class="form-group">
                <label for="profile_name">Nama Profil:</label>
                <input type="text" id="profile_name" name="name" class="form-control" required>
            </div>
            <div class="form-group">
                <label for="rate_limit">Batas Kecepatan (Rx/Tx, misal: 1M/2M):</label>
                <input type="text" id="rate_limit" name="rate-limit" class="form-control" placeholder="Contoh: 1M/2M (Unduh/Unggah)">
            </div>
            <div class="form-group">
                <label for="shared_users">Jumlah Pengguna Bersamaan:</label>
                <input type="number" id="shared_users" name="shared-users" class="form-control" value="1" min="1">
            </div>
            <div class="form-group">
                <label for="address_pool">Address Pool:</label>
                <select id="address_pool" name="address-pool" class="form-control">
                    <option value="none">none</option>
                    </select>
            </div>
            <div class="form-group">
                <label for="expire_mode">Mode Kedaluwarsa:</label>
                <select id="expire_mode" name="mode-kadaluwarsa" class="form-control">
                    <option value="0">None</option>
                    <option value="rem">Remove</option>
                </select>
            </div>
            <div class="form-group">
                <label for="validity">Masa Berlaku:</label>
                <input type="text" id="validity" name="validity" class="form-control" placeholder="Contoh: 1d, 30m">
            </div>
            <div class="form-group">
                <label for="price">Harga Rp:</label>
                <input type="number" id="price" name="price" class="form-control" placeholder="0">
            </div>
            <div class="form-group">
                <label for="user_key">Kunci Pengguna (MAC Lock):</label>
                <select id="user_key" name="user-key" class="form-control">
                    <option value="Disable">Disable</option>
                    <option value="Enable">Enable</option>
                </select>
            </div>
             <div class="form-group">
                <label for="parent_queue">Parent Queue:</label>
                <select id="parent_queue" name="parent" class="form-control">
                    <option value="none">none</option>
                    </select>
            </div>
            <button type="submit" class="btn btn-primary"><i class="fas fa-save"></i> Simpan Profil</button>
            <button type="button" class="btn btn-danger mt-2" id="deleteSelectedHotspotProfileBtn">
                <i class="fas fa-trash"></i> Hapus Profil yang Dipilih
            </button>
        </form>
    </div>
</div>


<script>
    // MEMAKSA penggunaan showCustomConfirm ini.
    // Ini akan menimpa showCustomConfirm yang ada yang didefinisikan di tempat lain.
    window.showCustomConfirm = function(title, message, callback) {
        const confirmModal = document.createElement('div');
        // Definisikan semua gaya inline untuk isolasi maksimum
        confirmModal.style.cssText = `
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background-color: rgba(0,0,0,0.8); /* Latar belakang lebih gelap agar sangat terlihat */
            display: flex; /* Selalu tampilkan sebagai flex untuk memusatkan konten */
            justify-content: center;
            align-items: center;
            z-index: 99999; /* Z-index lebih tinggi lagi */
            opacity: 0;
            transition: opacity 0.3s ease-in-out;
            pointer-events: none; /* Awalnya mencegah klik */
        `;

        const modalContent = document.createElement('div');
        modalContent.style.cssText = `
            background-color: #fefefe;
            padding: 30px; /* Padding ditingkatkan */
            border-radius: 10px; /* Sudut lebih membulat */
            max-width: 400px; /* Lebar maksimal disesuaikan */
            text-align: center;
            box-shadow: 0 5px 15px rgba(0,0,0,0.5); /* Bayangan lebih kuat */
            transform: translateY(-50px);
            transition: transform 0.3s ease-in-out;
        `;
        modalContent.innerHTML = `
            <h4 style="margin-top: 0; color: #333;">${title}</h4>
            <p style="margin-bottom: 20px; color: #555;">${message}</p>
            <div style="display: flex; justify-content: center; gap: 15px;">
                <button id="confirmYes" class="btn btn-primary">Ya</button>
                <button id="confirmNo" class="btn btn-secondary">Tidak</button>
            </div>
        `;
        confirmModal.appendChild(modalContent);
        document.body.appendChild(confirmModal);

        // Paksa reflow dan terapkan transisi/pointer-events
        confirmModal.offsetWidth; // Picu reflow untuk display:flex dan opacity:0 awal
        confirmModal.style.opacity = '1';
        modalContent.style.transform = 'translateY(0)';
        confirmModal.style.pointerEvents = 'auto'; // Izinkan klik segera setelah memulai transisi

        const confirmYes = document.getElementById('confirmYes');
        const confirmNo = document.getElementById('confirmNo');

        // Siapkan listener klik untuk tombol
        confirmYes.onclick = () => {
            confirmModal.style.opacity = '0';
            modalContent.style.transform = 'translateY(-50px)';
            confirmModal.style.pointerEvents = 'none'; // Cegah klik lebih lanjut pada overlay selama memudar

            // Hapus segera dari DOM setelah sedikit penundaan (durasi transisi)
            setTimeout(() => {
                if (document.body.contains(confirmModal)) { // Periksa apakah masih ada di DOM sebelum menghapus
                    document.body.removeChild(confirmModal);
                }
                callback(true); // Panggil callback setelah modal efektif hilang
            }, 300); // Sesuaikan durasi transisi CSS
        };

        confirmNo.onclick = () => {
            confirmModal.style.opacity = '0';
            modalContent.style.transform = 'translateY(-50px)';
            confirmModal.style.pointerEvents = 'none'; // Cegah klik lebih lanjut pada overlay selama memudar

            setTimeout(() => {
                if (document.body.contains(confirmModal)) {
                    document.body.removeChild(confirmModal);
                }
                callback(false);
            }, 300); // Sesuaikan durasi transisi CSS
        };

        // Izinkan penutupan dengan mengklik di luar konten
        confirmModal.addEventListener('click', function(event) {
            if (event.target === confirmModal) { // Hanya jika diklik langsung pada overlay
                confirmModal.style.opacity = '0';
                modalContent.style.transform = 'translateY(-50px)';
                confirmModal.style.pointerEvents = 'none';

                setTimeout(() => {
                    if (document.body.contains(confirmModal)) {
                        document.body.removeChild(confirmModal);
                    }
                    callback(false); // Perlakukan sebagai pembatalan
                }, 300);
            }
        });
    };

    // Fungsi pembantu untuk memformat durasi waktu RouterOS
    function formatRouterOSTime(time_str) {
        if (!time_str || time_str === '0s' || time_str === 'N/A') {
            return '0 Detik';
        }

        let seconds = 0;
        // Check for 'w' (weeks)
        const weeksMatch = time_str.match(/(\d+)w/);
        if (weeksMatch) {
            seconds += parseInt(weeksMatch[1]) * 7 * 24 * 3600;
            time_str = time_str.replace(/(\d+)w/, '');
        }
        // Check for 'd' (days)
        const daysMatch = time_str.match(/(\d+)d/);
        if (daysMatch) {
            seconds += parseInt(daysMatch[1]) * 24 * 3600;
            time_str = time_str.replace(/(\d+)d/, '');
        }
        // Check for 'h' (hours)
        const hoursMatch = time_str.match(/(\d+)h/);
        if (hoursMatch) {
            seconds += parseInt(hoursMatch[1]) * 3600;
            time_str = time_str.replace(/(\d+)h/, '');
        }
        // Check for 'm' (minutes)
        const minutesMatch = time_str.match(/(\d+)m/);
        if (minutesMatch) {
            seconds += parseInt(minutesMatch[1]) * 60;
            time_str = time_str.replace(/(\d+)m/, '');
        }
        // Check for 's' (seconds) - must be last
        const secondsMatch = time_str.match(/(\d+)s/);
        if (secondsMatch) {
            seconds += parseInt(secondsMatch[1]);
        }
        
        // Handle HH:MM:SS format if no specific units
        if (time_str.match(/^\d{2}:\d{2}:\d{2}$/)) {
            const parts = time_str.split(':');
            seconds = parseInt(parts[0]) * 3600 + parseInt(parts[1]) * 60 + parseInt(parts[2]);
        }


        const years = Math.floor(seconds / (365 * 24 * 3600));
        seconds %= (365 * 24 * 3600);
        const months = Math.floor(seconds / (30 * 24 * 3600)); // Approx month
        seconds %= (30 * 24 * 3600);
        const days = Math.floor(seconds / (24 * 3600));
        seconds %= (24 * 3600);
        const hours = Math.floor(seconds / 3600);
        seconds %= 3600;
        const minutes = Math.floor(seconds / 60);
        const secs = seconds % 60;

        const parts = [];
        if (years > 0) parts.push(years + ' Tahun');
        if (months > 0) parts.push(months + ' Bulan');
        if (days > 0) parts.push(days + ' Hari');
        if (hours > 0) parts.push(hours + ' Jam');
        if (minutes > 0) parts.push(minutes + ' Menit');
        // Hanya tampilkan detik jika tidak ada unit lebih besar yang sudah ditambahkan
        if (secs > 0) { // Hanya tampilkan detik jika ada detik
            parts.push(secs + ' Detik');
        } else if (parts.length === 0) { // Jika tidak ada unit waktu yang lebih besar, dan detik 0, tampilkan "0 Detik"
            parts.push('0 Detik');
        }

        return parts.join(' ');
    }


    // Fungsi pembantu untuk memformat byte (direplikasi dari mikrotik_api.php untuk tampilan sisi klien)
    function formatBytes(bytes, precision = 2) {
        const units = ['B', 'KB', 'MB', 'GB', 'TB'];
        bytes = Math.max(bytes, 0);
        const pow = Math.floor((bytes ? Math.log(bytes) : 0) / Math.log(1024));
        const p = Math.min(pow, units.length - 1);
        bytes /= (1 << (10 * p));
        return Math.round(bytes, precision) + ' ' + units[p];
    }

    // Fungsi pembantu untuk memformat mata uang (misal: 10000 menjadi Rp10.000)
    function formatCurrency(amount) {
        // --- LOG DEBUGGING ---
        console.log("formatCurrency diterima:", amount, "Tipe:", typeof amount);
        // --- AKHIR DEBUG ---

        // Pastikan jumlah adalah angka atau dapat diurai sebagai angka
        const numAmount = parseFloat(amount);
        if (isNaN(numAmount)) {
            console.warn("formatCurrency: Jumlah tidak valid diterima, mengembalikan 'Rp0'. Jumlah:", amount);
            return 'Rp0';
        }

        return new Intl.NumberFormat('id-ID', {
            style: 'currency',
            currency: 'IDR',
            minimumFractionDigits: 0,
            maximumFractionDigits: 0
        }).format(numAmount);
    }


    // Variabel global untuk URL logo
    let uploadedLogoUrl = '';
    
    // Variabel untuk menyimpan ID konfigurasi MikroTik yang saat ini dipilih
    // Default dari localStorage atau yang pertama jika belum ada
    let selectedMikrotikConfigId = localStorage.getItem('selectedMikrotikConfigId') || null;

    // Cache profil hotspot yang dimuat untuk menghindari duplikasi fetch
    window.cachedHotspotProfiles = []; 
    // Cache konfigurasi MikroTik yang dimuat
    window.cachedMikrotikConfigs = [];


    // --- Definisi DOMContentLoaded START ---
    document.addEventListener('DOMContentLoaded', function() {
        const generateVoucherForm = document.getElementById('generateVoucherForm');
        const voucherProfileSelect = document.getElementById('voucher_profile');
        const voucherOutputDiv = document.getElementById('voucherOutput');
        const voucherTableBody = document.getElementById('voucherTableBody');
        const voucherCommentInput = document.getElementById('voucher_comment');
        const searchVoucherInput = document.getElementById('searchVoucher');
        const filterProfileSelect = document.getElementById('filterProfile');
        const filterStatusSelect = document.getElementById('filterStatus');
        const refreshBtn = document.getElementById('refreshBtn');
        const logoUploadInput = document.getElementById('logoUpload');
        const logoPreviewImg = document.getElementById('logoPreview');
        const saveLogoBtn = document.getElementById('saveLogoBtn');
        const deleteLogoBtn = document.getElementById('deleteLogoBtn');

        // Elemen dropdown pilihan MikroTik di form 'Buat Voucher'
        const mikrotikConfigSelectCreate = document.getElementById('mikrotikConfigSelectCreate');
        // Elemen dropdown pilihan MikroTik di filter tabel
        const mikrotikConfigSelectFilter = document.getElementById('mikrotikConfigSelectFilter');
        // Elemen dropdown pilihan MikroTik di modal 'Tambah Profil Hotspot Baru'
        const mikrotikConfigSelectProfile = document.getElementById('mikrotikConfigSelectProfile');


        // Elemen untuk fitur hapus massal
        const checkAllVouchers = document.getElementById('checkAllVouchers');
        const deleteSelectedVouchersBtn = document.getElementById('deleteSelectedVouchersBtn');

        // START: Referensi Tombol Hapus User Kedaluwarsa
        const deleteExpiredUsersBtn = document.getElementById('deleteExpiredUsersBtn');
        // END: Referensi Tombol Hapus User Kedaluwarsa

        // Elements for Add Hotspot Profile Modal
        const addHotspotProfileBtn = document.getElementById('addHotspotProfileBtn');
        const addProfileModal = document.getElementById('addProfileModal');
        const closeButton = addProfileModal.querySelector('.close-button');
        const addProfileForm = document.getElementById('addProfileForm');

        // Reference to the delete profile button inside the modal
        const deleteProfileInModalBtn = document.getElementById('deleteSelectedHotspotProfileBtn');

        // References to form fields in the Add Profile Modal
        const profileNameInput = document.getElementById('profile_name');
        const rateLimitInput = document.getElementById('rate_limit');
        const sharedUsersInput = document.getElementById('shared_users');
        const addressPoolSelect = document.getElementById('address_pool');
        const expireModeSelect = document.getElementById('expire_mode');
        const validityInput = document.getElementById('validity');
        const priceInput = document.getElementById('price');
        const userKeySelect = document.getElementById('user_key');
        const parentQueueSelect = document.getElementById('parent_queue');

        // Elemen Paginasi (Atas dan Bawah)
        const rowsPerPageTopSelect = document.getElementById('rowsPerPageTop');
        const rowsPerPageBottomSelect = document.getElementById('rowsPerPageBottom');
        const paginationTopContainer = document.getElementById('paginationTop');
        const paginationBottomContainer = document.getElementById('paginationBottom');

        let currentPage = 1;
        // Gunakan nilai dari dropdown atas atau bawah sebagai sumber kebenaran awal
        let rowsPerPage = parseInt(rowsPerPageTopSelect.value);


        // Data voucher yang ada dari database PHP saat halaman dimuat (PHP injects this)
        // This initial load no longer filters, as the JS fetchAndRenderVouchersFromDB will handle it.
        let currentVouchers = <?php echo htmlspecialchars(json_encode($vouchers_from_db), ENT_QUOTES, "UTF-8"); ?>;
        let displayedVouchers = [...currentVouchers]; // Untuk menyimpan voucher yang sedang ditampilkan setelah filter


        // Array untuk menyimpan ID voucher yang dipilih
        let selectedVoucherIds = []; // Format: [{ db_id: X, username: Y, mikrotik_id: Z }, ...]


        // --- Fungsi untuk merender voucher ke tabel ---
        function renderVouchersToTable(vouchers) {
            voucherTableBody.innerHTML = '';
            voucherOutputDiv.style.display = 'block';

            // Paginasi: Ambil subset voucher untuk halaman saat ini
            const startIndex = (currentPage - 1) * rowsPerPage;
            const endIndex = startIndex + rowsPerPage;
            const vouchersToRender = vouchers.slice(startIndex, endIndex);

            // Dapatkan nama MikroTik yang dipilih untuk ditampilkan di kolom 'Server'
            const selectedConfig = window.cachedMikrotikConfigs.find(config => config.id == selectedMikrotikConfigId);
            const selectedMikrotikName = selectedConfig ? selectedConfig.name : 'N/A';


            if (vouchersToRender.length > 0) {
                vouchersToRender.forEach((voucher, index) => {
                    const globalIndex = startIndex + index; // Sesuaikan indeks untuk penomoran global
                    // Kirim selectedMikrotikName ke createUserTableRow
                    const row = createUserTableRow(voucher, globalIndex, selectedMikrotikName);
                    voucherTableBody.appendChild(row);
                });
            } else {
                const noVoucherRow = document.createElement('tr');
                // Updated colspan to reflect removed columns (original 14 - 4 removed = 10)
                noVoucherRow.innerHTML = `<td colspan="10" class="text-center">Tidak ada voucher yang ditemukan.</td>`;
                voucherTableBody.appendChild(noVoucherRow);
            }
            updateDeleteButtonVisibility();
            updatePagination(vouchers.length); // Perbarui paginasi setelah merender
            updateCheckAllCheckbox(); // Perbarui status checkbox "Pilih Semua"
        }

        // --- Fungsi pembantu untuk membuat baris tabel pengguna (khusus untuk tabel voucher) ---
        // Menerima selectedMikrotikName sebagai argumen baru
        function createUserTableRow(user, index, selectedMikrotikName) {
            const row = document.createElement('tr');
            const is_disabled = (user.disabled === 'true');

            let user_status_text = 'Aktif';
            let status_class = 'status-aktif';
            // Removed expirationDateDisplay and commentValue logic as these columns are removed

            // Determine expiration status based on the parsed date (still needed for filtering)
            let isExpired = false;
            const commentValue = user.comment || ''; // Keep commentValue for expiration logic
            let expirationDateFromComment = null; // null if none or invalid

            // Try to match the full format first
            const commentMatchWithPipe = commentValue.match(/^(\d{4}-\d{2}-\d{2}\s\d{2}:\d{2}:\d{2})\s\|\s(.*)/);
            if (commentMatchWithPipe) {
                expirationDateFromComment = commentMatchWithPipe[1];
            } else {
                // Fallback to just the date-time string if no pipe is found
                const commentMatchOnlyDate = commentValue.match(/^(\d{4}-\d{2}-\d{2}\s\d{2}:\d{2}:\d{2})$/);
                if (commentMatchOnlyDate) {
                    expirationDateFromComment = commentMatchOnlyDate[1];
                }
            }

            if (expirationDateFromComment) { // Only attempt to parse if a potential date string was found
                try {
                    const expiryDateTime = new Date(expirationDateFromComment);
                    const currentDateTime = new Date();
                    if (expiryDateTime < currentDateTime) {
                        isExpired = true;
                    }
                } catch (e) {
                    console.error("Error mengurai tanggal kedaluwarsa dari komentar (untuk status):", expirationDateFromComment, e);
                }
            }


            if (is_disabled) {
                user_status_text = 'Dinonaktifkan';
                status_class = 'status-tidak-aktif';
            } else if (isExpired) {
                user_status_text = 'Kedaluwarsa';
                status_class = 'status-kedaluwarsa';
            }

            let user_type = 'Pengguna Biasa';
            if (user.profile && user.profile.toLowerCase().includes('voucher')) { // Check profile for "voucher"
                user_type = 'Voucher';
            } else if (user.name === 'admin' || user.name === 'default-trial') {
                user_type = 'Sistem/Admin';
            }

            // Periksa apakah voucher ini saat ini dipilih
            const isSelected = selectedVoucherIds.some(item => item.db_id === user.db_id);


            row.innerHTML = `
                <td>
                    <input type="checkbox" class="voucher-checkbox"
                           data-db-id="${user.db_id}"
                           data-username="${user.name}"
                           data-mikrotik-id="${user.mikrotik_id || ''}"
                           ${isSelected ? 'checked' : ''}>
                </td>
                <td>${index + 1}</td>
                <!-- Removed Server column -->
                <td>${user.name || 'N/A'}</td>
                <td>${user.password || 'N/A'}</td>
                <td>${user.profile || 'N/A'}</td>
                <td>${user['mac-address'] || 'N/A'}</td>
                <td>${formatRouterOSTime(user.uptime || '0s')}</td>
                <!-- Removed Waktu Tersisa column -->
                <td>${formatBytes(user['bytes-in'] || 0)} / ${formatBytes(user['bytes-out'] || 0)}</td>
                <td>${formatCurrency(user.price || 0)}</td>
                <td><span class="status-badge ${status_class}">${user_status_text}</span></td>
                <!-- Removed Tanggal Kedaluwarsa column -->
                <td><span class="user-type-badge">${user_type}</span></td>
            `;

            const checkbox = row.querySelector('.voucher-checkbox');
            checkbox.addEventListener('change', function() {
                const dbId = parseInt(this.dataset.dbId);
                const username = this.dataset.username;
                const mikrotikId = this.dataset.mikrotikId;

                if (this.checked) {
                    selectedVoucherIds.push({ db_id: dbId, username: username, mikrotik_id: mikrotikId });
                } else {
                    selectedVoucherIds = selectedVoucherIds.filter(item => item.db_id !== dbId);
                }
                updateDeleteButtonVisibility();
                updateCheckAllCheckbox();
            });

            return row;
        }

        function updateDeleteButtonVisibility() {
            if (selectedVoucherIds.length > 0) {
                deleteSelectedVouchersBtn.style.display = 'inline-block';
            } else {
                deleteSelectedVouchersBtn.style.display = 'none';
            }
        }

        function updateCheckAllCheckbox() {
            // Hanya memperbarui berdasarkan voucher yang saat ini ditampilkan
            const displayedCheckboxes = document.querySelectorAll('#voucherTableBody .voucher-checkbox');
            if (displayedCheckboxes.length === 0) {
                checkAllVouchers.checked = false;
                checkAllVouchers.indeterminate = false;
                return;
            }

            const checkedCount = Array.from(displayedCheckboxes).filter(cb => selectedVoucherIds.some(item => item.db_id === parseInt(cb.dataset.dbId))).length;
            
            if (checkedCount === 0) {
                checkAllVouchers.checked = false;
                checkAllVouchers.indeterminate = false;
            } else if (checkedCount === displayedCheckboxes.length) {
                checkAllVouchers.checked = true;
                checkAllVouchers.indeterminate = false;
            } else {
                checkAllVouchers.checked = false;
                checkAllVouchers.indeterminate = true;
            }
        }


        // --- Paginasi Fungsi (Dibuat ulang untuk mendukung dua set) ---
        function updatePagination(totalRows) {
            const totalPages = Math.ceil(totalRows / rowsPerPage);

            // Fungsi pembantu untuk membuat dan mengisi satu set paginasi
            const createPaginationSet = (container) => {
                container.innerHTML = ''; // Clear existing pagination

                if (totalPages <= 1) {
                    return; // Don't show pagination if there's only 1 page or less
                }

                // 'Previous' button
                const prevItem = document.createElement('li');
                prevItem.classList.add('page-item');
                if (currentPage === 1) {
                    prevItem.classList.add('disabled');
                }
                const prevLink = document.createElement('a');
                prevLink.classList.add('page-link');
                prevLink.href = '#';
                prevLink.textContent = 'Previous';
                prevLink.addEventListener('click', (e) => {
                    e.preventDefault();
                    if (currentPage > 1) {
                        currentPage--;
                        renderVouchersToTable(displayedVouchers);
                        // Scroll to top of table or page if desired
                        // window.scrollTo(0, 0); 
                    }
                });
                prevItem.appendChild(prevLink);
                container.appendChild(prevItem);

                // Page numbers
                let startPage = Math.max(1, currentPage - 2);
                let endPage = Math.min(totalPages, currentPage + 2);

                if (endPage - startPage < 4) { // Ensure there are at least 5 page numbers if possible
                    if (currentPage <= 3) { // If at the beginning of pages
                        startPage = 1;
                        endPage = Math.min(totalPages, 5);
                    } else if (currentPage >= totalPages - 2) { // If at the end of pages
                        startPage = Math.max(1, totalPages - 4);
                        endPage = totalPages;
                    }
                }


                // Show first page and ellipsis if needed
                if (startPage > 1) {
                    const firstPageItem = document.createElement('li');
                    firstPageItem.classList.add('page-item');
                    const firstPageLink = document.createElement('a');
                    firstPageLink.classList.add('page-link');
                    firstPageLink.href = '#';
                    firstPageLink.textContent = '1';
                    firstPageLink.addEventListener('click', (e) => {
                        e.preventDefault();
                        currentPage = 1;
                        renderVouchersToTable(displayedVouchers);
                    });
                    firstPageItem.appendChild(firstPageLink);
                    container.appendChild(firstPageItem);

                    if (startPage > 2) {
                        const dotsItem = document.createElement('li');
                        dotsItem.classList.add('page-item', 'disabled');
                        const dotsLink = document.createElement('a');
                        dotsLink.classList.add('page-link');
                        dotsLink.href = '#';
                        dotsLink.textContent = '...';
                        dotsItem.appendChild(dotsLink);
                        container.appendChild(dotsItem);
                    }
                }

                for (let i = startPage; i <= endPage; i++) {
                    const pageItem = document.createElement('li');
                    pageItem.classList.add('page-item');
                    if (i === currentPage) {
                        pageItem.classList.add('active');
                    }
                    const pageLink = document.createElement('a');
                    pageLink.classList.add('page-link');
                    pageLink.href = '#';
                    pageLink.textContent = i;
                    pageLink.addEventListener('click', (e) => {
                        e.preventDefault();
                        currentPage = i;
                        renderVouchersToTable(displayedVouchers);
                    });
                    pageItem.appendChild(pageLink);
                    container.appendChild(pageItem);
                }

                // Show last page and ellipsis if needed
                if (endPage < totalPages) {
                    if (endPage < totalPages - 1) {
                        const dotsItem = document.createElement('li');
                        dotsItem.classList.add('page-item', 'disabled');
                        const dotsLink = document.createElement('a');
                        dotsLink.classList.add('page-link');
                        dotsLink.href = '#';
                        dotsLink.textContent = '...';
                        dotsItem.appendChild(dotsLink);
                        container.appendChild(dotsItem);
                    }
                    const lastPageItem = document.createElement('li');
                    lastPageItem.classList.add('page-item');
                    const lastPageLink = document.createElement('a');
                    lastPageLink.classList.add('page-link');
                    lastPageLink.href = '#';
                    lastPageLink.textContent = totalPages;
                    lastPageLink.addEventListener('click', (e) => {
                        e.preventDefault();
                        currentPage = totalPages;
                        renderVouchersToTable(displayedVouchers);
                    });
                    lastPageItem.appendChild(lastPageLink);
                    container.appendChild(lastPageItem);
                }

                // 'Next' button
                const nextItem = document.createElement('li');
                nextItem.classList.add('page-item');
                if (currentPage === totalPages) {
                    nextItem.classList.add('disabled');
                }
                const nextLink = document.createElement('a');
                nextLink.classList.add('page-link');
                nextLink.href = '#';
                nextLink.textContent = 'Next';
                nextLink.addEventListener('click', (e) => {
                    e.preventDefault();
                    if (currentPage < totalPages) {
                        currentPage++;
                        renderVouchersToTable(displayedVouchers);
                    }
                });
                prevItem.appendChild(nextLink);
                container.appendChild(nextItem);
            };

            // Call the helper function for each pagination set
            createPaginationSet(paginationTopContainer);
            createPaginationSet(paginationBottomContainer);
        }

        // Event listener for "Rows per page" change (top)
        if (rowsPerPageTopSelect) {
            rowsPerPageTopSelect.addEventListener('change', function() {
                rowsPerPage = parseInt(this.value);
                rowsPerPageBottomSelect.value = this.value; // Sync bottom dropdown
                currentPage = 1;
                applyFilters();
            });
        }

        // Event listener for "Rows per page" change (bottom)
        if (rowsPerPageBottomSelect) {
            rowsPerPageBottomSelect.addEventListener('change', function() {
                rowsPerPage = parseInt(this.value);
                rowsPerPageTopSelect.value = this.value; // Sync top dropdown
                currentPage = 1;
                applyFilters();
            });
        }


        // --- Load Hotspot Profiles for Voucher Creation and Filtering ---
        // Updated to accept config_id
        async function loadHotspotProfilesForSelection(configId) {
            if (!configId) {
                voucherProfileSelect.innerHTML = '<option value="">Pilih Profil (Pilih MikroTik dulu)</option>';
                filterProfileSelect.innerHTML = '<option value="">Semua Profil</option>';
                window.cachedHotspotProfiles = []; // Clear cache
                return;
            }

            try {
                const response = await fetch(`mikrotik_api.php?action=get_hotspot_user_profiles&config_id=${configId}`);
                const data = await response.json();

                if (data.status === 'success') {
                    voucherProfileSelect.innerHTML = '<option value="">Pilih Profil</option>';
                    filterProfileSelect.innerHTML = '<option value="">Semua Profil</option>';

                    window.cachedHotspotProfiles = data.profiles; // Cache loaded profiles

                    data.profiles.forEach(profile => {
                        const optionCreate = document.createElement('option');
                        optionCreate.value = profile.name;
                        optionCreate.textContent = profile.name;
                        voucherProfileSelect.appendChild(optionCreate);

                        const optionFilter = document.createElement('option');
                        optionFilter.value = profile.name;
                        optionFilter.textContent = profile.name;
                        filterProfileSelect.appendChild(optionFilter);
                    });
                    updateDeleteProfileButtonState();
                } else {
                    if (typeof showNotification === 'function') {
                        showNotification('Gagal memuat profil hotspot: ' + data.message, 'error');
                    } else {
                        console.error('Notification function not found or failed to load hotspot profiles:', data.message);
                    }
                    voucherProfileSelect.innerHTML = '<option value="">Gagal Memuat Profil</option>';
                    filterProfileSelect.innerHTML = '<option value="">Gagal Memuat Profil</option>';
                    window.cachedHotspotProfiles = [];
                }
            } catch (error) {
                console.error('Error loading hotspot profiles:', error);
                if (typeof showNotification === 'function') {
                    showNotification('Terjadi kesalahan saat memuat profil hotspot.', 'error');
                }
                voucherProfileSelect.innerHTML = '<option value="">Error Memuat Profil</option>';
                filterProfileSelect.innerHTML = '<option value="">Error Memuat Profil</option>';
                window.cachedHotspotProfiles = [];
            }
        }

        // Function to load IP Pools for Address Pool and Parent Queue dropdowns
        // Updated to accept config_id
        async function loadIPPoolsAndQueuesForSelection(configId) {
            if (!configId) {
                addressPoolSelect.innerHTML = '<option value="none">none</option>';
                parentQueueSelect.innerHTML = '<option value="none">none</option>';
                return;
            }
            try {
                const poolResponse = await fetch(`mikrotik_api.php?action=get_ip_pools&config_id=${configId}`);
                const poolData = await poolResponse.json();

                if (poolData.status === 'success') {
                    addressPoolSelect.innerHTML = '<option value="none">none</option>'; // Default option
                    poolData.pools.forEach(pool => {
                        const option = document.createElement('option');
                        option.value = pool;
                        option.textContent = pool;
                        addressPoolSelect.appendChild(option);
                    });
                } else {
                    if (typeof showNotification === 'function') {
                        showNotification('Gagal memuat daftar IP Pool: ' + poolData.message, 'error');
                    }
                    addressPoolSelect.innerHTML = '<option value="none">Gagal Memuat</option>';
                }

                const queueResponse = await fetch(`mikrotik_api.php?action=get_simple_queues&config_id=${configId}`);
                const queueData = await queueResponse.json();

                if (queueData.status === 'success') {
                    parentQueueSelect.innerHTML = '<option value="none">none</option>'; // Default option
                    queueData.queues.forEach(queue => {
                        const option = document.createElement('option');
                        option.value = queue.name;
                        option.textContent = queue.name;
                        parentQueueSelect.appendChild(option);
                    });
                } else {
                     if (typeof showNotification === 'function') {
                        showNotification('Gagal memuat daftar Parent Queue: ' + queueData.message, 'error');
                    }
                    parentQueueSelect.innerHTML = '<option value="none">Gagal Memuat</option>';
                }
            } catch (error) {
                console.error('Error loading IP Pools or Queues:', error);
                if (typeof showNotification === 'function') {
                    showNotification('Terjadi kesalahan saat memuat daftar IP Pool atau Parent Queue.', 'error');
                }
                addressPoolSelect.innerHTML = '<option value="none">Error Memuat</option>';
                parentQueueSelect.innerHTML = '<option value="none">Error Memuat</option>';
            }
        }


        // Function to fetch and display the saved logo when the page loads
        async function loadSavedLogo() {
            try {
                // Logo is not Mikrotik-specific, so no config_id needed
                const response = await fetch('mikrotik_api.php?action=get_voucher_logo_url');
                const data = await response.json();
                if (data.status === 'success' && data.logo_url) {
                    uploadedLogoUrl = data.logo_url;
                    logoPreviewImg.src = uploadedLogoUrl;
                    logoPreviewImg.style.display = 'block';
                } else {
                    uploadedLogoUrl = '';
                    logoPreviewImg.src = '#';
                    logoPreviewImg.style.display = 'none';
                }
            } catch (error) {
                console.error('Error loading saved logo:', error);
                uploadedLogoUrl = '';
                logoPreviewImg.src = '#';
                logoPreviewImg.style.display = 'none';
            }
        }


        // Event listener for Save Logo button
        if (saveLogoBtn) {
            saveLogoBtn.addEventListener('click', async function() {
                const file = logoUploadInput.files[0];
                if (!file) {
                    if (typeof showNotification === 'function') {
                        showNotification('Pilih file logo terlebih dahulu.', 'warning');
                    }
                    return;
                }

                if (typeof showLoadingOverlay === 'function') {
                    showLoadingOverlay();
                }

                const formData = new FormData();
                formData.append('logo', file);

                try {
                    const response = await fetch('mikrotik_api.php?action=upload_voucher_logo', {
                        method: 'POST',
                        body: formData // FormData sets Content-Type automatically
                    });
                    const data = await response.json();

                    if (typeof hideLoadingOverlay === 'function') {
                        hideLoadingOverlay();
                    }

                    if (data.status === 'success') {
                        if (typeof showNotification === 'function') {
                            showNotification(data.message, 'success');
                        }
                        uploadedLogoUrl = data.logo_url; // Update global URL with saved URL
                        logoPreviewImg.src = uploadedLogoUrl; // Ensure preview shows server-saved version
                        logoPreviewImg.style.display = 'block';
                    } else {
                        if (typeof showNotification === 'function') {
                            showNotification('Gagal menyimpan logo: ' + data.message, 'error');
                        }
                    }
                } catch (error) {
                    if (typeof hideLoadingOverlay === 'function') {
                        hideLoadingOverlay();
                    }
                    console.error('Error saving logo:', error);
                    if (typeof showNotification === 'function') {
                        showNotification('Terjadi kesalahan jaringan atau server saat menyimpan logo.', 'error');
                    }
                }
            });
        }

        // Event listener for Delete Logo button
        if (deleteLogoBtn) {
            deleteLogoBtn.addEventListener('click', async function() {
                if (typeof showCustomConfirm === 'function') {
                    showCustomConfirm('Konfirmasi Hapus Logo', 'Anda yakin ingin menghapus logo voucher yang tersimpan?', async (result) => {
                        if (result) {
                            if (typeof showLoadingOverlay === 'function') {
                                showLoadingOverlay();
                            }
                            try {
                                const response = await fetch('mikrotik_api.php?action=delete_voucher_logo', {
                                    method: 'POST', // Use POST for deletion
                                    headers: { 'Content-Type': 'application/json' },
                                    body: JSON.stringify({}) // No specific data needed for deletion
                                });
                                const data = await response.json();

                                if (typeof hideLoadingOverlay === 'function') {
                                    hideLoadingOverlay();
                                }

                                if (data.status === 'success' || data.status === 'warning') { // Warning if no file existed
                                    if (typeof showNotification === 'function') {
                                        showNotification(data.message, data.status);
                                    }
                                    uploadedLogoUrl = ''; // Clear global URL
                                    logoPreviewImg.src = '#';
                                    logoPreviewImg.style.display = 'none';
                                    logoUploadInput.value = ''; // Clear file input selection
                                } else {
                                    if (typeof showNotification === 'function') {
                                        showNotification('Gagal menghapus logo: ' + data.message, 'error');
                                    }
                                }
                            } catch (error) {
                                if (typeof hideLoadingOverlay === 'function') {
                                    hideLoadingOverlay();
                                }
                                console.error('Error deleting logo:', error);
                                if (typeof showNotification === 'function') {
                                    showNotification('Terjadi kesalahan jaringan atau server saat menghapus logo.', 'error');
                                }
                            }
                        }
                    });
                } else {
                    console.error('Fungsi konfirmasi khusus tidak ditemukan.');
                }
            });
        }


        // --- Voucher Creation Form Submission ---
        if (generateVoucherForm) {
            generateVoucherForm.addEventListener('submit', function(e) {
                e.preventDefault();

                if (!selectedMikrotikConfigId) {
                    showNotification('Pilih konfigurasi MikroTik untuk membuat voucher.', 'warning');
                    return;
                }

                if (typeof showLoadingOverlay === 'function') {
                    showLoadingOverlay();
                }

                const formData = new FormData(this);
                const jsonData = {};
                formData.forEach((value, key) => {
                    jsonData[key] = value;
                });

                // Set default comment if empty
                if (!jsonData.comment || jsonData.comment.trim() === '') {
                     jsonData.comment = "";
                }

                // Ensure `selling_price_gen` is explicitly set to 0 or null if not used,
                // so the backend does not try to access an undefined value.
                jsonData.selling_price_gen = 0;

                // Add config_id to payload
                jsonData.config_id = selectedMikrotikConfigId;


                fetch('mikrotik_api.php?action=generate_voucher', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json'
                    },
                    body: JSON.stringify(jsonData)
                })
                .then(response => response.json())
                .then(data => {
                    if (typeof hideLoadingOverlay === 'function') {
                        hideLoadingOverlay();
                    }
                    if (data.status === 'success') {
                        if (typeof showNotification === 'function') {
                            showNotification(data.message, 'success');
                        }

                        // After successfully creating vouchers, ensure to return to the first page
                        // so new vouchers are visible (as new vouchers are usually at the top of the list)
                        currentPage = 1;
                        fetchAndRenderVouchersFromDB(selectedMikrotikConfigId); // Send config_id
                        
                        generateVoucherForm.reset();
                        voucherProfileSelect.value = '';
                        // Also clear hidden inputs after form reset
                        document.getElementById('validity_gen_input').value = '';
                        document.getElementById('price_gen_input').value = '';
                        // Logo preview is not reset here as saved logo persists
                        updateDeleteProfileButtonState(); // Update button state after reset
                    } else {
                        if (typeof showNotification === 'function') {
                            showNotification('Gagal membuat voucher: ' + data.message, 'error');
                        }
                    }
                })
                .catch(error => {
                    if (typeof hideLoadingOverlay === 'function') {
                        hideLoadingOverlay();
                    }
                    console.error('Error creating voucher:', error);
                    if (typeof showNotification === 'function') {
                        showNotification('Terjadi kesalahan jaringan atau server saat membuat voucher: ' + error.message, 'error');
                    }
                });
            });
        }

        // --- New Function: Fetch and Render Vouchers from Database ---
        // Updated to accept config_id
        async function fetchAndRenderVouchersFromDB(configId) {
            if (!configId) {
                currentVouchers = [];
                displayedVouchers = [];
                renderVouchersToTable([]);
                showNotification('Pilih konfigurasi MikroTik untuk memuat voucher.', 'warning');
                return;
            }

            if (typeof showLoadingOverlay === 'function') {
                showLoadingOverlay();
            }
            try {
                // Fetch data from the database, FILTERED by config_id
                const dbResponse = await fetch(`mikrotik_api.php?action=get_vouchers_from_db&config_id=${configId}`);
                const dbData = await dbResponse.json();

                if (dbData.status !== 'success') {
                    if (typeof showNotification === 'function') {
                        showNotification('Gagal memuat voucher dari database: ' + dbData.message, 'error');
                    }
                    if (typeof hideLoadingOverlay === 'function') {
                        hideLoadingOverlay();
                    }
                    return;
                }

                let tempVouchers = dbData.vouchers.map(voucher => ({
                    db_id: voucher.db_id,
                    name: voucher.username,
                    password: voucher.password,
                    profile: voucher.profile,
                    comment: voucher.comment, // This is the comment from DB (original description)
                    server: 'N/A', // Default for display, will be overwritten if active
                    'mac-address': 'N/A', // Default for display, will be overwritten if active
                    uptime: '0s', // Default for display (new voucher has no uptime yet)
                    'session-time-left': 'N/A', // Default for display, will be overwritten if active
                    'bytes-in': 0, // Default for display, will be overwritten if active
                    'bytes-out': 0, // Default for display, will be overwritten if active
                    disabled: 'false', // Default for display, will be overwritten if active
                    mikrotik_id: voucher.mikrotik_id, // Get mikrotik_id from DB
                    price: voucher.price,
                }));

                // Fetch data from the selected Mikrotik
                const mikrotikResponse = await fetch(`mikrotik_api.php?action=get_hotspot_users&config_id=${configId}`);
                const mikrotikData = await mikrotikResponse.json();

                if (mikrotikData.status === 'success' && mikrotikData.users && mikrotikData.users.length > 0) {
                    // Create a map from Mikrotik username to Mikrotik ID and other details
                    const mikrotikUsersMap = {};
                    mikrotikData.users.forEach(user => {
                        mikrotikUsersMap[user.name] = user;
                    });

                    // Merge data from the database with data from Mikrotik
                    currentVouchers = tempVouchers.map(dbVoucher => {
                        const mikrotikUser = mikrotikUsersMap[dbVoucher.name];
                        if (mikrotikUser) {
                            return {
                                ...dbVoucher,
                                // Corrected: Do NOT overwrite dbVoucher.mikrotik_id with mikrotikUser['.id']
                                // The mikrotik_id from dbVoucher is the configuration ID needed for filtering.
                                mikrotik_user_id: mikrotikUser['.id'], // Store MikroTik's internal user ID in a new property if needed
                                server: mikrotikUser.server || dbVoucher.server,
                                'mac-address': mikrotikUser['mac-address'] || dbVoucher['mac-address'],
                                uptime: mikrotikUser.uptime || dbVoucher.uptime,
                                'session-time-left': mikrotikUser['session-time-left'] || dbVoucher['session-time-left'],
                                'bytes-in': mikrotikUser['bytes-in'] ? parseInt(mikrotikUser['bytes-in']) : dbVoucher['bytes-in'],
                                'bytes-out': mikrotikUser['bytes-out'] ? parseInt(mikrotikUser['bytes-out']) : dbVoucher['bytes-out'],
                                disabled: mikrotikUser.disabled || dbVoucher.disabled,
                                // IMPORTANT: Use current Mikrotik comment for display, as it contains expiration date
                                comment: mikrotikUser.comment || dbVoucher.comment, // Prefer Mikrotik comment if available
                            };
                        }
                        return dbVoucher; // If not found in Mikrotik, use data from DB only
                    });
                } else {
                    if (typeof showNotification === 'function') {
                        showNotification('Gagal memuat pengguna hotspot dari MikroTik atau tidak ada data. Hanya menampilkan data dari database.', 'warning');
                    }
                    currentVouchers = tempVouchers; // Only use data from DB if Mikrotik failed or empty
                }

                applyFilters(); // Apply filters after loading new data
                if (typeof hideLoadingOverlay === 'function') {
                    hideLoadingOverlay();
                }
            } catch (error) {
                if (typeof hideLoadingOverlay === 'function') {
                    hideLoadingOverlay();
                }
                console.error('Error fetching and rendering vouchers:', error);
                if (typeof showNotification === 'function') {
                    showNotification('Terjadi kesalahan saat memuat dan menggabungkan data voucher: ' + error.message, 'error');
                }
            }
        }


        // --- Function to apply filters ---
        function applyFilters() {
            const searchTerm = searchVoucherInput.value.toLowerCase();
            const selectedProfile = filterProfileSelect.value;
            const selectedStatus = filterStatusSelect.value;

            // Filter by mikrotik_id first
            const filteredByMikrotik = currentVouchers.filter(voucher => {
                // Ensure mikrotik_id is checked only if selectedMikrotikConfigId is set
                if (selectedMikrotikConfigId && voucher.mikrotik_id != selectedMikrotikConfigId) {
                    return false;
                }
                return true;
            });


            displayedVouchers = filteredByMikrotik.filter(voucher => {
                const matchesSearch = (searchTerm === '' || voucher.name.toLowerCase().includes(searchTerm) ||
                                       voucher.profile.toLowerCase().includes(searchTerm) ||
                                       (voucher.comment && voucher.comment.toLowerCase().includes(searchTerm)));
                const matchesProfile = (selectedProfile === '' || voucher.profile === selectedProfile);

                let actualStatus = 'enabled'; // Default to enabled
                if (voucher.disabled === 'true') {
                    actualStatus = 'disabled';
                } else {
                    // Check expiration based on date in comment (YYYY-MM-DD HH:MM:SS | Original Comment)
                    let isExpiredByComment = false;
                    const commentValue = voucher.comment || '';
                    let expirationDateFromComment = null; // null if none or invalid

                    // Try to match the full format first
                    const commentMatchWithPipe = commentValue.match(/^(\d{4}-\d{2}-\d{2}\s\d{2}:\d{2}:\d{2})\s\|\s(.*)/);
                    if (commentMatchWithPipe) {
                        expirationDateFromComment = commentMatchWithPipe[1];
                    } else {
                        // Fallback to just the date-time string if no pipe is found
                        const commentMatchOnlyDate = commentValue.match(/^(\d{4}-\d{2}-\d{2}\s\d{2}:\d{2}:\d{2})$/);
                        if (commentMatchOnlyDate) {
                            expirationDateFromComment = commentMatchOnlyDate[1];
                        }
                    }

                    if (expirationDateFromComment) { // Only attempt to parse if a potential date string was found
                        try {
                            const expiryDateTime = new Date(expirationDateFromComment);
                            const currentDateTime = new Date();
                            if (expiryDateTime < currentDateTime) {
                                isExpiredByComment = true;
                            }
                        } catch (e) {
                            console.error("Error parsing expiration date in filter:", expirationDateFromComment, e);
                        }
                    }

                    if (isExpiredByComment) {
                        actualStatus = 'expired';
                    }
                }

                const matchesStatus = (selectedStatus === '' || actualStatus === selectedStatus);

                return matchesSearch && matchesProfile && matchesStatus;
            });
            currentPage = 1; // Return to the first page each time filters are applied
            renderVouchersToTable(displayedVouchers);
            updateCheckAllCheckbox();
        }

        // --- Event Listener for Refresh ---
        if (refreshBtn) {
            refreshBtn.addEventListener('click', function() {
                searchVoucherInput.value = '';
                filterProfileSelect.value = '';
                filterStatusSelect.value = '';
                selectedVoucherIds = [];
                currentPage = 1; // Reset page to 1 on refresh
                fetchAndRenderVouchersFromDB(selectedMikrotikConfigId); // Send config_id
            });
        }

        // START: Event Listener for Delete Expired Users Button
        if (deleteExpiredUsersBtn) {
            deleteExpiredUsersBtn.addEventListener('click', function() {
                if (!selectedMikrotikConfigId) {
                    showNotification('Pilih konfigurasi MikroTik untuk menghapus user kedaluwarsa.', 'warning');
                    return;
                }

                if (typeof showCustomConfirm === 'function') {
                    showCustomConfirm('Konfirmasi Hapus User Kedaluwarsa', 'Anda yakin ingin menghapus SEMUA user hotspot yang kedaluwarsa atau dinonaktifkan dari MikroTik YANG DIPILIH DAN Database? Aksi ini tidak dapat dibatalkan.', (result) => {
                        if (result) {
                            if (typeof showLoadingOverlay === 'function') {
                                showLoadingOverlay();
                            }
                            fetch(`mikrotik_api.php?action=remove_expired_hotspot_users&config_id=${selectedMikrotikConfigId}`, { // Send config_id
                                method: 'POST',
                                headers: { 'Content-Type': 'application/json' },
                                body: JSON.stringify({})
                            })
                            .then(response => {
                                if (!response.ok) {
                                    throw new Error(`HTTP error! status: ${response.status}`);
                                    }
                                    return response.json();
                                })
                                .then(data => {
                                    if (typeof hideLoadingOverlay === 'function') {
                                        hideLoadingOverlay();
                                    }
                                    if (data.status === 'success' || data.status === 'warning' || data.status === 'info') {
                                        if (typeof showNotification === 'function') {
                                            showNotification(data.message, data.status);
                                        }
                                        selectedVoucherIds = [];
                                        currentPage = 1; // Reset page to 1 after deletion
                                        fetchAndRenderVouchersFromDB(selectedMikrotikConfigId); // Send config_id
                                    } else {
                                        if (typeof showNotification === 'function') {
                                            showNotification('Gagal menghapus user kedaluwarsa: ' + data.message, 'error');
                                        }
                                    }
                                })
                                .catch(err => {
                                    if (typeof hideLoadingOverlay === 'function') {
                                        hideLoadingOverlay();
                                    }
                                    console.error('Error during expired user deletion fetch:', err);
                                    if (typeof showNotification === 'function') {
                                        showNotification('Terjadi kesalahan jaringan atau server saat menghapus user kedaluwarsa: ' + err.message, 'error');
                                    }
                                });
                        }
                    });
                } else {
                    console.error('Custom confirmation function not found.');
                }
            });
        }
        // END: Event Listener for Delete Expired Users Button


        if (searchVoucherInput) {
            searchVoucherInput.addEventListener('keyup', applyFilters);
        }

        if (filterProfileSelect) {
            filterProfileSelect.addEventListener('change', applyFilters);
        }
        if (filterStatusSelect) {
            filterStatusSelect.addEventListener('change', applyFilters);
        }

        if (checkAllVouchers) {
            checkAllVouchers.addEventListener('change', function() {
                selectedVoucherIds = [];
                // Only select vouchers currently displayed on the active page
                const checkboxes = document.querySelectorAll('#voucherTableBody .voucher-checkbox');
                checkboxes.forEach(checkbox => {
                    checkbox.checked = this.checked;
                    if (this.checked) {
                        selectedVoucherIds.push({
                            db_id: parseInt(checkbox.dataset.dbId),
                            username: checkbox.dataset.username,
                            mikrotik_id: checkbox.dataset.mikrotikId
                        });
                    }
                });
                updateDeleteButtonVisibility();
                updateCheckAllCheckbox(); // This will manage the indeterminate status
            });
        }

        if (deleteSelectedVouchersBtn) {
            deleteSelectedVouchersBtn.addEventListener('click', function() {
                if (!selectedMikrotikConfigId) {
                    showNotification('Pilih konfigurasi MikroTik untuk menghapus voucher.', 'warning');
                    return;
                }
                if (selectedVoucherIds.length === 0) {
                    if (typeof showNotification === 'function') {
                        showNotification('Tidak ada voucher yang dipilih untuk dihapus.', 'warning');
                    }
                    return;
                }

                if (typeof showCustomConfirm === 'function') {
                    showCustomConfirm('Konfirmasi Hapus', `Anda yakin ingin menghapus ${selectedVoucherIds.length} voucher yang dipilih dari MikroTik YANG DIPILIH DAN Database?`, (result) => {
                        if (result) {
                            if (typeof showLoadingOverlay === 'function') {
                                showLoadingOverlay();
                            }
                            fetch(`mikrotik_api.php?action=delete_multiple_vouchers&config_id=${selectedMikrotikConfigId}`, { // Send config_id
                                method: 'POST',
                                headers: { 'Content-Type': 'application/json' },
                                body: JSON.stringify({ vouchers: selectedVoucherIds })
                            })
                            .then(response => {
                                if (!response.ok) {
                                    throw new Error(`HTTP error! status: ${response.status}`);
                                }
                                return response.json();
                            })
                            .then(data => {
                                if (typeof hideLoadingOverlay === 'function') {
                                    hideLoadingOverlay();
                                }
                                if (data.status === 'success' || data.status === 'warning') {
                                    if (typeof showNotification === 'function') {
                                        showNotification(data.message, data.status);
                                    }
                                    selectedVoucherIds = [];
                                    currentPage = 1; // Reset page to 1 after deletion
                                    fetchAndRenderVouchersFromDB(selectedMikrotikConfigId); // Send config_id
                                } else {
                                    if (typeof showNotification === 'function') {
                                        showNotification('Gagal menghapus voucher: ' + data.message, 'error');
                                    }
                                }
                            })
                            .catch(err => {
                                if (typeof hideLoadingOverlay === 'function') {
                                    hideLoadingOverlay();
                                }
                                console.error('Error during voucher deletion fetch:', err);
                                if (typeof showNotification === 'function') {
                                    showNotification('Terjadi kesalahan jaringan atau server saat menghapus voucher: ' + err.message, 'error');
                                }
                            });
                        }
                    });
                } else {
                    console.error('Custom confirmation function not found.');
                }
            });
        }

        // This function has no button in HTML, so comment out or remove if not used
        /*
        if (clearVouchersBtn) {
            clearVouchersBtn.addEventListener('click', function() {
                if (typeof showCustomConfirm === 'function') {
                    showCustomConfirm('Konfirmasi Bersihkan Database', 'Apakah Anda yakin ingin menghapus SEMUA daftar voucher dari database? Ini tidak akan menghapus dari MikroTik.', (result) => {
                        if (result) {
                            if (typeof showLoadingOverlay === 'function') {
                                showLoadingOverlay();
                            }
                            fetch('mikrotik_api.php?action=clear_vouchers_from_db', {
                                method: 'POST',
                                headers: { 'Content-Type': 'application/json' },
                                body: JSON.stringify({})
                            }).then(res => res.json()).then(dbData => {
                                if (typeof hideLoadingOverlay === 'function') {
                                    hideLoadingOverlay();
                                }
                                if (dbData.status === 'success') {
                                    currentVouchers = [];
                                    displayedVouchers = [];
                                    selectedVoucherIds = [];
                                    renderVouchersToTable(currentVouchers);
                                    if (typeof showNotification === 'function') {
                                        showNotification('Daftar voucher berhasil dibersihkan dari database.', 'info');
                                    }
                                } else {
                                    if (typeof showNotification === 'function') {
                                        showNotification('Gagal membersihkan voucher dari database: ' + dbData.message, 'error');
                                    }
                                }
                            }).catch(err => {
                                if (typeof hideLoadingOverlay === 'function') {
                                    hideLoadingOverlay();
                                }
                                console.error('Error clearing database:', err);
                                if (typeof showNotification === 'function') {
                                    showNotification('Terjadi kesalahan jaringan atau server saat membersihkan database.', 'error');
                                }
                            });
                        }
                    });
                } else {
                    console.error('Custom confirmation function not found.');
                }
            });
        }
        */

        // --- Add Hotspot Profile Modal Logic ---
        function showAddProfileModalCleanly() {
            addProfileModal.style.display = 'flex';
            addProfileModal.offsetWidth;
            addProfileModal.classList.add('show');
            updateDeleteProfileButtonState();
            // Call this with the selected config_id in the modal
            loadIPPoolsAndQueuesForSelection(mikrotikConfigSelectProfile.value); 
            addProfileForm.reset();
            // Set default values for options that might not reset to initial '0' or 'none'
            expireModeSelect.value = '0';
            userKeySelect.value = 'Disable';
            addressPoolSelect.value = 'none';
            parentQueueSelect.value = 'none';
            // Clear price field
            priceInput.value = '';
        }

        function hideAddProfileModalCleanly() {
            addProfileModal.classList.remove('show');
            const onTransitionEnd = () => {
                if (!addProfileModal.classList.contains('show')) {
                    addProfileModal.style.display = 'none';
                }
                addProfileModal.removeEventListener('transitionend', onTransitionEnd);
            };
            addProfileModal.addEventListener('transitionend', onTransitionEnd);
        }

        // Function to update the visibility of the delete profile button inside the modal
        function updateDeleteProfileButtonState() {
            if (deleteProfileInModalBtn && voucherProfileSelect) {
                // Check if a profile is selected in the main dropdown
                if (voucherProfileSelect.value && voucherProfileSelect.value !== "") {
                    // Check if the selected profile exists in cachedHotspotProfiles
                    const selectedProfileExists = window.cachedHotspotProfiles.some(p => p.name === voucherProfileSelect.value);
                    if (selectedProfileExists) {
                        deleteProfileInModalBtn.style.display = 'inline-block';
                    } else {
                        deleteProfileInModalBtn.style.display = 'none';
                    }
                } else {
                    deleteProfileInModalBtn.style.display = 'none';
                }
            }
        }


        if (addHotspotProfileBtn) {
            addHotspotProfileBtn.addEventListener('click', showAddProfileModalCleanly);
        }

        if (closeButton) {
            closeButton.addEventListener('click', hideAddProfileModalCleanly);
        }

        window.addEventListener('click', function(event) {
            if (event.target == addProfileModal) {
                hideAddProfileModalCleanly();
            }
        });

        if (addProfileForm) {
            addProfileForm.addEventListener('submit', function(e) {
                e.preventDefault();

                const configIdForProfile = mikrotikConfigSelectProfile.value;
                if (!configIdForProfile) {
                    showNotification('Pilih konfigurasi MikroTik untuk membuat profil.', 'warning');
                    return;
                }

                if (typeof showLoadingOverlay === 'function') {
                    showLoadingOverlay();
                }

                const formData = new FormData(this);
                const profileData = {};
                formData.forEach((value, key) => {
                    profileData[key] = value;
                });

                // Manually add values from specific dropdowns/inputs
                profileData['address-pool'] = addressPoolSelect.value;
                profileData['mode-kadaluwarsa'] = expireModeSelect.value;
                profileData['validity'] = validityInput.value;
                profileData['price'] = priceInput.value;
                profileData['selling-price'] = 0; // Explicitly set selling-price to 0
                profileData['user-key'] = userKeySelect.value; // For MAC Lock
                profileData['parent'] = parentQueueSelect.value; // For Parent Queue

                // Clean the name according to adduserprofile.php logic
                profileData.name = profileNameInput.value.replace(/\s+/g, '-');

                // Add config_id to payload
                profileData.config_id = configIdForProfile;


                fetch('mikrotik_api.php?action=add_hotspot_profile', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json'
                    },
                    body: JSON.stringify(profileData)
                })
                .then(response => response.json())
                .then(data => {
                    if (typeof hideLoadingOverlay === 'function') {
                        hideLoadingOverlay();
                    }
                    if (data.status === 'success') {
                        if (typeof showNotification === 'function') {
                            showNotification(data.message, 'success');
                        }
                        hideAddProfileModalCleanly();
                        addProfileForm.reset();
                        expireModeSelect.value = '0';
                        userKeySelect.value = 'Disable';
                        addressPoolSelect.value = 'none';
                        parentQueueSelect.value = 'none';
                        priceInput.value = '';
                        // Reload profiles with the correct config_id
                        loadHotspotProfilesForSelection(selectedMikrotikConfigId); 
                        // Reload IP Pools/Queues with the correct config_id
                        loadIPPoolsAndQueuesForSelection(selectedMikrotikConfigId);
                    } else {
                        if (typeof showNotification === 'function') {
                            showNotification('Gagal menambah profil hotspot: ' + data.message, 'error');
                        }
                    }
                })
                .catch(error => {
                    if (typeof hideLoadingOverlay === 'function') {
                        hideLoadingOverlay();
                    }
                    console.error('Error adding hotspot profile:', error);
                    if (typeof showNotification === 'function') {
                        showNotification('Terjadi kesalahan jaringan atau server saat menambah profil hotspot.', 'error');
                    }
                });
            });
        }

        // Event listener for delete profile button inside the modal
        if (deleteProfileInModalBtn) {
            deleteProfileInModalBtn.addEventListener('click', function() {
                const profileToDelete = voucherProfileSelect.value; // Get from main dropdown
                if (!profileToDelete || profileToDelete === "") {
                    if (typeof showNotification === 'function') {
                        showNotification('Tidak ada profil yang dipilih untuk dihapus.', 'warning');
                    }
                    return;
                }

                if (!selectedMikrotikConfigId) {
                    showNotification('Pilih konfigurasi MikroTik untuk menghapus profil.', 'warning');
                    return;
                }

                if (typeof showCustomConfirm === 'function') {
                    showCustomConfirm('Konfirmasi Hapus Profil', `Anda yakin ingin menghapus profil hotspot "${profileToDelete}" dari MikroTik YANG DIPILIH? Aksi ini tidak dapat dibatalkan.`, (result) => {
                        if (result) {
                            if (typeof showLoadingOverlay === 'function') {
                                showLoadingOverlay();
                            }
                            fetch(`mikrotik_api.php?action=delete_hotspot_profile&config_id=${selectedMikrotikConfigId}`, { // Send config_id
                                method: 'POST',
                                headers: {
                                    'Content-Type': 'application/json'
                                },
                                body: JSON.stringify({ profile_name: profileToDelete })
                            })
                            .then(response => {
                                if (!response.ok) {
                                    throw new Error(`HTTP error! status: ${response.status}`);
                                }
                                return response.json();
                            })
                            .then(data => {
                                if (typeof hideLoadingOverlay === 'function') {
                                    hideLoadingOverlay();
                                }
                                if (data.status === 'success' || data.status === 'warning') {
                                    if (typeof showNotification === 'function') {
                                        showNotification(data.message, data.status);
                                    }
                                    loadHotspotProfilesForSelection(selectedMikrotikConfigId); // Reload profiles
                                    loadIPPoolsAndQueuesForSelection(selectedMikrotikConfigId); // Reload IP Pools/Queues
                                    addProfileForm.reset(); // Reset modal form
                                    // Set default values for modal dropdowns after reset
                                    expireModeSelect.value = '0';
                                    userKeySelect.value = 'Disable';
                                    addressPoolSelect.value = 'none';
                                    parentQueueSelect.value = 'none';
                                    priceInput.value = '';
                                    hideAddProfileModalCleanly();
                                } else {
                                    if (typeof showNotification === 'function') {
                                        showNotification('Gagal menghapus profil: ' + data.message, 'error');
                                    }
                                }
                            })
                            .catch(error => {
                                if (typeof hideLoadingOverlay === 'function') {
                                    hideLoadingOverlay();
                                }
                                console.error('Error deleting hotspot profile:', error);
                                if (typeof showNotification === 'function') {
                                    showNotification('Terjadi kesalahan jaringan atau server saat menghapus profil hotspot: ' + error.message, 'error');
                                }
                            });
                        } else {
                            if (typeof showNotification === 'function') {
                                showNotification('Penghapusan profil dibatalkan.', 'info');
                            }
                        }
                    });
                } else {
                    console.error('Custom confirmation function not found.');
                }
            });
        }

        // Listen for changes in the main voucher profile selection to update delete button state
        if (voucherProfileSelect) {
            voucherProfileSelect.addEventListener('change', updateDeleteProfileButtonState);

            voucherProfileSelect.addEventListener('change', async function() {
                const selectedProfile = this.value;
                if (selectedProfile && window.cachedHotspotProfiles) {
                    const profileDetails = window.cachedHotspotProfiles.find(p => p.name === selectedProfile);
                    if (profileDetails) {
                        const priceValue = parseFloat(profileDetails.price || '0') || 0;

                        document.getElementById('validity_gen_input').value = profileDetails.validity === 'Tidak Terbatas' ? '' : profileDetails.validity;
                        document.getElementById('price_gen_input').value = priceValue;

                        // Update modal form fields with selected profile details from main dropdown
                        profileNameInput.value = profileDetails.name || '';
                        rateLimitInput.value = profileDetails['rate-limit'] || '';
                        sharedUsersInput.value = profileDetails['shared-users'] || '1';
                        addressPoolSelect.value = profileDetails['address-pool'] || 'none';
                        expireModeSelect.value = profileDetails['status-mode-kadaluwarsa'] === 'Tidak Ada' ? '0' :
                                                 (profileDetails['status-mode-kadaluwarsa'] === 'Remove' ? 'rem' : '0');
                        validityInput.value = profileDetails.validity === 'Tidak Terbatas' ? '' : profileDetails.validity;
                        priceInput.value = priceValue;
                        userKeySelect.value = profileDetails['user-key'] || 'Disable';
                        parentQueueSelect.value = profileDetails['parent-queue'] || 'none';

                    } else {
                        document.getElementById('validity_gen_input').value = '';
                        document.getElementById('price_gen_input').value = '';
                        // Reset fields in the modal form if no profile or a non-existent profile is selected
                        profileNameInput.value = '';
                        rateLimitInput.value = '';
                        sharedUsersInput.value = '1';
                        addressPoolSelect.value = 'none';
                        expireModeSelect.value = '0';
                        validityInput.value = '';
                        priceInput.value = '';
                        userKeySelect.value = 'Disable';
                        parentQueueSelect.value = 'none';
                    }
                } else {
                    document.getElementById('validity_gen_input').value = '';
                    document.getElementById('price_gen_input').value = '';
                    // Reset fields in the modal form if 'Pilih Profil' is selected
                    profileNameInput.value = '';
                    rateLimitInput.value = '';
                    sharedUsersInput.value = '1';
                    addressPoolSelect.value = 'none';
                    expireModeSelect.value = '0';
                    validityInput.value = '';
                    priceInput.value = '';
                    userKeySelect.value = 'Disable';
                    parentQueueSelect.value = 'none';
                }
            });
        }


        window.printVouchers = function() {
            if (displayedVouchers.length === 0) {
                if (typeof showNotification === 'function') {
                    showNotification('Tidak ada voucher untuk dicetak.', 'warning');
                }
                return;
            }

            const printWindow = window.open('', '_blank');
            printWindow.document.write('<html><head><title>Cetak Voucher Hotspot</title>');
            printWindow.document.write('<style>');
            printWindow.document.write(`
                body { font-family: 'Inter', sans-serif; margin: 20px; }
                .voucher-container {
                    display: grid;
                    grid-template-columns: repeat(auto-fill, minmax(280px, 1fr));
                    gap: 20px;
                    page-break-inside: avoid;
                }
                .voucher-card {
                    border: 1px solid #ddd;
                    padding: 15px;
                    text-align: center;
                    border-radius: 8px;
                    box-shadow: 0 2px 5px rgba(0,0,0,0.1);
                    background-color: #f9f9f9;
                    page-break-inside: avoid;
                    display: flex;
                    flex-direction: column;
                    justify-content: space-between;
                }
                .voucher-card h3 {
                    color: #333;
                    font-size: 1.3em;
                    margin-top: 0;
                    margin-bottom: 10px;
                }
                .voucher-card p {
                    margin: 5px 0;
                    font-size: 0.9em;
                    color: #555;
                }
                .voucher-card strong {
                    color: #000;
                    font-size: 1.1em;
                }
                .voucher-card .price-info {
                    font-size: 0.85em;
                    color: #777;
                    margin-top: 5px;
                }
                .voucher-logo {
                    max-width: 80px; /* Adjust as needed */
                    max-height: 80px; /* Adjust as needed */
                    margin: 0 auto 10px auto;
                    display: block;
                }
                @media print {
                    body { margin: 10mm; }
                    .voucher-container {
                        grid-template-columns: repeat(2, 1fr);
                        gap: 15mm;
                    }
                    .voucher-card {
                        box-shadow: none;
                        border: 1px dashed #ccc;
                    }
                }
            `);
            printWindow.document.write('</style></head><body>');
            printWindow.document.write('<h2 style="text-align:center;">Daftar Voucher Hotspot</h2>');
            printWindow.document.write('<div class="voucher-container">');

            // Get the selected Mikrotik name to display in the printout
            // (Still fetched but not displayed in the card directly as per request)
            const selectedConfigForPrint = window.cachedMikrotikConfigs.find(config => config.id == selectedMikrotikConfigId);
            const selectedMikrotikNameForPrint = selectedConfigForPrint ? selectedConfigForPrint.name : 'N/A';


            displayedVouchers.forEach(user => {
                const priceDisplay = user.price && user.price !== '0' ? `<p class="price-info">Harga: <strong>${formatCurrency(user.price)}</strong></p>` : '';

                // Removed expirationDateForPrint, originalCommentPartForPrint, expiryLine, and commentLine logic for print

                // Add logo if available
                const logoHtml = uploadedLogoUrl ? `<img src="${uploadedLogoUrl}" class="voucher-logo" alt="Logo">` : '';


                printWindow.document.write(`
                    <div class="voucher-card">
                        ${logoHtml}
                        <h3>Voucher Hotspot</h3>
                        <p>Username: <strong>${user.name}</strong></p>
                        <p>Password: <strong>${user.password}</strong></p>
                        <p>Profile: <strong>${user.profile}</strong></p>
                        <!-- Removed Masa Berlaku/Kedaluwarsa line -->
                        <!-- Removed Server line -->
                        <!-- Removed Waktu Tersisa line -->
                        <!-- Removed Komentar line -->
                        ${priceDisplay}
                    </div>
                `);
            });

            printWindow.document.write('</div>');
            printWindow.document.write('</body></html>');
            printWindow.document.close();
            printWindow.print();
        };

        // --- Function to load Mikrotik configurations ---
        async function loadMikrotikConfigs() {
            try {
                const response = await fetch('mikrotik_api.php?action=get_mikrotik_configs');
                const data = await response.json();

                mikrotikConfigSelectCreate.innerHTML = ''; // For voucher creation form
                // mikrotikConfigSelectFilter.innerHTML = ''; // Removed from here
                mikrotikConfigSelectProfile.innerHTML = ''; // For add profile modal

                if (data.status === 'success' && data.configs && Array.isArray(data.configs) && data.configs.length > 0) {
                    window.cachedMikrotikConfigs = data.configs; // Cache configurations
                    
                    data.configs.forEach(config => {
                        const optionCreate = document.createElement('option');
                        optionCreate.value = config.id;
                        optionCreate.textContent = `${config.name} (${config.ip_address})`;
                        mikrotikConfigSelectCreate.appendChild(optionCreate);

                        // const optionFilter = document.createElement('option'); // Removed from here
                        // optionFilter.value = config.id; // Removed from here
                        // optionFilter.textContent = `${config.name} (${config.ip_address})`; // Removed from here
                        // mikrotikConfigSelectFilter.appendChild(optionFilter); // Removed from here

                        const optionProfile = document.createElement('option');
                        optionProfile.value = config.id;
                        optionProfile.textContent = `${config.name} (${config.ip_address})`;
                        mikrotikConfigSelectProfile.appendChild(optionProfile);
                    });

                    // Set the Mikrotik selection saved in localStorage or the first one as default
                    if (selectedMikrotikConfigId && data.configs.some(c => c.id == selectedMikrotikConfigId)) {
                        mikrotikConfigSelectCreate.value = selectedMikrotikConfigId;
                        // mikrotikConfigSelectFilter.value = selectedMikrotikConfigId; // Removed from here
                        mikrotikConfigSelectProfile.value = selectedMikrotikConfigId;
                    } else {
                        // Default to the first Mikrotik if none is saved or invalid
                        mikrotikConfigSelectCreate.value = data.configs[0].id;
                        // mikrotikConfigSelectFilter.value = data.configs[0].id; // Removed from here
                        mikrotikConfigSelectProfile.value = data.configs[0].id;
                        selectedMikrotikConfigId = data.configs[0].id; // Update global variable
                        localStorage.setItem('selectedMikrotikConfigId', selectedMikrotikConfigId); // Save to localStorage
                    }
                } else {
                    mikrotikConfigSelectCreate.innerHTML = '<option value="">Tidak ada konfigurasi MikroTik</option>';
                    // mikrotikConfigSelectFilter.innerHTML = '<option value="">Tidak ada konfigurasi MikroTik</option>'; // Removed from here
                    mikrotikConfigSelectProfile.innerHTML = '<option value="">Tidak ada konfigurasi MikroTik</option>';
                    mikrotikConfigSelectCreate.disabled = true;
                    // mikrotikConfigSelectFilter.disabled = true; // Removed from here
                    mikrotikConfigSelectProfile.disabled = true;
                    selectedMikrotikConfigId = null; // Reset selected ID
                    localStorage.removeItem('selectedMikrotikConfigId');
                    showNotification('Tidak ada konfigurasi MikroTik yang tersimpan. Silakan tambahkan di Pengaturan API MikroTik.', 'warning');
                }

                // After loading configurations, proceed to load profiles and vouchers
                if (selectedMikrotikConfigId) {
                    loadHotspotProfilesForSelection(selectedMikrotikConfigId);
                    loadIPPoolsAndQueuesForSelection(selectedMikrotikConfigId);
                    fetchAndRenderVouchersFromDB(selectedMikrotikConfigId);
                } else {
                    // If no Mikrotik, clear display
                    loadHotspotProfilesForSelection(null);
                    loadIPPoolsAndQueuesForSelection(null);
                    fetchAndRenderVouchersFromDB(null);
                }

            } catch (error) {
                console.error('Error loading Mikrotik configurations:', error);
                mikrotikConfigSelectCreate.innerHTML = '<option value="">Gagal memuat konfigurasi</option>';
                // mikrotikConfigSelectFilter.innerHTML = '<option value="">Gagal memuat konfigurasi</option>'; // Removed from here
                mikrotikConfigSelectProfile.innerHTML = '<option value="">Gagal memuat konfigurasi</option>';
                mikrotikConfigSelectCreate.disabled = true;
                // mikrotikConfigSelectFilter.disabled = true; // Removed from here
                mikrotikConfigSelectProfile.disabled = true;
                selectedMikrotikConfigId = null;
                localStorage.removeItem('selectedMikrotikConfigId');
                showNotification('Terjadi kesalahan saat memuat daftar konfigurasi MikroTik.', 'error');

                // Even if error, try to load vouchers from DB only if no Mikrotik
                loadHotspotProfilesForSelection(null);
                loadIPPoolsAndQueuesForSelection(null);
                fetchAndRenderVouchersFromDB(null);
            }
        }

        // Event listener for Mikrotik selection change in 'Create Voucher' form
        if (mikrotikConfigSelectCreate) {
            mikrotikConfigSelectCreate.addEventListener('change', function() {
                selectedMikrotikConfigId = this.value;
                localStorage.setItem('selectedMikrotikConfigId', selectedMikrotikConfigId);
                // Sync other dropdowns - mikrotikConfigSelectFilter is removed
                // if (mikrotikConfigSelectFilter) mikrotikConfigSelectFilter.value = this.value; // Removed
                if (mikrotikConfigSelectProfile) mikrotikConfigSelectProfile.value = this.value;

                // Reload data dependent on the selected Mikrotik
                loadHotspotProfilesForSelection(selectedMikrotikConfigId);
                loadIPPoolsAndQueuesForSelection(selectedMikrotikConfigId);
                fetchAndRenderVouchersFromDB(selectedMikrotikConfigId);
            });
        }

        // Event listener for Mikrotik selection change in add profile modal
        if (mikrotikConfigSelectProfile) {
            mikrotikConfigSelectProfile.addEventListener('change', function() {
                // When selection in modal changes, load IP Pools and Queues for the newly selected Mikrotik
                loadIPPoolsAndQueuesForSelection(this.value);
            });
        }


        // Initial load when DOM is ready
        loadMikrotikConfigs(); // This will trigger loading profiles, IP Pools/Queues, and vouchers
        loadSavedLogo(); // Call function to load saved logo when page loads
    });
</script>