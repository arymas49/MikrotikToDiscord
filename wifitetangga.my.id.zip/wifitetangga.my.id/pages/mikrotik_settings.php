<?php
// C:\xampp\htdocs\billing_isp_app\pages\mikrotik_settings.php

ini_set('session.use_strict_mode', 1);
ini_set('session.cookie_httponly', 1);
ini_set('session.cookie_samesite', 'Lax');
if (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on') {
    ini_set('session.cookie_secure', 1);
}
session_start();
include '../config/koneksi.php';
include '../includes/header.php';

// Pastikan hanya superadmin yang bisa mengakses halaman ini
if (!hasRole('superadmin')) {
    echo "<script>
            alert('Anda tidak memiliki akses ke halaman ini.');
            window.location.href = '../pages/dashboard.php';
          </script>";
    exit();
}

$message = '';
$message_type = ''; // success, error, warning

// Ambil semua pengaturan Mikrotik yang sudah ada
$mikrotik_configs = [];
// Tambahkan kolom 'server_url' ke query SELECT
$query_all = "SELECT id, name, ip_address, username, port_api, server_url FROM mikrotik_settings ORDER BY name ASC";
$result_all = $koneksi->query($query_all);
if ($result_all) {
    while ($row = $result_all->fetch_assoc()) {
        $mikrotik_configs[] = $row;
    }
} else {
    $message = 'Gagal memuat konfigurasi Mikrotik dari database: ' . $koneksi->error;
    $message_type = 'error';
}

// Tangani aksi POST (tambah/edit/hapus)
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action_post = $_POST['action'] ?? '';

    if ($action_post === 'save') {
        $config_id = $_POST['config_id'] ?? null;
        $new_name = $koneksi->real_escape_string($_POST['name']);
        $new_ip = $koneksi->real_escape_string($_POST['ip_address']);
        $new_username = $koneksi->real_escape_string($_POST['username']);
        $new_password = $koneksi->real_escape_string($_POST['password']);
        $new_port_api = $koneksi->real_escape_string($_POST['port_api']);
        $new_server_url = $koneksi->real_escape_string($_POST['server_url']); // Ambil nilai server_url

        if (empty($new_name) || empty($new_ip) || empty($new_username)) {
            $message = 'Nama, IP Address, dan Username tidak boleh kosong.';
            $message_type = 'error';
        } else {
            if ($config_id) { // Edit existing
                // Hanya update password jika tidak kosong. Selalu update server_url.
                if (!empty($new_password)) {
                    $update_query = "UPDATE mikrotik_settings SET name = ?, ip_address = ?, username = ?, password = ?, port_api = ?, server_url = ? WHERE id = ?";
                    if ($stmt = $koneksi->prepare($update_query)) {
                        $stmt->bind_param("ssssssi", $new_name, $new_ip, $new_username, $new_password, $new_port_api, $new_server_url, $config_id);
                    }
                } else {
                    $update_query = "UPDATE mikrotik_settings SET name = ?, ip_address = ?, username = ?, port_api = ?, server_url = ? WHERE id = ?";
                    if ($stmt = $koneksi->prepare($update_query)) {
                        $stmt->bind_param("sssssi", $new_name, $new_ip, $new_username, $new_port_api, $new_server_url, $config_id);
                    }
                }

                if ($stmt && $stmt->execute()) {
                    $message = 'Konfigurasi Mikrotik berhasil diperbarui.';
                    $message_type = 'success';
                } else {
                    $message = 'Gagal memperbarui konfigurasi Mikrotik: ' . ($stmt ? $stmt->error : $koneksi->error);
                    $message_type = 'error';
                }
                if ($stmt) $stmt->close();
            } else { // Add new
                // Tambahkan kolom 'server_url' ke query INSERT
                $insert_query = "INSERT INTO mikrotik_settings (name, ip_address, username, password, port_api, server_url) VALUES (?, ?, ?, ?, ?, ?)";
                if ($stmt = $koneksi->prepare($insert_query)) {
                    $stmt->bind_param("sssssi", $new_name, $new_ip, $new_username, $new_password, $new_port_api, $new_server_url);
                    if ($stmt->execute()) {
                        $message = 'Konfigurasi Mikrotik berhasil disimpan.';
                        $message_type = 'success';
                    } else {
                        // Cek error duplikat nama
                        if ($koneksi->errno == 1062) { // Kode error untuk entri duplikat
                            $message = 'Gagal menyimpan: Nama konfigurasi Mikrotik sudah ada.';
                        } else {
                            $message = 'Gagal menyimpan konfigurasi Mikrotik: ' . $stmt->error;
                        }
                        $message_type = 'error';
                    }
                    $stmt->close();
                } else {
                    $message = 'Gagal menyiapkan pernyataan: ' . $koneksi->error;
                    $message_type = 'error';
                }
            }
        }
    } elseif ($action_post === 'delete') {
        $config_id_to_delete = $_POST['config_id_delete'] ?? null;
        if ($config_id_to_delete) {
            $delete_query = "DELETE FROM mikrotik_settings WHERE id = ?";
            if ($stmt = $koneksi->prepare($delete_query)) {
                $stmt->bind_param("i", $config_id_to_delete);
                if ($stmt->execute()) {
                    $message = 'Konfigurasi Mikrotik berhasil dihapus.';
                    $message_type = 'success';
                } else {
                    $message = 'Gagal menghapus konfigurasi Mikrotik: ' . $stmt->error;
                    $message_type = 'error';
                }
                $stmt->close();
            }
        } else {
            $message = 'ID konfigurasi tidak valid untuk penghapusan.';
            $message_type = 'error';
        }
    }
    // Redirect untuk mencegah resubmission form
    echo "<script>window.location.href = 'mikrotik_settings.php?msg=" . urlencode($message) . "&type=" . urlencode($message_type) . "';</script>";
    exit();
}

// Tampilkan pesan notifikasi dari redirect
if (isset($_GET['msg']) && isset($_GET['type'])) {
    $message = htmlspecialchars($_GET['msg']);
    $message_type = htmlspecialchars($_GET['type']);
    echo "<script>
            document.addEventListener('DOMContentLoaded', function() {
                showNotification('$message', '$message_type');
            });
          </script>";
}
?>

<style>
    /* Custom styles for MikroTik Settings page */
    .card-header h3 {
        display: flex;
        align-items: center;
        gap: 10px; /* Space between icon and text */
    }

    .form-group label {
        font-weight: 600;
        margin-bottom: 5px;
        color: #ECF0F1; /* Light text for labels */
    }

    .form-control {
        background-color: #34495E; /* Dark blue background */
        color: #ECF0F1; /* Light text color */
        border: 1px solid #2C3E50; /* Slightly darker border */
        box-shadow: inset 0 1px 1px rgba(0, 0, 0, 0.075);
    }

    .form-control::placeholder {
        color: #BDC3C7; /* Lighter placeholder text */
        opacity: 1;
    }

    .form-control:focus {
        border-color: #5DADE2; /* A brighter blue border on focus */
        box-shadow: 0 0 0 0.25rem rgba(93, 173, 226, 0.25); /* Light blue shadow on focus */
        background-color: #3B536B; /* Slightly lighter dark blue on focus */
        color: #FFFFFF; /* White text on focus */
    }

    .btn {
        transition: all 0.3s ease;
    }

    .btn:hover {
        transform: translateY(-2px);
        box-shadow: 0 4px 8px rgba(0,0,0,0.2);
    }

    .table {
        color: #ECF0F1; /* Light text for table content */
    }

    .table th {
        background-color: #2C3E50; /* Darker header background */
        color: #ECF0F1;
        border-color: #34495E;
    }

    .table td {
        border-color: #34495E;
    }

    .table-striped tbody tr:nth-of-type(odd) {
        background-color: #2F4050; /* Slightly lighter dark for odd rows */
    }

    .table-hover tbody tr:hover {
        background-color: #3B536B; /* Lighter dark on hover */
    }

    /* Connection Status styling */
    #connectionStatus {
        padding: 15px;
        border-radius: 8px;
        font-weight: 600;
        margin-top: 20px;
    }
    #connectionStatus.text-success {
        background-color: rgba(40, 167, 69, 0.2); /* Light green background */
        color: #28a745;
        border: 1px solid #28a745;
    }
    #connectionStatus.text-danger {
        background-color: rgba(220, 53, 69, 0.2); /* Light red background */
        color: #dc3545;
        border: 1px solid #dc3545;
    }
    #connectionStatus.text-info {
        background-color: rgba(23, 162, 184, 0.2); /* Light blue background */
        color: #17a2b8;
        border: 1px solid #17a2b8;
    }

    /* General modal styles, copied and adjusted from cetak_voucher.php for consistency */
    .modal {
        display: none; /* Hidden by default */
        position: fixed; /* Stay in place */
        z-index: 1000; /* Sit on top */
        left: 0;
        top: 0;
        width: 100%; /* Full width */
        height: 100%;
        overflow: auto; /* Enable scroll if needed */
        background-color: rgba(0,0,0,0.4); /* Black w/ opacity */
        justify-content: center; /* Center horizontally */
        align-items: center;
        opacity: 0;
        transition: opacity 0.4s ease-in-out;
        pointer-events: none; /* Disables interaction when hidden */
    }

    .modal.show {
        opacity: 1;
        pointer-events: auto;
    }

    .modal-content {
        background-color: #fefefe; /* Light background for modal content */
        margin: auto;
        padding: 20px;
        border: 1px solid #888;
        width: 90%; /* Responsive width */
        max-width: 500px; /* Max width for larger screens */
        border-radius: 8px;
        position: relative;
        transform: translateY(-50px); /* Start slightly above, then slide down */
        transition: transform 0.4s ease-in-out;
        color: #333; /* Dark text inside modal */
    }

    .modal.show .modal-content {
        transform: translateY(0);
    }

    .modal-content h4 {
        color: #333;
        margin-top: 0;
        margin-bottom: 15px;
        display: flex;
        align-items: center;
        gap: 10px;
    }

    .close-button {
        color: #aaa;
        float: right;
        font-size: 28px;
        font-weight: bold;
        transition: color 0.3s ease;
    }

    .close-button:hover,
    .close-button:focus {
        color: black;
        text-decoration: none;
        cursor: pointer;
    }
</style>

<div class="main-content">
    <div class="page-header">
        <h1>Pengaturan MikroTik</h1>
        <p>Kelola koneksi ke beberapa perangkat MikroTik Anda.</p>
    </div>

    <div class="container">
        <!-- Form Tambah/Edit Konfigurasi MikroTik -->
        <div class="card mb-4">
            <div class="card-header">
                <h3 id="formTitle"><i class="fas fa-plus-circle"></i> Tambah Konfigurasi MikroTik Baru</h3>
            </div>
            <div class="card-body">
                <form id="mikrotikConfigForm" action="" method="POST"><?php if (!isset($_SESSION['csrf_token'])) { $_SESSION['csrf_token'] = bin2hex(random_bytes(32)); } ?><input type='hidden' name='csrf_token' value='<?php echo $_SESSION['csrf_token']; ?>'>
                    <input type="hidden" name="action" value="save">
                    <input type="hidden" id="config_id" name="config_id" value="">
                    
                    <div class="form-group">
                        <label for="name">Nama Konfigurasi:</label>
                        <input type="text" id="name" name="name" class="form-control" placeholder="Contoh: Kantor Pusat, Cabang A" required>
                    </div>
                    <div class="form-group">
                        <label for="ip_address">IP Address MikroTik:</label>
                        <input type="text" id="ip_address" name="ip_address" class="form-control" placeholder="Contoh: 192.168.88.1" required>
                    </div>
                    <div class="form-group">
                        <label for="username">Username API MikroTik:</label>
                        <input type="text" id="username" name="username" class="form-control" placeholder="Contoh: admin" required>
                    </div>
                    <div class="form-group">
                        <label for="password">Password API MikroTik:</label>
                        <input type="password" id="password" name="password" class="form-control" placeholder="Biarkan kosong jika tidak ingin mengubah password" autocomplete="new-password">
                        <small class="form-text text-muted">Isi password jika ingin mengubahnya, atau biarkan kosong jika tidak ada perubahan.</small>
                    </div>
                    <div class="form-group">
                        <label for="port_api">Port API (biasanya 8728):</label>
                        <input type="number" id="port_api" name="port_api" class="form-control" value="8728" placeholder="Contoh: 8728" required>
                    </div>
                    <div class="form-group">
                        <label for="server_url">URL Dasar Aplikasi Billing (untuk notifikasi login):</label>
                        <input type="url" id="server_url" name="server_url" class="form-control" placeholder="Contoh: http://billing.tzn.my.id/" required>
                        <small class="form-text text-muted">Ini adalah URL dasar instalasi aplikasi billing Anda (misalnya, domain atau IP). Jangan sertakan "/pages/mikrotik_api.php".</small>
                    </div>
                    <button type="submit" id="saveConfigBtn" class="btn btn-primary"><i class="fas fa-save"></i> Simpan Konfigurasi Baru</button>
                    <button type="button" id="updateConfigBtn" class="btn btn-warning" style="display:none;"><i class="fas fa-edit"></i> Perbarui Konfigurasi</button>
                    <button type="button" id="cancelEditBtn" class="btn btn-secondary" style="display:none;"><i class="fas fa-times"></i> Batal Edit</button>
                </form>
            </div>
        </div>

        <!-- Daftar Konfigurasi MikroTik -->
        <div class="card mb-4">
            <div class="card-header">
                <h3><i class="fas fa-list"></i> Daftar Konfigurasi MikroTik</h3>
            </div>
            <div class="card-body">
                <?php if (empty($mikrotik_configs)): ?>
                    <p class="text-center text-muted">Belum ada konfigurasi MikroTik yang tersimpan.</p>
                <?php else: ?>
                    <div class="table-responsive">
                        <table class="table table-bordered table-striped table-hover">
                            <thead>
                                <tr>
                                    <th>ID</th>
                                    <th>Nama</th>
                                    <th>IP Address</th>
                                    <th>Username</th>
                                    <th>Port API</th>
                                    <th>URL Server</th>
                                    <th>Aksi</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($mikrotik_configs as $config): ?>
                                    <tr>
                                        <td><?php echo htmlspecialchars($config['id']); ?></td>
                                        <td><?php echo htmlspecialchars($config['name']); ?></td>
                                        <td><?php echo htmlspecialchars($config['ip_address']); ?></td>
                                        <td><?php echo htmlspecialchars($config['username']); ?></td>
                                        <td><?php echo htmlspecialchars($config['port_api']); ?></td>
                                        <td><?php echo htmlspecialchars($config['server_url'] ?? 'N/A'); ?></td> <!-- Tampilkan server_url -->
                                        <td>
                                            <button class="btn btn-warning btn-sm edit-config-btn"
                                                    data-id="<?php echo $config['id']; ?>"
                                                    data-name="<?php echo htmlspecialchars($config['name']); ?>"
                                                    data-ip="<?php echo htmlspecialchars($config['ip_address']); ?>"
                                                    data-username="<?php echo htmlspecialchars($config['username']); ?>"
                                                    data-port="<?php echo htmlspecialchars($config['port_api']); ?>"
                                                    data-serverurl="<?php echo htmlspecialchars($config['server_url'] ?? ''); ?>"> <!-- Tambahkan data-serverurl -->
                                                <i class="fas fa-edit"></i> Edit
                                            </button>
                                            <button class="btn btn-danger btn-sm delete-config-btn"
                                                    data-id="<?php echo $config['id']; ?>"
                                                    data-name="<?php echo htmlspecialchars($config['name']); ?>">
                                                <i class="fas fa-trash"></i> Hapus
                                            </button>
                                        </td>
                                    </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                <?php endif; ?>
            </div>
        </div>

        <div class="card mt-4">
            <div class="card-header">
                <h3><i class="fas fa-plug"></i> Tes Koneksi MikroTik</h3>
            </div>
            <div class="card-body">
                <div class="form-group">
                    <label for="test_config_id">Pilih Konfigurasi untuk Tes:</label>
                    <select id="test_config_id" class="form-control">
                        <?php if (empty($mikrotik_configs)): ?>
                            <option value="">Tidak ada konfigurasi tersedia</option>
                        <?php else: ?>
                            <?php foreach ($mikrotik_configs as $config): ?>
                                <option value="<?php echo $config['id']; ?>"><?php echo htmlspecialchars($config['name']); ?> (<?php echo htmlspecialchars($config['ip_address']); ?>)</option>
                            <?php endforeach; ?>
                        <?php endif; ?>
                    </select>
                </div>
                <button id="testConnectionBtn" class="btn btn-info mt-2" <?php echo empty($mikrotik_configs) ? 'disabled' : ''; ?>><i class="fas fa-plug"></i> Tes Koneksi</button>
            </div>
        </div>

    </div>
</div>

<!-- New Test Connection Modal HTML -->
<div id="testConnectionModal" class="modal">
    <div class="modal-content">
        <span class="close-button" id="closeTestConnectionModal">&times;</span>
        <h4 id="testModalTitle"><i class="fas fa-plug"></i> Hasil Tes Koneksi</h4>
        <div id="connectionStatusModal" class="mt-3">
            <!-- Connection status will be displayed here -->
            <p class="text-center text-muted">Memuat hasil...</p>
        </div>
    </div>
</div>

<script>
document.addEventListener('DOMContentLoaded', function() {
    const mikrotikConfigForm = document.getElementById('mikrotikConfigForm');
    const configIdInput = document.getElementById('config_id');
    const nameInput = document.getElementById('name');
    const ipAddressInput = document.getElementById('ip_address');
    const usernameInput = document.getElementById('username');
    const passwordInput = document.getElementById('password');
    const portApiInput = document.getElementById('port_api');
    const serverUrlInput = document.getElementById('server_url');
    const formTitle = document.getElementById('formTitle');
    
    // Tombol baru
    const saveConfigBtn = document.getElementById('saveConfigBtn');
    const updateConfigBtn = document.getElementById('updateConfigBtn');
    const cancelEditBtn = document.getElementById('cancelEditBtn');

    const testConnectionBtn = document.getElementById('testConnectionBtn');
    const testConfigIdSelect = document.getElementById('test_config_id');

    // New modal elements
    const testConnectionModal = document.getElementById('testConnectionModal');
    const closeTestConnectionModalBtn = document.getElementById('closeTestConnectionModal');
    const connectionStatusModalDiv = document.getElementById('connectionStatusModal');
    const testModalTitle = document.getElementById('testModalTitle');


    // Fungsi helper untuk menampilkan notifikasi (asumsi sudah ada di header.php atau file lain)
    function showNotification(message, type = 'info') {
        const notificationArea = document.getElementById('notificationArea') || document.createElement('div');
        notificationArea.id = 'notificationArea';
        notificationArea.innerHTML = `<div class="alert alert-${type} alert-dismissible fade show" role="alert">
                                        ${message}
                                        <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                                            <span aria-hidden="true">&times;</span>
                                        </button>
                                    </div>`;
        document.body.prepend(notificationArea);
        setTimeout(() => {
            const alert = notificationArea.querySelector('.alert');
            if (alert) {
                $(alert).alert('close');
            }
        }, 5000);
    }

    // Functions to show/hide the new modal
    function showTestConnectionModal() {
        testConnectionModal.style.display = 'flex';
        testConnectionModal.offsetWidth; // Trigger reflow for transition
        testConnectionModal.classList.add('show');
    }

    function hideTestConnectionModal() {
        testConnectionModal.classList.remove('show');
        const onTransitionEnd = () => {
            if (!testConnectionModal.classList.contains('show')) {
                testConnectionModal.style.display = 'none';
            }
            testConnectionModal.removeEventListener('transitionend', onTransitionEnd);
        };
        testConnectionModal.addEventListener('transitionend', onTransitionEnd);
    }

    // Fungsi untuk mengatur tampilan tombol (Simpan/Perbarui/Batal)
    function setFormMode(mode) {
        if (mode === 'add') {
            formTitle.innerHTML = '<i class="fas fa-plus-circle"></i> Tambah Konfigurasi MikroTik Baru';
            saveConfigBtn.style.display = 'inline-block';
            updateConfigBtn.style.display = 'none';
            cancelEditBtn.style.display = 'none';
            mikrotikConfigForm.reset();
            configIdInput.value = '';
            portApiInput.value = '8728'; // Set default
            serverUrlInput.value = ''; // Clear server URL
        } else if (mode === 'edit') {
            formTitle.innerHTML = '<i class="fas fa-edit"></i> Edit Konfigurasi MikroTik';
            saveConfigBtn.style.display = 'none';
            updateConfigBtn.style.display = 'inline-block';
            cancelEditBtn.style.display = 'inline-block';
        }
    }

    // Panggil setFormMode saat halaman dimuat (mode default: add)
    setFormMode('add');

    // Event listener untuk tombol Edit
    document.querySelectorAll('.edit-config-btn').forEach(button => {
        button.addEventListener('click', function() {
            setFormMode('edit');
            configIdInput.value = this.dataset.id;
            nameInput.value = this.dataset.name;
            ipAddressInput.value = this.dataset.ip;
            usernameInput.value = this.dataset.username;
            passwordInput.value = ''; // Biarkan kosong untuk keamanan
            portApiInput.value = this.dataset.port;
            serverUrlInput.value = this.dataset.serverurl;
            nameInput.focus();
            window.scrollTo({ top: 0, behavior: 'smooth' });
        });
    });

    // Event listener untuk tombol Hapus
    document.querySelectorAll('.delete-config-btn').forEach(button => {
        button.addEventListener('click', function() {
            const configId = this.dataset.id;
            const configName = this.dataset.name;
            if (confirm(`Apakah Anda yakin ingin menghapus konfigurasi "${configName}"? Tindakan ini tidak dapat dibatalkan.`)) {
                const form = document.createElement('form');
                form.method = 'POST';
                form.action = ''; 

                const actionInput = document.createElement('input');
                actionInput.type = 'hidden';
                actionInput.name = 'action';
                actionInput.value = 'delete';
                form.appendChild(actionInput);

                const idInput = document.createElement('input');
                idInput.type = 'hidden';
                idInput.name = 'config_id_delete';
                idInput.value = configId;
                form.appendChild(idInput);

                document.body.appendChild(form);
                form.submit();
            }
        });
    });

    // Event listener untuk tombol Batal Edit
    if (cancelEditBtn) {
        cancelEditBtn.addEventListener('click', function() {
            setFormMode('add'); // Kembali ke mode 'add'
        });
    }

    // Event listener untuk tombol Simpan Konfigurasi Baru
    if (saveConfigBtn) {
        saveConfigBtn.addEventListener('click', function(e) {
            // Pastikan action_post diatur ke 'save' untuk insert baru
            mikrotikConfigForm.querySelector('input[name="action"]').value = 'save';
            mikrotikConfigForm.submit();
        });
    }

    // Event listener untuk tombol Perbarui Konfigurasi
    if (updateConfigBtn) {
        updateConfigBtn.addEventListener('click', function(e) {
            // Pastikan action_post diatur ke 'save' untuk update (dengan config_id terisi)
            mikrotikConfigForm.querySelector('input[name="action"]').value = 'save';
            mikrotikConfigForm.submit();
        });
    }


    // Fungsi Tes Koneksi
    if (testConnectionBtn) {
        testConnectionBtn.addEventListener('click', function() {
            const selectedConfigId = testConfigIdSelect.value;
            const selectedConfigName = testConfigIdSelect.options[testConfigIdSelect.selectedIndex].text;

            if (!selectedConfigId) {
                showNotification('Pilih konfigurasi MikroTik untuk diuji.', 'warning');
                return;
            }

            showTestConnectionModal();
            testModalTitle.innerHTML = `<i class="fas fa-plug"></i> Hasil Tes Koneksi: ${selectedConfigName}`;
            connectionStatusModalDiv.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Memuat status...';
            connectionStatusModalDiv.className = 'mt-3 text-info';

            fetch(`mikrotik_api.php?action=check_status&config_id=${selectedConfigId}`, {
                method: 'GET',
                headers: {
                    'Content-Type': 'application/json'
                }
            })
            .then(response => {
                if (!response.ok) {
                    throw new Error(`HTTP error! Status: ${response.status}`);
                }
                return response.json();
            })
            .then(data => {
                if (data.status === 'success') {
                    connectionStatusModalDiv.className = 'mt-3 text-success';
                    let infoHtml = `
                        <p><i class="fas fa-check-circle"></i> <strong>Koneksi Berhasil!</strong></p>
                        <p><strong>Uptime:</strong> ${data.uptime}</p>
                        <p><strong>Free Memory:</strong> ${data.free_memory}</p>
                        <p><strong>Total Memory:</strong> ${data.total_memory}</p>
                        <p><strong>CPU Load:</strong> ${data.cpu_load}</p>
                        <p><strong>Board Name:</strong> ${data.board_name}</p>
                        <p><strong>Version:</strong> ${data.version}</p>
                    `;
                    connectionStatusModalDiv.innerHTML = infoHtml;
                } else {
                    connectionStatusModalDiv.className = 'mt-3 text-danger';
                    connectionStatusModalDiv.innerHTML = `<p><i class="fas fa-times-circle"></i> Gagal terhubung: ${data.message}</p>`;
                    if (typeof showNotification === 'function') {
                        showNotification(data.message, 'error');
                    }
                }
            })
            .catch(error => {
                console.error('Error fetching Mikrotik status:', error);
                connectionStatusModalDiv.className = 'mt-3 text-danger';
                connectionStatusModalDiv.innerHTML = `<p><i class="fas fa-times-circle"></i> Terjadi kesalahan jaringan atau server: ${error.message}</p>`;
                 if (typeof showNotification === 'function') {
                    showNotification('Terjadi kesalahan saat mengambil status Mikrotik: ' + error.message, 'error');
                }
            });
        });
    }

    // Event listeners for the new modal close button and clicking outside
    if (closeTestConnectionModalBtn) {
        closeTestConnectionModalBtn.addEventListener('click', hideTestConnectionModal);
    }
    window.addEventListener('click', function(event) {
        if (event.target == testConnectionModal) {
            hideTestConnectionModal();
        }
    });


    // Set default selection for test dropdown if only one config exists
    if (testConfigIdSelect && testConfigIdSelect.options.length > 0) {
        testConfigIdSelect.selectedIndex = 0;
    }
});
</script>

<?php include '../includes/footer.php'; ?>