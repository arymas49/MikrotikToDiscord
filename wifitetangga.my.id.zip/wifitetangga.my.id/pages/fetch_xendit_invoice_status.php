<?php
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!isset($_POST['csrf_token']) || $_POST['csrf_token'] !== $_SESSION['csrf_token']) {
        die('CSRF validation failed.');
    }
}
?>
<?php
// C:\xampp\htdocs\billing_isp_app\pages\fetch_xendit_invoice_status.php
// Endpoint AJAX untuk mengambil status invoice Xendit dari API Xendit

// --- PENTING: Mulai Output Buffering SEBELUM output apapun ---
ob_start();

// Pastikan pelaporan error diaktifkan untuk debugging
ini_set('display_errors', 0); // *** Pastikan ini 0 di production ***
ini_set('display_startup_errors', 0); // *** Pastikan ini 0 di production ***
error_reporting(E_ALL);

$autoloadPath = dirname(__DIR__, 1) . '/vendor/autoload.php';

// Verifikasi apakah file autoload.php ada sebelum mencoba memuatnya
if (!file_exists($autoloadPath)) {
    ob_clean(); 
    http_response_code(500); // Internal Server Error
    header('Content-Type: application/json');
    echo json_encode(['status' => 'error', 'message' => 'Composer autoload file not found. Please ensure Composer dependencies are installed.']);
    exit();
}

require_once $autoloadPath; 

// --- PENTING: Gunakan namespace yang benar untuk kelas Xendit (InvoiceApi) ---
use Xendit\Configuration;
use Xendit\Invoice\InvoiceApi; // Perbaikan di sini: Gunakan InvoiceApi

// Memuat konfigurasi Xendit
$xenditConfig = include __DIR__ . '/../config/xendit_config.php';

// Setel Secret Key Xendit
Configuration::setXenditKey($xenditConfig['xendit_secret_key']); 

// Memastikan request adalah POST dan 'invoice_id' ada dalam payload
if ($_SERVER['REQUEST_METHOD'] !== 'POST' || !isset($_POST['invoice_id'])) {
    ob_clean(); 
    http_response_code(400); // Bad Request
    header('Content-Type: application/json');
    echo json_encode(['status' => 'error', 'message' => 'Invalid request method or missing invoice ID.']);
    exit();
}

$xendit_invoice_id = $_POST['invoice_id'];

// Tambahkan log ini
error_log("fetch_xendit_invoice_status.php: Received invoice_id: " . $xendit_invoice_id);

try {
    // --- PERBAIKAN: Buat instance InvoiceApi dan panggil getInvoiceById ---
    $apiInstance = new InvoiceApi();
    $invoice = $apiInstance->getInvoiceById($xendit_invoice_id); // Baris 36 yang diperbaiki

    // Log respons dari Xendit API untuk debugging
    if ($invoice) {
        error_log("fetch_xendit_invoice_status.php: Successfully retrieved invoice from Xendit. Invoice Data: " . json_encode($invoice));
    } else {
        error_log("fetch_xendit_invoice_status.php: Xendit API returned NULL or empty for invoice ID: " . $xendit_invoice_id . ". This means invoice was not found by Xendit.");
    }
    
    ob_clean(); 
    header('Content-Type: application/json');
    echo json_encode(['status' => 'success', 'invoice_data' => $invoice]);

} catch (\Xendit\Exceptions\ApiException $e) { // Tangkap ApiException dari Xendit
    error_log("fetch_xendit_invoice_status.php: Xendit API Error: " . $e->getMessage() . " - Full Error: " . json_encode($e->getErrors()));
    ob_clean(); 
    http_response_code(500); // Internal Server Error
    header('Content-Type: application/json');
    echo json_encode(['status' => 'error', 'message' => 'Failed to retrieve invoice from Xendit: ' . $e->getMessage()]);
} catch (Exception $e) { // Tangkap Exception umum
    error_log("fetch_xendit_invoice_status.php: General Error: " . $e->getMessage());
    ob_clean(); 
    http_response_code(500); // Internal Server Error
    header('Content-Type: application/json');
    echo json_encode(['status' => 'error', 'message' => 'An unexpected error occurred: ' . $e->getMessage()]);
}
exit(); // Pastikan script berhenti di sini setelah mengirim respons