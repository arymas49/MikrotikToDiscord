<?php
// C:\xampp\htdocs\billing_isp_app\pages\print_penagih.php

// DEBUGGING AGRESIV: Pastikan semua error ditampilkan
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

// Coba tangkap fatal error juga
register_shutdown_function(function() {
    $error = error_get_last();
    if ($error && ($error['type'] === E_ERROR || $error['type'] === E_PARSE || $error['type'] === E_CORE_ERROR || $error['type'] === E_COMPILE_ERROR)) {
        echo "<div style='background-color: #fdd; border: 1px solid red; padding: 10px;'>";
        echo "<h2>Fatal Error Detected:</h2>";
        echo "<strong>Type:</strong> " . $error['type'] . "<br>";
        echo "<strong>Message:</strong> " . $error['message'] . "<br>";
        echo "<strong>File:</strong> " . $error['file'] . " (Line: " . $error['line'] . ")<br>";
        echo "</div>";
    }
});


ini_set('session.use_strict_mode', 1);
ini_set('session.cookie_httponly', 1);
ini_set('session.cookie_samesite', 'Lax');
if (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on') {
    ini_set('session.cookie_secure', 1);
}
session_start();
include '../config/koneksi.php'; // Pastikan path ini benar dan koneksi berhasil

// Batasi akses ke halaman ini jika diperlukan (opsional, karena ini adalah halaman cetak)
// include '../includes/header.php'; // Hapus ini jika hanya ingin print tanpa UI lengkap
// if (!hasRole(['superadmin', 'admin'])) {
//     header('Location: dashboard.php');
//     exit();
// }


// --- Ambil parameter filter bulan dan tahun dari URL ---
// Default ke bulan dan tahun saat ini jika tidak ada di URL
$selected_year = $_GET['filter_year'] ?? date('Y');
$selected_month = $_GET['filter_month'] ?? date('m');

// Format YYYY-MM untuk query (digunakan untuk bulan_tagihan)
$filtered_month_year = $selected_year . '-' . sprintf('%02d', $selected_month); // Ensures MM is two digits

// Label untuk tampilan di halaman cetak
$bulan_ini_label = date('F Y', strtotime($selected_year . '-' . $selected_month . '-01'));


// Ambil semua penagih yang aktif untuk dropdown filter (digunakan untuk menampilkan nama penagih yang difilter)
$all_penagih = [];
$query_all_penagih = "SELECT id_penagih, nama_penagih FROM penagih WHERE status_aktif = 'Aktif' ORDER BY nama_penagih ASC";
$result_all_penagih = $koneksi->query($query_all_penagih);
if ($result_all_penagih) {
    while ($row = $result_all_penagih->fetch_assoc()) {
        $all_penagih[] = $row;
    }
} else {
    error_log("Error fetching all penagih: " . $koneksi->error);
}


// Filter berdasarkan penagih yang dipilih (jika ada)
$selected_penagih_id = $_GET['penagih_id'] ?? '';
$where_penagih_clause_for_main_query = ''; // Clause for the main query's WHERE (penagih table)
$param_penagih_value_for_bind = []; // Array to store bind parameter values

if (!empty($selected_penagih_id)) {
    // This filter applies to the 'pn.id_penagih' in the main query's WHERE clause
    $where_penagih_clause_for_main_query = " AND pn.id_penagih = ?";
    $param_penagih_value_for_bind[] = $selected_penagih_id;
}


// --- Common Table Expression (CTE) for All Invoices (Regular and Manual) ---
$cte_invoices = "
WITH CombinedInvoices AS (
    SELECT
        t.id_tagihan AS id,
        t.pelanggan_id,
        p.nama_pelanggan,
        p.alamat,
        p.telepon,
        pk.nama_paket,
        t.total_tagihan AS jumlah_tagihan_total,
        t.bulan_tagihan,
        t.tanggal_jatuh_tempo,
        t.status_tagihan,
        t.penagih_id, 
        'regular' AS type_invoice
    FROM
        tagihan t
    JOIN
        pelanggan p ON t.pelanggan_id = p.id_pelanggan
    JOIN
        paket_layanan pk ON t.paket_id = pk.id_paket
    WHERE
        p.status_aktif = 'Aktif'
    
    UNION ALL
    
    SELECT
        tm.id_tagihan_manual AS id,
        NULL AS pelanggan_id, 
        tm.nama_pelanggan_manual AS nama_pelanggan,
        tm.alamat_manual AS alamat,
        tm.telepon_manual AS telepon,
        COALESCE(tm.nama_paket_manual, 'Manual Invoice') AS nama_paket,
        tm.jumlah_tagihan AS jumlah_tagihan_total,
        DATE_FORMAT(tm.tanggal_terbit, '%Y-%m') AS bulan_tagihan, 
        tm.tanggal_jatuh_tempo,
        tm.status_tagihan,
        tm.penagih_id, 
        'manual' AS type_invoice
    FROM
        tagihan_manual tm
    WHERE 1
)
";


// 1. Total Tagihan Belum Lunas bulan ini per Penagih (menggunakan CTE CombinedInvoices)
$tagihan_belum_lunas_per_penagih = [];
$query_tagihan_belum_lunas = $cte_invoices . "
    SELECT
        pn.id_penagih,
        pn.nama_penagih,
        COUNT(DISTINCT ci.pelanggan_id) AS total_pelanggan_belum_lunas_reguler,
        COUNT(DISTINCT CASE WHEN ci.type_invoice = 'manual' THEN ci.id ELSE NULL END) AS total_pelanggan_belum_lunas_manual,
        COALESCE(SUM(ci.jumlah_tagihan_total), 0) AS total_nominal_belum_lunas
    FROM
        penagih pn
    LEFT JOIN
        CombinedInvoices ci 
        ON pn.id_penagih = ci.penagih_id
        AND ci.bulan_tagihan = ? -- Filter by selected month-year
        AND ci.status_tagihan = 'Belum Lunas'
    WHERE
        pn.status_aktif = 'Aktif'
        " . $where_penagih_clause_for_main_query . "
    GROUP BY
        pn.id_penagih, pn.nama_penagih
    ORDER BY
        pn.nama_penagih ASC
";

$stmt_belum_lunas_penagih = $koneksi->prepare($query_tagihan_belum_lunas);
if ($stmt_belum_lunas_penagih === false) {
    error_log("Prepare failed for tagihan_belum_lunas: " . $koneksi->error);
    $tagihan_belum_lunas_per_penagih = [];
} else {
    $bind_args = array_merge([$filtered_month_year], $param_penagih_value_for_bind); // Use filtered_month_year
    $bind_types = "s"; 
    if (!empty($param_penagih_value_for_bind)) {
        $bind_types .= str_repeat('i', count($param_penagih_value_for_bind));
    }

    $refs = [];
    foreach($bind_args as $key => $value) {
        $refs[$key] = &$bind_args[$key];
    }
    call_user_func_array([$stmt_belum_lunas_penagih, 'bind_param'], array_merge([$bind_types], $refs));

    if ($stmt_belum_lunas_penagih->execute()) {
        $result_belum_lunas_penagih = $stmt_belum_lunas_penagih->get_result();
        while ($row = $result_belum_lunas_penagih->fetch_assoc()) {
            $tagihan_belum_lunas_per_penagih[] = $row;
        }
    } else {
        error_log("Execute failed for tagihan_belum_lunas: " . $stmt_belum_lunas_penagih->error);
    }
    $stmt_belum_lunas_penagih->close();
}


// 2. Total Pembayaran Lunas bulan ini per Penagih (menggunakan CTE CombinedInvoices)
$pembayaran_lunas_per_penagih = [];
$query_pembayaran_lunas = $cte_invoices . "
    SELECT
        pn.id_penagih,
        pn.nama_penagih,
        COUNT(DISTINCT ci.pelanggan_id) AS total_pelanggan_lunas_reguler,
        COUNT(DISTINCT CASE WHEN ci.type_invoice = 'manual' THEN ci.id ELSE NULL END) AS total_pelanggan_lunas_manual,
        COALESCE(SUM(ci.jumlah_tagihan_total), 0) AS total_nominal_lunas
    FROM
        penagih pn
    LEFT JOIN
        CombinedInvoices ci 
        ON pn.id_penagih = ci.penagih_id
        AND ci.bulan_tagihan = ? -- Filter by selected month-year
        AND ci.status_tagihan = 'Lunas'
    WHERE
        pn.status_aktif = 'Aktif'
        " . $where_penagih_clause_for_main_query . "
    GROUP BY
        pn.id_penagih, pn.nama_penagih
    ORDER BY
        pn.nama_penagih ASC
";

$stmt_lunas_penagih = $koneksi->prepare($query_pembayaran_lunas);
if ($stmt_lunas_penagih === false) {
    error_log("Prepare failed for pembayaran_lunas: " . $koneksi->error);
    $pembayaran_lunas_per_penagih = [];
} else {
    $bind_args_lunas = array_merge([$filtered_month_year], $param_penagih_value_for_bind); // Use filtered_month_year
    $bind_types_lunas = "s"; 
    if (!empty($param_penagih_value_for_bind)) {
        $bind_types_lunas .= str_repeat('i', count($param_penagih_value_for_bind));
    }

    $refs_lunas = [];
    foreach($bind_args_lunas as $key => $value) {
        $refs_lunas[$key] = &$bind_args_lunas[$key];
    }
    call_user_func_array([$stmt_lunas_penagih, 'bind_param'], array_merge([$bind_types_lunas], $refs_lunas));

    if ($stmt_lunas_penagih->execute()) {
        $result_lunas_penagih = $stmt_lunas_penagih->get_result();
        while ($row = $result_lunas_penagih->fetch_assoc()) {
            $pembayaran_lunas_per_penagih[] = $row;
        }
    } else {
        error_log("Execute failed for pembayaran_lunas: " . $stmt_lunas_penagih->error);
    }
    $stmt_lunas_penagih->close();
}


// Gabungkan data untuk ditampilkan
$merged_penagih_data = [];
foreach ($all_penagih as $penagih) {
    $id = $penagih['id_penagih'];
    $nama = $penagih['nama_penagih'];

    // Temukan data belum lunas untuk penagih ini
    $belum_lunas_data = null;
    foreach ($tagihan_belum_lunas_per_penagih as $item) {
        if ($item['id_penagih'] == $id) {
            $belum_lunas_data = $item;
            break;
        }
    }

    // Temukan data lunas untuk penagih ini
    $lunas_data = null;
    foreach ($pembayaran_lunas_per_penagih as $item) {
        if ($item['id_penagih'] == $id) {
            $lunas_data = $item;
            break;
        }
    }

    $merged_penagih_data[] = [
        'id_penagih' => $id,
        'nama_penagih' => $nama,
        'total_pelanggan_belum_lunas' => ($belum_lunas_data['total_pelanggan_belum_lunas_reguler'] ?? 0) + ($belum_lunas_data['total_pelanggan_belum_lunas_manual'] ?? 0),
        'total_nominal_belum_lunas' => $belum_lunas_data['total_nominal_belum_lunas'] ?? 0,
        'total_pelanggan_lunas' => ($lunas_data['total_pelanggan_lunas_reguler'] ?? 0) + ($lunas_data['total_pelanggan_lunas_manual'] ?? 0),
        'total_nominal_lunas' => $lunas_data['total_nominal_lunas'] ?? 0,
    ];
}


// Ambil daftar pelanggan yang belum lunas (detail tabel) - menggunakan CTE CombinedInvoices
$pelanggan_belum_lunas_detail = [];
$query_pelanggan_belum_lunas_detail = $cte_invoices . "
    SELECT
        ci.id,
        ci.pelanggan_id,
        ci.nama_pelanggan,
        ci.alamat,
        ci.telepon,
        ci.nama_paket,
        ci.jumlah_tagihan_total AS total_tagihan,
        ci.tanggal_jatuh_tempo,
        ci.type_invoice,
        pn.nama_penagih -- Added to display collector name in the table
    FROM
        CombinedInvoices ci
    JOIN
        penagih pn ON ci.penagih_id = pn.id_penagih -- Join with penagih table
    WHERE
        ci.bulan_tagihan = ? -- Filter by selected month-year
        AND ci.status_tagihan = 'Belum Lunas'
        AND ci.penagih_id IS NOT NULL " . // Only show invoices assigned to a collector
        // Apply filter for selected_penagih_id to this query as well
        (!empty($selected_penagih_id) ? " AND ci.penagih_id = ?" : "") . "
    ORDER BY
        ci.nama_pelanggan ASC
";
$stmt_pelanggan_belum_lunas_detail = $koneksi->prepare($query_pelanggan_belum_lunas_detail);

if ($stmt_pelanggan_belum_lunas_detail === false) {
    error_log("Prepare failed for pelanggan_belum_lunas_detail: " . $koneksi->error);
    $pelanggan_belum_lunas_detail = [];
} else {
    $bind_args_detail = [$filtered_month_year]; // Use filtered_month_year
    $bind_types_detail = "s";

    // If a penagih is selected, add its ID to the bind parameters
    if (!empty($selected_penagih_id)) {
        $bind_args_detail[] = $selected_penagih_id;
        $bind_types_detail .= "i";
    }

    $refs_detail = [];
    foreach($bind_args_detail as $key => $value) {
        $refs_detail[$key] = &$bind_args_detail[$key];
    }
    call_user_func_array([$stmt_pelanggan_belum_lunas_detail, 'bind_param'], array_merge([$bind_types_detail], $refs_detail));

    if ($stmt_pelanggan_belum_lunas_detail->execute()) {
        $result_pelanggan_belum_lunas_detail = $stmt_pelanggan_belum_lunas_detail->get_result();
        while ($row = $result_pelanggan_belum_lunas_detail->fetch_assoc()) {
            $pelanggan_belum_lunas_detail[] = $row;
        }
    } else {
        error_log("Execute failed for pelanggan_belum_lunas_detail: " . $stmt_pelanggan_belum_lunas_detail->error);
    }
    $stmt_pelanggan_belum_lunas_detail->close();
}

$koneksi->close();
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Laporan Kinerja Penagih - <?php echo htmlspecialchars($bulan_ini_label, ENT_QUOTES, "UTF-8"); ?></title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 20mm; /* Margin standar untuk cetak */
            color: #333;
        }
        h1, h2, h3 {
            color: #000;
            text-align: center;
        }
        .header-print {
            text-align: center;
            margin-bottom: 30px;
        }
        .header-print h1 {
            margin-bottom: 5px;
        }
        .section {
            margin-bottom: 30px;
            page-break-inside: avoid; /* Hindari pemisahan section di tengah halaman */
        }
        .card-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(280px, 1fr));
            gap: 20px;
            margin-bottom: 20px;
        }
        .info-card {
            border: 1px solid #ddd;
            border-radius: 8px;
            padding: 15px;
            box-shadow: 0 2px 4px rgba(0,0,0,0.05);
            background-color: #fff;
        }
        .info-card h3 {
            margin-top: 0;
            margin-bottom: 10px;
            font-size: 1.1em;
            text-align: left;
        }
        .info-card .value-label {
            font-size: 0.9em;
            color: #666;
            margin-top: 8px;
        }
        .info-card .card-value {
            font-size: 1.4em;
            font-weight: bold;
            margin-bottom: 5px;
        }
        .info-card .nominal-value {
            font-size: 1.2em;
            font-weight: bold;
        }
        .status-red { color: #dc3545; }
        .status-green { color: #28a745; }
        .data-table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
        }
        .data-table th, .data-table td {
            border: 1px solid #ccc;
            padding: 8px 12px;
            text-align: left;
            font-size: 0.9em;
        }
        .data-table th {
            background-color: #f2f2f2;
            font-weight: bold;
        }
        .data-table tbody tr:nth-child(even) {
            background-color: #f9f9f9;
        }
        .data-table tbody tr:hover {
            background-color: #f1f1f1;
        }

        /* Hide elements not needed for print */
        @media print {
            body {
                margin: 0;
                -webkit-print-color-adjust: exact; /* Untuk memastikan warna latar belakang tercetak */
                print-color-adjust: exact;
            }
            .info-card {
                box-shadow: none; /* Hilangkan shadow saat cetak */
                border: 1px solid #eee;
            }
            /* Jika ada elemen lain yang tidak ingin dicetak */
            .no-print {
                display: none !important;
            }
        }
    </style>
</head>
<body onload="window.print()">
    <div class="header-print">
        <h1>Laporan Kinerja Penagih</h1>
        <h2>Bulan: <?php echo htmlspecialchars($bulan_ini_label, ENT_QUOTES, "UTF-8"); ?></h2>
        <?php if (!empty($selected_penagih_id) && !empty($all_penagih)): ?>
            <?php
            $selected_penagih_name = '';
            foreach($all_penagih as $p) {
                if ($p['id_penagih'] == $selected_penagih_id) {
                    $selected_penagih_name = $p['nama_penagih'];
                    break;
                }
            }
            ?>
            <h3>Untuk Penagih: <?php echo htmlspecialchars($selected_penagih_name); ?></h3>
        <?php else: ?>
            <h3>Untuk Semua Penagih</h3>
        <?php endif; ?>
    </div>

    <div class="section">
        <h2>Ringkasan Kinerja Penagih</h2>
        <?php if (!empty($merged_penagih_data)): ?>
            <div class="card-grid">
                <?php foreach ($merged_penagih_data as $data): ?>
                <div class="info-card">
                    <h3>Kinerja <?php echo htmlspecialchars($data['nama_penagih']); ?></h3>
                    <div class="value-label">Pelanggan Belum Lunas</div>
                    <div class="card-value status-red"><?php echo $data['total_pelanggan_belum_lunas']; ?></div>
                    <div class="value-label">Nominal Belum Lunas</div>
                    <div class="nominal-value status-red">Rp <?php echo number_format($data['total_nominal_belum_lunas'] ?? 0, 0, ',', '.'); ?></div>

                    <div class="value-label">Pelanggan Lunas</div>
                    <div class="card-value status-green"><?php echo $data['total_pelanggan_lunas']; ?></div>
                    <div class="value-label">Nominal Lunas</div>
                    <div class="nominal-value status-green">Rp <?php echo number_format($data['total_nominal_lunas'] ?? 0, 0, ',', '.'); ?></div>
                </div>
                <?php endforeach; ?>
            </div>
        <?php else: ?>
            <p style="text-align: center;">Tidak ada data kinerja penagih untuk bulan ini.</p>
        <?php endif; ?>
    </div>

    <div class="section">
        <h2>Daftar Tagihan Pelanggan Belum Lunas (<?php echo htmlspecialchars($bulan_ini_label, ENT_QUOTES, "UTF-8"); ?>)</h2>
        <?php if (!empty($pelanggan_belum_lunas_detail)): ?>
            <table class="data-table">
                <thead>
                    <tr>
                        <th>Tipe Invoice</th>
                        <th>ID Invoice</th>
                        <th>ID Pelanggan</th>
                        <th>Nama Pelanggan</th>
                        <th>Alamat</th>
                        <th>Telepon</th>
                        <th>Paket</th>
                        <th>Total Tagihan</th>
                        <th>Jatuh Tempo</th>
                        <th>Penagih</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($pelanggan_belum_lunas_detail as $tagihan_detail): ?>
                        <tr>
                            <td>
                                <span class="status-badge <?php echo ($tagihan_detail['type_invoice'] === 'manual' ? 'status-info' : 'status-default'); ?>">
                                    <?php echo htmlspecialchars($tagihan_detail['type_invoice'] === 'manual' ? 'Manual' : 'Reguler'); ?>
                                </span>
                            </td>
                            <td>
                                <?php 
                                    // Menampilkan ID Tagihan sesuai dengan tipenya
                                    echo htmlspecialchars($tagihan_detail['type_invoice'] === 'manual' ? 
                                        'MAN-' . $tagihan_detail['id'] : $tagihan_detail['id']); 
                                ?>
                            </td>
                            <td><?php echo htmlspecialchars($tagihan_detail['pelanggan_id'] ?? 'N/A'); ?></td>
                            <td><?php echo htmlspecialchars($tagihan_detail['nama_pelanggan']); ?></td>
                            <td><?php echo htmlspecialchars($tagihan_detail['alamat']); ?></td>
                            <td><?php echo htmlspecialchars($tagihan_detail['telepon']); ?></td>
                            <td><?php echo htmlspecialchars($tagihan_detail['nama_paket']); ?></td>
                            <td>Rp <?php echo number_format($tagihan_detail['total_tagihan'], 0, ',', '.'); ?></td>
                            <td><?php echo htmlspecialchars(date('d-m-Y', strtotime($tagihan_detail['tanggal_jatuh_tempo']))); ?></td>
                            <td><?php echo htmlspecialchars($tagihan_detail['nama_penagih']); ?></td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        <?php else: ?>
            <p style="text-align: center;">Tidak ada pelanggan dengan tagihan belum lunas untuk bulan ini.</p>
        <?php endif; ?>
    </div>

</body>
</html>