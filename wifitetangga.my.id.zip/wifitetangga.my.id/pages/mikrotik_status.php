<?php
// C:\xampp\htdocs\billing_isp_app\pages\mikrotik_status.php

ini_set('session.use_strict_mode', 1);
ini_set('session.cookie_httponly', 1);
ini_set('session.cookie_samesite', 'Lax');
if (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on') {
    ini_set('session.cookie_secure', 1);
}
session_start();
include '../config/koneksi.php';
include '../includes/header.php';

// Pastikan user memiliki role yang sesuai (misal: superadmin atau teknisi)
if (!hasRole(['superadmin', 'teknisi'])) {
    echo "<script>
            alert('Anda tidak memiliki akses ke halaman ini.');
            window.location.href = '../pages/dashboard.php';
          </script>";
    exit();
}
?>

<div class="main-content">
    <div class="page-header">
        <h1>Status & Informasi Mikrotik</h1>
        <p>Lihat status dan detail sumber daya Mikrotik.</p>
    </div>

    <div class="container">
        <div class="card">
            <div class="card-header">
                <h3>Informasi Sistem Mikrotik</h3>
            </div>
            <div class="card-body">
                <div id="mikrotikInfo" class="mikrotik-info-grid">
                    <div class="info-item">
                        <strong>Status Koneksi:</strong> <span id="connectionStatusText">Memuat...</span>
                    </div>
                    <div class="info-item">
                        <strong>Uptime:</strong> <span id="uptime"></span>
                    </div>
                    <div class="info-item">
                        <strong>Memori Bebas:</strong> <span id="freeMemory"></span>
                    </div>
                    <div class="info-item">
                        <strong>Total Memori:</strong> <span id="totalMemory"></span>
                    </div>
                    <div class="info-item">
                        <strong>Beban CPU:</strong> <span id="cpuLoad"></span>
                    </div>
                    <div class="info-item">
                        <strong>Nama Board:</strong> <span id="boardName"></span>
                    </div>
                    <div class="info-item">
                        <strong>Versi:</strong> <span id="version"></span>
                    </div>
                </div>
                <button id="refreshStatusBtn" class="btn btn-primary mt-3"><i class="fas fa-sync-alt"></i> Refresh Status</button>
            </div>
        </div>
    </div>
</div>

<script>
document.addEventListener('DOMContentLoaded', function() {
    const connectionStatusText = document.getElementById('connectionStatusText');
    const uptimeElem = document.getElementById('uptime');
    const freeMemoryElem = document.getElementById('freeMemory');
    const totalMemoryElem = document.getElementById('totalMemory');
    const cpuLoadElem = document.getElementById('cpuLoad');
    const boardNameElem = document.getElementById('boardName');
    const versionElem = document.getElementById('version');
    const refreshStatusBtn = document.getElementById('refreshStatusBtn');

    function fetchMikrotikStatus() {
        // Hanya ubah status koneksi menjadi "Memuat..."
        connectionStatusText.textContent = 'Memuat...';
        connectionStatusText.className = 'text-info';

        // Biarkan nilai-nilai lain tetap tampil sampai data baru diterima
        // Jika ini adalah pemanggilan pertama, mereka akan tetap 'Memuat...' (dari PHP)

        fetch('mikrotik_api.php?action=check_status')
            .then(response => {
                if (!response.ok) {
                    throw new Error(`HTTP error! Status: ${response.status}`);
                }
                return response.json();
            })
            .then(data => {
                if (data.status === 'success') {
                    connectionStatusText.textContent = 'Terhubung';
                    connectionStatusText.className = 'text-success';
                    uptimeElem.textContent = data.uptime;
                    freeMemoryElem.textContent = data.free_memory;
                    totalMemoryElem.textContent = data.total_memory;
                    cpuLoadElem.textContent = data.cpu_load;
                    boardNameElem.textContent = data.board_name;
                    versionElem.textContent = data.version;
                } else {
                    connectionStatusText.textContent = `Gagal (${data.message})`;
                    connectionStatusText.className = 'text-danger';
                    // Jika gagal, set ke N/A
                    uptimeElem.textContent = 'N/A';
                    freeMemoryElem.textContent = 'N/A';
                    totalMemoryElem.textContent = 'N/A';
                    cpuLoadElem.textContent = 'N/A';
                    boardNameElem.textContent = 'N/A';
                    versionElem.textContent = 'N/A';
                    showNotification(data.message, 'error');
                }
            })
            .catch(error => {
                console.error('Error fetching Mikrotik status:', error);
                connectionStatusText.textContent = `Error Koneksi: ${error.message}`;
                connectionStatusText.className = 'text-danger';
                // Jika error, set ke N/A
                uptimeElem.textContent = 'N/A';
                freeMemoryElem.textContent = 'N/A';
                totalMemoryElem.textContent = 'N/A';
                cpuLoadElem.textContent = 'N/A';
                boardNameElem.textContent = 'N/A';
                versionElem.textContent = 'N/A';
                showNotification('Terjadi kesalahan saat mengambil status Mikrotik.', 'error');
            });
    }

    // Fetch status on page load (pertama kali dimuat)
    fetchMikrotikStatus();

    // Refresh button listener
    if (refreshStatusBtn) {
        refreshStatusBtn.addEventListener('click', fetchMikrotikStatus);
    }

    // Auto-refresh status every 30 seconds (30000 milliseconds)
    setInterval(fetchMikrotikStatus, 10000);
});
</script>

<style>
/* CSS khusus untuk tampilan status Mikrotik */
.mikrotik-info-grid {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
    gap: 15px;
}
.mikrotik-info-grid .info-item {
    padding: 10px 0;
    border-bottom: 1px solid #eee;
    display: flex;
    justify-content: space-between;
    align-items: center;
}
.mikrotik-info-grid .info-item:last-child {
    border-bottom: none;
}
.mikrotik-info-grid .info-item strong {
    color: #555;
}
.mikrotik-info-grid .info-item span {
    font-weight: 500;
    color: #333;
}
.text-success { color: #28a745; }
.text-danger { color: #dc3545; }
.text-info { color: #17a2b8; }
</style>

<?php include '../includes/footer.php'; ?>