<?php
// C:\xampp\htdocs\billing_isp_app\pages\tagihan_belum_lunas_corporate.php
ob_start(); // Aktifkan output buffering
ini_set('session.use_strict_mode', 1);
ini_set('session.cookie_httponly', 1);
ini_set('session.cookie_samesite', 'Lax');
if (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on') {
    ini_set('session.cookie_secure', 1);
}
session_start();
include '../config/koneksi.php';
include '../includes/header.php'; // Header akan meng-include sidebar dan fungsi hasRole()

// Batasi akses ke halaman ini: hanya superadmin dan admin
if (!hasRole(['superadmin', 'admin'])) {
    header('Location: dashboard.php'); // Redirect ke dashboard atau halaman akses ditolak
    exit();
}

$message_script = ''; // Variabel untuk menampung script notifikasi JS
$current_month_year = date('Y-m'); // FormatYYYY-MM untuk bulan saat ini

// --- Logika Paginasi ---
$per_page_options = [30, 50, 100]; // Opsi jumlah baris per halaman
$per_page = isset($_GET['per_page']) && in_array((int)$_GET['per_page'], $per_page_options) ? (int)$_GET['per_page'] : 30; // Default 30 baris per halaman
$current_page = isset($_GET['page']) && (int)$_GET['page'] > 0 ? (int)$_GET['page'] : 1; // Mendapatkan halaman saat ini
$offset = ($current_page - 1) * $per_page; // Menghitung offset untuk query database

// --- Logika Pencarian dan Pengurutan ---
$search_query = $_GET['search'] ?? '';
// FIX: Menggunakan t.tanggal_terbit sebagai default sort column
$sort_column = $_GET['sort_column'] ?? 't.tanggal_terbit';
$sort_order = $_GET['sort_order'] ?? 'DESC';

// Validasi sort column
$allowed_sort_columns = [
    't.id_tagihan', 'p.nama_pelanggan', 'p.alamat', 'pk.nama_paket',
    't.bulan_tagihan', 't.total_tagihan', 't.sisa_tagihan', 't.status_tagihan',
    't.tanggal_terbit', 't.tanggal_jatuh_tempo' // FIX: Menggunakan tanggal_terbit
];
if (!in_array($sort_column, $allowed_sort_columns)) {
    $sort_column = 't.tanggal_terbit'; // FIX: Default ke tanggal_terbit
}
// Validasi sort order
if (!in_array(strtoupper($sort_order), ['ASC', 'DESC'])) {
    $sort_order = 'DESC';
}

$where_clauses = [];
$params = [];
$param_types = "";

// Filter utama: Tagihan Belum Lunas (corporate, tanpa penagih)
$where_clauses[] = "t.status_tagihan IN ('Belum Lunas', 'Jatuh Tempo', 'Kadaluarsa')";
$where_clauses[] = "pl.pelanggan_corporate = 1"; // Hanya corporate
// Perhatikan: Sebelumnya Anda meminta "tanpa penagih" untuk halaman ini juga.
// Jika Anda hanya ingin "corporate" (dengan atau tanpa penagih), HAPUS baris di bawah ini.
// Jika Anda ingin "corporate DAN tanpa penagih", biarkan baris di bawah ini.
// Saya akan asumsikan Anda ingin "corporate DAN tanpa penagih" seperti permintaan sebelumnya.
$where_clauses[] = "pl.penagih_id IS NULL";      // Tanpa penagih

// Filter pencarian
if (!empty($search_query)) {
    $search_term = '%' . $search_query . '%';
    $where_clauses[] = "(
        pl.nama_pelanggan LIKE ? OR
        pl.alamat LIKE ? OR
        t.id_tagihan LIKE ? OR   /* FIX: Menggunakan id_tagihan sebagai pengganti nomor_invoice */
        pk.nama_paket LIKE ?
    )";
    $params[] = $search_term;
    $params[] = $search_term;
    $params[] = $search_term;
    $params[] = $search_term;
    $param_types .= "ssss";
}

$final_where_clause = count($where_clauses) > 0 ? " WHERE " . implode(" AND ", $where_clauses) : "";

// --- LOGIKA PAGINASI: Ambil TOTAL data tanpa LIMIT untuk menghitung total halaman ---
$query_count = "
    SELECT COUNT(t.id_tagihan) AS total_records
    FROM tagihan t
    JOIN pelanggan pl ON t.pelanggan_id = pl.id_pelanggan
    JOIN paket_layanan pk ON pl.paket_id = pk.id_paket
    " . $final_where_clause;

$stmt_count = $koneksi->prepare($query_count);
if ($stmt_count === false) {
    die('Prepare count failed: ' . htmlspecialchars($koneksi->error));
}

if (count($params) > 0) {
    $refs_count = [];
    foreach ($params as $key => $value) {
        $refs_count[$key] = &$params[$key];
    }
    call_user_func_array([$stmt_count, 'bind_param'], array_merge([$param_types], $refs_count));
}

$stmt_count->execute();
$total_records_result = $stmt_count->get_result()->fetch_assoc();
$total_records = $total_records_result['total_records'];
$stmt_count->close();

$total_pages = ceil($total_records / $per_page);

if ($current_page > $total_pages && $total_pages > 0) {
    $current_page = $total_pages;
    $offset = ($current_page - 1) * $per_page;
} elseif ($total_pages == 0) {
    $current_page = 1;
    $offset = 0;
}

// --- Ambil data tagihan untuk ditampilkan (dengan LIMIT dan OFFSET) ---
$query_tagihan_list = "
    SELECT
        t.id_tagihan,
        t.pelanggan_id, /* Tambahkan pelanggan_id untuk prefillForm */
        pl.nama_pelanggan,
        pl.alamat,
        pl.telepon,
        pl.paket_id, /* Tambahkan paket_id dari pelanggan untuk prefillForm */
        pk.nama_paket,
        pk.kecepatan,
        t.bulan_tagihan,
        t.total_tagihan,
        t.sisa_tagihan,
        t.status_tagihan,
        t.tanggal_terbit, /* FIX: Menggunakan tanggal_terbit */
        t.tanggal_jatuh_tempo
    FROM
        tagihan t
    JOIN
        pelanggan pl ON t.pelanggan_id = pl.id_pelanggan
    JOIN
        paket_layanan pk ON pl.paket_id = pk.id_paket
    " . $final_where_clause .
    " ORDER BY " . $sort_column . " " . $sort_order .
    " LIMIT ? OFFSET ?";

$all_params_for_list_query = $params; // Mulai dengan parameter pencarian/filter
$all_param_types_for_list_query = $param_types;

// Tambahkan parameter LIMIT dan OFFSET
$all_params_for_list_query[] = $per_page;
$all_params_for_list_query[] = $offset;
$all_param_types_for_list_query .= "ii";

$stmt_tagihan_list = $koneksi->prepare($query_tagihan_list);
if ($stmt_tagihan_list === false) {
    die('Prepare failed: ' . htmlspecialchars($koneksi->error));
}

// FIX: Pastikan bind_param dipanggil hanya jika ada parameter
if (count($all_params_for_list_query) > 0) {
    $refs = [];
    foreach ($all_params_for_list_query as $key => $value) {
        $refs[$key] = &$all_params_for_list_query[$key];
    }
    call_user_func_array([$stmt_tagihan_list, 'bind_param'], array_merge([$all_param_types_for_list_query], $refs));
}

$stmt_tagihan_list->execute();
$result_tagihan_list = $stmt_tagihan_list->get_result();
$stmt_tagihan_list->close();
?>

<style>
    /* Tambahan CSS jika diperlukan untuk styling spesifik halaman ini */
    .status-badge.status-belum-lunas { background-color: #f0ad4e; color: white; }
    .status-badge.status-jatuh-tempo { background-color: #dc3545; color: white; }
    .status-badge.status-kadaluarsa { background-color: #6c757d; color: white; }
    .status-badge {
        padding: 3px 8px;
        border-radius: 4px;
        font-size: 0.85em;
        font-weight: bold;
        display: inline-block; /* Agar bisa diatur padding dan radius */
    }
    .data-table th a {
        text-decoration: none;
        color: inherit;
    }
    .pagination-controls {
        display: flex;
        justify-content: space-between;
        align-items: center;
        margin-top: 20px;
    }
    .pagination {
        list-style: none;
        padding: 0;
        margin: 0;
        display: flex;
        gap: 5px;
    }
    .page-item {
        display: inline;
    }
    .page-link {
        padding: 8px 12px;
        border: 1px solid #ddd;
        border-radius: 4px;
        text-decoration: none;
        color: #007bff;
    }
    .page-item.active .page-link {
        background-color: #007bff;
        color: white;
        border-color: #007bff;
    }
    .page-item.disabled .page-link {
        color: #6c757d;
        pointer-events: none;
        background-color: #e9ecef;
    }
</style>

<div class="main-content">
    <div class="top-header">
        <div class="alert-message">
            Pemberitahuan: Daftar Tagihan Belum Lunas Pelanggan Corporate (Tanpa Penagih).
        </div>
        <div class="welcome-message">
            <span>Selamat datang, <?php echo htmlspecialchars($_SESSION['username'] ?? 'User'); ?>!</span>
            <a href="../logout.php" class="btn-logout">Logout</a>
        </div>
    </div>

    <div class="container">
        <h2>Tagihan Belum Lunas: Corporate Tanpa Penagih</h2>

        <div class="card">
            <div class="card-header">
                <h3>Daftar Tagihan</h3>
                <div class="search-form-group">
                    <form method="GET" action="tagihan_belum_lunas_corporate.php" style="display: flex; flex-wrap: wrap; gap: 10px; align-items: flex-end;">
                        <input type="text" name="search" placeholder="Cari pelanggan/ID invoice..." value="<?php echo htmlspecialchars($search_query); ?>" style="flex: 1; min-width: 200px;">
                        <button type="submit" class="btn btn-primary btn-sm"><i class="fas fa-filter"></i> Filter</button>
                        <?php if (!empty($search_query)): ?>
                            <a href="tagihan_belum_lunas_corporate.php" class="btn btn-secondary btn-sm"><i class="fas fa-redo"></i> Reset</a>
                        <?php endif; ?>
                        
                        <div style="margin-left: auto; display: flex; align-items: center; gap: 5px;">
                            <label for="per_page" style="white-space: nowrap; margin-bottom: 0;">Baris per halaman:</label>
                            <select id="per_page" name="per_page" onchange="this.form.submit()" style="padding: 6px; border-radius: 4px; border: 1px solid #ddd;">
                                <?php foreach ($per_page_options as $option): ?>
                                    <option value="<?php echo htmlspecialchars($option, ENT_QUOTES, "UTF-8"); ?>" <?php echo ($per_page == $option) ? 'selected' : ''; ?>><?php echo htmlspecialchars($option, ENT_QUOTES, "UTF-8"); ?></option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                    </form>
                </div>
            </div>
            <div class="card-body">
                <div class="pagination-controls" style="margin-bottom: 15px;">
                    <div>
                        Menampilkan <?php echo htmlspecialchars(min($total_records, $offset + 1), ENT_QUOTES, "UTF-8"); ?> - <?php echo htmlspecialchars(min($total_records, $offset + $per_page), ENT_QUOTES, "UTF-8"); ?> dari <?php echo htmlspecialchars($total_records, ENT_QUOTES, "UTF-8"); ?> data.
                    </div>
                    <ul class="pagination" style="margin: 0;">
                        <?php if ($current_page > 1): ?>
                            <li class="page-item"><a class="page-link" href="?<?php echo htmlspecialchars(http_build_query(array_merge($_GET, ['page' => 1]))); ?>">First</a></li>
                            <li class="page-item"><a class="page-link" href="?<?php echo htmlspecialchars(http_build_query(array_merge($_GET, ['page' => $current_page - 1]))); ?>">Previous</a></li>
                        <?php endif; ?>

                        <?php
                        $start_page = max(1, $current_page - 2);
                        $end_page = min($total_pages, $current_page + 2);

                        if ($start_page > 1) {
                            echo '<li class="page-item disabled"><span class="page-link">...</span></li>';
                        }
                        for ($i = $start_page; $i <= $end_page; $i++): ?>
                            <li class="page-item <?php echo ($i == $current_page) ? 'active' : ''; ?>"><a class="page-link" href="?<?php echo htmlspecialchars(http_build_query(array_merge($_GET, ['page' => $i]))); ?>"><?php echo htmlspecialchars($i, ENT_QUOTES, "UTF-8"); ?></a></li>
                        <?php endfor; ?>

                        <?php
                        if ($end_page < $total_pages) {
                            echo '<li class="page-item disabled"><span class="page-link">...</span></li>';
                        }
                        ?>

                        <?php if ($current_page < $total_pages): ?>
                            <li class="page-item"><a class="page-link" href="?<?php echo htmlspecialchars(http_build_query(array_merge($_GET, ['page' => $current_page + 1]))); ?>">Next</a></li>
                            <li class="page-item"><a class="page-link" href="?<?php echo htmlspecialchars(http_build_query(array_merge($_GET, ['page' => $total_pages]))); ?>">Last</a></li>
                        <?php endif; ?>
                    </ul>
                </div>

                <div class="table-responsive">
                    <table class="data-table" style="width: 100%; border-collapse: collapse;">
                        <thead>
                            <tr>
                                <th><a href="?<?php echo htmlspecialchars(http_build_query(array_merge($_GET, ['sort_column' => 't.id_tagihan', 'sort_order' => ($sort_column == 't.id_tagihan' && $sort_order == 'ASC') ? 'DESC' : 'ASC']))); ?>">ID Tagihan <?php if ($sort_column == 't.id_tagihan') echo ($sort_order == 'ASC' ? '&#9650;' : '&#9660;'); ?></a></th>
                                <th>ID Invoice <?php if ($sort_column == 't.id_tagihan') echo ($sort_order == 'ASC' ? '&#9650;' : '&#9660;'); ?></th>
                                <th><a href="?<?php echo htmlspecialchars(http_build_query(array_merge($_GET, ['sort_column' => 'p.nama_pelanggan', 'sort_order' => ($sort_column == 'p.nama_pelanggan' && $sort_order == 'ASC') ? 'DESC' : 'ASC']))); ?>">Nama Pelanggan <?php if ($sort_column == 'p.nama_pelanggan') echo ($sort_order == 'ASC' ? '&#9650;' : '&#9660;'); ?></a></th>
                                <th><a href="?<?php echo htmlspecialchars(http_build_query(array_merge($_GET, ['sort_column' => 'p.alamat', 'sort_order' => ($sort_column == 'p.alamat' && $sort_order == 'ASC') ? 'DESC' : 'ASC']))); ?>">Alamat <?php if ($sort_column == 'p.alamat') echo ($sort_order == 'ASC' ? '&#9650;' : '&#9660;'); ?></a></th>
                                <th><a href="?<?php echo htmlspecialchars(http_build_query(array_merge($_GET, ['sort_column' => 'p.telepon', 'sort_order' => ($sort_column == 'p.telepon' && $sort_order == 'ASC') ? 'DESC' : 'ASC']))); ?>">Telepon <?php if ($sort_column == 'p.telepon') echo ($sort_order == 'ASC' ? '&#9650;' : '&#9660;'); ?></a></th>
                                <th><a href="?<?php echo htmlspecialchars(http_build_query(array_merge($_GET, ['sort_column' => 'pk.nama_paket', 'sort_order' => ($sort_column == 'pk.nama_paket' && $sort_order == 'ASC') ? 'DESC' : 'ASC']))); ?>">Paket <?php if ($sort_column == 'pk.nama_paket') echo ($sort_order == 'ASC' ? '&#9650;' : '&#9660;'); ?></a></th>
                                <th><a href="?<?php echo htmlspecialchars(http_build_query(array_merge($_GET, ['sort_column' => 't.bulan_tagihan', 'sort_order' => ($sort_column == 't.bulan_tagihan' && $sort_order == 'ASC') ? 'DESC' : 'ASC']))); ?>">Bulan Tagihan <?php if ($sort_column == 't.bulan_tagihan') echo ($sort_order == 'ASC' ? '&#9650;' : '&#9660;'); ?></a></th>
                                <th><a href="?<?php echo htmlspecialchars(http_build_query(array_merge($_GET, ['sort_column' => 't.total_tagihan', 'sort_order' => ($sort_column == 't.total_tagihan' && $sort_order == 'ASC') ? 'DESC' : 'ASC']))); ?>">Total Tagihan <?php if ($sort_column == 't.total_tagihan') echo ($sort_order == 'ASC' ? '&#9650;' : '&#9660;'); ?></a></th>
                                <th><a href="?<?php echo htmlspecialchars(http_build_query(array_merge($_GET, ['sort_column' => 't.sisa_tagihan', 'sort_order' => ($sort_column == 't.sisa_tagihan' && $sort_order == 'ASC') ? 'DESC' : 'ASC']))); ?>">Sisa Tagihan <?php if ($sort_column == 't.sisa_tagihan') echo ($sort_order == 'ASC' ? '&#9650;' : '&#9660;'); ?></a></th>
                                <th><a href="?<?php echo htmlspecialchars(http_build_query(array_merge($_GET, ['sort_column' => 't.status_tagihan', 'sort_order' => ($sort_column == 't.status_tagihan' && $sort_order == 'ASC') ? 'DESC' : 'ASC']))); ?>">Status <?php if ($sort_column == 't.status_tagihan') echo ($sort_order == 'ASC' ? '&#9650;' : '&#9660;'); ?></a></th>
                                <th><a href="?<?php echo htmlspecialchars(http_build_query(array_merge($_GET, ['sort_column' => 't.tanggal_terbit', 'sort_order' => ($sort_column == 't.tanggal_terbit' && $sort_order == 'ASC') ? 'DESC' : 'ASC']))); ?>">Tanggal Terbit <?php if ($sort_column == 't.tanggal_terbit') echo ($sort_order == 'ASC' ? '&#9650;' : '&#9660;'); ?></a></th>
                                <th><a href="?<?php echo htmlspecialchars(http_build_query(array_merge($_GET, ['sort_column' => 't.tanggal_jatuh_tempo', 'sort_order' => ($sort_column == 't.tanggal_jatuh_tempo' && $sort_order == 'ASC') ? 'DESC' : 'ASC']))); ?>">Jatuh Tempo <?php if ($sort_column == 't.tanggal_jatuh_tempo') echo ($sort_order == 'ASC' ? '&#9650;' : '&#9660;'); ?></a></th>
                                <th>Aksi</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php if ($result_tagihan_list->num_rows > 0): ?>
                                <?php while($row = $result_tagihan_list->fetch_assoc()): ?>
                                    <tr>
                                        <td><?php echo htmlspecialchars($row['id_tagihan']); ?></td>
                                        <td><?php echo htmlspecialchars($row['id_tagihan']); ?></td>
                                        <td><?php echo htmlspecialchars($row['nama_pelanggan']); ?></td>
                                        <td><?php echo htmlspecialchars($row['alamat']); ?></td>
                                        <td><?php echo htmlspecialchars($row['telepon']); ?></td>
                                        <td><?php echo htmlspecialchars($row['nama_paket'] . ' (' . $row['kecepatan'] . ')'); ?></td>
                                        <td><?php echo htmlspecialchars($row['bulan_tagihan']); ?></td>
                                        <td><?php echo "Rp " . number_format($row['total_tagihan'], 0, ',', '.'); ?></td>
                                        <td><?php echo "Rp " . number_format($row['sisa_tagihan'], 0, ',', '.'); ?></td>
                                        <td>
                                            <span class="status-badge status-<?php echo strtolower(str_replace(' ', '-', $row['status_tagihan'])); ?>">
                                                <?php echo htmlspecialchars($row['status_tagihan']); ?>
                                            </span>
                                        </td>
                                        <td><?php echo htmlspecialchars(date('d-m-Y', strtotime($row['tanggal_terbit']))); ?></td>
                                        <td><?php echo htmlspecialchars(date('d-m-Y', strtotime($row['tanggal_jatuh_tempo']))); ?></td>
                                        <td>
                                            <a href="detail_tagihan.php?id=<?php echo htmlspecialchars($row['id_tagihan']); ?></a>
                                            <button type="button" class="btn btn-success btn-sm" onclick="prefillPaymentForm(
                                                '<?php echo htmlspecialchars($row['pelanggan_id']); ?>',
                                                '<?php echo htmlspecialchars($row['sisa_tagihan']); ?>',
                                                '<?php echo htmlspecialchars($row['paket_id']); ?>',
                                                '<?php echo htmlspecialchars($row['bulan_tagihan']); ?>'
                                            )">Catat Bayar</button>
                                        </td>
                                    </tr>
                                <?php endwhile; ?>
                            <?php else: ?>
                                <tr><td colspan="13" style="text-align: center;">Tidak ada tagihan belum lunas corporate tanpa penagih yang ditemukan.</td></tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>

                <div class="pagination-controls" style="margin-top: 20px;">
                    <div>
                        Menampilkan <?php echo htmlspecialchars(min($total_records, $offset + 1), ENT_QUOTES, "UTF-8"); ?> - <?php echo htmlspecialchars(min($total_records, $offset + $per_page), ENT_QUOTES, "UTF-8"); ?> dari <?php echo htmlspecialchars($total_records, ENT_QUOTES, "UTF-8"); ?> data.
                    </div>
                    <ul class="pagination" style="margin: 0;">
                        <?php if ($current_page > 1): ?>
                            <li class="page-item"><a class="page-link" href="?<?php echo htmlspecialchars(http_build_query(array_merge($_GET, ['page' => 1]))); ?>">First</a></li>
                            <li class="page-item"><a class="page-link" href="?<?php echo htmlspecialchars(http_build_query(array_merge($_GET, ['page' => $current_page - 1]))); ?>">Previous</a></li>
                        <?php endif; ?>

                        <?php
                        $start_page = max(1, $current_page - 2);
                        $end_page = min($total_pages, $current_page + 2);

                        if ($start_page > 1) {
                            echo '<li class="page-item disabled"><span class="page-link">...</span></li>';
                        }
                        for ($i = $start_page; $i <= $end_page; $i++): ?>
                            <li class="page-item <?php echo ($i == $current_page) ? 'active' : ''; ?>"><a class="page-link" href="?<?php echo htmlspecialchars(http_build_query(array_merge($_GET, ['page' => $i]))); ?>"><?php echo htmlspecialchars($i, ENT_QUOTES, "UTF-8"); ?></a></li>
                        <?php endfor; ?>

                        <?php
                        if ($end_page < $total_pages) {
                            echo '<li class="page-item disabled"><span class="page-link">...</span></li>';
                        }
                        ?>

                        <?php if ($current_page < $total_pages): ?>
                            <li class="page-item"><a class="page-link" href="?<?php echo htmlspecialchars(http_build_query(array_merge($_GET, ['page' => $current_page + 1]))); ?>">Next</a></li>
                            <li class="page-item"><a class="page-link" href="?<?php echo htmlspecialchars(http_build_query(array_merge($_GET, ['page' => $total_pages]))); ?>">Last</a></li>
                        <?php endif; ?>
                    </ul>
                </div>
            </div>
        </div>

    </div>
</div>

<script>
    // Fungsi prefillPaymentForm yang akan dipanggil dari tombol "Catat Bayar"
    function prefillPaymentForm(pelangganId, jumlahBayar, paketId, bulanTagihan) {
        // Asumsi ada tab atau form untuk mencatat pembayaran di halaman ini atau halaman pembayaran.php
        // Ini akan mengarahkan ke pembayaran.php dengan parameter yang sudah terisi.
        // Anda perlu memastikan pembayaran.php dapat menerima parameter ini.
        window.location.href = `pembayaran.php?tab=catatPembayaran&pelanggan_id=${pelangganId}&bulan_tagihan=${bulanTagihan}&jumlah_bayar=${jumlahBayar}&paket_id=${paketId}`;
    }
</script>

<?php include '../includes/footer.php'; ?>