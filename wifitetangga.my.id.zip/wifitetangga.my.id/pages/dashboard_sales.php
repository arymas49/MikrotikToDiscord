<?php
// C:\xampp\htdocs\billing_isp_app\pages\dashboard_sales.php
ob_start();
ini_set('session.use_strict_mode', 1);
ini_set('session.cookie_httponly', 1);
ini_set('session.cookie_samesite', 'Lax');
if (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on') {
    ini_set('session.cookie_secure', 1);
}
session_start();
include '../config/koneksi.php';
include '../includes/header.php'; // Header akan meng-include sidebar dan fungsi hasRole()

// DEBUGGING AGRESIV: Pastikan semua error ditampilkan
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);
// Coba tangkap fatal error juga
register_shutdown_function(function() {
    $error = error_get_last();
    if ($error && ($error['type'] === E_ERROR || $error['type'] === E_PARSE || $error['type'] === E_CORE_ERROR || $error['type'] === E_COMPILE_ERROR)) {
        echo "<div style='background-color: #fdd; border: 1px solid red; padding: 10px;'>";
        echo "<h2>Fatal Error Detected:</h2>";
        echo "<strong>Type:</strong> " . $error['type'] . "<br>";
        echo "<strong>Message:</strong> " . $error['message'] . "<br>";
        echo "<strong>File:</strong> " . $error['file'] . " (Line: " . $error['line'] . ")<br>";
        echo "</div>";
    }
});
// Tingkatkan batas memori dan waktu eksekusi jika perlu
ini_set('memory_limit', '256M'); 
set_time_limit(300);

// Batasi akses ke halaman ini: hanya superadmin dan admin
if (!hasRole(['superadmin', 'admin'])) {
    header('Location: dashboard.php'); // Redirect ke dashboard atau halaman akses ditolak
    exit();
}

$message = '';

// --- Tangkap parameter filter bulan dan tahun ---
$filter_month = $_GET['filter_month'] ?? '';
$filter_year = $_GET['filter_year'] ?? '';

$filtered_month_year_for_registration = '';
$where_registration_clause = "1";
$bind_params_registration = [];
$bind_types_registration = "";

if (!empty($filter_month) && !empty($filter_year)) {
    $filtered_month_year_for_registration = $filter_year . '-' . sprintf('%02d', $filter_month);
    $where_registration_clause = "SUBSTRING(p.tanggal_registrasi, 1, 7) = ?";
    $bind_params_registration[] = $filtered_month_year_for_registration;
    $bind_types_registration .= "s";
    $display_filtered_date = date('F Y', strtotime($filtered_month_year_for_registration . '-01'));
} elseif (!empty($filter_year)) {
    $where_registration_clause = "SUBSTRING(p.tanggal_registrasi, 1, 4) = ?";
    $bind_params_registration[] = $filter_year;
    $bind_types_registration .= "s";
    $display_filtered_date = "Tahun " . $filter_year;
} elseif (!empty($filter_month)) {
    $where_registration_clause = "SUBSTRING(p.tanggal_registrasi, 6, 2) = ?";
    $bind_params_registration[] = sprintf('%02d', $filter_month);
    $bind_types_registration .= "s";
    $display_filtered_date = "Bulan " . date('F', strtotime("2000-" . sprintf('%02d', $filter_month) . "-01")) . " (Semua Tahun)";
} else {
    $display_filtered_date = "Semua Periode";
}

$filtered_month_year_for_tagihan = '';
$where_tagihan_clause = "1";
$bind_params_tagihan = [];
$bind_types_tagihan = "";

if (!empty($filter_month) && !empty($filter_year)) {
    $filtered_month_year_for_tagihan = $filter_year . '-' . sprintf('%02d', $filter_month);
    $where_tagihan_clause = "t_filtered.bulan_tagihan = ?";
    $bind_params_tagihan[] = $filtered_month_year_for_tagihan;
    $bind_types_tagihan .= "s";
}


// --- Sorting Parameters ---
$sort_column = $_GET['sort_column'] ?? 'total_pelanggan_recorded';
$sort_order = $_GET['sort_order'] ?? 'DESC';

$allowed_sort_columns = [
    's.id_sales', 's.nama_sales', 's.email', 's.telepon',
    'total_pelanggan_recorded', 'total_pelanggan_aktif_overall',
    'total_pelanggan_tidak_aktif_overall', 'total_pelanggan_blokir_overall',
    'pelanggan_lunas_bulan_terpilih', 'pelanggan_belum_lunas_bulan_terpilih',
    's.status_aktif'
];
if (!in_array($sort_column, $allowed_sort_columns)) {
    $sort_column = 'total_pelanggan_recorded';
}
if (!in_array(strtoupper($sort_order), ['ASC', 'DESC'])) {
    $sort_order = 'DESC';
}

function get_sort_url_params($current_params, $column, $current_sort_column, $current_sort_order) {
    $new_order = 'ASC';
    if ($current_sort_column === $column) {
        $new_order = ($current_sort_order === 'ASC') ? 'DESC' : 'ASC';
    }
    $params = $current_params;
    unset($params['sort_column']);
    unset($params['sort_order']);
    $params['sort_column'] = $column;
    $params['sort_order'] = $new_order;
    return http_build_query($params);
}
$current_get_params = $_GET;


// --- Ambil data sales performance ke dalam array ---
$query_sales_performance = "
    SELECT
        s.id_sales,
        s.nama_sales,
        s.email,
        s.telepon,
        s.tanggal_bergabung,
        s.status_aktif,
        COUNT(p.id_pelanggan) AS total_pelanggan_recorded,
        SUM(CASE WHEN p.status_aktif = 'Aktif' THEN 1 ELSE 0 END) AS total_pelanggan_aktif_overall,
        SUM(CASE WHEN p.status_aktif = 'Tidak Aktif' THEN 1 ELSE 0 END) AS total_pelanggan_tidak_aktif_overall,
        SUM(CASE WHEN p.status_aktif = 'Blokir' THEN 1 ELSE 0 END) AS total_pelanggan_blokir_overall,
        
        SUM(CASE
            WHEN " . ($filtered_month_year_for_tagihan ? $where_tagihan_clause : '0') . " AND t_filtered.status_tagihan = 'Lunas' THEN 1
            ELSE 0
        END) AS pelanggan_lunas_bulan_terpilih,
        SUM(CASE
            WHEN " . ($filtered_month_year_for_tagihan ? $where_tagihan_clause : '0') . " AND t_filtered.status_tagihan = 'Belum Lunas' THEN 1
            ELSE 0
        END) AS pelanggan_belum_lunas_bulan_terpilih
    FROM
        sales s
    LEFT JOIN
        pelanggan p ON s.id_sales = p.sales_id AND " . $where_registration_clause . "
    LEFT JOIN
        tagihan t_filtered ON p.id_pelanggan = t_filtered.pelanggan_id
            AND " . ($filtered_month_year_for_tagihan ? $where_tagihan_clause : '1') . "
    GROUP BY
        s.id_sales, s.nama_sales, s.email, s.telepon, s.tanggal_bergabung, s.status_aktif
    ORDER BY
        " . $sort_column . " " . $sort_order . ", s.nama_sales ASC
";

$stmt_sales_performance = $koneksi->prepare($query_sales_performance);
if ($stmt_sales_performance === false) {
    die('Prepare failed for sales performance: ' . htmlspecialchars($koneksi->error));
}

$final_bind_params_sales = array_merge($bind_params_registration);
if ($filtered_month_year_for_tagihan) {
    $final_bind_params_sales = array_merge($final_bind_params_sales, $bind_params_tagihan, $bind_params_tagihan, $bind_params_tagihan);
}
$final_bind_types_sales = $bind_types_registration;
if ($filtered_month_year_for_tagihan) {
    $final_bind_types_sales .= str_repeat($bind_types_tagihan, 3);
}

if (!empty($final_bind_params_sales)) {
    $refs_sales = [];
    foreach ($final_bind_params_sales as $key => $value) {
        $refs_sales[$key] = &$final_bind_params_sales[$key];
    }
    call_user_func_array([$stmt_sales_performance, 'bind_param'], array_merge([$final_bind_types_sales], $refs_sales));
}

$stmt_sales_performance->execute();
$sales_performance_data = $stmt_sales_performance->get_result()->fetch_all(MYSQLI_ASSOC);
$stmt_sales_performance->close();


// --- Ambil data detail pelanggan per sales untuk sub-tabel ---
$sales_customer_details = [];
foreach ($sales_performance_data as $row) {
    $sales_id = $row['id_sales'];
    $sales_customer_details[$sales_id] = [];

    // Query untuk semua pelanggan yang dicatat oleh sales ini, di periode registrasi yang difilter
    $query_customers_for_sales = "
        SELECT p.id_pelanggan, p.nama_pelanggan, p.alamat, p.telepon
        FROM pelanggan p
        WHERE p.sales_id = ? AND " . $where_registration_clause . "
        ORDER BY p.nama_pelanggan ASC
    ";
    $stmt_customers = $koneksi->prepare($query_customers_for_sales);
    if ($stmt_customers === false) {
        error_log("Prepare failed for customers for sales (ID: {$sales_id}): " . $koneksi->error);
        continue;
    }

    $bind_params_customers = [$sales_id];
    $bind_types_customers = "i";
    if ($where_registration_clause !== "1") {
        $bind_params_customers[] = $bind_params_registration[0];
        $bind_types_customers .= "s";
    }

    $refs_customers = [];
    foreach ($bind_params_customers as $key => $value) {
        $refs_customers[$key] = &$bind_params_customers[$key];
    }
    call_user_func_array([$stmt_customers, 'bind_param'], array_merge([$bind_types_customers], $refs_customers));
    
    $stmt_customers->execute();
    $result_customers = $stmt_customers->get_result();
    while ($customer_row = $result_customers->fetch_assoc()) {
        $sales_customer_details[$sales_id][] = $customer_row;
    }
    $stmt_customers->close();
}

?>

<div class="main-content">
    <div class="top-header">
        <div class="alert-message">
            Pemberitahuan: Pantau performa sales Anda secara real-time.
        </div>
        <div class="welcome-message">
            <span>Selamat datang, <?php echo htmlspecialchars($_SESSION['username'] ?? 'User'); ?>!</span>
            <a href="../logout.php" class="btn-logout">Logout</a>
        </div>
    </div>

    <div class="container">
        <h2>Dashboard Sales</h2>

        <?php echo htmlspecialchars($message, ENT_QUOTES, "UTF-8"); ?>

        <div class="card">
            <div class="card-header">
                <h3>Performa Sales Berdasarkan Jumlah Pelanggan</h3>
                <div class="filter-print-section" style="display: flex; justify-content: space-between; align-items: center; flex-wrap: wrap; margin-bottom: 15px;">
                    <form method="GET" action="dashboard_sales.php" class="filter-form" style="display: flex; gap: 10px; align-items: center;">
                        <select name="filter_month" id="filter_month" style="padding: 8px; border-radius: 4px; border: 1px solid #ddd;">
                            <option value="">Semua Bulan</option> <?php
                            $months = [
                                '01' => 'Januari', '02' => 'Februari', '03' => 'Maret', '04' => 'April',
                                '05' => 'Mei', '06' => 'Juni', '07' => 'Juli', '08' => 'Agustus',
                                '09' => 'September', '10' => 'Oktober', '11' => 'November', '12' => 'Desember'
                            ];
                            foreach ($months as $num => $name) {
                                $selected = (sprintf('%02d', $filter_month) == $num) ? 'selected' : '';
                                echo "<option value=\"{$num}\" {$selected}>{$name}</option>";
                            }
                            ?>
                        </select>
                        <select name="filter_year" id="filter_year" style="padding: 8px; border-radius: 4px; border: 1px solid #ddd;">
                            <option value="">Semua Tahun</option> <?php
                            $current_year = date('Y');
                            for ($y = $current_year - 5; $y <= $current_year + 1; $y++) { // 5 tahun ke belakang, 1 tahun ke depan
                                $selected = ($filter_year == $y) ? 'selected' : '';
                                echo "<option value=\"{$y}\" {$selected}>{$y}</option>";
                            }
                            ?>
                        </select>
                        <button type="submit" class="btn btn-secondary btn-sm" style="padding: 8px 12px;"><i class="fas fa-filter"></i> Filter</button>
                        <a href="dashboard_sales.php" class="btn btn-secondary btn-sm" style="padding: 8px 12px;"><i class="fas fa-redo"></i> Reset</a>
                    </form>
                    
                    <div class="print-button-container" style="margin-top: 10px;">
                        <button type="button" class="btn btn-info" onclick="printReport()"><i class="fas fa-print"></i> Cetak Laporan</button>
                    </div>
                </div>
            </div>
            <div class="card-body">
                <table class="data-table">
                    <thead>
                        <tr>
                            <th><a href="?<?php echo get_sort_url_params($current_get_params, 's.id_sales', $sort_column, $sort_order); ?>">ID Sales <?php if ($sort_column == 's.id_sales') echo ($sort_order == 'ASC' ? '&#9650;' : '&#9660;'); ?></a></th>
                            <th><a href="?<?php echo get_sort_url_params($current_get_params, 's.nama_sales', $sort_column, $sort_order); ?>">Nama Sales <?php if ($sort_column == 's.nama_sales') echo ($sort_order == 'ASC' ? '&#9650;' : '&#9660;'); ?></a></th>
                            <th><a href="?<?php echo get_sort_url_params($current_get_params, 's.email', $sort_column, $sort_order); ?>">Email <?php if ($sort_column == 's.email') echo ($sort_order == 'ASC' ? '&#9650;' : '&#9660;'); ?></a></th>
                            <th><a href="?<?php echo get_sort_url_params($current_get_params, 's.telepon', $sort_column, $sort_order); ?>">Telepon <?php if ($sort_column == 's.telepon') echo ($sort_order == 'ASC' ? '&#9650;' : '&#9660;'); ?></a></th>
                            <th><a href="?<?php echo get_sort_url_params($current_get_params, 'total_pelanggan_recorded', $sort_column, $sort_order); ?>">Total Pelanggan Dicatat (Periode Ini) <?php if ($sort_column == 'total_pelanggan_recorded') echo ($sort_order == 'ASC' ? '&#9650;' : '&#9660;'); ?></a></th>
                            <th>Pelanggan Aktif (Keseluruhan)</th>
                            <th>Pelanggan Tidak Aktif (Keseluruhan)</th>
                            <th>Pelanggan Diblokir (Keseluruhan)</th>
                            <th>Tagihan Lunas (Bulan Terpilih)</th>
                            <th>Tagihan Belum Lunas (Bulan Terpilih)</th>
                            <th>Status Sales</th>
                            <th>Aksi Detail</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if (count($sales_performance_data) > 0): ?>
                            <?php foreach ($sales_performance_data as $row): ?>
                                <tr data-sales-id="<?php echo htmlspecialchars($row['id_sales']); ?>" class="main-row">
                                    <td><?php echo htmlspecialchars($row['id_sales']); ?></td>
                                    <td><?php echo htmlspecialchars($row['nama_sales']); ?></td>
                                    <td><?php echo htmlspecialchars($row['email']); ?></td>
                                    <td><?php echo htmlspecialchars($row['telepon']); ?></td>
                                    <td><?php echo htmlspecialchars($row['total_pelanggan_recorded']); ?></td>
                                    <td><?php echo htmlspecialchars($row['total_pelanggan_aktif_overall']); ?></td>
                                    <td><?php echo htmlspecialchars($row['total_pelanggan_tidak_aktif_overall']); ?></td>
                                    <td><?php echo htmlspecialchars($row['total_pelanggan_blokir_overall']); ?></td>
                                    <td><?php echo htmlspecialchars($row['pelanggan_lunas_bulan_terpilih']); ?></td>
                                    <td><?php echo htmlspecialchars($row['pelanggan_belum_lunas_bulan_terpilih']); ?></td>
                                    <td><span class="status-badge status-<?php echo strtolower(str_replace(' ', '-', $row['status_aktif'])); ?>"><?php echo htmlspecialchars($row['status_aktif']); ?></span></td>
                                    <td>
                                        <button class="btn btn-sm btn-info toggle-detail-btn" data-sales-id="<?php echo htmlspecialchars($row['id_sales']); ?>">
                                            <i class="fas fa-plus"></i>
                                        </button>
                                    </td>
                                </tr>
                                <tr id="detail-row-<?php echo htmlspecialchars($row['id_sales']); ?>" class="detail-row" style="display: none;">
                                    <td colspan="12"> <h4>Detail Pelanggan Dicatat (Periode Ini):</h4>
                                        <?php 
                                        $customers = $sales_customer_details[$row['id_sales']] ?? [];
                                        if (!empty($customers)): 
                                        ?>
                                            <table class="sub-data-table">
                                                <thead>
                                                    <tr>
                                                        <th>ID Pelanggan</th>
                                                        <th>Nama Pelanggan</th>
                                                        <th>Alamat</th>
                                                        <th>Telepon</th>
                                                        <th>Aksi</th>
                                                    </tr>
                                                </thead>
                                                <tbody>
                                                    <?php foreach ($customers as $customer): ?>
                                                        <tr>
                                                            <td><?php echo htmlspecialchars($customer['id_pelanggan']); ?></td>
                                                            <td><?php echo htmlspecialchars($customer['nama_pelanggan']); ?></td>
                                                            <td><?php echo htmlspecialchars($customer['alamat']); ?></td>
                                                            <td><?php echo htmlspecialchars($customer['telepon']); ?></td>
                                                            <td>
                                                                <a href="manajemen_pelanggan.php?action=edit&id=<?php echo htmlspecialchars($customer['id_pelanggan']); ?>" class="btn-action btn-edit btn-sm" target="_blank">Edit</a>
                                                                <a href="pembayaran.php?pelanggan_id=<?php echo htmlspecialchars($customer['id_pelanggan']); ?>" class="btn-action btn-info btn-sm" target="_blank">Bayar/History</a>
                                                            </td>
                                                        </tr>
                                                    <?php endforeach; ?>
                                                </tbody>
                                            </table>
                                        <?php else: ?>
                                            <p>Tidak ada pelanggan dicatat untuk sales ini pada periode yang dipilih.</p>
                                        <?php endif; ?>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        <?php else: ?>
                            <tr><td colspan="12" style="text-align: center;">Tidak ada data sales ditemukan untuk periode ini.</td></tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>

    </div>
</div>

<script>
    document.addEventListener('DOMContentLoaded', function() {
        // Toggle detail rows
        document.querySelectorAll('.toggle-detail-btn').forEach(button => {
            button.addEventListener('click', function() {
                const salesId = this.dataset.salesId;
                const detailRow = document.getElementById(`detail-row-${salesId}`);
                const icon = this.querySelector('i');

                if (detailRow.style.display === 'none') {
                    detailRow.style.display = 'table-row';
                    icon.classList.remove('fa-plus');
                    icon.classList.add('fa-minus');
                } else {
                    detailRow.style.display = 'none';
                    icon.classList.remove('fa-minus');
                    icon.classList.add('fa-plus');
                }
            });
        });
    });

    function printReport() {
        const filterMonth = document.getElementById('filter_month').value;
        const filterYear = document.getElementById('filter_year').value;
        const sortColumn = '<?php echo htmlspecialchars($sort_column, ENT_QUOTES, "UTF-8"); ?>';
        const sortOrder = '<?php echo htmlspecialchars($sort_order, ENT_QUOTES, "UTF-8"); ?>';
        
        window.open(`print_dashboard_sales.php?filter_month=${filterMonth}&filter_year=${filterYear}&sort_column=${sortColumn}&sort_order=${sortOrder}`, '_blank');
    }
</script>

<?php include '../includes/footer.php'; ?>