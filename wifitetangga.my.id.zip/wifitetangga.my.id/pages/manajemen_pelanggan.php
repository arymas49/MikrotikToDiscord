<?php
// C:\xampp\htdocs\billing_isp_app\pages\pelanggan
ob_start(); // Aktifkan output buffering
ini_set('session.use_strict_mode', 1);
ini_set('session.cookie_httponly', 1);
ini_set('session.cookie_samesite', 'Lax');
if (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on') {
    ini_set('session.cookie_secure', 1);
}
session_start();
include '../config/koneksi.php';
include '../includes/header.php'; // Header akan meng-include sidebar dan fungsi hasRole()

// Batasi akses ke halaman ini: hanya superadmin dan admin
if (!hasRole(['superadmin', 'admin'])) {
    header('Location: dashboard.php'); // Redirect ke dashboard atau halaman akses ditolak
    exit();
}

$message_script = ''; // Variabel baru untuk menampung script notifikasi JS
$pelanggan_id_to_edit = null;
$pelanggan_data = [];
$current_month_year = date('Y-m'); // FormatYYYY-MM untuk bulan saat ini

// --- Logika Paginasi ---
$per_page_options = [30, 50, 100]; // Opsi jumlah baris per halaman
$per_page = isset($_GET['per_page']) && in_array((int)$_GET['per_page'], $per_page_options) ? (int)$_GET['per_page'] : 30; // Default 30 baris per halaman
$current_page = isset($_GET['page']) && (int)$_GET['page'] > 0 ? (int)$_GET['page'] : 1; // Mendapatkan halaman saat ini
$offset = ($current_page - 1) * $per_page; // Menghitung offset untuk query database

// --- Menampilkan Pesan Setelah Redirect (GET) ---
if (isset($_GET['msg'])) {
    if ($_GET['msg'] == 'add_success') {
        $message_script = "showNotification('Pelanggan berhasil ditambahkan.', 'success');";
    } elseif ($_GET['msg'] == 'edit_success') {
        $message_script = "showNotification('Pelanggan berhasil diperbarui.', 'success');";
    } elseif ($_GET['msg'] == 'delete_success') {
        $message_script = "showNotification('Pelanggan dan semua riwayat terkait berhasil dihapus.', 'success');";
    } elseif ($_GET['msg'] == 'delete_fail') {
        $error_detail = $_GET['err'] ?? 'Terjadi kesalahan tidak diketahui.';
        $message_script = "showNotification('Gagal menghapus pelanggan: " . htmlspecialchars($error_detail, ENT_QUOTES, 'UTF-8') . "', 'error');";
    } elseif ($_GET['msg'] == 'status_success') {
        $status_updated_to = $_GET['new_status'] ?? 'N/A';
        $message_script = "showNotification('Status pelanggan berhasil diperbarui menjadi " . htmlspecialchars($status_updated_to, ENT_QUOTES, 'UTF-8') . ".', 'success');";
    } elseif ($_GET['msg'] == 'status_fail') {
        $error_detail = $_GET['err'] ?? 'Terjadi kesalahan tidak diketahui.';
        $message_script = "showNotification('Gagal memperbarui status pelanggan: " . htmlspecialchars($error_detail, ENT_QUOTES, 'UTF-8') . "', 'error');";
    } elseif ($_GET['msg'] == 'mass_delete_success') {
        $deleted_count = $_GET['count'] ?? 0;
        $message_script = "showNotification('" . htmlspecialchars($deleted_count, ENT_QUOTES, 'UTF-8') . " pelanggan berhasil dihapus secara massal.', 'success');";
    } elseif ($_GET['msg'] == 'mass_delete_fail') {
        $error_detail = $_GET['err'] ?? 'Terjadi kesalahan tidak diketahui.';
        $message_script = "showNotification('Gagal menghapus pelanggan secara massal: " . htmlspecialchars($error_detail, ENT_QUOTES, 'UTF-8') . "', 'error');";
    } elseif ($_GET['msg'] == 'mass_delete_no_selection') {
        $message_script = "showNotification('Tidak ada pelanggan yang dipilih untuk dihapus.', 'warning');";
    }
}


// --- Logika Hapus Pelanggan Tunggal (TERMASUK RIWAYAT TERKAIT) ---
if (isset($_GET['action']) && $_GET['action'] == 'delete' && isset($_GET['id'])) {
    if (!hasRole('superadmin')) {
        header('Location: pelanggan?msg=delete_fail&err=' . urlencode("Anda tidak memiliki izin untuk menghapus pelanggan. Hanya Superadmin yang dapat melakukan aksi ini."));
        ob_end_clean();
        exit();
    } else {
        $id_pelanggan_to_delete = $koneksi->real_escape_string($_GET['id']);

        $koneksi->begin_transaction();
        try {
            // 1. Hapus semua pembayaran terkait pelanggan ini
            $stmt_del_pembayaran = $koneksi->prepare("DELETE FROM pembayaran WHERE pelanggan_id = ?");
            $stmt_del_pembayaran->bind_param("i", $id_pelanggan_to_delete);
            if (!$stmt_del_pembayaran->execute()) {
                throw new Exception("Gagal menghapus riwayat pembayaran: " . $stmt_del_pembayaran->error);
            }
            $stmt_del_pembayaran->close();

            // 2. Hapus semua tagihan terkait pelanggan ini
            $stmt_del_tagihan = $koneksi->prepare("DELETE FROM tagihan WHERE pelanggan_id = ?");
            $stmt_del_tagihan->bind_param("i", $id_pelanggan_to_delete);
            if (!$stmt_del_tagihan->execute()) {
                throw new Exception("Gagal menghapus riwayat tagihan: " . $stmt_del_tagihan->error);
            }
            $stmt_del_tagihan->close();

            // 3. Sekarang, hapus pelanggan itu sendiri
            $stmt_del_pelanggan = $koneksi->prepare("DELETE FROM pelanggan WHERE id_pelanggan = ?");
            $stmt_del_pelanggan->bind_param("i", $id_pelanggan_to_delete);
            if ($stmt_del_pelanggan->execute()) {
                $koneksi->commit();
                logActivity('Delete', 'Menghapus pelanggan ID ' . $id_pelanggan_to_delete . '.');
                header('Location: pelanggan?msg=delete_success');
                ob_end_clean();
                exit();
            } else {
                throw new Exception("Gagal menghapus data pelanggan: " . $stmt_del_pelanggan->error);
            }
            $stmt_del_pelanggan->close();

        } catch (Exception $e) {
            $koneksi->rollback();
            header('Location: pelanggan?msg=delete_fail&err=' . urlencode($e->getMessage()));
            ob_end_clean();
            exit();
        }
    }
}


// --- Logika Hapus Massal Pelanggan ---
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['action']) && $_POST['action'] == 'mass_delete') {
    if (!hasRole('superadmin')) {
        header('Location: pelanggan?msg=mass_delete_fail&err=' . urlencode("Anda tidak memiliki izin untuk melakukan hapus massal."));
        ob_end_clean();
        exit();
    }

    if (!isset($_POST['selected_customers']) || !is_array($_POST['selected_customers']) || empty($_POST['selected_customers'])) {
        header('Location: pelanggan?msg=mass_delete_no_selection');
        ob_end_clean();
        exit();
    }

    $selected_ids = array_map('intval', $_POST['selected_customers']);
    $placeholders = implode(',', array_fill(0, count($selected_ids), '?'));
    $types = str_repeat('i', count($selected_ids));

    $deleted_count = 0;
    $koneksi->begin_transaction();
    try {
        // Hapus pembayaran terkait
        $stmt_del_pembayaran = $koneksi->prepare("DELETE FROM pembayaran WHERE pelanggan_id IN ($placeholders)");
        call_user_func_array([$stmt_del_pembayaran, 'bind_param'], array_merge([$types], $selected_ids));
        if (!$stmt_del_pembayaran->execute()) {
            throw new Exception("Gagal menghapus riwayat pembayaran massal: " . $stmt_del_pembayaran->error);
        }
        $stmt_del_pembayaran->close();

        // Hapus tagihan terkait
        $stmt_del_tagihan = $koneksi->prepare("DELETE FROM tagihan WHERE pelanggan_id IN ($placeholders)");
        call_user_func_array([$stmt_del_tagihan, 'bind_param'], array_merge([$types], $selected_ids));
        if (!$stmt_del_tagihan->execute()) {
            throw new Exception("Gagal menghapus riwayat tagihan massal: " . $stmt_del_tagihan->error);
        }
        $stmt_del_tagihan->close();

        // Hapus pelanggan itu sendiri
        $stmt_del_pelanggan = $koneksi->prepare("DELETE FROM pelanggan WHERE id_pelanggan IN ($placeholders)");
        call_user_func_array([$stmt_del_pelanggan, 'bind_param'], array_merge([$types], $selected_ids));
        if (!$stmt_del_pelanggan->execute()) {
            throw new Exception("Gagal menghapus data pelanggan massal: " . $stmt_del_pelanggan->error);
        }
        $deleted_count = $stmt_del_pelanggan->affected_rows;
        $stmt_del_pelanggan->close();

        $koneksi->commit();
        logActivity('Delete', 'Menghapus massal ' . $deleted_count . ' pelanggan. IDs: ' . implode(', ', $selected_ids) . '.');
        header('Location: pelanggan?msg=mass_delete_success&count=' . $deleted_count);
        ob_end_clean();
        exit();
    } catch (Exception $e) {
        $koneksi->rollback();
        header('Location: pelanggan?msg=mass_delete_fail&err=' . urlencode($e->getMessage()));
        ob_end_clean();
        exit();
    }
}


// --- Logika Update Status Aktif Pelanggan (dari tombol) ---
if (isset($_GET['action']) && $_GET['action'] == 'update_status' && isset($_GET['id']) && isset($_GET['new_status'])) {
    $id_pelanggan_to_update = $koneksi->real_escape_string($_GET['id']);
    $new_status = $koneksi->real_escape_string($_GET['new_status']);

    // Hanya superadmin dan admin yang bisa mengubah status
    if (!hasRole(['superadmin', 'admin'])) {
        header('Location: pelanggan?msg=status_fail&err=' . urlencode("Anda tidak memiliki izin untuk mengubah status pelanggan."));
        ob_end_clean();
        exit();
    } else {
        // Validasi status yang diterima
        $allowed_statuses = ['Aktif', 'Tidak Aktif', 'Blokir'];
        if (!in_array($new_status, $allowed_statuses)) {
             header('Location: pelanggan?msg=status_fail&err=' . urlencode("Status tidak valid."));
             ob_end_clean();
             exit();
        }

        $stmt_update_status = $koneksi->prepare("UPDATE pelanggan SET status_aktif = ? WHERE id_pelanggan = ?");
        $stmt_update_status->bind_param("si", $new_status, $id_pelanggan_to_update);
        if ($stmt_update_status->execute()) {
            logActivity('Update', 'Mengubah status pelanggan ID ' . $id_pelanggan_to_update . ' menjadi ' . $new_status . '.');
            header('Location: pelanggan?msg=status_success&new_status=' . urlencode($new_status));
            ob_end_clean();
            exit();
        } else {
            header('Location: pelanggan?msg=status_fail&err=' . urlencode($stmt_update_status->error));
            ob_end_clean();
            exit();
        }
        $stmt_update_status->close();
    }
}


// --- Logika Tambah/Edit Pelanggan ---
if ($_SERVER['REQUEST_METHOD'] == 'POST' && (!isset($_POST['action']) || ($_POST['action'] != 'update_status' && $_POST['action'] != 'mass_delete'))) {
    // Ambil semua data dari POST di awal
    $nama_pelanggan = $koneksi->real_escape_string($_POST['nama_pelanggan']);
    $alamat = $koneksi->real_escape_string($_POST['alamat']);
    $telepon = $koneksi->real_escape_string($_POST['telepon']);
    $email = $koneksi->real_escape_string($_POST['email']);

    // START MODIFIKASI: Tetapkan email default unik jika kosong
    $is_email_unique = true; // Akan di-override jika ditemukan duplikat

    if (empty($email)) {
        if (empty($pelanggan_id)) {
            $email_temp_placeholder = 'no-reply-' . time() . rand(1000, 9999) . '@yourdomain.com';
            $email = $email_temp_placeholder;
        } else {
            $email = 'no-reply-' . $pelanggan_id . '@yourdomain.com';
        }
    }
    // END MODIFIKASI


    $paket_id = $koneksi->real_escape_string($_POST['paket_id']);
    $status_aktif = $koneksi->real_escape_string($_POST['status_aktif']);
    $tanggal_registrasi = $koneksi->real_escape_string($_POST['tanggal_registrasi']);
    $uses_ppn = $koneksi->real_escape_string($_POST['uses_ppn'] ?? '0');
    // NEW: Ambil nilai pelanggan_corporate
    $pelanggan_corporate = $koneksi->real_escape_string($_POST['pelanggan_corporate'] ?? '0');
    $pelanggan_id = $koneksi->real_escape_string($_POST['pelanggan_id'] ?? '');

    $sales_id = empty($_POST['sales_id']) ? NULL : (int)$_POST['sales_id'];
    $penagih_id = empty($_POST['penagih_id']) ? NULL : (int)$_POST['penagih_id'];

    // NEW: Validasi Email Unik Sebelum Operasi INSERT/UPDATE
    if (!empty($email) && $email !== 'no@reply.com' && !str_contains($email, 'no-reply-')) {
        $check_email_query = "SELECT COUNT(*) FROM pelanggan WHERE email = ?";
        if (!empty($pelanggan_id)) {
            $check_email_query .= " AND id_pelanggan != ?";
        }

        $stmt_check_email = $koneksi->prepare($check_email_query);
        if (!empty($pelanggan_id)) {
            $stmt_check_email->bind_param("si", $email, $pelanggan_id);
        } else {
            $stmt_check_email->bind_param("s", $email);
        }
        $stmt_check_email->execute();
        $stmt_check_email->bind_result($count_email);
        $stmt_check_email->fetch();
        $stmt_check_email->close();

        if ($count_email > 0) {
            $is_email_unique = false;
            $message_script = "showNotification('Gagal menyimpan data: Email &quot;" . htmlspecialchars($email, ENT_QUOTES, 'UTF-8') . "&quot; sudah digunakan oleh pelanggan lain. Silakan gunakan email yang berbeda.', 'error');";
        }
    }

    if ($is_email_unique) { // Lanjutkan proses INSERT/UPDATE hanya jika email unik atau kosong
        if (empty($pelanggan_id)) { // Tambah Pelanggan Baru
            // NEW: Tambahkan pelanggan_corporate ke query INSERT
            $stmt = $koneksi->prepare("INSERT INTO pelanggan (nama_pelanggan, alamat, telepon, email, sales_id, penagih_id, paket_id, status_aktif, tanggal_registrasi, uses_ppn, pelanggan_corporate) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");

            $dynamic_types = "";
            $dynamic_params = [];

            $dynamic_params[] = $nama_pelanggan; $dynamic_types .= "s";
            $dynamic_params[] = $alamat; $dynamic_types .= "s";
            $dynamic_params[] = $telepon; $dynamic_types .= "s";
            $dynamic_params[] = $email; $dynamic_types .= "s";

            if (is_null($sales_id)) { $dynamic_params[] = NULL; $dynamic_types .= "i"; } else { $dynamic_params[] = $sales_id; $dynamic_types .= "i"; }
            if (is_null($penagih_id)) { $dynamic_params[] = NULL; $dynamic_types .= "i"; } else { $dynamic_params[] = $penagih_id; $dynamic_types .= "i"; }

            $dynamic_params[] = $paket_id; $dynamic_types .= "i";
            $dynamic_params[] = $status_aktif; $dynamic_types .= "s";
            $dynamic_params[] = $tanggal_registrasi; $dynamic_types .= "s";
            $dynamic_params[] = $uses_ppn; $dynamic_types .= "i";
            $dynamic_params[] = $pelanggan_corporate; $dynamic_types .= "i"; // NEW: Add pelanggan_corporate


            $refs = [];
            foreach ($dynamic_params as $key => $value) {
                $refs[$key] = &$dynamic_params[$key];
            }
            call_user_func_array([$stmt, 'bind_param'], array_merge([$dynamic_types], $refs));

            if ($stmt->execute()) {
                $new_pelanggan_id = $koneksi->insert_id;
                // JIKA EMAIL TADI KOSONG, KITA PERBARUI DENGAN ID YANG BARU
                if (strpos($email, 'no-reply-') !== false && strpos($email, '@yourdomain.com') !== false) {
                    $final_placeholder_email = 'no-reply-' . $new_pelanggan_id . '@yourdomain.com';
                    $update_email_stmt = $koneksi->prepare("UPDATE pelanggan SET email = ? WHERE id_pelanggan = ?");
                    $update_email_stmt->bind_param("si", $final_placeholder_email, $new_pelanggan_id);
                    $update_email_stmt->execute();
                    $update_email_stmt->close();
                    logActivity('Update', 'Mengubah email placeholder pelanggan ID ' . $new_pelanggan_id . ' menjadi ' . $final_placeholder_email . '.');
                }
                logActivity('Create', 'Menambah pelanggan baru: ' . htmlspecialchars($nama_pelanggan) . '. ID: ' . $new_pelanggan_id);
                header('Location: pelanggan?msg=add_success');
                ob_end_clean();
                exit();
            } else {
                $message_script = "showNotification('Gagal menambahkan pelanggan: " . htmlspecialchars($stmt->error, ENT_QUOTES, 'UTF-8') . "', 'error');";
            }
        } else { // Edit Pelanggan
            // NEW: Tambahkan pelanggan_corporate ke query UPDATE
            $stmt = $koneksi->prepare("UPDATE pelanggan SET nama_pelanggan = ?, alamat = ?, telepon = ?, email = ?, sales_id = ?, penagih_id = ?, paket_id = ?, status_aktif = ?, tanggal_registrasi = ?, uses_ppn = ?, pelanggan_corporate = ? WHERE id_pelanggan = ?");

            $dynamic_types = "";
            $dynamic_params = [];

            $dynamic_params[] = $nama_pelanggan; $dynamic_types .= "s";
            $dynamic_params[] = $alamat; $dynamic_types .= "s";
            $dynamic_params[] = $telepon; $dynamic_types .= "s";
            $dynamic_params[] = $email; $dynamic_types .= "s";

            if (is_null($sales_id)) { $dynamic_params[] = NULL; $dynamic_types .= "i"; } else { $dynamic_params[] = $sales_id; $dynamic_types .= "i"; }
            if (is_null($penagih_id)) { $dynamic_params[] = NULL; $dynamic_types .= "i"; } else { $dynamic_params[] = $penagih_id; $dynamic_types .= "i"; }

            $dynamic_params[] = $paket_id; $dynamic_types .= "i";
            $dynamic_params[] = $status_aktif; $dynamic_types .= "s";
            $dynamic_params[] = $tanggal_registrasi; $dynamic_types .= "s";
            $dynamic_params[] = $uses_ppn; $dynamic_types .= "i";
            $dynamic_params[] = $pelanggan_corporate; $dynamic_types .= "i"; // NEW: Add pelanggan_corporate

            $dynamic_params[] = $pelanggan_id; $dynamic_types .= "i";


            $refs = [];
            foreach ($dynamic_params as $key => $value) {
                $refs[$key] = &$dynamic_params[$key];
            }
            call_user_func_array([$stmt, 'bind_param'], array_merge([$dynamic_types], $refs));

            logActivity('Update', 'Mengubah data pelanggan ID ' . $pelanggan_id . ': ' . htmlspecialchars($nama_pelanggan) . '.');

            if ($stmt->execute()) {
                header('Location: pelanggan?msg=edit_success');
                ob_end_clean();
                exit();
            } else {
                $message_script = "showNotification('Gagal memperbarui pelanggan: " . htmlspecialchars($stmt->error, ENT_QUOTES, 'UTF-8') . "', 'error');";
            }
        }
        if (isset($stmt) && $stmt instanceof mysqli_stmt) {
            $stmt->close();
        }
    } // End if ($is_email_unique)
}

// --- Logika Ambil Data Untuk Form Edit ---
if (isset($_GET['action']) && $_GET['action'] == 'edit' && isset($_GET['id'])) {
    $pelanggan_id_to_edit = $koneksi->real_escape_string($_GET['id']);
    // NEW: Ambil pelanggan_corporate
    $query_edit = $koneksi->query("SELECT *, uses_ppn, sales_id, penagih_id, pelanggan_corporate FROM pelanggan WHERE id_pelanggan = '$pelanggan_id_to_edit'");
    if ($query_edit->num_rows > 0) {
        $pelanggan_data = $query_edit->fetch_assoc();
    } else {
        $message_script = "showNotification('Data pelanggan tidak ditemukan.', 'error');";
        $pelanggan_id_to_edit = null;
    }
    $form_should_be_visible = true;
} else {
    $form_should_be_visible = false;
}

// Ambil semua data paket untuk dropdown
$query_paket_options = "SELECT id_paket, nama_paket, kecepatan FROM paket_layanan ORDER BY nama_paket ASC";
$result_paket_options = $koneksi->query($query_paket_options);

// Ambil semua data sales untuk dropdown
$query_sales_options = "SELECT id_sales, nama_sales FROM sales WHERE status_aktif = 'Aktif' ORDER BY nama_sales ASC";
$result_sales_options = $koneksi->query($query_sales_options);

// NEW: Ambil semua data penagih untuk dropdown
$query_penagih_options = "SELECT id_penagih, nama_penagih FROM penagih WHERE status_aktif = 'Aktif' ORDER BY nama_penagih ASC";
$result_penagih_options = $koneksi->query($query_penagih_options);


// --- Logika Pencarian, Filter, dan Pengurutan Pelanggan ---
$search_query = $_GET['search'] ?? '';
$filter_status_aktif_dropdown = $_GET['status_aktif_dropdown'] ?? '';
$filter_corporate_dropdown = $_GET['filter_corporate_dropdown'] ?? ''; // NEW: Ambil filter corporate

// New: Sorting parameters
$sort_column = $_GET['sort_column'] ?? 'p.nama_pelanggan';
$sort_order = $_GET['sort_order'] ?? 'ASC';

// Validasi sort column to prevent SQL injection
$allowed_sort_columns = [
    'p.id_pelanggan',
    'p.nama_pelanggan',
    'p.alamat',
    'p.telepon',
    's.nama_sales',
    'coll.nama_penagih',
    'pk.nama_paket',
    'p.status_aktif',
    'status_tagihan_bulan_ini',
    'tanggal_pembayaran_terakhir',
    'p.tanggal_registrasi',
    'p.pelanggan_corporate' // Tambahkan ini
];
if (!in_array($sort_column, $allowed_sort_columns)) {
    $sort_column = 'p.nama_pelanggan';
}

// Validasi sort order
if (!in_array(strtoupper($sort_order), ['ASC', 'DESC'])) {
    $sort_order = 'ASC';
}

$where_clauses_pelanggan = [];
$params_pelanggan = [];
$param_types_pelanggan = "";

if (!empty($search_query)) {
    $search_term = '%' . $search_query . '%';
    $where_clauses_pelanggan[] = "(p.nama_pelanggan LIKE ? OR p.alamat LIKE ? OR p.telepon LIKE ? OR p.email LIKE ? OR p.id_pelanggan LIKE ?)";
    $params_pelanggan[] = $search_term;
    $params_pelanggan[] = $search_term;
    $params_pelanggan[] = $search_term;
    $params_pelanggan[] = $search_term;
    $params_pelanggan[] = $search_term;
    $param_types_pelanggan .= "sssss";
}

// Tambahkan filter status aktif dari dropdown atau dari dashboard
if (!empty($filter_status_aktif_dropdown)) {
    $where_clauses_pelanggan[] = "p.status_aktif = ?";
    $params_pelanggan[] = $filter_status_aktif_dropdown;
    $param_types_pelanggan .= "s";
} else if (isset($_GET['status_aktif']) && $_GET['status_aktif'] != '') {
    $dashboard_status = $_GET['status_aktif'];
    $where_clauses_pelanggan[] = "p.status_aktif = ?";
    $params_pelanggan[] = $dashboard_status;
    $param_types_pelanggan .= "s";
    $filter_status_aktif_dropdown = $dashboard_status;
}

// NEW: Tambahkan filter pelanggan corporate
if ($filter_corporate_dropdown !== '') {
    $where_clauses_pelanggan[] = "p.pelanggan_corporate = ?";
    $params_pelanggan[] = (int)$filter_corporate_dropdown;
    $param_types_pelanggan .= "i";
}


$final_where_clause_pelanggan = count($where_clauses_pelanggan) > 0 ? " WHERE " . implode(" AND ", $where_clauses_pelanggan) : "";

// --- LOGIKA PAGINASI: Ambil TOTAL data tanpa LIMIT untuk menghitung total halaman ---
$query_count_pelanggan = "
    SELECT COUNT(*) AS total_records
    FROM pelanggan p
    JOIN paket_layanan pk ON p.paket_id = pk.id_paket
    LEFT JOIN sales s ON p.sales_id = s.id_sales
    LEFT JOIN penagih coll ON p.penagih_id = coll.id_penagih
    " . $final_where_clause_pelanggan;

$stmt_count = $koneksi->prepare($query_count_pelanggan);
if ($stmt_count === false) {
    die('Prepare count failed: ' . htmlspecialchars($koneksi->error));
}

// Bind parameter untuk query hitung total data
if (count($params_pelanggan) > 0) {
    $refs_count = [];
    foreach ($params_pelanggan as $key => $value) {
        $refs_count[$key] = &$params_pelanggan[$key];
    }
    call_user_func_array([$stmt_count, 'bind_param'], array_merge([$param_types_pelanggan], $refs_count));
}

$stmt_count->execute();
$total_records_result = $stmt_count->get_result()->fetch_assoc();
$total_records = $total_records_result['total_records'];
$stmt_count->close();

$total_pages = ceil($total_records / $per_page);

// Pastikan current_page tidak melebihi total_pages (jika filter/search membuat total_records berubah)
if ($current_page > $total_pages && $total_pages > 0) {
    $current_page = $total_pages;
    $offset = ($current_page - 1) * $per_page;
} elseif ($total_pages == 0) {
    $current_page = 1;
    $offset = 0;
}


// Ambil semua data pelanggan untuk ditampilkan (dengan LIMIT dan OFFSET)
$query_pelanggan_list = "
    SELECT
        p.*,
        pk.nama_paket,
        pk.kecepatan,
        coll.nama_penagih,
        (SELECT t.status_tagihan
           FROM tagihan t
           WHERE t.pelanggan_id = p.id_pelanggan
             AND t.bulan_tagihan = ?
           LIMIT 1) AS status_tagihan_bulan_ini,
        (SELECT py.tanggal_bayar
           FROM pembayaran py
           WHERE py.pelanggan_id = p.id_pelanggan
           ORDER BY py.tanggal_bayar DESC
           LIMIT 1) AS tanggal_pembayaran_terakhir
    FROM
        pelanggan p
    JOIN
        paket_layanan pk ON p.paket_id = pk.id_paket
    LEFT JOIN sales s ON p.sales_id = s.id_sales
    LEFT JOIN penagih coll ON p.penagih_id = coll.id_penagih
    " . $final_where_clause_pelanggan .
    " ORDER BY " . $sort_column . " " . $sort_order .
    " LIMIT ? OFFSET ?";

// Siapkan parameter untuk query utama (termasuk bulan_tagihan untuk subquery, LIMIT, dan OFFSET)
$all_params_for_list_query = [$current_month_year];
$all_param_types_for_list_query = "s";

// Gabungkan parameter pencarian/filter (jika ada)
if (!empty($params_pelanggan)) {
    $all_params_for_list_query = array_merge($all_params_for_list_query, $params_pelanggan);
    $all_param_types_for_list_query .= $param_types_pelanggan;
}

// Tambahkan parameter LIMIT dan OFFSET
$all_params_for_list_query[] = $per_page;
$all_params_for_list_query[] = $offset;
$all_param_types_for_list_query .= "ii";

// Gunakan prepared statement untuk query utama
$stmt_pelanggan_list = $koneksi->prepare($query_pelanggan_list);
if ($stmt_pelanggan_list === false) {
    die('Prepare failed: ' . htmlspecialchars($koneksi->error));
}

// Hanya bind parameter jika ada. Penting untuk kasus tanpa parameter filter.
if (count($all_params_for_list_query) > 0) {
    // Menggunakan call_user_func_array untuk bind_param dengan argumen dinamis
    $refs = [];
    foreach ($all_params_for_list_query as $key => $value) {
        $refs[$key] = &$all_params_for_list_query[$key];
    }
    call_user_func_array([$stmt_pelanggan_list, 'bind_param'], array_merge([$all_param_types_for_list_query], $refs));
}

$stmt_pelanggan_list->execute();
$result_pelanggan_list = $stmt_pelanggan_list->get_result();
$stmt_pelanggan_list->close();

// Tutup blok PHP di sini sebelum mulai HTML
?>

<style>
    /* NEW: Styles for the Action Menu Modal */
    .action-menu-modal-overlay {
        position: fixed;
        top: 0;
        left: 0;
        width: 100%;
        height: 100%;
        background-color: rgba(0, 0, 0, 0.6);
        display: flex;
        justify-content: center;
        align-items: center;
        z-index: 2000; /* Higher than other modals like customConfirmModal (1000) */
        opacity: 0;
        visibility: hidden;
        transition: opacity 0.3s ease, visibility 0.3s ease;
    }

    .action-menu-modal-overlay.show {
        opacity: 1;
        visibility: visible;
    }

    .action-menu-modal-content {
        background-color: var(--tznpisp-card-bg); /* Use theme variable */
        padding: 25px;
        border-radius: 8px;
        box-shadow: 0 5px 15px rgba(0, 0, 0, 0.4);
        text-align: center;
        max-width: 350px;
        width: 90%;
        color: var(--tznpisp-text-light); /* Use theme variable */
        transform: translateY(-20px);
        transition: transform 0.3s ease;
        position: relative; /* Needed for close button positioning */
    }

    .action-menu-modal-overlay.show .action-menu-modal-content {
        transform: translateY(0);
    }

    .action-menu-modal-content h3 {
        margin-top: 0;
        margin-bottom: 20px;
        color: var(--tznpisp-text-light); /* Use theme variable */
        font-size: 1.2em;
    }

    .action-menu-modal-content .close-button-modal {
        position: absolute;
        top: 10px;
        right: 15px;
        font-size: 24px;
        color: var(--tznpisp-text-muted);
        cursor: pointer;
        transition: color 0.2s ease;
    }
    .action-menu-modal-content .close-button-modal:hover {
        color: var(--tznpisp-primary-blue); /* Use theme variable */
    }

    .action-menu-list {
        display: flex;
        flex-direction: column; /* Stack buttons vertically */
        gap: 10px; /* Space between buttons */
    }

    .action-menu-list .btn-action-modal {
        display: flex; /* Make buttons flex items */
        align-items: center;
        justify-content: flex-start; /* Align text to left */
        padding: 10px 15px;
        border-radius: 6px;
        font-size: 0.95em;
        text-decoration: none;
        color: var(--tznpisp-text-light);
        background-color: var(--tznpisp-sidebar-bg); /* Slightly darker background for buttons */
        border: 1px solid var(--tznpisp-border-color);
        transition: background-color 0.2s ease, color 0.2s ease, border-color 0.2s ease;
    }

    .action-menu-list .btn-action-modal i {
        margin-right: 10px;
        color: var(--tznpisp-text-muted); /* Icon color */
        font-size: 1.1em;
        transition: color 0.2s ease;
    }

    .action-menu-list .btn-action-modal:hover {
        background-color: var(--tznpisp-active-menu-bg); /* Hover background */
        color: var(--tznpisp-primary-blue); /* Hover text color */
        border-color: var(--tznpisp-primary-blue);
    }
    .action-menu-list .btn-action-modal:hover i {
        color: var(--tznpisp-primary-blue); /* Hover icon color */
    }

    /* Specific colors for action buttons (optional) */
    .action-menu-list .btn-action-modal.delete-modal {
        color: var(--tznpisp-accent-red);
    }
    .action-menu-list .btn-action-modal.delete-modal:hover {
        background-color: rgba(255, 23, 68, 0.1);
    }
    .action-menu-list .btn-action-modal.warning-modal {
        color: var(--tznpisp-accent-orange);
    }
    .action-menu-list .btn-action-modal.warning-modal:hover {
        background-color: rgba(255, 152, 0, 0.1);
    }
    .action-menu-list .btn-action-modal.success-modal {
        color: var(--tznpisp-accent-green);
    }
    .action-menu-list .btn-action-modal.success-modal:hover {
        background-color: rgba(0, 200, 83, 0.1);
    }
    .action-menu-list .btn-action-modal.info-modal {
        color: var(--tznpisp-primary-blue);
    }
    .action-menu-list .btn-action-modal.info-modal:hover {
        background-color: rgba(34, 150, 243, 0.1);
    }

    /* END NEW MODAL STYLES */

    /* Existing Styles */
    .hide-form {
        display: none;
        visibility: hidden;
        height: 0;
        overflow: hidden;
    }
    /* Untuk menyembunyikan kelompok tombol aksi */
    .hide-group {
        display: none !important; /* Ditambahkan !important */
        visibility: hidden !important; /* Ditambahkan !important */
        height: 0 !important; /* Ditambahkan !important */
        overflow: hidden !important; /* Ditambahkan !important */
    }
    /* Opsional: Untuk membuat tampilan tombol aksi lebih rapi jika banyak */
    .action-buttons-group {
        display: flex; /* Menggunakan flexbox untuk tata letak horizontal */
        flex-wrap: wrap; /* Memungkinkan tombol untuk wrap ke baris berikutnya jika tidak muat */
        gap: 5px; /* Memberikan sedikit jarak antar tombol */
        margin-top: 5px; /* Sedikit jarak dari tombol toggle */
    }
    /* Jika Anda ingin tombol aksi per baris juga memiliki gaya yang sama */
    .data-table td .btn-action {
        margin-bottom: 5px; /* Atau sesuaikan sesuai kebutuhan */
    }

    /* Gaya untuk Custom Modal (old/general confirm modal) */
    .custom-modal-overlay {
        position: fixed;
        top: 0;
        left: 0;
        width: 100%;
        height: 100%;
        background-color: rgba(0, 0, 0, 0.5);
        display: flex;
        justify-content: center;
        align-items: center;
        z-index: 2000; /* Pastikan di atas elemen lain */
        opacity: 0;
        visibility: hidden;
        transition: opacity 0.3s ease, visibility 0.3s ease;
    }

    .custom-modal-overlay.show {
        opacity: 1;
        visibility: visible;
    }

    .custom-modal-content {
        background-color: #fff;
        padding: 30px;
        border-radius: 8px;
        box-shadow: 0 5px 15px rgba(0, 0, 0, 0.3);
        text-align: center;
        max-width: 400px;
        width: 90%;
        transform: translateY(-20px);
        transition: transform 0.3s ease;
    }

    .custom-modal-overlay.show .custom-modal-content {
        transform: translateY(0);
    }

    .custom-modal-content h3 {
        margin-top: 0;
        margin-bottom: 20px;
        color: #333;
    }

    .custom-modal-buttons {
        display: flex;
        justify-content: center;
        gap: 15px;
        margin-top: 25px;
    }

    .custom-modal-buttons .btn {
        padding: 10px 25px;
        border-radius: 5px;
        cursor: pointer;
        font-size: 1em;
        border: none;
        transition: background-color 0.2s ease;
    }

    .custom-modal-buttons .btn-confirm {
        background-color: #dc3545; /* Merah untuk konfirmasi aksi berbahaya */
        color: #fff;
    }

    .custom-modal-buttons .btn-confirm:hover {
        background-color: #c82333;
    }

    .custom-modal-buttons .btn-cancel {
        background-color: #6c757d; /* Abu-abu untuk batal */
        color: #fff;
    }

    .custom-modal-buttons .btn-cancel:hover {
        background-color: #5a6268;
    }

    /* Column Resizing Styles */
    .data-table {
        overflow-x: auto; /* Allow horizontal scroll if table is wider than container */
        table-layout: fixed; /* Added to ensure consistent column sizing */
    }
    .data-table th,
    .data-table td {
        overflow: hidden; /* Ensure content is hidden if it overflows */
        white-space: nowrap; /* Prevent text from wrapping */
        text-overflow: ellipsis; /* Display ellipsis for overflowing text */
    }
    .data-table th.resizable-column {
        position: relative; /* Crucial for resizer positioning */
    }
    .resizer {
        position: absolute;
        right: 0;
        top: 0;
        width: 5px; /* Width of the clickable area for resizing */
        height: 100%;
        cursor: col-resize;
        user-select: none;
        /* background: rgba(0, 0, 0, 0.1);  Uncomment for visual debugging of resizer area */
    }
    .resizer:hover {
        background: rgba(0, 0, 0, 0.3); /* Visual feedback on hover */
    }
    /* Add this class to the table during resizing to prevent text selection */
    .data-table.resizing {
        cursor: col-resize;
        user-select: none;
    }

    /* Centering for status badges */
    .data-table td .status-badge {
        display: block; /* Make it a block element to allow text-align */
        margin: 0 auto; /* Center horizontally */
        width: fit-content; /* Adjust width to content */
    }

</style>

<div class="main-content">
    <div class="top-header">
        <div class="alert-message">
            Pemberitahuan: Manajemen pelanggan adalah inti dari bisnis Anda.
        </div>
        <div class="welcome-message">
            <span>Selamat datang, <?php echo htmlspecialchars($_SESSION['username'] ?? 'User'); ?>!</span>
            <a href="../logout.php" class="btn-logout">Logout</a>
        </div>
    </div>

    <div class="container">
        <h2>Manajemen Pelanggan</h2>

        <button id="toggleFormBtn" class="btn btn-primary" style="margin-bottom: 20px;">
            <?php echo ($pelanggan_id_to_edit ? 'Kembali ke Form Edit' : 'Tambah Pelanggan Baru'); ?>
        </button>

        <div id="formPelangganCard" class="card <?php echo $form_should_be_visible ? '' : 'hide-form'; ?>" style="margin-bottom: 20px;">
            <div class="card-header">
                <h3><?php echo ($pelanggan_id_to_edit ? 'Edit' : 'Tambah'); ?> Pelanggan</h3>
            </div>
            <div class="card-body">
                <form method="POST"><?php if (!isset($_SESSION['csrf_token'])) { $_SESSION['csrf_token'] = bin2hex(random_bytes(32)); } ?><input type='hidden' name='csrf_token' value='<?php echo $_SESSION['csrf_token']; ?>'>
                    <?php if ($pelanggan_id_to_edit): ?>
                        <input type="hidden" name="pelanggan_id" value="<?php echo htmlspecialchars($pelanggan_data['id_pelanggan']); ?>">
                    <?php endif; ?>
                    <div class="form-group">
                        <label for="nama_pelanggan">Nama Pelanggan:</label>
                        <input type="text" id="nama_pelanggan" name="nama_pelanggan" value="<?php echo htmlspecialchars($pelanggan_data['nama_pelanggan'] ?? ''); ?>" required>
                    </div>
                    <div class="form-group">
                        <label for="alamat">Alamat:</label>
                        <textarea id="alamat" name="alamat" required><?php echo htmlspecialchars($pelanggan_data['alamat'] ?? ''); ?></textarea>
                    </div>
                    <div class="form-group">
                        <label for="telepon">Telepon:</label>
                        <input type="text" id="telepon" name="telepon" value="<?php echo htmlspecialchars($pelanggan_data['telepon'] ?? ''); ?>">
                    </div>
                    <div class="form-group">
                        <label for="email">Email (Opsional):</label>
                        <input type="email" id="email" name="email" value="<?php echo htmlspecialchars($pelanggan_data['email'] ?? ''); ?>">
                    </div>
                    <div class="form-group">
                        <label for="sales_id">Sales:</label>
                        <select id="sales_id" name="sales_id">
                            <option value="">-- Pilih Sales (Opsional) --</option>
                            <?php
                            if ($result_sales_options->num_rows > 0) {
                                $result_sales_options->data_seek(0); // Reset pointer
                            }
                            while($row_sales = $result_sales_options->fetch_assoc()): ?>
                                <option value="<?php echo htmlspecialchars($row_sales['id_sales']); ?>"
                                        <?php echo (isset($pelanggan_data['sales_id']) && $pelanggan_data['sales_id'] == $row_sales['id_sales']) ? 'selected' : ''; ?>>
                                        <?php echo htmlspecialchars($row_sales['nama_sales']); ?>
                                </option>
                            <?php endwhile; ?>
                        </select>
                    </div>
                    <div class="form-group">
                        <label for="penagih_id">Nama Penagih:</label>
                        <select id="penagih_id" name="penagih_id">
                            <option value="">-- Pilih Penagih (Opsional) --</option>
                            <?php
                            if ($result_penagih_options->num_rows > 0) {
                                $result_penagih_options->data_seek(0); // Reset pointer
                            }
                            while($row_penagih = $result_penagih_options->fetch_assoc()): ?>
                                <option value="<?php echo htmlspecialchars($row_penagih['id_penagih']); ?>"
                                        <?php echo (isset($pelanggan_data['penagih_id']) && $pelanggan_data['penagih_id'] == $row_penagih['id_penagih']) ? 'selected' : ''; ?>>
                                        <?php echo htmlspecialchars($row_penagih['nama_penagih']); ?>
                                </option>
                            <?php endwhile; ?>
                        </select>
                    </div>
                    <div class="form-group">
                        <label for="paket_id">Paket Layanan:</label>
                        <select id="paket_id" name="paket_id" required>
                            <option value="">Pilih Paket</option>
                            <?php
                            if ($result_paket_options->num_rows > 0) {
                                $result_paket_options->data_seek(0); // Reset pointer
                            }
                            while($row_paket = $result_paket_options->fetch_assoc()): ?>
                                <option value="<?php echo htmlspecialchars($row_paket['id_paket']); ?>"
                                    <?php echo (isset($pelanggan_data['paket_id']) && $pelanggan_data['paket_id'] == $row_paket['id_paket']) ? 'selected' : ''; ?>>
                                    <?php echo htmlspecialchars($row_paket['nama_paket'] . ' (' . $row_paket['kecepatan'] . ')'); ?>
                                </option>
                            <?php endwhile; ?>
                        </select>
                    </div>
                    <div class="form-group">
                        <label for="status_aktif">Status Aktif:</label>
                        <select id="status_aktif" name="status_aktif" required>
                            <option value="Aktif" <?php echo (isset($pelanggan_data['status_aktif']) && $pelanggan_data['status_aktif'] == 'Aktif') ? 'selected' : ''; ?>>Aktif</option>
                            <option value="Tidak Aktif" <?php echo (isset($pelanggan_data['status_aktif']) && $pelanggan_data['status_aktif'] == 'Tidak Aktif') ? 'selected' : ''; ?>>Tidak Aktif</option>
                            <option value="Blokir" <?php echo (isset($pelanggan_data['status_aktif']) && $pelanggan_data['status_aktif'] == 'Blokir') ? 'selected' : ''; ?>>Blokir</option>
                        </select>
                    </div>
                    <div class="form-group">
                        <label for="uses_ppn">Kenakan PPN 11%:</label>
                        <select id="uses_ppn" name="uses_ppn" required>
                            <option value="0" <?php echo (isset($pelanggan_data['uses_ppn']) && $pelanggan_data['uses_ppn'] == '0') ? 'selected' : ''; ?>>Tidak</option>
                            <option value="1" <?php echo (isset($pelanggan_data['uses_ppn']) && $pelanggan_data['uses_ppn'] == '1') ? 'selected' : ''; ?>>Ya</option>
                        </select>
                    </div>
                    <div class="form-group">
                        <label for="pelanggan_corporate">Pelanggan Corporate:</label>
                        <select id="pelanggan_corporate" name="pelanggan_corporate" required>
                            <option value="0" <?php echo (isset($pelanggan_data['pelanggan_corporate']) && $pelanggan_data['pelanggan_corporate'] == '0') ? 'selected' : ''; ?>>Tidak</option>
                            <option value="1" <?php echo (isset($pelanggan_data['pelanggan_corporate']) && $pelanggan_data['pelanggan_corporate'] == '1') ? 'selected' : ''; ?>>Ya</option>
                        </select>
                    </div>
                    <div class="form-group">
                        <label for="tanggal_registrasi">Tanggal Registrasi:</label>
                        <input type="date" id="tanggal_registrasi" name="tanggal_registrasi" 
                               value="<?php 
                                   // Pastikan tanggal diformat keYYYY-MM-DD agar ditampilkan dengan benar di input type="date"
                                   echo htmlspecialchars(isset($pelanggan_data['tanggal_registrasi']) && !empty($pelanggan_data['tanggal_registrasi']) ? date('Y-m-d', strtotime($pelanggan_data['tanggal_registrasi'])) : date('Y-m-d')); 
                               ?>" required>
                    </div>
                    <?php
                        // AWAL BLOK TANGGAL BERAKHIR YANG DIHILANGKAN
                        /*
                        <div class="form-group">
                            <label for="tanggal_berakhir">Tanggal Berakhir (Opsional):</label>
                            <input type="date" id="tanggal_berakhir" name="tanggal_berakhir" 
                                   value="<?php 
                                       // Pastikan tanggal diformat keYYYY-MM-DD atau kosong jika NULL
                                       echo htmlspecialchars(isset($pelanggan_data['tanggal_berakhir']) && !empty($pelanggan_data['tanggal_berakhir']) ? date('Y-m-d', strtotime($pelanggan_data['tanggal_berakhir'])) : ''); 
                                   ?>">
                        </div>
                        */
                        // AKHIR BLOK TANGGAL BERAKSIR YANG DIHILANGKAN
                    ?>
                    <button type="submit" class="btn btn-primary"><?php echo ($pelanggan_id_to_edit ? 'Update' : 'Tambah'); ?> Pelanggan</button>
                    <?php if ($pelanggan_id_to_edit): ?>
                        <a href="pelanggan" class="btn btn-secondary">Batal Edit</a>
                    <?php endif; ?>
                </form>
            </div>
        </div>

        <div class="card">
            <div class="card-header">
                <h3>Daftar Pelanggan</h3>
                <div class="search-form-group">
                    <form method="GET" action="pelanggan" style="display: flex; flex-wrap: wrap; gap: 10px; align-items: flex-end;">
                        <input type="text" name="search" placeholder="Cari pelanggan..." value="<?php echo htmlspecialchars($search_query); ?>" style="flex: 1; min-width: 150px;">
                        <select name="status_aktif_dropdown" style="flex: 0 0 auto;">
                            <option value="">Semua Status</option>
                            <option value="Aktif" <?php echo ($filter_status_aktif_dropdown == 'Aktif') ? 'selected' : ''; ?>>Aktif</option>
                            <option value="Tidak Aktif" <?php echo ($filter_status_aktif_dropdown == 'Tidak Aktif') ? 'selected' : ''; ?>>Tidak Aktif</option>
                            <option value="Blokir" <?php echo ($filter_status_aktif_dropdown == 'Blokir') ? 'selected' : ''; ?>>Blokir</option>
                        </select>
                        <select name="filter_corporate_dropdown" style="flex: 0 0 auto;">
                            <option value="">Semua Pelanggan</option>
                            <option value="1" <?php echo ($filter_corporate_dropdown == '1') ? 'selected' : ''; ?>>Hanya Corporate</option>
                            <option value="0" <?php echo ($filter_corporate_dropdown == '0') ? 'selected' : ''; ?>>Bukan Corporate</option>
                        </select>
                        <button type="submit" class="btn btn-primary btn-sm"><i class="fas fa-filter"></i> Filter</button>
                        <?php if (!empty($search_query) || !empty($filter_status_aktif_dropdown) || !empty($filter_corporate_dropdown) || (isset($_GET['status_aktif']) && $_GET['status_aktif'] != '') ): ?>
                            <a href="pelanggan" class="btn btn-secondary btn-sm"><i class="fas fa-redo"></i> Reset</a>
                        <?php endif; ?>
                        
                        <div style="margin-left: auto; display: flex; align-items: center; gap: 5px;">
                            <label for="per_page" style="white-space: nowrap; margin-bottom: 0;">Baris per halaman:</label>
                            <select id="per_page" name="per_page" onchange="this.form.submit()" style="padding: 6px; border-radius: 4px; border: 1px solid #ddd;">
                                <?php foreach ($per_page_options as $option): ?>
                                    <option value="<?php echo htmlspecialchars($option, ENT_QUOTES, "UTF-8"); ?>" <?php echo ($per_page == $option) ? 'selected' : ''; ?>><?php echo htmlspecialchars($option, ENT_QUOTES, "UTF-8"); ?></option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                    </form>
                </div>
            </div>
            <div class="card-body">
                <?php if (hasRole('superadmin')): ?>
                <div style="margin-bottom: 15px;">
                    <button id="massDeleteBtn" class="btn btn-danger" disabled><i class="fas fa-trash-alt"></i> Hapus Terpilih (<span id="selectedCount">0</span>)</button>
                </div>
                <?php endif; ?>

                <div class="pagination-controls" style="margin-bottom: 15px;">
                    <div>
                        Menampilkan <?php echo htmlspecialchars(min($total_records, $offset + 1), ENT_QUOTES, "UTF-8"); ?> - <?php echo htmlspecialchars(min($total_records, $offset + $per_page), ENT_QUOTES, "UTF-8"); ?> dari <?php echo htmlspecialchars($total_records, ENT_QUOTES, "UTF-8"); ?> data.
                    </div>
                    <ul class="pagination" style="margin: 0;">
                        <?php if ($current_page > 1): ?>
                            <li class="page-item"><a class="page-link" href="?<?php echo htmlspecialchars(http_build_query(array_merge($_GET, ['page' => 1]))); ?>">First</a></li>
                            <li class="page-item"><a class="page-link" href="?<?php echo htmlspecialchars(http_build_query(array_merge($_GET, ['page' => $current_page - 1]))); ?>">Previous</a></li>
                        <?php endif; ?>

                        <?php
                        $start_page = max(1, $current_page - 2);
                        $end_page = min($total_pages, $current_page + 2);

                        if ($start_page > 1) {
                            echo '<li class="page-item disabled"><span class="page-link">...</span></li>';
                        }
                        for ($i = $start_page; $i <= $end_page; $i++): ?>
                            <li class="page-item <?php echo ($i == $current_page) ? 'active' : ''; ?>"><a class="page-link" href="?<?php echo htmlspecialchars(http_build_query(array_merge($_GET, ['page' => $i]))); ?>"><?php echo htmlspecialchars($i, ENT_QUOTES, "UTF-8"); ?></a></li>
                        <?php endfor; ?>

                        <?php
                        if ($end_page < $total_pages) {
                            echo '<li class="page-item disabled"><span class="page-link">...</span></li>';
                        }
                        ?>

                        <?php if ($current_page < $total_pages): ?>
                            <li class="page-item"><a class="page-link" href="?<?php echo htmlspecialchars(http_build_query(array_merge($_GET, ['page' => $current_page + 1]))); ?>">Next</a></li>
                            <li class="page-item"><a class="page-link" href="?<?php echo htmlspecialchars(http_build_query(array_merge($_GET, ['page' => $total_pages]))); ?>">Last</a></li>
                        <?php endif; ?>
                    </ul>
                </div>
                <form id="massDeleteForm" method="POST" action="pelanggan" onsubmit="return confirm('Apakah Anda yakin ingin menghapus pelanggan yang terpilih ini? Aksi ini tidak dapat dibatalkan.');"><?php if (!isset($_SESSION['csrf_token'])) { $_SESSION['csrf_token'] = bin2hex(random_bytes(32)); } ?><input type='hidden' name='csrf_token' value='<?php echo $_SESSION['csrf_token']; ?>'>
                    <input type="hidden" name="action" value="mass_delete">
                    <table class="data-table" style="width: 100%; border-collapse: collapse;">
                        <thead>
                            <tr>
                                <?php if (hasRole('superadmin')): ?>
                                <th style="width: 20px;"><input type="checkbox" id="selectAllCustomers"></th>
                                <?php endif; ?>
                                <th class="resizable-column" style="width: 50px;"><a href="?<?php echo htmlspecialchars(http_build_query(array_merge($_GET, ['sort_column' => 'p.id_pelanggan', 'sort_order' => ($sort_column == 'p.id_pelanggan' && $sort_order == 'ASC') ? 'DESC' : 'ASC']))); ?>">ID <?php if ($sort_column == 'p.id_pelanggan') echo ($sort_order == 'ASC' ? '&#9650;' : '&#9660;'); ?></a></th>
                                <th class="resizable-column" style="width: 150px;"><a href="?<?php echo htmlspecialchars(http_build_query(array_merge($_GET, ['sort_column' => 'p.nama_pelanggan', 'sort_order' => ($sort_column == 'p.nama_pelanggan' && $sort_order == 'ASC') ? 'DESC' : 'ASC']))); ?>">Nama <?php if ($sort_column == 'p.nama_pelanggan') echo ($sort_order == 'ASC' ? '&#9650;' : '&#9660;'); ?></a></th>
                                <th class="resizable-column"><a href="?<?php echo htmlspecialchars(http_build_query(array_merge($_GET, ['sort_column' => 'p.alamat', 'sort_order' => ($sort_column == 'p.alamat' && $sort_order == 'ASC') ? 'DESC' : 'ASC']))); ?>">Alamat <?php if ($sort_column == 'p.alamat') echo ($sort_order == 'ASC' ? '&#9650;' : '&#9660;'); ?></a></th>
                                <th class="resizable-column" style="width: 100px;"><a href="?<?php echo htmlspecialchars(http_build_query(array_merge($_GET, ['sort_column' => 'p.telepon', 'sort_order' => ($sort_column == 'p.telepon' && $sort_order == 'ASC') ? 'DESC' : 'ASC']))); ?>">Telepon <?php if ($sort_column == 'p.telepon') echo ($sort_order == 'ASC' ? '&#9650;' : '&#9660;'); ?></a></th>
                                <th class="resizable-column" style="width: 100px;"><a href="?<?php echo htmlspecialchars(http_build_query(array_merge($_GET, ['sort_column' => 'coll.nama_penagih', 'sort_order' => ($sort_column == 'coll.nama_penagih' && $sort_order == 'ASC') ? 'DESC' : 'ASC']))); ?>">Penagih <?php if ($sort_column == 'coll.nama_penagih') echo ($sort_order == 'ASC' ? '&#9650;' : '&#9660;'); ?></a></th>
                                <th class="resizable-column" style="width: 100px;"><a href="?<?php echo htmlspecialchars(http_build_query(array_merge($_GET, ['sort_column' => 'pk.nama_paket', 'sort_order' => ($sort_column == 'pk.nama_paket' && $sort_order == 'ASC') ? 'DESC' : 'ASC']))); ?>">Paket <?php if ($sort_column == 'pk.nama_paket') echo ($sort_order == 'ASC' ? '&#9650;' : '&#9660;'); ?></a></th>
                                <th class="resizable-column" style="width: 100px;"><a href="?<?php echo htmlspecialchars(http_build_query(array_merge($_GET, ['sort_column' => 'p.status_aktif', 'sort_order' => ($sort_column == 'p.status_aktif' && $sort_order == 'ASC') ? 'DESC' : 'ASC']))); ?>">Status Akun <?php if ($sort_column == 'p.status_aktif') echo ($sort_order == 'ASC' ? '&#9650;' : '&#9660;'); ?></a></th>
                                <th class="resizable-column" style="width: 120px;"><a href="?<?php echo htmlspecialchars(http_build_query(array_merge($_GET, ['sort_column' => 'status_tagihan_bulan_ini', 'sort_order' => ($sort_column == 'status_tagihan_bulan_ini' && $sort_column == 'ASC') ? 'DESC' : 'ASC']))); ?>">Status Bayar (Bulan Ini) <?php if ($sort_column == 'status_tagihan_bulan_ini') echo ($sort_order == 'ASC' ? '&#9650;' : '&#9660;'); ?></a></th>
                                <th class="resizable-column" style="width: 120px;"><a href="?<?php echo htmlspecialchars(http_build_query(array_merge($_GET, ['sort_column' => 'tanggal_pembayaran_terakhir', 'sort_order' => ($sort_column == 'tanggal_pembayaran_terakhir' && $sort_order == 'ASC') ? 'DESC' : 'ASC']))); ?>">Pembayaran Terakhir <?php if ($sort_column == 'tanggal_pembayaran_terakhir') echo ($sort_order == 'ASC' ? '&#9650;' : '&#9660;'); ?></a></th>
                                <th class="resizable-column" style="width: 100px;"><a href="?<?php echo htmlspecialchars(http_build_query(array_merge($_GET, ['sort_column' => 'p.tanggal_registrasi', 'sort_order' => ($sort_column == 'p.tanggal_registrasi' && $sort_order == 'ASC') ? 'DESC' : 'ASC']))); ?>">Reg. Date <?php if ($sort_column == 'p.tanggal_registrasi') echo ($sort_order == 'ASC' ? '&#9650;' : '&#9660;'); ?></a></th>
                                <th class="resizable-column" style="width: 100px;"><a href="?<?php echo htmlspecialchars(http_build_query(array_merge($_GET, ['sort_column' => 'p.pelanggan_corporate', 'sort_order' => ($sort_column == 'p.pelanggan_corporate' && $sort_order == 'ASC') ? 'DESC' : 'ASC']))); ?>">Corporate <?php if ($sort_column == 'p.pelanggan_corporate') echo ($sort_order == 'ASC' ? '&#9650;' : '&#9660;'); ?></a></th>
                                <th style="width: 200px;">Aksi</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php if ($result_pelanggan_list->num_rows > 0): ?>
                                <?php while($row = $result_pelanggan_list->fetch_assoc()):
                                    // Tentukan status pembayaran bulan ini
                                    $status_pembayaran_bulan_ini = $row['status_tagihan_bulan_ini'] ?? 'Belum Ada Tagihan';
                                    if (is_null($row['status_tagihan_bulan_ini']) && $row['status_aktif'] == 'Aktif') {
                                        $status_pembayaran_bulan_ini = 'Belum Ada Tagihan';
                                    } else if (is_null($row['status_tagihan_bulan_ini']) && $row['status_aktif'] != 'Aktif') {
                                        $status_pembayaran_bulan_ini = 'N/A';
                                    }
                                    if ($row['status_tagihan_bulan_ini'] == 'Jatuh Tempo') {
                                        $status_pembayaran_bulan_ini = 'Jatuh Tempo';
                                    } elseif ($row['status_tagihan_bulan_ini'] == 'Kadaluarsa') {
                                        $status_pembayaran_bulan_ini = 'Kadaluarsa';
                                    }
                                    

                                    $tanggal_pembayaran_terakhir = $row['tanggal_pembayaran_terakhir'] ? date('d-m-Y', strtotime($row['tanggal_pembayaran_terakhir'])) : 'N/A';
                                ?>
                                    <tr>
                                        <?php if (hasRole('superadmin')): ?>
                                        <td><input type="checkbox" name="selected_customers[]" value="<?php echo htmlspecialchars($row['id_pelanggan']); ?>" class="customer-checkbox"></td>
                                        <?php endif; ?>
                                        <td><?php echo htmlspecialchars($row['id_pelanggan']); ?></td>
                                        <td><?php echo htmlspecialchars($row['nama_pelanggan']); ?></td>
                                        <td><?php echo htmlspecialchars($row['alamat']); ?></td>
                                        <td><?php echo htmlspecialchars($row['telepon']); ?></td>
                                        <td><?php echo htmlspecialchars($row['nama_penagih'] ?? 'N/A'); ?></td>
                                        <td><?php echo htmlspecialchars($row['nama_paket']); ?></td>
                                        <td><span class="status-badge status-<?php echo strtolower(str_replace(' ', '-', $row['status_aktif'])); ?>"><?php echo htmlspecialchars($row['status_aktif']); ?></span></td>
                                        <td><span class="status-badge status-<?php echo strtolower(str_replace(' ', '-', $status_pembayaran_bulan_ini)); ?>"><?php echo htmlspecialchars($status_pembayaran_bulan_ini); ?></span></td>
                                        <td><?php echo htmlspecialchars($tanggal_pembayaran_terakhir); ?></td>
                                        <td><?php echo htmlspecialchars(date('d-m-Y', strtotime($row['tanggal_registrasi']))); ?></td>
                                        <td>
                                            <?php
                                                if (isset($row['pelanggan_corporate'])) {
                                                    echo $row['pelanggan_corporate'] == 1 ? '<span class="status-badge status-info">Ya</span>' : '<span class="status-badge status-tidak-aktif">Tidak</span>';
                                                } else {
                                                    echo 'N/A';
                                                }
                                            ?>
                                        </td>
                                        <td>
                                            <button type="button" class="btn-action btn-secondary open-action-modal-btn" 
                                                    data-id="<?php echo $row['id_pelanggan']; ?>" 
                                                    data-name="<?php echo htmlspecialchars($row['nama_pelanggan']); ?>"
                                                    data-status-aktif="<?php echo htmlspecialchars($row['status_aktif']); ?>">
                                                <i class="fas fa-ellipsis-h"></i> Aksi
                                            </button>
                                            </td>
                                    </tr>
                                <?php endwhile; ?>
                            <?php else: ?>
                                <tr><td colspan="13" style="text-align: center;">Tidak ada data pelanggan yang ditemukan.</td></tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </form>

                <div class="pagination-controls" style="margin-top: 20px;">
                    <div>
                        Menampilkan <?php echo htmlspecialchars(min($total_records, $offset + 1), ENT_QUOTES, "UTF-8"); ?> - <?php echo htmlspecialchars(min($total_records, $offset + $per_page), ENT_QUOTES, "UTF-8"); ?> dari <?php echo htmlspecialchars($total_records, ENT_QUOTES, "UTF-8"); ?> data.
                    </div>
                    <ul class="pagination" style="margin: 0;">
                        <?php if ($current_page > 1): ?>
                            <li class="page-item"><a class="page-link" href="?<?php echo htmlspecialchars(http_build_query(array_merge($_GET, ['page' => 1]))); ?>">First</a></li>
                            <li class="page-item"><a class="page-link" href="?<?php echo htmlspecialchars(http_build_query(array_merge($_GET, ['page' => $current_page - 1]))); ?>">Previous</a></li>
                        <?php endif; ?>

                        <?php
                        $start_page = max(1, $current_page - 2);
                        $end_page = min($total_pages, $current_page + 2);

                        if ($start_page > 1) {
                            echo '<li class="page-item disabled"><span class="page-link">...</span></li>';
                        }
                        for ($i = $start_page; $i <= $end_page; $i++): ?>
                            <li class="page-item <?php echo ($i == $current_page) ? 'active' : ''; ?>"><a class="page-link" href="?<?php echo htmlspecialchars(http_build_query(array_merge($_GET, ['page' => $i]))); ?>"><?php echo htmlspecialchars($i, ENT_QUOTES, "UTF-8"); ?></a></li>
                        <?php endfor; ?>

                        <?php
                        if ($end_page < $total_pages) {
                            echo '<li class="page-item disabled"><span class="page-link">...</span></li>';
                        }
                        ?>

                        <?php if ($current_page < $total_pages): ?>
                            <li class="page-item"><a class="page-link" href="?<?php echo htmlspecialchars(http_build_query(array_merge($_GET, ['page' => $current_page + 1]))); ?>">Next</a></li>
                            <li class="page-item"><a class="page-link" href="?<?php echo htmlspecialchars(http_build_query(array_merge($_GET, ['page' => $total_pages]))); ?>">Last</a></li>
                        <?php endif; ?>
                    </ul>
                </div>
            </div>
        </div>

    </div>
</div>

<div id="actionMenuModal" class="action-menu-modal-overlay">
    <div class="action-menu-modal-content">
        <span class="close-button-modal" id="closeActionMenuModal">&times;</span>
        <h3 id="actionMenuModalTitle"><span id="actionCustomerName"></span></h3>
        <div class="action-menu-list" id="actionMenuButtons">
            </div>
    </div>
</div>
<div id="customConfirmModal" class="custom-modal-overlay">
    <div class="custom-modal-content">
        <h3 id="confirmModalTitle">Konfirmasi Aksi</h3>
        <p id="confirmModalMessage"></p>
        <div class="custom-modal-buttons">
            <button class="btn btn-confirm" id="confirmModalYes">Oke</button>
            <button class="btn btn-cancel" id="confirmModalNo">Batal</button>
        </div>
    </div>
</div>
<script>
// Panggil showNotification dari PHP jika ada pesan
<?php if (!empty($message_script)): ?>
document.addEventListener('DOMContentLoaded', function() {
    <?php echo htmlspecialchars($message_script, ENT_QUOTES, "UTF-8"); ?>
});
<?php endif; ?>


document.addEventListener('DOMContentLoaded', function() {
    var formCard = document.getElementById('formPelangganCard');
    var toggleBtn = document.getElementById('toggleFormBtn');
    
    // NEW: Mass Delete elements
    var selectAllCustomers = document.getElementById('selectAllCustomers');
    var customerCheckboxes = document.querySelectorAll('.customer-checkbox');
    var massDeleteBtn = document.getElementById('massDeleteBtn');
    var selectedCountSpan = document.getElementById('selectedCount');
    var massDeleteForm = document.getElementById('massDeleteForm');

    // Custom Modal Elements (for general confirmations)
    const customConfirmModal = document.getElementById('customConfirmModal');
    const confirmModalTitle = document.getElementById('confirmModalTitle');
    const confirmModalMessage = document.getElementById('confirmModalMessage');
    const confirmModalYes = document.getElementById('confirmModalYes');
    const confirmModalNo = document.getElementById('confirmModalNo');
    let actionConfirmedUrl = ''; // To store the URL for redirection after confirmation

    // Action Menu Modal Elements
    const actionMenuModal = document.getElementById('actionMenuModal');
    const closeActionMenuModalBtn = document.getElementById('closeActionMenuModal');
    const actionCustomerNameSpan = document.getElementById('actionCustomerName');
    const actionMenuButtonsDiv = document.getElementById('actionMenuButtons');

    // Function to show the custom confirm modal
    function showCustomConfirm(title, message, url) {
        confirmModalTitle.textContent = title;
        confirmModalMessage.textContent = message;
        actionConfirmedUrl = url;
        customConfirmModal.classList.add('show');
    }

    // Function to hide the custom confirm modal
    function hideCustomConfirm() {
        customConfirmModal.classList.remove('show');
        actionConfirmedUrl = ''; // Clear URL
    }

    // Event listener for custom confirm modal "Oke" button
    confirmModalYes.addEventListener('click', function() {
        if (actionConfirmedUrl) {
            window.location.href = actionConfirmedUrl;
        }
        hideCustomConfirm();
    });

    // Event listener for custom confirm modal "Batal" button
    confirmModalNo.addEventListener('click', function() {
        hideCustomConfirm();
    });

    // Function to show the action menu modal
    function showActionMenuModal(customerId, customerName, statusAktif) {
        actionCustomerNameSpan.textContent = customerName;
        actionMenuButtonsDiv.innerHTML = ''; // Clear previous buttons

        // Dynamically create buttons based on roles and status
        const currentCustomerId = customerId; // Capture in closure
        const currentCustomerName = customerName;
        const currentStatusAktif = statusAktif;

        // Edit Button (always available)
        let editBtn = document.createElement('a');
        editBtn.href = `pelanggan?action=edit&id=${currentCustomerId}`;
        editBtn.className = 'btn-action-modal edit-modal';
        editBtn.innerHTML = '<i class="fas fa-edit"></i> Edit';
        actionMenuButtonsDiv.appendChild(editBtn);

        // History Button (always available)
        let historyBtn = document.createElement('a');
        historyBtn.href = `pembayaran.php?pelanggan_id=${currentCustomerId}`;
        historyBtn.className = 'btn-action-modal info-modal';
        historyBtn.innerHTML = '<i class="fas fa-history"></i> History Pembayaran';
        actionMenuButtonsDiv.appendChild(historyBtn);
        
        // Hapus Button (only for superadmin)
        <?php if (hasRole('superadmin')): ?>
        let deleteBtn = document.createElement('button');
        deleteBtn.type = 'button';
        deleteBtn.className = 'btn-action-modal delete-modal';
        deleteBtn.innerHTML = '<i class="fas fa-trash-alt"></i> Hapus';
        deleteBtn.addEventListener('click', function() {
            showCustomConfirm(
                'Konfirmasi Hapus Pelanggan',
                `Apakah Anda yakin ingin menghapus pelanggan "${currentCustomerName}" (ID: ${currentCustomerId}) dan semua riwayat terkait? Aksi ini tidak dapat dibatalkan.`,
                `pelanggan?action=delete&id=${currentCustomerId}`
            );
            hideActionMenuModal(); // Hide action modal after showing confirm
        });
        actionMenuButtonsDiv.appendChild(deleteBtn);
        <?php endif; ?>

        // Status Change Buttons (for superadmin and admin)
        <?php if (hasRole(['superadmin', 'admin'])): ?>
            if (currentStatusAktif === 'Aktif') {
                let nonaktifBtn = document.createElement('button');
                nonaktifBtn.type = 'button';
                nonaktifBtn.className = 'btn-action-modal warning-modal';
                nonaktifBtn.innerHTML = '<i class="fas fa-power-off"></i> Nonaktifkan';
                nonaktifBtn.addEventListener('click', function() {
                    showCustomConfirm(
                        'Konfirmasi Nonaktifkan Pelanggan',
                        `Apakah Anda yakin ingin menonaktifkan pelanggan "${currentCustomerName}" (ID: ${currentCustomerId})?`,
                        `pelanggan?action=update_status&id=${currentCustomerId}&new_status=Tidak%20Aktif`
                    );
                    hideActionMenuModal();
                });
                actionMenuButtonsDiv.appendChild(nonaktifBtn);

                let blokirBtn = document.createElement('button');
                blokirBtn.type = 'button';
                blokirBtn.className = 'btn-action-modal danger-modal';
                blokirBtn.innerHTML = '<i class="fas fa-ban"></i> Blokir';
                blokirBtn.addEventListener('click', function() {
                    showCustomConfirm(
                        'Konfirmasi Blokir Pelanggan',
                        `Apakah Anda yakin ingin memblokir pelanggan "${currentCustomerName}" (ID: ${currentCustomerId})?`,
                        `pelanggan?action=update_status&id=${currentCustomerId}&new_status=Blokir`
                    );
                    hideActionMenuModal();
                });
                actionMenuButtonsDiv.appendChild(blokirBtn);

            } else if (currentStatusAktif === 'Tidak Aktif' || currentStatusAktif === 'Blokir') {
                let aktifBtn = document.createElement('button');
                aktifBtn.type = 'button';
                aktifBtn.className = 'btn-action-modal success-modal';
                aktifBtn.innerHTML = '<i class="fas fa-check-circle"></i> Aktifkan';
                aktifBtn.addEventListener('click', function() {
                    showCustomConfirm(
                        'Konfirmasi Aktifkan Pelanggan',
                        `Apakah Anda yakin ingin mengaktifkan kembali pelanggan "${currentCustomerName}" (ID: ${currentCustomerId})?`,
                        `pelanggan?action=update_status&id=${currentCustomerId}&new_status=Aktif`
                    );
                    hideActionMenuModal();
                });
                actionMenuButtonsDiv.appendChild(aktifBtn);
            }
        <?php endif; ?>


        actionMenuModal.classList.add('show');
    }

    // Function to hide the action menu modal
    function hideActionMenuModal() {
        actionMenuModal.classList.remove('show');
    }

    // Event listener for opening the action menu modal
    document.querySelectorAll('.open-action-modal-btn').forEach(button => {
        button.addEventListener('click', function(event) {
            event.stopPropagation(); // Prevent event from bubbling up to document and closing immediately
            const customerId = this.getAttribute('data-id');
            const customerName = this.getAttribute('data-name');
            const customerStatusAktif = this.getAttribute('data-status-aktif');
            showActionMenuModal(customerId, customerName, customerStatusAktif);
        });
    });

    // Event listener for closing the action menu modal (X button)
    closeActionMenuModalBtn.addEventListener('click', hideActionMenuModal);

    // Close modal if clicked outside of content
    actionMenuModal.addEventListener('click', function(event) {
        if (event.target === actionMenuModal) {
            hideActionMenuModal();
        }
    });


    // Toggle Form logic (existing)
    if (!formCard || !toggleBtn) {
        console.error("Error: formPelangganCard or toggleBtn not found. Script cannot proceed for form toggle.");
    } else {
        var urlParams = new URLSearchParams(window.location.search);
        var isEditMode = urlParams.get('action') === 'edit';

        // Set teks tombol default dan visibilitas form (berdasarkan kelas)
        if (formCard.classList.contains('hide-form')) {
            toggleBtn.textContent = 'Tambah Pelanggan Baru';
        } else {
            toggleBtn.textContent = 'Sembunyikan Form';
        }

        // Add event listener only once
        if (!toggleBtn._hasClickListener) {
            toggleBtn.addEventListener('click', function() {
                console.log("Toggle button clicked. Current classes:", formCard.classList);
                if (formCard.classList.contains('hide-form')) {
                    formCard.classList.remove('hide-form'); // Tampilkan form
                    toggleBtn.textContent = 'Sembunyikan Form';
                    formCard.scrollIntoView({ behavior: 'smooth', block: 'start' });
                } else {
                    formCard.classList.add('hide-form'); // Sembunyikan form
                    toggleBtn.textContent = 'Tambah Pelanggan Baru';
                    if (!isEditMode) { // Hanya reset form jika bukan mode edit
                        var form = formCard.querySelector('form');
                        if (form) {
                            form.reset();
                            var selects = form.querySelectorAll('select');
                            selects.forEach(s => {
                                let defaultOption = s.querySelector('option[selected]');
                                if (defaultOption) {
                                    s.value = defaultOption.value;
                                } else if (s.options.length > 0) {
                                    s.value = s.options[0].value;
                                }
                            });
                            // Reset date inputs to current date for new entry
                            var dateInputs = form.querySelectorAll('input[type="date"]');
                            dateInputs.forEach(input => {
                                // Only reset if it's a new entry (not edit mode)
                                if (input.id === 'tanggal_registrasi') {
                                    input.value = new Date().toISOString().slice(0,10);
                                }
                                // Tanggal berakhir tidak perlu direset karena sudah dihilangkan dari form
                            });
                        }
                    }
                    if (isEditMode) {
                        // Jika dalam mode edit dan form disembunyikan, redirect kembali ke halaman utama
                        // Ini untuk membersihkan parameter URL edit
                        window.location.href = 'pelanggan';
                    }
                }
            });
            toggleBtn._hasClickListener = true;
        }
    }

    // JavaScript untuk menampilkan pesan setelah redirect (existing)
    // Ini adalah bagian yang akan memanggil showNotification() dari header.php
    <?php if (!empty($message_script)): ?>
        // Pastikan window.showNotification sudah tersedia dari header.php
        if (window.showNotification) {
            // Panggil script pesan yang sudah disiapkan PHP
            <?php echo htmlspecialchars($message_script, ENT_QUOTES, "UTF-8"); ?>
        } else {
            // Fallback jika showNotification belum siap (misal, DOMContentLoaded di header belum jalan)
            document.addEventListener('DOMContentLoaded', function() {
                <?php echo htmlspecialchars($message_script, ENT_QUOTES, "UTF-8"); ?>
            });
        }
        // Hapus parameter msg dari URL agar notifikasi tidak muncul lagi saat refresh
        if (window.history.replaceState) {
            const url = new URL(window.location.href);
            url.searchParams.delete('msg');
            url.searchParams.delete('new_status');
            url.searchParams.delete('count');
            url.searchParams.delete('err');
            window.history.replaceState({path: url.href}, '', url.href);
        }
    <?php endif; ?>


    // --- Mass Delete Logic (existing) ---
    if (selectAllCustomers && customerCheckboxes.length > 0 && massDeleteBtn && selectedCountSpan && massDeleteForm) {
        // Function to update selected count and button state
        function updateSelectedCount() {
            let checkedCount = 0;
            customerCheckboxes.forEach(checkbox => {
                if (checkbox.checked) {
                    checkedCount++;
                }
            });
            selectedCountSpan.textContent = checkedCount;
            massDeleteBtn.disabled = checkedCount === 0; // Enable/disable button based on selection
        }

        // Event listener for "Select All" checkbox
        selectAllCustomers.addEventListener('change', function() {
            customerCheckboxes.forEach(checkbox => {
                checkbox.checked = this.checked;
            });
            updateSelectedCount();
        });

        // Event listener for individual customer checkboxes
        customerCheckboxes.forEach(checkbox => {
            checkbox.addEventListener('change', function() {
                // If any checkbox is unchecked, uncheck "Select All"
                if (!this.checked) {
                    selectAllCustomers.checked = false;
                }
                updateSelectedCount();
            });
        });

        // Event listener for the "Hapus Terpilih" button (uses native confirm for form submit)
        massDeleteBtn.addEventListener('click', function() {
            if (parseInt(selectedCountSpan.textContent) > 0) {
                // The form's onsubmit already handles the confirm dialog for mass delete
                massDeleteForm.submit();
            } else {
                console.log('Tidak ada pelanggan yang dipilih untuk dihapus.');
            }
        });

        // Initial update of selected count (in case page reloads with pre-checked boxes)
        updateSelectedCount();

    } else if (massDeleteBtn && selectedCountSpan) {
        // If no checkboxes found (e.g., no customers in table or not superadmin)
        massDeleteBtn.disabled = true; // Ensure button is disabled
    }

    // --- Paginasi: Simpan nilai per_page saat filter/sort (existing) ---
    document.querySelector('.search-form-group form').addEventListener('submit', function(event) {
        const perPageSelect = document.getElementById('per_page');
        const hiddenPerPageInput = document.createElement('input');
        hiddenPerPageInput.type = 'hidden';
        hiddenPerPageInput.name = 'per_page';
        hiddenPerPageInput.value = perPageSelect.value;
        this.appendChild(hiddenPerPageInput);
    });

    document.querySelectorAll('.data-table th a').forEach(link => {
        link.addEventListener('click', function(event) {
            event.preventDefault();
            const url = new URL(this.href);
            url.searchParams.set('per_page', document.getElementById('per_page').value);
            window.location.href = url.toString();
        });
    });

    document.querySelectorAll('.pagination a').forEach(link => {
        link.addEventListener('click', function(event) {
            event.preventDefault();
            const url = new URL(this.href);
            url.searchParams.set('per_page', document.getElementById('per_page').value);
            window.location.href = url.toString();
        });
    });
    
    // --- Column Resizing Logic (existing) ---
    const table = document.querySelector('.data-table');
    let thElements = table.querySelectorAll('th.resizable-column');
    let isResizing = false;
    let currentResizer;
    let startX;
    let startWidth;
    let currentTh;
    let currentTdIndex;

    thElements.forEach((th, index) => {
        // Create a resizer element
        const resizer = document.createElement('div');
        resizer.classList.add('resizer');
        th.appendChild(resizer);

        // Add event listeners for resizing
        resizer.addEventListener('mousedown', function(e) {
            e.preventDefault(); // Prevent default browser behavior like text selection
            currentResizer = this;
            isResizing = true;
            startX = e.clientX;
            currentTh = currentResizer.parentElement;
            startWidth = currentTh.offsetWidth;
            currentTdIndex = Array.from(currentTh.parentNode.children).indexOf(currentTh);

            // Add class to table for visual feedback
            table.classList.add('resizing');
        });
    });

    document.addEventListener('mousemove', function(e) {
        if (!isResizing) return;

        const width = startWidth + (e.clientX - startX);
        // Set a very small minimum width to allow almost full shrinkage, but prevent it from collapsing to 0
        const newWidth = Math.max(5, width); // Minimum 5px to keep resizer visible and clickable

        currentTh.style.width = `${newWidth}px`;
        // currentTh.style.minWidth = `${newWidth}px`; // Menghapus pengaturan min-width dinamis

        // Apply width to all cells in the same column to prevent misalignment
        table.querySelectorAll('tr').forEach(row => {
            if (row.children[currentTdIndex]) {
                row.children[currentTdIndex].style.width = `${newWidth}px`;
                // row.children[currentTdIndex].style.minWidth = `${newWidth}px`; // Menghapus pengaturan min-width dinamis
            }
        });
    });

    document.addEventListener('mouseup', function() {
        if (isResizing) {
            isResizing = false;
            table.classList.remove('resizing');
        }
    });

});
</script>

<?php include '../includes/footer.php'; ?>