<?php
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!isset($_POST['csrf_token']) || $_POST['csrf_token'] !== $_SESSION['csrf_token']) {
        die('CSRF validation failed.');
    }
}
?>
<?php
// C:\xampp\htdocs\billing_isp_app\pages\mikrotik_api.php

// Mulai logging error ke file kustom
ini_set('log_errors', 'On');
ini_set('error_log', __DIR__ . '/mikrotik_api_errors.log');
error_reporting(E_ALL); // Pastikan semua error dilaporkan
ini_set('display_errors', 'Off'); // Jangan tampilkan error di browser

if (session_status() == PHP_SESSION_NONE) {
ini_set('session.use_strict_mode', 1);
ini_set('session.cookie_httponly', 1);
ini_set('session.cookie_samesite', 'Lax');
if (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on') {
    ini_set('session.cookie_secure', 1);
}
    session_start();
}

// Tambahkan aksi baru untuk daftar konfigurasi MikroTik
$public_actions = [
    'get_financial_summary', 'get_all_financial_records', 'record_login_income',
    'get_voucher_logo_url', 'get_mikrotik_configs'
]; 

$method = $_SERVER['REQUEST_METHOD'];
$action = ''; // Inisialisasi $action

// Tangani input data dari berbagai metode (GET, POST, JSON)
$input_data = [];
if ($method === 'POST' || $method === 'PUT') {
    // Check if it's a file upload (multipart/form-data)
    if (strpos($_SERVER['CONTENT_TYPE'], 'multipart/form-data') === 0) {
        // For file uploads, data is in $_POST and $_FILES
        $input_data = $_POST; // Use $_POST for other form fields if any
    } else {
        // For JSON data
        $json_input = file_get_contents('php://input');
        $input_data = json_decode($json_input, true);
        if (json_last_error() !== JSON_ERROR_NONE) {
            error_log("ERROR: Input JSON tidak valid: " . json_last_error_msg() . " Raw input: " . $json_input);
            echo json_encode(['status' => 'error', 'message' => 'Input JSON tidak valid.']);
            exit();
        }
    }
}


// Tentukan aksi berdasarkan prioritas: GET, kemudian JSON POST, kemudian form-urlencoded POST
if (isset($_GET['action'])) {
    $action = $_GET['action'];
} elseif (isset($input_data['action'])) { // Jika ada di JSON POST body
    $action = $input_data['action'];
} elseif (isset($_POST['action'])) { // Jika ada di standard POST body (form-urlencoded)
    $action = $_POST['action'];
}

// Untuk aksi yang memerlukan autentikasi, pastikan pengguna memiliki peran yang sesuai
if (!in_array($action, $public_actions) && (!isset($_SESSION['user_id']) || !isset($_SESSION['role']) || ($_SESSION['role'] !== 'superadmin' && $_SESSION['role'] !== 'teknisi'))) {
    http_response_code(403); // Forbidden
    echo json_encode(['status' => 'error', 'message' => 'Akses ditolak. Anda tidak memiliki izin.']);
    exit();
}

// Include koneksi database untuk mengambil pengaturan Mikrotik DAN UNTUK SIMPAN VOUCHER
include_once __DIR__ . '/../config/koneksi.php';
// Include library Routeros API
include_once __DIR__ . '/../vendor/routeros_api/routeros_api.class.php';

header('Content-Type: application/json');

/**
 * Mengambil pengaturan Mikrotik dari database.
 *
 * @param mysqli $koneksi Objek koneksi database.
 * @param int|null $configId ID konfigurasi Mikrotik yang spesifik. Jika null, ambil yang pertama.
 * @return array Pengaturan Mikrotik.
 */
function getMikrotikSettings($koneksi, $configId = null) {
    $settings = [];
    if (!$koneksi || $koneksi->connect_error) {
        error_log("ERROR: Koneksi database tidak tersedia di getMikrotikSettings.");
        return [];
    }

    // Tambahkan kolom server_url ke query SELECT
    $query = "SELECT ip_address, username, password, port_api, server_url FROM mikrotik_settings";
    if ($configId !== null) {
        $query .= " WHERE id = ?";
    } else {
        $query .= " LIMIT 1"; // Default: ambil yang pertama jika tidak ada ID spesifik
    }
    
    if ($stmt = $koneksi->prepare($query)) {
        if ($configId !== null) {
            $stmt->bind_param("i", $configId);
        }
        $stmt->execute();
        $result = $stmt->get_result();
        if ($result && $result->num_rows > 0) {
            $settings = $result->fetch_assoc();
        }
        $stmt->close();
    } else {
        error_log("ERROR: Gagal menyiapkan pernyataan SQL di getMikrotikSettings: " . $koneksi->error);
    }
    return $settings;
}

/**
 * Menghubungkan ke perangkat Mikrotik menggunakan pengaturan yang diberikan atau pengaturan default.
 *
 * @param mysqli $koneksi Objek koneksi database.
 * @param int|null $configId Opsional. ID konfigurasi Mikrotik untuk dihubungkan.
 * @return array Array asosiatif dengan status ('success'/'error') dan objek API atau pesan error.
 */
function connectToMikrotik($koneksi, $configId = null) {
    $settings = getMikrotikSettings($koneksi, $configId);
    
    if (empty($settings['ip_address']) || empty($settings['username'])) {
        error_log("ERROR: Pengaturan Mikrotik tidak lengkap: IP atau Username hilang.");
        return ['status' => 'error', 'message' => 'Pengaturan Mikrotik (IP, Username) belum lengkap atau tidak ditemukan. Silakan atur di halaman Pengaturan API Mikrotik.'];
    }

    $API = new RouterosAPI();
    $API->debug = false; // Pastikan debug mode RouterosAPI dimatikan
    $API->port = $settings['port_api'] ?? 8728;

    if ($API->connect($settings['ip_address'], $settings['username'], $settings['password'])) {
        return ['status' => 'success', 'API' => $API, 'server_url' => $settings['server_url'] ?? '']; // Mengembalikan server_url juga
    } else {
        $error_message = $API->error_str ?? 'Tidak ada pesan error spesifik.';
        error_log("ERROR: Gagal terhubung ke Mikrotik. IP: {$settings['ip_address']}, Pengguna: {$settings['username']}, Port: {$API->port}. Error: " . $error_message);
        return ['status' => 'error', 'message' => 'Gagal terhubung ke Mikrotik. Periksa IP, username, password, dan port API di Pengaturan. Pastikan API Mikrotik diaktifkan. ' . $error_message];
    }
}

function generateRandomString($length = 5, $prefix = '') {
    $characters = '0123456789abcdefghijklmnopqrstuvwxyz'; // Hanya huruf kecil dan angka
    $charactersLength = strlen($characters);
    $randomString = '';
    for ($i = 0; $i < $length; $i++) {
        $randomString .= $characters[rand(0, $charactersLength - 1)];
    }
    return $prefix . $randomString;
}

function formatBytes($bytes, $precision = 2) {
    $units = array('B', 'KB', 'MB', 'GB', 'TB');
    $bytes = max($bytes, 0);
    $bytes = (float) $bytes; 
    $pow = floor(($bytes ? log($bytes) : 0) / log(1024));
    $pow = min($pow, count($units) - 1);
    $bytes /= (1 << (10 * $pow));
    return round($bytes, $precision) . ' ' . $units[$pow];
}

function formatRouterOSTime($time_str) {
    if (empty($time_str) || $time_str === '0s') {
        return '0 Detik';
    }
    $seconds = 0;
    if (preg_match('/(\d+)w/', $time_str, $m)) { $seconds += $m[1] * 7 * 24 * 3600; }
    if (preg_match('/(\d+)d/', $time_str, $m)) { $seconds += $m[1] * 24 * 3600; }
    if (preg_match('/(\d+)h/', $time_str, $m)) { $seconds += $m[1] * 3600; }
    if (preg_match('/(\d+)m/', $time_str, $m)) { $seconds += $m[1] * 60; }
    if (preg_match('/(\d+)s/', $time_str, $m)) { $seconds += $m[1]; }

    $dtF = new \DateTime('@0');
    $dtT = new \DateTime("@$seconds");
    $diff = $dtF->diff($dtT);

    $parts = [];
    if ($diff->y > 0) $parts[] = $diff->y . ' Tahun';
    if ($diff->m > 0) $parts[] = $diff->m . ' Bulan';
    if ($diff->d > 0) $parts[] = $diff->d . ' Hari';
    if ($diff->h > 0) $parts[] = $diff->h . ' Jam';
    if ($diff->i > 0) $parts[] = $diff->i . ' Menit';
    if ($diff->s > 0 && empty($parts)) $parts[] = $diff->s . ' Detik';

    return empty($parts) ? '0 Detik' : implode(' ', $parts);
}

// Define the path for logo uploads
$upload_dir = __DIR__ . '/../uploads/';
$logo_filename = 'voucher_logo.png'; // Fixed filename for simplicity
$logo_path = $upload_dir . $logo_filename;
$logo_url = '../uploads/' . $logo_filename; // Relative URL for frontend

try {
    // Dapatkan ID konfigurasi MikroTik yang dipilih dari request (jika ada)
    // Ini adalah parameter umum yang akan dilewatkan oleh halaman frontend untuk memilih MikroTik
    $selected_mikrotik_config_id = $_GET['config_id'] ?? $input_data['config_id'] ?? null;

    switch ($action) {
        case 'get_mikrotik_configs':
            // Aksi baru: Mengembalikan daftar semua konfigurasi MikroTik yang tersimpan
            $configs_list = [];
            // Tambahkan kolom 'server_url' ke query SELECT
            $query_configs = "SELECT id, name, ip_address, username, port_api, server_url FROM mikrotik_settings ORDER BY name ASC";
            $result_configs = $koneksi->query($query_configs);
            if ($result_configs) {
                while ($row = $result_configs->fetch_assoc()) {
                    $configs_list[] = $row;
                }
                echo json_encode(['status' => 'success', 'configs' => $configs_list]);
            } else {
                error_log("ERROR: Gagal mengambil daftar konfigurasi Mikrotik: " . $koneksi->error);
                echo json_encode(['status' => 'error', 'message' => 'Gagal mengambil daftar konfigurasi Mikrotik.']);
            }
            break;

        case 'check_status':
            // Gunakan $selected_mikrotik_config_id untuk terhubung ke MikroTik spesifik
            $connection = connectToMikrotik($koneksi, $selected_mikrotik_config_id);
            if ($connection['status'] === 'success') {
                $API = $connection['API'];
                $data = $API->comm("/system/resource/print");
                $API->disconnect();
                if (!empty($data) && is_array($data)) {
                    $info = $data[0] ?? [];
                    if (is_array($info)) {
                        echo json_encode([
                            'status' => 'success',
                            'message' => 'Terhubung ke Mikrotik.',
                            'uptime' => formatRouterOSTime($info['uptime'] ?? 'N/A'),
                            'free_memory' => formatBytes($info['free-memory'] ?? 0),
                            'total_memory' => formatBytes($info['total-memory'] ?? 0),
                            'cpu_load' => ($info['cpu-load'] ?? 'N/A') . '%',
                            'board_name' => $info['board-name'] ?? 'N/A',
                            'version' => $info['version'] ?? 'N/A'
                        ]);
                    } else {
                         echo json_encode(['status' => 'error', 'message' => 'Data sumber daya Mikrotik tidak dalam format yang diharapkan.']);
                    }
                } else {
                    echo json_encode(['status' => 'error', 'message' => 'Gagal mendapatkan informasi sumber daya Mikrotik atau data kosong.']);
                }
            } else {
                echo json_encode($connection);
            }
            break;

        case 'generate_voucher':
            $jumlah = $input_data['jumlah'] ?? 1;
            $profile = $input_data['profile'] ?? '';
            $panjang_karakter = $input_data['panjang_karakter'] ?? 5;
            $awalan = $input_data['awalan'] ?? '';
            $comment = $input_data['comment'] ?? 'Voucher Otomatis';
            $validity_gen = $input_data['validity_gen'] ?? '';
            $price_gen = (float)($input_data['price_gen'] ?? '0.00');
            $selling_price_gen = (float)($input_data['selling_price_gen'] ?? '0.00'); 

            if (empty($profile)) {
                echo json_encode(['status' => 'error', 'message' => 'Profil voucher harus diisi.']);
                exit();
            }
            if ($jumlah <= 0) {
                echo json_encode(['status' => 'error', 'message' => 'Jumlah voucher harus lebih dari 0.']);
                exit();
            }
            if ($panjang_karakter < 3 || $panjang_karakter > 15) {
                echo json_encode(['status' => 'error', 'message' => 'Panjang karakter harus antara 3 dan 15.']);
                exit();
            }

            // Gunakan $selected_mikrotik_config_id untuk terhubung ke MikroTik spesifik
            $connection = connectToMikrotik($koneksi, $selected_mikrotik_config_id);
            if ($connection['status'] === 'success') {
                $API = $connection['API'];
                $generated_vouchers_temp_for_response = [];

                $stmt = null;
                // Pastikan $koneksi adalah objek koneksi yang valid dan dapat di-ping sebelum menyiapkan statement
                if (isset($koneksi) && $koneksi->ping()) {
                    // Tambahkan kolom mikrotik_id ke query INSERT
                    $sql_insert = "INSERT INTO vouchers (username, password, profile, mikrotik_id, comment, price, selling_price, is_income_recorded) VALUES (?, ?, ?, ?, ?, ?, ?, 0)";
                    $stmt = $koneksi->prepare($sql_insert);
                    if (!$stmt) {
                        error_log("ERROR: Database error (prepare voucher insert): " . $koneksi->error);
                    }
                } else {
                    error_log("WARNING: Database connection not available when trying to prepare voucher insert statement.");
                }

                for ($i = 0; $i < $jumlah; $i++) {
                    $username = generateRandomString($panjang_karakter, $awalan);
                    $password = generateRandomString($panjang_karakter);
                    $server_name = 'all';

                    $voucher_comment_to_db = $comment; 
                    if (!empty($validity_gen)) {
                        $voucher_comment_to_db .= " | Validity: " . $validity_gen;
                    }
                    if ($price_gen > 0) {
                        $voucher_comment_to_db .= " | Price: " . $price_gen;
                    }

                    $mikrotik_params = [
                        "name" => $username,
                        "password" => $password,
                        "profile" => $profile,
                        "comment" => $comment // Kirim komentar asli ke Mikrotik (tanpa tanggal awal)
                    ];

                    if (!empty($validity_gen) && $validity_gen !== '0s') { 
                        $mikrotik_params["limit-uptime"] = $validity_gen;
                    } else {
                        $mikrotik_params["limit-uptime"] = '0s';
                    }

                    $response_mikrotik = $API->comm("/ip/hotspot/user/add", $mikrotik_params);

                    if (isset($response_mikrotik['!trap'])) {
                        error_log("ERROR: Mikrotik API Error (generate voucher for {$username}): " . json_encode($response_mikrotik['!trap']));
                        echo json_encode(['status' => 'error', 'message' => 'Gagal membuat voucher di Mikrotik: ' . ($response['!trap'][0]['message'] ?? 'Kesalahan tidak diketahui dari Mikrotik')]);
                        $API->disconnect();
                        if ($stmt) $stmt->close();
                        exit();
                    } else {
                        if ($stmt) { 
                            // Pastikan untuk mengikat mikrotik_id saat menyimpan
                            $stmt->bind_param("sssisss", $username, $password, $profile, $selected_mikrotik_config_id, $voucher_comment_to_db, $price_gen, $selling_price_gen);
                            if (!$stmt->execute()) {
                                error_log("ERROR: Database error (insert voucher for {$username}): " . $stmt->error);
                            }
                        } else {
                            error_log("WARNING: Database statement not prepared, skipping DB insert for voucher {$username}.");
                        }

                        $generated_vouchers_temp_for_response[] = [
                            'username' => $username,
                            'password' => $password,
                            'profile' => $profile,
                            'price' => $price_gen,
                            'selling_price' => $selling_price_gen
                        ];
                    }
                }
                $API->disconnect();
                if ($stmt) $stmt->close();
                echo json_encode(['status' => 'success', 'message' => 'Voucher berhasil dibuat dan disimpan.', 'vouchers' => $generated_vouchers_temp_for_response]);
            } else {
                echo json_encode($connection);
            }
            break;

        case 'record_login_income':
            $username_from_mikrotik = $_GET['username'] ?? '';
            $price_from_mikrotik = (float)($_GET['price'] ?? '0.00');

            if (empty($username_from_mikrotik)) {
                error_log("ERROR: record_login_income: Username kosong.");
                echo json_encode(['status' => 'error', 'message' => 'Username tidak ditemukan.']);
                exit();
            }

            if (isset($koneksi) && $koneksi->ping()) {
                $sql_check_recorded = "SELECT id, is_income_recorded FROM vouchers WHERE username = ?";
                $stmt_check = $koneksi->prepare($sql_check_recorded);
                $stmt_check->bind_param("s", $username_from_mikrotik);
                $stmt_check->execute();
                $result_check = $stmt_check->get_result();

                if ($result_check->num_rows > 0) {
                    $voucher_data = $result_check->fetch_assoc();
                    $voucher_id = $voucher_data['id'];
                    $is_recorded = $voucher_data['is_income_recorded'];

                    if ($is_recorded == 0) {
                        $sql_get_price = "SELECT price, profile FROM vouchers WHERE id = ?";
                        $stmt_get_price = $koneksi->prepare($sql_get_price);
                        $stmt_get_price->bind_param("i", $voucher_id);
                        $stmt_get_price->execute();
                        $result_get_price = $stmt_get_price->get_result();
                        $db_voucher = $result_get_price->fetch_assoc();
                        $actual_price = (float)($db_voucher['price'] ?? $price_from_mikrotik);
                        $profile_name = $db_voucher['profile'] ?? 'N/A';
                        $stmt_get_price->close();

                        $sql_insert_financial = "INSERT INTO financial_records (username, profile_name, price, selling_price, transaction_date) VALUES (?, ?, ?, ?, NOW())";
                        $stmt_financial = $koneksi->prepare($sql_insert_financial);
                        $zero_sprice = 0.00;
                        $stmt_financial->bind_param("ssdd", $username_from_mikrotik, $profile_name, $actual_price, $zero_sprice);
                        
                        if ($stmt_financial->execute()) {
                            // Log aktivitas pendapatan berhasil dicatat
                            error_log("INFO: Pendapatan berhasil dicatat untuk user: {$username_from_mikrotik} (Harga: {$actual_price}).");
                            $sql_update_flag = "UPDATE vouchers SET is_income_recorded = 1 WHERE id = ?";
                            $stmt_update_flag = $koneksi->prepare($sql_update_flag);
                            $stmt_update_flag->bind_param("i", $voucher_id);
                            $stmt_update_flag->execute();
                            $stmt_update_flag->close();
                            echo json_encode(['status' => 'success', 'message' => 'Pendapatan login berhasil dicatat.']);
                        } else {
                            error_log("ERROR: Gagal mencatat pendapatan login untuk {$username_from_mikrotik}: " . $stmt_financial->error);
                            echo json_encode(['status' => 'error', 'message' => 'Gagal mencatat pendapatan login.']);
                        }
                        $stmt_financial->close();
                    } else {
                        // Log bahwa pendapatan sudah dicatat
                        error_log("INFO: Pendapatan untuk user: {$username_from_mikrotik} sudah dicatat sebelumnya.");
                        echo json_encode(['status' => 'success', 'message' => 'Pendapatan sudah dicatat sebelumnya.']);
                    }
                } else {
                    error_log("WARNING: record_login_income: Voucher '{$username_from_mikrotik}' tidak ditemukan di database.");
                    echo json_encode(['status' => 'error', 'message' => 'Voucher tidak ditemukan.']);
                }
                $stmt_check->close();
            } else {
                error_log("ERROR: Koneksi database tidak tersedia untuk record_login_income.");
                echo json_encode(['status' => 'error', 'message' => 'Koneksi database tidak tersedia.']);
            }
            break;


        case 'add_hotspot_profile':
            $name = $input_data['name'] ?? null;
            $trimmed_name = trim($name);
            $cleaned_name = preg_replace('/\s+/', '-', $trimmed_name);

            $rate_limit = $input_data['rate-limit'] ?? '';
            $shared_users = $input_data['shared-users'] ?? '1';
            $address_pool = $input_data['address-pool'] ?? '';
            $parent_queue = $input_data['parent'] ?? '';
            
            $expmode = $input_data['mode-kadaluwarsa'] ?? '0';
            $validity = $input_data['validity'] ?? '';
            $price = (float)($input_data['price'] ?? '0.00');
            $sprice = (float)($input_data['selling-price'] ?? '0.00');

            $mikrotik_validity = '';
            if (!empty($validity)) {
                $mikrotik_validity = str_replace(
                    [' Hari', ' Jam', ' Menit', ' Detik', 'Tidak Terbatas', 'W'],
                    ['d', 'h', 'm', 's', '', 'w'],
                    $validity
                );
                $mikrotik_validity = trim($mikrotik_validity);
                if (!preg_match('/^\d+[wdhms]$|^0s$|^$/', $mikrotik_validity) && !empty($mikrotik_validity)) {
                    error_log("WARNING: Format validitas Mikrotik tidak valid: '{$mikrotik_validity}'. Disetel kosong.");
                    $mikrotik_validity = '';
                }
            }

            if (empty($cleaned_name)) {
                error_log("ERROR: Nama profil setelah pembersihan kosong.");
                echo json_encode(['status' => 'error', 'message' => 'Nama profil tidak boleh kosong.']);
                exit();
            }

            // Gunakan $selected_mikrotik_config_id untuk terhubung ke MikroTik spesifik
            $connection = connectToMikrotik($koneksi, $selected_mikrotik_config_id);
            if ($connection['status'] === 'success') {
                $API = $connection['API'];
                $server_url_from_db = $connection['server_url'] ?? ''; // Ambil server_url dari koneksi

                // Perubahan di sini: tambahkan 'pages/mikrotik_api.php' secara statis
                $server_url_for_mikrotik = rtrim($server_url_from_db, '/') . '/pages/mikrotik_api.php';
                
                $CR = chr(13); // baris baru

                $onlogin  = ":local usernameval \$user" . $CR;
                $onlogin .= ":local priceval \"{$price}\"" . $CR;
                $onlogin .= ":local fetchurl (\"{$server_url_for_mikrotik}?action=record_login_income&username=\$usernameval&price=\$priceval\")" . $CR;
                $onlogin .= "/tool fetch url=\$fetchurl keep-result=no" . $CR;
                $onlogin .= ":local userid [/ip hotspot user find where name=\$user]" . $CR;

                $onlogin_for_profile  = ':local userprofile [/ip hotspot user get [find where name=$user] profile]' . $CR;
                $onlogin_for_profile .= ':local limituptime [/ip hotspot user get [find where name=$user] limit-uptime]' . $CR;
                $onlogin_for_profile .= ':if ($limituptime = "") do={:set limituptime "0d00:00:00"}' . $CR;

                $onlogin_for_profile .= ':local utdias 0' . $CR;
                $onlogin_for_profile .= ':local uthoras 0' . $CR;
                $onlogin_for_profile .= ':local utminutos 0' . $CR;
                $onlogin_for_profile .= ':if ([:find $limituptime "d"] != -1) do={:set utdias [:tonum [:pick $limituptime 0 [:find $limituptime "d"]]]; :set limituptime [:pick $limituptime ([:find $limituptime "d"] + 1) [:len $limituptime]]}' . $CR;
                $onlogin_for_profile .= ':if ([:find $limituptime ":"] != -1) do={:set uthoras [:tonum [:pick $limituptime 0 [:find $limituptime ":"]]]; :set limituptime [:pick $limituptime ([:find $limituptime ":"] + 1) [:len $limituptime]]}' . $CR;
                $onlogin_for_profile .= ':if ([:find $limituptime ":"] != -1) do={:set utminutos [:tonum [:pick $limituptime 0 [:find $limituptime ":"]]]}' . $CR;

                $onlogin_for_profile .= ':local tdias $utdias'    . $CR;
                $onlogin_for_profile .= ':local thoras $uthoras'  . $CR;
                $onlogin_for_profile .= ':local tminutos $utminutos' . $CR;

                $onlogin_for_profile .= ':delay 1s' . $CR;
                $onlogin_for_profile .= ':local expTime [/system clock get time]' . $CR;
                $onlogin_for_profile .= ':local expDate [/system clock get date]' . $CR;

                $onlogin_for_profile .= ':local mesarray ("jan","feb","mar","apr","may","jun","jul","aug","sep","oct","nov","dec")' . $CR;
                $onlogin_for_profile .= ':local diaarray ("31","28","31","30","31","30","31","31","30","31","30","31")' . $CR;
                $onlogin_for_profile .= ':local day [:pick $expDate 4 6]' . $CR;
                $onlogin_for_profile .= ':local monthtxt [:pick $expDate 0 3]' . $CR;
                $onlogin_for_profile .= ':local year [:pick $expDate 7 11]' . $CR;
                $onlogin_for_profile .= ':local months ([:find $mesarray $monthtxt])' . $CR;
                $onlogin_for_profile .= ':local dia [:pick $diaarray $months]' . $CR;

                $onlogin_for_profile .= ':local fhora [:pick $expTime 0 2]' . $CR;
                $onlogin_for_profile .= ':local fmin  [:pick $expTime 3 5]' . $CR;
                $onlogin_for_profile .= ':local fseg  [:pick $expTime 6 8]' . $CR;

                $onlogin_for_profile .= ':set fmin ($fmin + $tminutos)' . $CR;
                $onlogin_for_profile .= ':if ($fmin > 59) do={:set fmin ($fmin - 60); :set thoras ($thoras + 1)}' . $CR;
                $onlogin_for_profile .= ':set fhora ($fhora + $thoras)' . $CR;
                $onlogin_for_profile .= ':if ($fhora > 23) do={:set fhora ($fhora - 24); :set tdias ($tdias + 1)}' . $CR;

                $onlogin_for_profile .= ':set day ($day + $tdias)' . $CR;
                $onlogin_for_profile .= ':if ($day > $dia) do={:set day ($day - $dia); :set months ($months + 1); :if ($months > 11) do={:set months 0; :set year ($year + 1)}}' . $CR;

                $onlogin_for_profile .= ':local mes [:pick $mesarray $months]' . $CR;
                $onlogin_for_profile .= ':if ([:len $day] = 1) do={:set day ("0" . $day)}' . $CR;
                $onlogin_for_profile .= ':if ([:len $fhora] = 1) do={:set fhora ("0" . $fhora)}' . $CR;
                $onlogin_for_profile .= ':if ([:len $fmin] = 1) do={:set fmin ("0" . $fmin)}' . $CR;
                $onlogin_for_profile .= ':if ([:len $fseg] = 1) do={:set fseg ("0" . $fseg)}' . $CR;

                $onlogin_for_profile .= ':local expDate ($mes . "/" . $day . "/" . $year)' . $CR;
                $onlogin_for_profile .= ':local expTime ($fhora . ":" . $fmin . ":" . $fseg)' . $CR;
                // Mengubah format komentar untuk menyimpan tanggal kadaluwarsa:YYYY-MM-DD HH:MM:SS | Original Comment
                // Perhatikan konversi bulan dari 'jan'/'feb' ke '01'/'02' dst.
                $onlogin_for_profile .= ':local monthNumber ([:find $mesarray $mes] + 1)' . $CR;
                $onlogin_for_profile .= ':if ($monthNumber < 10) do={:set monthNumber ("0" . $monthNumber)}' . $CR;
                $onlogin_for_profile .= ':local formattedExpDate ($year . "-" . $monthNumber . "-" . $day)' . $CR;
                $onlogin_for_profile .= ':local fullComment ($formattedExpDate . " " . $expTime . " | ' . $comment . '")' . $CR;
                $onlogin_for_profile .= ':if ([:len [/ip hotspot user get $user comment]] = 0) do={/ip hotspot user set $user comment=$fullComment}' . $CR;
                $onlogin_for_profile .= "        :local mac \$\"mac-address\";" . $CR;
                $onlogin_for_profile .= "        /ip hotspot user set mac-address=\$mac [/ip hotspot user find where name=\"\$user\"];" . $CR;


                $final_onlogin_script = $onlogin . $CR . $onlogin_for_profile;


                $existing_scheduler = $API->comm("/system/scheduler/print", ["?name" => "auto-remove-{$cleaned_name}"]);
                $monid = null;
                if (!empty($existing_scheduler)) {
                    $monid = $existing_scheduler[0]['.id'];
                }

                $profile_params = [
                    "name" => "$cleaned_name",
                    "address-pool" => "$address_pool",
                    "rate-limit" => "$rate_limit",
                    "shared-users" => "$shared_users",
                    "status-autorefresh" => "1m",
                    "on-login" => "$final_onlogin_script",
                    "parent-queue" => "$parent_queue",
                ];

                if (!empty($mikrotik_validity)) {
                    $profile_params["session-timeout"] = $mikrotik_validity;
                } else {
                    $profile_params["session-timeout"] = '0s';
                }

                $API->comm("/ip/hotspot/user/profile/add", $profile_params);

                $dynamic_scheduler_script_content  = ':local mesarray {"jan"=1; "feb"=2; "mar"=3; "apr"=4; "may"=5; "jun"=6; "jul"=7; "aug"=8; "sep"=9; "oct"=10; "nov"=11; "dec"=12}' . $CR;
                $dynamic_scheduler_script_content .= '/ip hotspot user' . $CR;
                $dynamic_scheduler_script_content .= ':foreach u in=[find] do={' . $CR;
                $dynamic_scheduler_script_content .= '    :local cmt [get $u comment]' . $CR;
                $dynamic_scheduler_script_content .= '    :if ([:len $cmt] >= 19 && [:pick $cmt 4 5] = "-" && [:pick $cmt 7 8] = "-" && [:pick $cmt 10 11] = " " && [:pick $cmt 13 14] = ":" && [:pick $cmt 16 17] = ":") do={' . $CR;
                $dynamic_scheduler_script_content .= '        :local yearStr [:tonum [:pick $cmt 0 4]]' . $CR;
                $dynamic_scheduler_script_content .= '        :local monthNumStr [:tonum [:pick $cmt 5 7]]' . $CR;
                $dynamic_scheduler_script_content .= '        :local day [:tonum [:pick $cmt 8 10]]' . $CR;
                $dynamic_scheduler_script_content .= '        :local timeStr [:pick $cmt 11 19]' . $CR;
                $dynamic_scheduler_script_content .= '        :local hour [:tonum [:pick $timeStr 0 2]]' . $CR;
                $dynamic_scheduler_script_content .= '        :local min  [:tonum [:pick $timeStr 3 5]]' . $CR;
                $dynamic_scheduler_script_content .= '        :local sec  [:tonum [:pick $timeStr 6 8]]' . $CR;
                $dynamic_scheduler_script_content .= '        :local expDateTime ($yearStr * 10000000000 + $monthNumStr * 100000000 + $day * 1000000 + $hour * 10000 + $min * 100 + $sec)' . $CR;
                $dynamic_scheduler_script_content .= '        :local nowDate [/system clock get date]' . $CR;
                $dynamic_scheduler_script_content .= '        :local nowTime [/system clock get time]' . $CR;
                $dynamic_scheduler_script_content .= '        :local nowYear [:tonum [:pick $nowDate 7 11]]' . $CR;
                $dynamic_scheduler_script_content .= '        :local nowMonth [:pick $nowDate 0 3]' . $CR;
                $dynamic_scheduler_script_content .= '        :local nowMon ($mesarray->$nowMonth)' . $CR;
                $dynamic_scheduler_script_content .= '        :local nowDay [:tonum [:pick $nowDate 4 6]]' . $CR;
                $dynamic_scheduler_script_content .= '        :local nowHour [:tonum [:pick $nowTime 0 2]]' . $CR;
                $dynamic_scheduler_script_content .= '        :local nowMin  [:tonum [:pick $nowTime 3 5]]' . $CR;
                $dynamic_scheduler_script_content .= '        :local nowSec  [:tonum [:pick $nowTime 6 8]]' . $CR;
                $dynamic_scheduler_script_content .= '        :local nowDateTime ($nowYear * 10000000000 + $nowMon * 100000000 + $nowDay * 1000000 + $nowHour * 10000 + $nowMin * 100 + $nowSec)' . $CR;
                $dynamic_scheduler_script_content .= '        :if ($nowDateTime > $expDateTime) do={' . $CR;
                $dynamic_scheduler_script_content .= '            :local uname [get $u name]' . $CR;
                $dynamic_scheduler_script_content .= '            :log info "Menghapus user expired: $uname ($cmt)"' . $CR; // Log aktivitas penting
                $dynamic_scheduler_script_content .= '            /ip hotspot user remove [find where name=$uname]' . $CR;
                $dynamic_scheduler_script_content .= '        }' . $CR;
                $dynamic_scheduler_script_content .= '    }' . $CR;
                $dynamic_scheduler_script_content .= '}' . $CR;



                if ($expmode != "0") {
                    $randstarttime = "0".rand(1,5).":".rand(10,59).":".rand(10,59);
                    $randinterval = "00:02:".rand(10,59);

                    if (empty($monid)) {
                        $API->comm("/system/scheduler/add", array(
                            "name" => "auto-remove-{$cleaned_name}",
                            "start-time" => "$randstarttime",
                            "interval" => "$randinterval",
                            "on-event" => "$dynamic_scheduler_script_content",
                            "disabled" => "no",
                            "comment" => "Monitor Profile $cleaned_name for Expiration",
                        ));
                    } else {
                        $API->comm("/system/scheduler/set", array(
                            ".id" => "$monid",
                            "name" => "auto-remove-{$cleaned_name}",
                            "start-time" => "$randstarttime",
                            "interval" => "$randinterval",
                            "on-event" => "$dynamic_scheduler_script_content",
                            "disabled" => "no",
                            "comment" => "Monitor Profile $cleaned_name for Expiration",
                        ));
                    }
                } else {
                    if (!empty($monid)) {
                        $API->comm("/system/scheduler/remove", array(
                            ".id" => "$monid"
                        ));
                    }
                }

                if (isset($koneksi) && $koneksi->ping()) {
                    $sql_check = "SELECT id_paket FROM paket_layanan WHERE nama_paket = ?";
                    $stmt_check = $koneksi->prepare($sql_check);
                    $stmt_check->bind_param("s", $cleaned_name);
                    $stmt_check->execute();
                    $result_check = $stmt_check->get_result();

                    if ($result_check->num_rows > 0) {
                        $sql_update = "UPDATE paket_layanan SET kecepatan = ?, harga = ?, harga_jual = ?, deskripsi = ?, status_paket = 'Aktif' WHERE nama_paket = ?";
                        $stmt_update = $koneksi->prepare($sql_update);
                        $deskripsi_validity = !empty($mikrotik_validity) ? formatRouterOSTime($mikrotik_validity) : 'Tidak Terbatas';
                        $deskripsi = $rate_limit . " / " . $deskripsi_validity; 
                        $status_paket = 'Aktif';
                        $stmt_update->bind_param("sdsss", $rate_limit, $price, $sprice, $deskripsi, $cleaned_name);
                        if (!$stmt_update->execute()) {
                            error_log("ERROR: Gagal memperbarui paket layanan di DB: " . $stmt_update->error);
                        }
                        $stmt_update->close();
                    } else {
                        $sql_insert_db = "INSERT INTO paket_layanan (nama_paket, kecepatan, harga, harga_jual, deskripsi, status_paket) VALUES (?, ?, ?, ?, ?, ?)";
                        $stmt_insert_db = $koneksi->prepare($sql_insert_db);
                        $deskripsi_validity = !empty($mikrotik_validity) ? formatRouterOSTime($mikrotik_validity) : 'Tidak Terbatas';
                        $deskripsi = $rate_limit . " / " . $deskripsi_validity; 
                        $status_paket = 'Aktif';
                        $stmt_insert_db->bind_param("ssdsss", $cleaned_name, $rate_limit, $price, $sprice, $deskripsi, $status_paket);
                        if (!$stmt_insert_db->execute()) {
                            error_log("ERROR: Gagal menyimpan paket layanan baru di DB: " . $stmt_insert_db->error);
                        }
                        $stmt_insert_db->close();
                    }
                    $stmt_check->close();
                } else {
                    error_log("ERROR: Koneksi database tidak tersedia saat mencoba menyimpan paket layanan.");
                }

                echo json_encode(['status' => 'success', 'message' => 'Profil hotspot berhasil ditambahkan/diperbarui dan harga disimpan di database lokal.']);

            } else {
                echo json_encode($connection);
            }
            break;

        case 'get_vouchers_from_db':
            $vouchers_list = [];
            // Dapatkan filter config_id dari request (jika ada)
            $filter_mikrotik_id = $_GET['config_id'] ?? null; 

            if (isset($koneksi) && $koneksi->ping()) {
                // Modifikasi query untuk memfilter berdasarkan mikrotik_id jika diberikan
                $sql = "SELECT id, username, password, profile, comment, price, selling_price, is_income_recorded FROM vouchers";
                if ($filter_mikrotik_id !== null) {
                    $sql .= " WHERE mikrotik_id = ?";
                }
                $sql .= " ORDER BY created_at DESC";
                
                if ($stmt = $koneksi->prepare($sql)) {
                    if ($filter_mikrotik_id !== null) {
                        $stmt->bind_param("i", $filter_mikrotik_id);
                    }
                    $stmt->execute();
                    $result = $stmt->get_result();
                    if ($result) {
                        while ($row = mysqli_fetch_assoc($result)) {
                            $vouchers_list[] = [
                                'db_id' => $row['id'],
                                'username' => $row['username'],
                                'password' => $row['password'],
                                'profile' => $row['profile'],
                                'comment' => $row['comment'] ?? '',
                                'server' => 'all', // Default untuk tampilan, akan ditimpa jika aktif
                                'mac-address' => 'N/A',
                                'uptime' => '0s',
                                'session-time-left' => 'N/A',
                                'bytes-in' => 0,
                                'bytes-out' => 0,
                                'disabled' => 'false',
                                'mikrotik_id' => $filter_mikrotik_id, // Voucher dari DB akan memiliki mikrotik_id ini
                                'price' => $row['price'] ?? '0',
                                'is_income_recorded' => $row['is_income_recorded'] ?? 0,
                            ];
                        }
                        $response = ['status' => 'success', 'vouchers' => $vouchers_list];
                    } else {
                        $response = ['status' => 'error', 'message' => 'Gagal mengambil voucher dari database: ' . $stmt->error];
                        error_log("ERROR: Gagal mengambil voucher dari DB di mikrotik_api.php: " . $stmt->error);
                    }
                    $stmt->close();
                } else {
                    $response = ['status' => 'error', 'message' => 'Gagal menyiapkan pernyataan SQL untuk voucher: ' . $koneksi->error];
                    error_log("ERROR: Gagal menyiapkan pernyataan SQL di get_vouchers_from_db: " . $koneksi->error);
                }
            } else {
                $response = ['status' => 'error', 'message' => 'Koneksi database tidak tersedia atau gagal.'];
                error_log("ERROR: Koneksi database tidak tersedia untuk get_vouchers_from_db.");
            }
            echo json_encode($response);
            break;


        case 'clear_vouchers_from_db':
            if (isset($koneksi) && $koneksi->ping()) {
                // Filter berdasarkan mikrotik_id jika diberikan
                $filter_mikrotik_id = $input_data['config_id'] ?? null;

                $check_table_sql = "SHOW TABLES LIKE 'vouchers'";
                $table_exists = $koneksi->query($check_table_sql)->num_rows > 0;

                if ($table_exists) {
                    $sql = "DELETE FROM vouchers";
                    if ($filter_mikrotik_id !== null) {
                        $sql .= " WHERE mikrotik_id = ?";
                    }
                    
                    if ($stmt = $koneksi->prepare($sql)) {
                        if ($filter_mikrotik_id !== null) {
                            $stmt->bind_param("i", $filter_mikrotik_id);
                        }
                        if ($stmt->execute()) {
                            $response = ['status' => 'success', 'message' => 'Daftar voucher berhasil dibersihkan dari database.'];
                        } else {
                            $response = ['status' => 'error', 'message' => 'Gagal membersihkan voucher dari database: ' . $stmt->error];
                            error_log("ERROR: Gagal membersihkan voucher dari DB: " . $stmt->error);
                        }
                        $stmt->close();
                    } else {
                        $response = ['status' => 'error', 'message' => 'Gagal menyiapkan pernyataan hapus voucher: ' . $koneksi->error];
                        error_log("ERROR: Gagal menyiapkan pernyataan hapus voucher: " . $koneksi->error);
                    }
                } else {
                     $response = ['status' => 'error', 'message' => 'Tabel "vouchers" tidak ditemukan di database.'];
                     error_log("ERROR: Tabel 'vouchers' tidak ditemukan selama aksi clear_vouchers_from_db.");
                }
            } else {
                $response = ['status' => 'error', 'message' => 'Koneksi database tidak tersedia atau gagal.'];
                error_log("ERROR: Koneksi database tidak tersedia untuk clear_vouchers_from_db.");
            }
            echo json_encode($response);
            break;


        case 'delete_multiple_vouchers':
            $vouchers_to_delete = $input_data['vouchers'] ?? [];
            // Ambil mikrotik_id dari input data untuk filter
            $filter_mikrotik_id = $input_data['config_id'] ?? null; 

            if (empty($vouchers_to_delete) || !is_array($vouchers_to_delete)) {
                echo json_encode(['status' => 'error', 'message' => 'Daftar voucher untuk dihapus tidak valid.']);
                exit();
            }

            // Gunakan $selected_mikrotik_config_id untuk terhubung ke MikroTik spesifik
            $connection = connectToMikrotik($koneksi, $selected_mikrotik_config_id);
            if ($connection['status'] !== 'success') {
                echo json_encode($connection);
                exit();
            }
            $API = $connection['API'];

            $mikrotik_deleted_count = 0;
            $db_deleted_count = 0;
            $errors = [];

            $mikrotik_users = $API->comm("/ip/hotspot/user/print");
            $mikrotik_users_map = [];
            if (is_array($mikrotik_users)) {
                foreach ($mikrotik_users as $user) {
                    if (isset($user['name'])) {
                        $mikrotik_users_map[$user['name']] = $user;
                    }
                }
            }


            foreach ($vouchers_to_delete as $voucher) {
                $username = $voucher['username'] ?? null;
                $mikrotik_id_to_delete = $mikrotik_users_map[$username]['.id'] ?? null; // Get ID from map

                $mikrotik_delete_successful = false; 

                if ($mikrotik_id_to_delete) {
                    $response_mikrotik = $API->comm("/ip/hotspot/user/remove", [
                        ".id" => $mikrotik_id_to_delete
                    ]);

                    if (isset($response_mikrotik['!trap'])) {
                        if (strpos(($response_mikrotik['!trap'][0]['message'] ?? ''), 'no such item') !== false) {
                            $mikrotik_delete_successful = true;
                        } else {
                            $errors[] = "Gagal menghapus pengguna '{$username}' (Mikrotik ID: {$mikrotik_id_to_delete}) dari Mikrotik: " . ($response_mikrotik['!trap'][0]['message'] ?? 'Unknown error');
                            error_log("ERROR: Mikrotik API Error (hapus user {$username}): " . json_encode($response_mikrotik['!trap']));
                        }
                    } else {
                        $mikrotik_delete_successful = true;
                    }
                } else {
                    $mikrotik_delete_successful = true; // User already gone from Mikrotik
                }

                if ($mikrotik_delete_successful) {
                    $mikrotik_deleted_count++;
                }

                if (isset($koneksi) && $koneksi->ping()) {
                    // Modifikasi query DELETE untuk menyertakan mikrotik_id
                    $sql_delete_db = "DELETE FROM vouchers WHERE username = ?";
                    if ($filter_mikrotik_id !== null) {
                        $sql_delete_db .= " AND mikrotik_id = ?";
                    }
                    
                    if ($stmt_delete_db = $koneksi->prepare($sql_delete_db)) {
                        if ($filter_mikrotik_id !== null) {
                            $stmt_delete_db->bind_param("si", $username, $filter_mikrotik_id);
                        } else {
                            $stmt_delete_db->bind_param("s", $username);
                        }
                        
                        if ($stmt_delete_db->execute()) {
                            if ($stmt_delete_db->affected_rows > 0) {
                                $db_deleted_count++;
                            } else {
                                $errors[] = "Voucher '{$username}' tidak ditemukan di database untuk dihapus (mungkin filter MikroTik salah).";
                            }
                        } else {
                            $errors[] = "Gagal menghapus voucher '{$username}' dari database: " . $stmt_delete_db->error;
                            error_log("ERROR: Database error (hapus voucher by username '{$username}'): " . $stmt_delete_db->error);
                        }
                        $stmt_delete_db->close();
                    } else {
                        $errors[] = "Kesalahan database: Tidak dapat menyiapkan pernyataan hapus untuk nama pengguna '{$username}'.";
                        error_log("ERROR: Database error (siapkan hapus voucher by username '{$username}'): " . $koneksi->error);
                    }
                }
            }

            $API->disconnect();

            if (empty($errors)) {
                echo json_encode(['status' => 'success', 'message' => "Berhasil menghapus {$mikrotik_deleted_count} voucher dari MikroTik dan {$db_deleted_count} dari database."]);
            } else {
                echo json_encode(['status' => 'warning', 'message' => "Selesai dengan beberapa masalah. " . implode(" ", $errors), 'errors' => $errors]);
            }
            break;

        case 'get_hotspot_profiles':
            // Gunakan $selected_mikrotik_config_id untuk terhubung ke MikroTik spesifik
            $connection = connectToMikrotik($koneksi, $selected_mikrotik_config_id);
            if ($connection['status'] === 'success') {
                $API = $connection['API'];
                $profiles = $API->comm("/ip/hotspot/user/profile/print");
                $API->disconnect();
                $profile_names = [];
                foreach ($profiles as $profile) {
                    if (isset($profile['name'])) {
                        $profile_names[] = $profile['name'];
                    }
                }
                echo json_encode(['status' => 'success', 'profiles' => $profile_names]);
            } else {
                echo json_encode($connection);
            }
            break;

        case 'get_hotspot_user_profiles':
            // Gunakan $selected_mikrotik_config_id untuk terhubung ke MikroTik spesifik
            $connection = connectToMikrotik($koneksi, $selected_mikrotik_config_id);
            if ($connection['status'] === 'success') {
                $API = $connection['API'];
                $profiles_from_mikrotik = $API->comm("/ip/hotspot/user/profile/print");
                $API->disconnect();

                $db_profiles = [];
                if (isset($koneksi) && $koneksi->ping()) {
                    $sql_db_profiles = "SELECT nama_paket, harga, harga_jual FROM paket_layanan";
                    $result_db_profiles = mysqli_query($koneksi, $sql_db_profiles);
                    if ($result_db_profiles) {
                        while ($row = mysqli_fetch_assoc($result_db_profiles)) {
                            $db_profiles[$row['nama_paket']] = [
                                'price' => $row['harga'],
                                'sprice' => (float)($row['harga_jual'] ?? '0.00'),
                            ];
                        }
                    }
                }
                
                $merged_profiles = [];
                foreach ($profiles_from_mikrotik as $mt_profile) {
                    $profile_name = $mt_profile['name'] ?? null;
                    if ($profile_name) {
                        $merged_profile = $mt_profile;
                        
                        $merged_profile['price'] = $db_profiles[$profile_name]['price'] ?? '0';
                        $merged_profile['sprice'] = $db_profiles[$profile_name]['sprice'] ?? '0';

                        $merged_profile['validity'] = $mt_profile['session-timeout'] ?? 'Tidak Terbatas';
                        $merged_profile['status-mode-kadaluwarsa'] = 'Tidak Ada';
                        $merged_profile['user-key'] = 'Disable';
                        
                        $merged_profiles[] = $merged_profile;
                    }
                }

                echo json_encode(['status' => 'success', 'profiles' => $merged_profiles]);

            } else {
                echo json_encode($connection);
            }
            break;

        case 'delete_hotspot_profile':
            $input = json_decode(file_get_contents('php://input'), true);
            $profile_name = $input['profile_name'] ?? '';

            if (empty($profile_name)) {
                echo json_encode(['status' => 'error', 'message' => 'Nama profil tidak boleh kosong.']);
                exit();
            }

            // Gunakan $selected_mikrotik_config_id untuk terhubung ke MikroTik spesifik
            $connection = connectToMikrotik($koneksi, $selected_mikrotik_config_id);
            if ($connection['status'] === 'success') {
                $API = $connection['API'];

                try {
                    $API->write('/ip/hotspot/user/profile/print', false);
                    $API->write('?name=' . $profile_name, true);
                    $profile_id = null;
                    $profiles = $API->read();

                    if (is_array($profiles)) {
                        foreach ($profiles as $profile) {
                            if (isset($profile['name']) && $profile['name'] === $profile_name) {
                                $profile_id = $profile['.id'];
                                break;
                            }
                        }
                    }

                    if ($profile_id) {
                        $existing_scheduler = $API->comm("/system/scheduler/print", ["?name" => "auto-remove-{$profile_name}"]);
                        if (!empty($existing_scheduler)) {
                            $scheduler_id = $existing_scheduler[0]['.id'];
                            $API->comm("/system/scheduler/remove", [".id" => $scheduler_id]);
                        }

                        $response = $API->comm("/ip/hotspot/user/profile/remove", [
                            ".id" => $profile_id
                        ]);
                        $API->disconnect();

                        if (isset($koneksi) && $koneksi->ping()) {
                            $sql_delete_db = "DELETE FROM paket_layanan WHERE nama_paket = ?";
                            $stmt_delete_db = $koneksi->prepare($sql_delete_db);
                            $stmt_delete_db->bind_param("s", $profile_name);
                            if (!$stmt_delete_db->execute()) {
                                error_log("ERROR: Gagal menghapus paket layanan dari DB: " . $stmt_delete_db->error);
                            }
                            $stmt_delete_db->close();
                        }

                        if (isset($response['!trap'])) {
                            echo json_encode(['status' => 'error', 'message' => 'Gagal menghapus profil dari Mikrotik: ' . ($response['!trap'][0]['message'] ?? 'Kesalahan tidak diketahui dari Mikrotik')]);
                        } else {
                            echo json_encode(['status' => 'success', 'message' => 'Profil hotspot "' . $profile_name . '" berhasil dihapus dari Mikrotik dan database lokal.']);
                        }
                    } else {
                        $API->disconnect();
                        if (isset($koneksi) && $koneksi->ping()) {
                            $sql_delete_db = "DELETE FROM paket_layanan WHERE nama_paket = ?";
                            $stmt_delete_db = $koneksi->prepare($sql_delete_db);
                            $stmt_delete_db->bind_param("s", $profile_name);
                            if ($stmt_delete_db->execute() && $stmt_delete_db->affected_rows > 0) {
                                echo json_encode(['status' => 'warning', 'message' => 'Profil hotspot "' . $profile_name . '" tidak ditemukan di Mikrotik, namun berhasil dihapus dari database lokal.']);
                            } else {
                                echo json_encode(['status' => 'error', 'message' => 'Profil hotspot "' . $profile_name . '" tidak ditemukan di Mikrotik maupun database lokal.']);
                            }
                            $stmt_delete_db->close();
                        } else {
                            echo json_encode(['status' => 'error', 'message' => 'Profil hotspot "' . $profile_name . '" tidak ditemukan di MikroTik.']);
                        }
                    }

                } catch (Exception $e) {
                    $API->disconnect();
                    error_log("ERROR: Koneksi MikroTik gagal atau error: " . $e->getMessage());
                    echo json_encode(['status' => 'error', 'message' => 'Koneksi MikroTik gagal atau error: ' . $e->getMessage()]);
                }
            } else {
                echo json_encode($connection);
            }
            break;

        case 'remove_hotspot_user_profile':
            $profile_id = $input_data['id'] ?? null;

            if (empty($profile_id)) {
                echo json_encode(['status' => 'error', 'message' => 'ID profil tidak valid.']);
                exit();
            }

            // Gunakan $selected_mikrotik_config_id untuk terhubung ke MikroTik spesifik
            $connection = connectToMikrotik($koneksi, $selected_mikrotik_config_id);
            if ($connection['status'] === 'success') {
                $API = $connection['API'];
                $profile_details = $API->comm("/ip/hotspot/user/profile/print", [".id" => $profile_id]);
                $profile_name_to_delete_scheduler = $profile_details[0]['name'] ?? null;

                if ($profile_name_to_delete_scheduler) {
                    $existing_scheduler = $API->comm("/system/scheduler/print", ["?name" => "auto-remove-{$profile_name_to_delete_scheduler}"]);
                    if (!empty($existing_scheduler)) {
                        $scheduler_id = $existing_scheduler[0]['.id'];
                        $API->comm("/system/scheduler/remove", [".id" => $scheduler_id]);
                    }
                }

                $response = $API->comm("/ip/hotspot/user/profile/remove", [
                    ".id" => $profile_id
                ]);
                $API->disconnect();

                if ($profile_name_to_delete_scheduler && isset($koneksi) && $koneksi->ping()) {
                    $sql_delete_db = "DELETE FROM paket_layanan WHERE nama_paket = ?";
                    $stmt_delete_db = $koneksi->prepare($sql_delete_db);
                    $stmt_delete_db->bind_param("s", $profile_name_to_delete_scheduler);
                    if (!$stmt_delete_db->execute()) {
                        error_log("ERROR: Gagal menghapus paket layanan dari DB (remove_hotspot_user_profile): " . $stmt_delete_db->error);
                    }
                    $stmt_delete_db->close();
                }

                if (isset($response['!trap'])) {
                    echo json_encode(['status' => 'error', 'message' => 'Gagal menghapus profil: ' . ($response['!trap'][0]['message'] ?? 'Kesalahan tidak diketahui dari Mikrotik')]);
                } else {
                    echo json_encode(['status' => 'success', 'message' => 'Profil hotspot berhasil dihapus.']);
                }
            } else {
                echo json_encode($connection);
            }
            break;

        case 'get_hotspot_users':
            $filter_search = $_GET['search'] ?? '';
            $filter_profile = $_GET['profile'] ?? 'all';
            $filter_status = $_GET['status'] ?? 'all';

            // Gunakan $selected_mikrotik_config_id untuk terhubung ke MikroTik spesifik
            $connection = connectToMikrotik($koneksi, $selected_mikrotik_config_id);
            if ($connection['status'] === 'success') {
                $API = $connection['API'];

                // Ambil semua pengguna hotspot
                $users_from_mikrotik = $API->comm("/ip/hotspot/user/print");
                
                // Ambil semua pengguna hotspot aktif
                $active_users_from_mikrotik = $API->comm("/ip/hotspot/active/print");
                
                $API->disconnect();

                // Buat map dari pengguna aktif untuk pencarian cepat
                $active_users_map = [];
                if (!empty($active_users_from_mikrotik) && is_array($active_users_from_mikrotik)) {
                    foreach ($active_users_from_mikrotik as $active_user) {
                        if (isset($active_user['user'])) {
                            $active_users_map[$active_user['user']] = $active_user;
                        }
                    }
                }

                $filtered_users = [];
                if (!empty($users_from_mikrotik) && is_array($users_from_mikrotik)) {
                    foreach ($users_from_mikrotik as $user) {
                        $match_search = true;
                        $match_profile = true;
                        $match_status = true;

                        // Gabungkan data aktif jika pengguna ditemukan
                        if (isset($active_users_map[$user['name']])) {
                            $active_data = $active_users_map[$user['name']];
                            $user['session-time-left'] = $active_data['session-time-left'] ?? 'N/A';
                            $user['uptime'] = $active_data['uptime'] ?? '0s';
                            $user['bytes-in'] = $active_data['bytes-in'] ?? 0;
                            $user['bytes-out'] = $active_data['bytes-out'] ?? 0;
                            $user['mac-address'] = $active_data['mac-address'] ?? $user['mac-address']; // Prefer active MAC
                            $user['address'] = $active_data['address'] ?? $user['address']; // Prefer active IP
                            $user['server'] = $active_data['server'] ?? $user['server']; // Prefer active server
                            $user['login-by'] = $active_data['login-by'] ?? $user['login-by']; // Prefer active login method
                        } else {
                            // Set default jika tidak aktif
                            $user['session-time-left'] = 'N/A'; // Default jika tidak aktif
                            $user['uptime'] = '0s';
                            $user['bytes-in'] = 0;
                            $user['bytes-out'] = 0;
                            // MAC address dan IP address mungkin masih ada dari data user jika diset statis
                            // $user['mac-address'] tetap dari user/print jika ada, atau N/A
                            // $user['address'] tetap dari user/print jika ada, atau N/A
                        }


                        if ($filter_search) {
                            $username = $user['name'] ?? '';
                            $comment = $user['comment'] ?? '';
                            if (stripos($username, $filter_search) === false && stripos($comment, $filter_search) === false) {
                                $match_search = false;
                            }
                        }

                        if ($filter_profile !== 'all') {
                            if (($user['profile'] ?? '') !== $filter_profile) {
                                $match_profile = false;
                            }
                        }

                        $is_disabled = ($user['disabled'] ?? 'false') === 'true';

                        $current_user_status = 'enabled';
                        if ($is_disabled) {
                            $current_user_status = 'disabled';
                        }
                        if (isset($user['comment'])) {
                            $comment_parts = explode(' | ', $user['comment']);
                            $exp_str_from_comment = $comment_parts[0]; 
                            if (preg_match('/^\d{4}-\d{2}-\d{2}\s\d{2}:\d{2}:\d{2}$/', $exp_str_from_comment)) {
                                try {
                                    $expiry_datetime = new DateTime($exp_str_from_comment);
                                    $now_datetime = new DateTime();
                                    if ($expiry_datetime < $now_datetime) {
                                        $current_user_status = 'expired';
                                    }
                                } catch (Exception $e) {
                                    error_log("ERROR: Gagal mengurai tanggal kedaluwarsa '{$exp_str_from_comment}' dari komentar pengguna: " . $e->getMessage());
                                }
                            }
                        }


                        if ($filter_status !== 'all') {
                            if ($current_user_status !== $filter_status) {
                                $match_status = false;
                            }
                        }

                        if ($match_search && $match_profile && $match_status) {
                            $filtered_users[] = $user;
                        }
                    }
                    echo json_encode(['status' => 'success', 'users' => $filtered_users]);
                } else {
                    echo json_encode(['status' => 'success', 'users' => [], 'message' => 'Tidak ada pengguna hotspot ditemukan dari Mikrotik.']);
                }
            } else {
                echo json_encode($connection);
            }
            break;

        case 'get_hotspot_user_detail':
            $user_id = $_GET['id'] ?? null;
            if (!$user_id) {
                echo json_encode(['status' => 'error', 'message' => 'ID pengguna tidak valid.']);
                exit();
            }
            // Gunakan $selected_mikrotik_config_id untuk terhubung ke MikroTik spesifik
            $connection = connectToMikrotik($koneksi, $selected_mikrotik_config_id);
            if ($connection['status'] === 'success') {
                $API = $connection['API'];
                $user_detail = $API->comm("/ip/hotspot/user/print", [".id" => $user_id]);
                $API->disconnect();
                if (!empty($user_detail)) {
                    echo json_encode(['status' => 'success', 'user' => $user_detail[0]]);
                } else {
                    echo json_encode(['status' => 'error', 'message' => 'Pengguna tidak ditemukan.']);
                }
            } else {
                echo json_encode($connection);
            }
            break;

        case 'update_hotspot_user':
            $user_id = $input_data['id'] ?? null;
            if (!$user_id) {
                echo json_encode(['status' => 'error', 'message' => 'ID pengguna tidak valid.']);
                exit();
            }
            // Gunakan $selected_mikrotik_config_id untuk terhubung ke MikroTik spesifik
            $connection = connectToMikrotik($koneksi, $selected_mikrotik_config_id);
            if ($connection['status'] === 'success') {
                $API = $connection['API'];
                $params = [".id" => $user_id];
                foreach (['name', 'password', 'profile', 'server', 'mac-address', 'limit-uptime', 'limit-bytes-total', 'comment', 'disabled'] as $field) {
                    if (isset($input_data[$field])) {
                        if (in_array($field, ['limit-uptime']) && empty($input_data[$field])) {
                            $params[$field] = '';
                        } elseif (in_array($field, ['limit-bytes-total']) && empty($input_data[$field])) {
                            $params[$field] = '';
                        } else {
                            $params[$field] = $input_data[$field];
                        }
                    }
                }
                $response = $API->comm("/ip/hotspot/user/set", $params);
                $API->disconnect();
                if (isset($response['!trap'])) {
                    echo json_encode(['status' => 'error', 'message' => 'Gagal memperbarui pengguna: ' . ($response['!trap'][0]['message'] ?? 'Kesalahan tidak diketahui')]);
                } else {
                    echo json_encode(['status' => 'success', 'message' => 'Pengguna berhasil diperbarui.']);
                }
            } else {
                echo json_encode($connection);
            }
            break;

        case 'remove_hotspot_user':
            $id = $input_data['id'] ?? '';
            $username_to_delete = $input_data['username'] ?? '';

            if (empty($id)) {
                echo json_encode(['status' => 'error', 'message' => 'ID pengguna tidak ditemukan.']);
                exit();
            }

            // Gunakan $selected_mikrotik_config_id untuk terhubung ke MikroTik spesifik
            $connection = connectToMikrotik($koneksi, $selected_mikrotik_config_id);
            if ($connection['status'] === 'success') {
                $API = $connection['API'];
                $response = $API->comm("/ip/hotspot/user/remove", [
                    ".id" => $id
                ]);
                $API->disconnect();

                $mikrotik_success = !isset($response['!trap']) || (isset($response['!trap'][0]['message']) && strpos($response['!trap'][0]['message'], 'no such item') !== false);
                $db_deleted = false;

                if ($username_to_delete && isset($koneksi) && $koneksi->ping()) {
                    // Modifikasi query DELETE untuk menyertakan mikrotik_id
                    $sql_delete_db = "DELETE FROM vouchers WHERE username = ?";
                    if ($selected_mikrotik_config_id !== null) {
                        $sql_delete_db .= " AND mikrotik_id = ?";
                    }
                    
                    if ($stmt_delete_db = $koneksi->prepare($sql_delete_db)) {
                        if ($selected_mikrotik_config_id !== null) {
                            $stmt_delete_db->bind_param("si", $username_to_delete, $selected_mikrotik_config_id);
                        } else {
                            $stmt_delete_db->bind_param("s", $username_to_delete);
                        }
                        
                        if ($stmt_delete_db->execute()) {
                            if ($stmt_delete_db->affected_rows > 0) {
                                $db_deleted = true;
                                error_log("INFO: User '{$username_to_delete}' dihapus dari DB."); // Log aktivitas
                            } else {
                                error_log("WARNING: Voucher '{$username_to_delete}' tidak ditemukan di database untuk dihapus.");
                            }
                        } else {
                            error_log("ERROR: Database error (hapus voucher by username '{$username_to_delete}'): " . $stmt_delete_db->error);
                        }
                        $stmt_delete_db->close();
                    } else {
                        error_log("ERROR: Database error (siapkan hapus voucher by username '{$username_to_delete}'): " . $koneksi->error);
                    }
                }

                if ($mikrotik_success && $db_deleted) {
                    echo json_encode(['status' => 'success', 'message' => 'Pengguna hotspot berhasil dihapus dari MikroTik dan database.']);
                } elseif ($mikrotik_success) {
                    echo json_encode(['status' => 'warning', 'message' => 'Pengguna hotspot berhasil dihapus dari MikroTik, tetapi tidak ditemukan di database.']);
                } elseif ($db_deleted) {
                    echo json_encode(['status' => 'warning', 'message' => 'Pengguna hotspot tidak ditemukan di MikroTik, tetapi berhasil dihapus dari database.']);
                } else {
                    echo json_encode(['status' => 'error', 'message' => 'Gagal menghapus pengguna: ' . ($response['!trap'][0]['message'] ?? 'Kesalahan tidak diketahui dari Mikrotik')]);
                }
            } else {
                echo json_encode($connection);
            }
            break;

        case 'enable_hotspot_user':
            $id = $input_data['id'] ?? '';
            if (empty($id)) {
                echo json_encode(['status' => 'error', 'message' => 'ID pengguna tidak ditemukan.']);
                exit();
            }
            // Gunakan $selected_mikrotik_config_id untuk terhubung ke MikroTik spesifik
            $connection = connectToMikrotik($koneksi, $selected_mikrotik_config_id);
            if ($connection['status'] === 'success') {
                $API = $connection['API'];
                $response = $API->comm("/ip/hotspot/user/set", [".id" => $id, "disabled" => "no"]);
                $API->disconnect();
                if (isset($response['!trap'])) {
                    echo json_encode(['status' => 'error', 'message' => 'Gagal mengaktifkan pengguna: ' . ($response['!trap'][0]['message'] ?? 'Kesalahan tidak diketahui')]);
                } else {
                    echo json_encode(['status' => 'success', 'message' => 'Pengguna berhasil diaktifkan.']);
                }
            } else {
                echo json_encode($connection);
            }
            break;

        case 'disable_hotspot_user':
            $id = $input_data['id'] ?? '';
            if (empty($id)) {
                echo json_encode(['status' => 'error', 'message' => 'ID pengguna tidak ditemukan.']);
                exit();
            }
            // Gunakan $selected_mikrotik_config_id untuk terhubung ke MikroTik spesifik
            $connection = connectToMikrotik($koneksi, $selected_mikrotik_config_id);
            if ($connection['status'] === 'success') {
                $API = $connection['API'];
                $response = $API->comm("/ip/hotspot/user/set", [".id" => $id, "disabled" => "yes"]);
                $API->disconnect();
                if (isset($response['!trap'])) {
                    echo json_encode(['status' => 'error', 'message' => 'Gagal menonaktifkan pengguna: ' . ($response['!trap'][0]['message'] ?? 'Kesalahan tidak diketahui')]);
                } else {
                    echo json_encode(['status' => 'success', 'message' => 'Pengguna berhasil dinonaktifkan.']);
                }
            } else {
                echo json_encode($connection);
            }
            break;

        case 'reset_hotspot_user_uptime_data':
            $id = $input_data['id'] ?? '';
            if (empty($id)) {
                echo json_encode(['status' => 'error', 'message' => 'ID pengguna tidak ditemukan.']);
                exit();
            }
            // Gunakan $selected_mikrotik_config_id untuk terhubung ke MikroTik spesifik
            $connection = connectToMikrotik($koneksi, $selected_mikrotik_config_id);
            if ($connection['status'] === 'success') {
                $API = $connection['API'];
                $response = $API->comm("/ip/hotspot/user/reset-counters", [".id" => $id]);
                $API->disconnect();
                if (isset($response['!trap'])) {
                    echo json_encode(['status' => 'error', 'message' => 'Gagal mereset counter: ' . ($response['!trap'][0]['message'] ?? 'Kesalahan tidak diketahui')]);
                } else {
                    echo json_encode(['status' => 'success', 'message' => 'Counter pengguna berhasil direset.']);
                }
            } else {
                echo json_encode($connection);
            }
            break;

        case 'remove_expired_hotspot_users':
            // Gunakan $selected_mikrotik_config_id untuk terhubung ke MikroTik spesifik
            $connection = connectToMikrotik($koneksi, $selected_mikrotik_config_id);
            if ($connection['status'] === 'success') {
                $API = $connection['API'];
                
                $users_to_delete = [];
                
                // --- 1. Ambil semua pengguna dari database lokal (vouchers) ---
                $local_db_users = [];
                if (isset($koneksi) && $koneksi->ping()) {
                    $sql = "SELECT id, username, profile, comment FROM vouchers"; // Ambil data relevan
                    if ($selected_mikrotik_config_id !== null) {
                        $sql .= " WHERE mikrotik_id = ?";
                    }
                    $result = null;
                    if ($stmt = $koneksi->prepare($sql)) {
                        if ($selected_mikrotik_config_id !== null) {
                            $stmt->bind_param("i", $selected_mikrotik_config_id);
                        }
                        $stmt->execute();
                        $result = $stmt->get_result();
                        $stmt->close();
                    } else {
                        error_log("ERROR: Gagal menyiapkan statement SQL untuk mengambil voucher dari DB (remove_expired_hotspot_users): " . $koneksi->error);
                    }

                    if ($result) {
                        while ($row = mysqli_fetch_assoc($result)) {
                            $local_db_users[$row['username']] = $row;
                        }
                    } else {
                        error_log("ERROR: Gagal mengambil voucher dari database untuk penghapusan kedaluwarsa: " . mysqli_error($koneksi));
                    }
                }

                // --- 2. Ambil semua pengguna dari MikroTik ---
                $mikrotik_users = $API->comm("/ip/hotspot/user/print");
                $mikrotik_users_map = [];
                if (is_array($mikrotik_users)) {
                    foreach ($mikrotik_users as $user) {
                        if (isset($user['name'])) {
                            $mikrotik_users_map[$user['name']] = $user;
                        }
                    }
                }

                // --- 3. Bandingkan kedua daftar dan tentukan siapa yang harus dihapus ---
                foreach ($local_db_users as $local_username => $local_user_data) {
                    $username = $local_username;
                    $mikrotik_user = $mikrotik_users_map[$username] ?? null;
                    $mikrotik_id = $mikrotik_user['.id'] ?? null;

                    $is_disabled = false;
                    $session_time_left_zero = false;
                    $uptime_equals_limit_uptime = false;
                    $comment_indicates_expired = false;
                    $parsed_expiry_date = null;
                    $is_only_in_db = ($mikrotik_user === null);

                    $reason_for_deletion = '';
                    $should_delete = false;


                    if ($is_only_in_db) {
                        $should_delete = true;
                        $reason_for_deletion = 'Tidak ditemukan di Mikrotik (kemungkinan dihapus secara manual dari WinBox)';
                    } else {
                        $is_disabled = ($mikrotik_user['disabled'] ?? 'false') === 'true';
                        $session_time_left_zero = (isset($mikrotik_user['session-time-left']) && $mikrotik_user['session-time-left'] === '0s');
                        $uptime_equals_limit_uptime = (isset($mikrotik_user['uptime']) && isset($mikrotik_user['limit-uptime']) && $mikrotik_user['uptime'] === $mikrotik_user['limit-uptime'] && $mikrotik_user['limit-uptime'] !== '0s');
                        
                        if (isset($mikrotik_user['comment'])) {
                            $comment_parts = explode(' | ', $mikrotik_user['comment']);
                            $exp_str_from_comment = $comment_parts[0]; 
                            if (preg_match('/^\d{4}-\d{2}-\d{2}\s\d{2}:\d{2}:\d{2}$/', $exp_str_from_comment)) {
                                try {
                                    $parsed_expiry_date = new DateTime($exp_str_from_comment);
                                    $now_datetime = new DateTime();
                                    if ($parsed_expiry_date < $now_datetime) {
                                        $comment_indicates_expired = true;
                                    }
                                } catch (Exception $e) {
                                    error_log("ERROR: Gagal mengurai tanggal kedaluwarsa '{$exp_str_from_comment}' dari komentar MikroTik: " . $e->getMessage());
                                }
                            }
                        }
                        
                        if ($is_disabled) {
                            $should_delete = true;
                            $reason_for_deletion = 'Dinonaktifkan di Mikrotik';
                        } elseif ($comment_indicates_expired) {
                            $should_delete = true;
                            $reason_for_deletion = 'Komentar menunjukkan kedaluwarsa';
                        } elseif ($session_time_left_zero && (isset($mikrotik_user['limit-uptime']) && $mikrotik_user['limit-uptime'] !== '0s')) {
                            $should_delete = true;
                            $reason_for_deletion = 'Waktu sesi tersisa 0 detik (batas uptime tercapai)';
                        } elseif ($uptime_equals_limit_uptime) {
                            $should_delete = true;
                            $reason_for_deletion = 'Uptime sama persis dengan limit-uptime';
                        }
                    }

                    if ($should_delete) {
                        $users_to_delete[] = [
                            'mikrotik_id' => $mikrotik_id,
                            'username' => $username,
                            'reason' => $reason_for_deletion,
                            'delete_from_mikrotik' => !$is_only_in_db
                        ];
                    }
                }

                $mikrotik_deleted_count = 0;
                $db_deleted_count = 0;
                $errors = [];

                // --- 4. Lakukan penghapusan ---
                foreach ($users_to_delete as $user_data) {
                    $mikrotik_id = $user_data['mikrotik_id'];
                    $username = $user_data['username'];
                    $reason = $user_data['reason'];

                    $mikrotik_delete_successful = false;

                    if ($user_data['delete_from_mikrotik'] && $mikrotik_id) {
                        $response_mikrotik = $API->comm("/ip/hotspot/user/remove", [".id" => $mikrotik_id]);
                        if (isset($response_mikrotik['!trap'])) {
                            if (strpos(($response_mikrotik['!trap'][0]['message'] ?? ''), 'no such item') === false) {
                                $errors[] = "Gagal menghapus pengguna '{$username}' (ID Mikrotik: {$mikrotik_id}, Alasan: {$reason}) dari Mikrotik: " . ($response_mikrotik['!trap'][0]['message'] ?? 'Unknown error');
                                error_log("ERROR: Mikrotik API Error (hapus user {$username}, Alasan: {$reason}): " . json_encode($response_mikrotik['!trap']));
                            } else {
                                $mikrotik_delete_successful = true;
                            }
                        } else {
                            $mikrotik_delete_successful = true;
                        }
                    } else {
                        $mikrotik_delete_successful = true; 
                    }

                    if ($mikrotik_delete_successful) {
                        $mikrotik_deleted_count++;
                    }

                    if (isset($koneksi) && $koneksi->ping()) {
                        // Modifikasi query DELETE untuk menyertakan mikrotik_id
                        $sql_delete_db = "DELETE FROM vouchers WHERE username = ?";
                        if ($selected_mikrotik_config_id !== null) { // Filter berdasarkan ID MikroTik yang saat ini dipilih
                            $sql_delete_db .= " AND mikrotik_id = ?";
                        }
                        
                        if ($stmt_delete_db = $koneksi->prepare($sql_delete_db)) {
                            if ($selected_mikrotik_config_id !== null) {
                                $stmt_delete_db->bind_param("si", $username, $selected_mikrotik_config_id);
                            } else {
                                $stmt_delete_db->bind_param("s", $username);
                            }
                            
                            if ($stmt_delete_db->execute()) {
                                if ($stmt_delete_db->affected_rows > 0) {
                                    $db_deleted_count++;
                                    error_log("INFO: Voucher '{$username}' berhasil dihapus dari database lokal. Baris terpengaruh: " . $stmt_delete_db->affected_rows); // Log aktivitas
                                } else {
                                    error_log("WARNING: Voucher '{$username}' tidak ditemukan di database lokal untuk dihapus. Baris terpengaruh: " . $stmt_delete_db->affected_rows);
                                    // If not found in DB but deleted from Mikrotik, still count as success in Mikrotik side
                                    if ($mikrotik_delete_successful) {
                                        $errors[] = "Voucher '{$username}' dihapus dari Mikrotik tetapi tidak ditemukan di database lokal.";
                                    } else {
                                        $errors[] = "Voucher '{$username}' tidak ditemukan di database lokal.";
                                    }
                                }
                            } else {
                                $errors[] = "Gagal menghapus voucher '{$username}' dari database: " . $stmt_delete_db->error;
                                error_log("ERROR: Database error (hapus voucher {$username}): " . $stmt_delete_db->error);
                            }
                            $stmt_delete_db->close();
                        } else {
                            $errors[] = "Kesalahan database: Tidak dapat menyiapkan pernyataan hapus untuk voucher '{$username}'.";
                            error_log("ERROR: Database error (siapkan hapus voucher {$username}): " . $koneksi->error);
                        }
                    } else {
                        $errors[] = "Koneksi database tidak tersedia untuk menghapus voucher '{$username}'.";
                        error_log("ERROR: Koneksi database tidak tersedia untuk menghapus voucher.");
                    }
                }

                $API->disconnect();

                if (empty($errors)) {
                    echo json_encode(['status' => 'success', 'message' => "Berhasil menghapus {$mikrotik_deleted_count} pengguna kedaluwarsa dari Mikrotik dan {$db_deleted_count} dari database."]);
                } else {
                    echo json_encode(['status' => 'warning', 'message' => "Selesai dengan beberapa masalah: " . implode(" ", $errors), 'errors' => $errors]);
                }
            } else {
                echo json_encode($connection);
            }
            break;


        case 'upload_voucher_logo':
            // Check if upload directory exists, create if not
            if (!is_dir($upload_dir)) {
                if (!mkdir($upload_dir, 0777, true)) {
                    echo json_encode(['status' => 'error', 'message' => 'Gagal membuat direktori unggahan.']);
                    exit();
                }
            }

            if (isset($_FILES['logo']) && $_FILES['logo']['error'] === UPLOAD_ERR_OK) {
                $file_tmp_name = $_FILES['logo']['tmp_name'];
                $file_name = $_FILES['logo']['name'];
                $file_size = $_FILES['logo']['size'];
                $file_type = $_FILES['logo']['type'];
                $file_ext = strtolower(pathinfo($file_name, PATHINFO_EXTENSION));

                $allowed_extensions = ['jpg', 'jpeg', 'png', 'gif'];
                $max_file_size = 2 * 1024 * 1024; // 2MB

                if (!in_array($file_ext, $allowed_extensions)) {
                    echo json_encode(['status' => 'error', 'message' => 'Ekstensi file tidak diizinkan. Hanya JPG, JPEG, PNG, GIF.']);
                    exit();
                }

                if ($file_size > $max_file_size) {
                    echo json_encode(['status' => 'error', 'message' => 'Ukuran file terlalu besar. Maksimal 2MB.']);
                    exit();
                }

                // Delete old logo if it exists
                if (file_exists($logo_path)) {
                    unlink($logo_path);
                }

                if (move_uploaded_file($file_tmp_name, $logo_path)) {
                    echo json_encode(['status' => 'success', 'message' => 'Logo berhasil diunggah.', 'logo_url' => $logo_url]);
                } else {
                    echo json_encode(['status' => 'error', 'message' => 'Gagal memindahkan file yang diunggah.']);
                }
            } else {
                echo json_encode(['status' => 'error', 'message' => 'Tidak ada file yang diunggah atau terjadi kesalahan.']);
            }
            break;

        case 'delete_voucher_logo':
            if (file_exists($logo_path)) {
                if (unlink($logo_path)) {
                    echo json_encode(['status' => 'success', 'message' => 'Logo berhasil dihapus.']);
                } else {
                    echo json_encode(['status' => 'error', 'message' => 'Gagal menghapus logo.']);
                }
            } else {
                echo json_encode(['status' => 'warning', 'message' => 'Tidak ada logo untuk dihapus.']);
            }
            break;

        case 'get_voucher_logo_url':
            if (file_exists($logo_path)) {
                echo json_encode(['status' => 'success', 'logo_url' => $logo_url]);
            } else {
                echo json_encode(['status' => 'success', 'logo_url' => '']); // Return empty if no logo
            }
            break;

        case 'get_financial_summary':
            $today_income = 0;
            $month_income = 0;
            $all_time_income = 0;

            if (isset($koneksi) && $koneksi->ping()) {
                $sql_today = "SELECT COALESCE(SUM(price), 0) AS total_today FROM financial_records WHERE DATE(transaction_date) = CURDATE()";
                $result_today = mysqli_query($koneksi, $sql_today);
                if ($result_today && $row_today = mysqli_fetch_assoc($result_today)) {
                    $today_income = (float)$row_today['total_today'];
                }
            }
            $sql_month = "SELECT COALESCE(SUM(price), 0) AS total_month FROM financial_records WHERE YEAR(transaction_date) = YEAR(CURDATE()) AND MONTH(transaction_date) = MONTH(CURDATE())";
            $result_month = mysqli_query($koneksi, $sql_month);
            if ($result_month && $row_month = mysqli_fetch_assoc($result_month)) {
                $month_income = (float)$row_month['total_month'];
            }
            $sql_all_time = "SELECT COALESCE(SUM(price), 0) AS total_all_time FROM financial_records";
            $result_all_time = mysqli_query($koneksi, $sql_all_time);
            if ($result_all_time && $row_all_time = mysqli_fetch_assoc($result_all_time)) {
                $all_time_income = (float)$row_all_time['total_all_time'];
            }

            echo json_encode([
                'status' => 'success',
                'today_income' => $today_income,
                'month_income' => $month_income,
                'all_time_income' => $all_time_income
            ]);
            break;

        case 'get_all_financial_records':
            $records = [];
            if (isset($koneksi) && $koneksi->ping()) {
                $sql = "SELECT id, username, profile_name, price, selling_price, transaction_date FROM financial_records ORDER BY transaction_date DESC";
                $result = mysqli_query($koneksi, $sql);
                if ($result) {
                    while ($row = mysqli_fetch_assoc($result)) {
                        $records[] = $row;
                    }
                    echo json_encode(['status' => 'success', 'records' => $records]);
                } else {
                    error_log("ERROR: Gagal mengambil semua catatan keuangan: " . mysqli_error($koneksi));
                    echo json_encode(['status' => 'error', 'message' => 'Gagal mengambil semua catatan keuangan: ' . mysqli_error($koneksi)]);
                }
            } else {
                error_log("ERROR: Koneksi database tidak tersedia untuk get_all_financial_records.");
                echo json_encode(['status' => 'error', 'message' => 'Koneksi database tidak tersedia.']);
            }
            break;

        case 'get_hotspot_active_users':
            $filter_server = $_GET['server'] ?? 'all';
            $connection = connectToMikrotik($koneksi, $selected_mikrotik_config_id); // Gunakan config_id di sini
            if ($connection['status'] === 'success') {
                $API = $connection['API'];
                
                // Mulai dengan perintah dasar untuk print hotspot active user
                $API->write('/ip/hotspot/active/print');
                
                // Tambahkan filter server jika bukan 'all'
                if ($filter_server !== 'all') {
                    $API->write('?server=' . $filter_server); // Menambahkan filter server
                }
                
                // Baca respons dari MikroTik
                $active_users = $API->read();

                $API->disconnect();
                echo json_encode(['status' => 'success', 'active_users' => $active_users]);
            } else {
                echo json_encode($connection);
            }
            break;

        case 'remove_hotspot_active_user':
            $id = $input_data['id'] ?? '';
            if (empty($id)) {
                echo json_encode(['status' => 'error', 'message' => 'ID pengguna aktif tidak ditemukan.']);
                exit();
            }
            $connection = connectToMikrotik($koneksi, $selected_mikrotik_config_id); // Gunakan config_id di sini
            if ($connection['status'] === 'success') {
                $API = $connection['API'];
                $response = $API->comm("/ip/hotspot/active/remove", [".id" => $id]);
                $API->disconnect();
                if (isset($response['!trap'])) {
                    echo json_encode(['status' => 'error', 'message' => 'Gagal menghapus pengguna aktif: ' . ($response['!trap'][0]['message'] ?? 'Kesalahan tidak diketahui')]);
                } else {
                    echo json_encode(['status' => 'success', 'message' => 'Pengguna aktif berhasil dihapus.']);
                }
            } else {
                echo json_encode($connection);
            }
            break;

        case 'get_hotspot_cookies':
            $connection = connectToMikrotik($koneksi, $selected_mikrotik_config_id); // Gunakan config_id di sini
            if ($connection['status'] === 'success') {
                $API = $connection['API'];
                $cookies = $API->comm("/ip/hotspot/cookie/print");
                $API->disconnect();
                echo json_encode(['status' => 'success', 'cookies' => $cookies]);
            } else {
                echo json_encode($connection);
            }
            break;

        case 'remove_hotspot_cookie':
            $id = $input_data['id'] ?? '';
            if (empty($id)) {
                echo json_encode(['status' => 'error', 'message' => 'ID cookie tidak ditemukan.']);
                exit();
            }
            $connection = connectToMikrotik($koneksi, $selected_mikrotik_config_id); // Gunakan config_id di sini
            if ($connection['status'] === 'success') {
                $API = $connection['API'];
                $response = $API->comm("/ip/hotspot/cookie/remove", [".id" => $id]);
                $API->disconnect();
                if (isset($response['!trap'])) {
                    echo json_encode(['status' => 'error', 'message' => 'Gagal menghapus cookie: ' . ($response['!trap'][0]['message'] ?? 'Kesalahan tidak diketahui')]);
                } else {
                    echo json_encode(['status' => 'success', 'message' => 'Cookie hotspot berhasil dihapus.']);
                }
            } else {
                echo json_encode($connection);
            }
            break;

        case 'get_hotspot_active_count':
            $connection = connectToMikrotik($koneksi, $selected_mikrotik_config_id); // Gunakan config_id di sini
            if ($connection['status'] === 'success') {
                $API = $connection['API'];
                $count = $API->comm("/ip/hotspot/active/print", ["count-only" => ""]);
                $API->disconnect();
                echo json_encode(['status' => 'success', 'count' => (int)$count]);
            } else {
                echo json_encode($connection);
            }
            break;

        case 'get_hotspot_users_count':
            $connection = connectToMikrotik($koneksi, $selected_mikrotik_config_id); // Gunakan config_id di sini
            if ($connection['status'] === 'success') {
                $API = $connection['API'];
                $count = $API->comm("/ip/hotspot/user/print", ["count-only" => ""]);
                $API->disconnect();
                echo json_encode(['status' => 'success', 'count' => (int)$count]);
            } else {
                echo json_encode($connection);
            }
            break;

        case 'get_hotspot_logs':
            $connection = connectToMikrotik($koneksi, $selected_mikrotik_config_id); // Gunakan config_id di sini
            if ($connection['status'] === 'success') {
                $API = $connection['API'];
                // Hanya mengambil log yang relevan untuk hotspot dan info
                $logs = $API->comm("/log/print", ["?topics" => "hotspot,info"]); 
                $API->disconnect();
                $recent_logs = array_slice(array_reverse($logs), 0, 30);
                echo json_encode(['status' => 'success', 'logs' => $recent_logs]);
            } else {
                echo json_encode($connection);
            }
            break;

        case 'get_interface_traffic':
            $interface = $_GET['interface'] ?? '';
            if (empty($interface)) {
                echo json_encode(['status' => 'error', 'message' => 'Nama antarmuka tidak boleh kosong.']);
                exit();
            }

            $connection = connectToMikrotik($koneksi, $selected_mikrotik_config_id); // Gunakan config_id di sini
            if ($connection['status'] === 'success') {
                $API = $connection['API'];
                $traffic_data = $API->comm("/interface/monitor-traffic", [
                    "interface" => $interface,
                    "once" => "",
                ]);
                $API->disconnect();

                if (!empty($traffic_data) && is_array($traffic_data) && isset($traffic_data[0])) {
                    $tx_bytes = $traffic_data[0]['tx-bytes'] ?? 0;
                    $rx_bytes = $traffic_data[0]['rx-bytes'] ?? 0;

                    echo json_encode([
                        'status' => 'success',
                        'traffic' => [
                            'tx' => $tx_bytes,
                            'rx' => $rx_bytes,
                        ]
                    ]);
                } else {
                    echo json_encode(['status' => 'error', 'message' => 'Gagal mendapatkan data lalu lintas atau antarmuka tidak ditemukan.']);
                }
            } else {
                echo json_encode($connection);
            }
            break;

        case 'get_ip_pools':
            $connection = connectToMikrotik($koneksi, $selected_mikrotik_config_id); // Gunakan config_id di sini
            if ($connection['status'] === 'success') {
                $API = $connection['API'];
                $pools = $API->comm("/ip/pool/print");
                $API->disconnect();
                $pool_names = [];
                foreach ($pools as $pool) {
                    if (isset($pool['name'])) {
                        $pool_names[] = $pool['name'];
                    }
                }
                echo json_encode(['status' => 'success', 'pools' => $pool_names]);
            } else {
                echo json_encode($connection);
            }
            break;

        case 'get_simple_queues':
            $connection = connectToMikrotik($koneksi, $selected_mikrotik_config_id); // Gunakan config_id di sini
            if ($connection['status'] === 'success') {
                $API = $connection['API'];
                $queues = $API->comm("/queue/simple/print", ["?dynamic" => "no"]);
                $API->disconnect();
                echo json_encode(['status' => 'success', 'queues' => $queues]);
            } else {
                echo json_encode($connection);
            }
            break;

        case 'get_hotspot_servers':
            $connection = connectToMikrotik($koneksi, $selected_mikrotik_config_id); // Gunakan config_id di sini
            if ($connection['status'] === 'success') {
                $API = $connection['API'];
                $servers = $API->comm("/ip/hotspot/print");
                $API->disconnect();
                echo json_encode(['status' => 'success', 'servers' => $servers]);
            } else {
                echo json_encode($connection);
            }
            break;

        default:
            error_log("WARNING: Aksi tidak dikenal '{$action}' diterima. Input mentah: " . file_get_contents('php://input'));
            echo json_encode(['status' => 'error', 'message' => 'Aksi tidak dikenal.']);
            break;
    }
} catch (Exception $e) {
    error_log("FATAL ERROR di mikrotik_api.php: " . $e->getMessage() . " on line " . $e->getLine());
    http_response_code(500);
    echo json_encode(['status' => 'error', 'message' => 'Terjadi kesalahan internal server. Silakan cek log server untuk detail lebih lanjut.']);
} finally {
    if (isset($koneksi) && is_object($koneksi) && method_exists($koneksi, 'close')) {
        $koneksi->close();
    }
}
?>