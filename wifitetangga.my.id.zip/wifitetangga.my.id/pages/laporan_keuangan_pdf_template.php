<?php
// C:\xampp\htdocs\billing_isp_app\pages\laporan_keuangan_pdf_template.php
// Template HTML ini akan di-include oleh laporan_keuangan.php saat membuat PDF.
// Variabel PHP seperti $report_data, $report_type, $filter_params, $app_base_url, $logo_full_physical_path tersedia di sini.

// Data perusahaan (hardcoded sesuai gambar di invoice)
$company_name = "PT Triple Zhi Network";
$company_address = "Jl Gadarmun Hangkiho Kec Baoalan Kel Tuweley , Kabupaten Tolitoli Provinsi Sulawesi Tengah 94515";
$company_email = "adm@triplezhinetwork.id";
$company_phone = "082259438445";

$report_title = "Laporan Keuangan ";
switch ($report_type) {
    case 'harian':
        $report_title .= "Harian - " . date('d F Y', strtotime($filter_params['date']));
        break;
    case 'mingguan':
        $report_title .= "Mingguan - " . date('d F Y', strtotime($filter_params['start_date'])) . " s/d " . date('d F Y', strtotime($filter_params['start_date'] . ' +6 days'));
        break;
    case 'bulanan':
        $report_title .= "Bulanan - " . date('F Y', mktime(0, 0, 0, $filter_params['month'], 1, $filter_params['year']));
        break;
    case 'tahunan':
        $report_title .= "Tahunan - " . $filter_params['year'];
        break;
    default:
        $report_title .= "Umum";
        break;
}

?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo htmlspecialchars($report_title); ?></title>
    <style>
        body { font-family: 'sans-serif'; margin: 0; padding: 20px; font-size: 10px; }
        .header-section { text-align: center; margin-bottom: 20px; }
        .header-section img { max-width: 100px; height: auto; float: left; margin-right: 15px; } /* Adjust size and float for header */
        .header-section h1 { margin: 0; font-size: 1.5em; text-align: center; }
        .header-section p { margin: 2px 0; font-size: 0.9em; text-align: center; }
        .clearfix::after { content: ""; clear: both; display: table; }

        .report-info { text-align: center; margin-bottom: 20px; }
        .report-info h2 { font-size: 1.3em; margin-bottom: 5px; }
        .report-info p { font-size: 1em; margin: 0; }

        .data-table { width: 100%; border-collapse: collapse; margin-top: 20px; }
        .data-table th, .data-table td { border: 1px solid #ddd; padding: 8px; text-align: left; }
        .data-table th { background-color: #f2f2f2; font-weight: bold; }
        .data-table tfoot th { background-color: #e0e0e0; font-weight: bold; }
        .text-right { text-align: right; }
        .text-center { text-align: center; }
    </style>
</head>
<body>
    <div class="container">
        <div class="header-section clearfix">
            <?php
            // Coba memuat gambar dari jalur fisik terlebih dahulu
            // Pastikan $logo_full_physical_path dikirim dari laporan_keuangan.php
            if (isset($logo_full_physical_path) && file_exists($logo_full_physical_path)) :
            ?>
                <img src="file://<?php echo htmlspecialchars($logo_full_physical_path); ?>" alt="Logo Perusahaan">
            <?php
            // Fallback ke URL publik jika jalur fisik tidak berhasil atau tidak tersedia
            elseif (!empty($app_base_url)):
            ?>
                <img src="<?php echo htmlspecialchars($app_base_url); ?>/assets/images/Logo-TZN.png" alt="Logo Perusahaan">
            <?php endif; ?>
            <h1><?php echo htmlspecialchars($company_name); ?></h1>
            <p><?php echo nl2br(htmlspecialchars($company_address)); ?></p>
            <p>Email: <?php echo htmlspecialchars($company_email); ?> | Telepon: <?php echo htmlspecialchars($company_phone); ?></p>
        </div>

        <div class="report-info">
            <h2><?php echo htmlspecialchars($report_title); ?></h2>
        </div>

        <table class="data-table">
            <thead>
                <tr>
                    <th>Periode</th>
                    <th>Pemasukan ISP</th>
                    <th>Pemasukan Manual</th>
                    <th>Total Pemasukan</th>
                    <th>Pengeluaran</th>
                    <th>Balance</th>
                </tr>
            </thead>
            <tbody>
                <?php 
                $grand_total_pemasukan_isp = 0;
                $grand_total_pemasukan_manual = 0;
                $grand_total_pemasukan = 0;
                $grand_total_pengeluaran = 0;
                $grand_total_balance = 0;
                ?>
                <?php if (!empty($report_data)): ?>
                    <?php foreach ($report_data as $row): ?>
                        <tr>
                            <td><?php echo htmlspecialchars($row['period']); ?></td>
                            <td class="text-right">Rp <?php echo number_format($row['pemasukan_isp'], 0, ',', '.'); ?></td>
                            <td class="text-right">Rp <?php echo number_format($row['pemasukan_manual'], 0, ',', '.'); ?></td>
                            <td class="text-right">Rp <?php echo number_format($row['total_pemasukan'], 0, ',', '.'); ?></td>
                            <td class="text-right">Rp <?php echo number_format($row['pengeluaran'], 0, ',', '.'); ?></td>
                            <td class="text-right">Rp <?php echo number_format($row['balance'], 0, ',', '.'); ?></td>
                        </tr>
                        <?php 
                        $grand_total_pemasukan_isp += $row['pemasukan_isp'];
                        $grand_total_pemasukan_manual += $row['pemasukan_manual'];
                        $grand_total_pemasukan += $row['total_pemasukan'];
                        $grand_total_pengeluaran += $row['pengeluaran'];
                        $grand_total_balance += $row['balance'];
                        ?>
                    <?php endforeach; ?>
                <?php else: ?>
                    <tr><td colspan="6" class="text-center">Tidak ada data laporan untuk periode ini.</td></tr>
                <?php endif; ?>
            </tbody>
            <tfoot>
                <tr>
                    <th>Total Keseluruhan</th>
                    <th class="text-right">Rp <?php echo number_format($grand_total_pemasukan_isp, 0, ',', '.'); ?></th>
                    <th class="text-right">Rp <?php echo number_format($grand_total_pemasukan_manual, 0, ',', '.'); ?></th>
                    <th class="text-right">Rp <?php echo number_format($grand_total_pemasukan, 0, ',', '.'); ?></th>
                    <th class="text-right">Rp <?php echo number_format($grand_total_pengeluaran, 0, ',', '.'); ?></th>
                    <th class="text-right">Rp <?php echo number_format($grand_total_balance, 0, ',', '.'); ?></th>
                </tr>
            </tfoot>
        </table>
    </div>
</body>
</html>