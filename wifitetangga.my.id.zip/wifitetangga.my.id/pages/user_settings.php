<?php
// C:\xampp\htdocs\billing_isp_app\pages\user_settings.php
ob_start();
ini_set('session.use_strict_mode', 1);
ini_set('session.cookie_httponly', 1);
ini_set('session.cookie_samesite', 'Lax');
if (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on') {
    ini_set('session.cookie_secure', 1);
}
session_start();
include '../config/koneksi.php';
include '../includes/header.php'; // Header akan meng-include sidebar dan fungsi hasRole()

// Redirect jika bukan superadmin
if (!hasRole('superadmin')) {
    header('Location: dashboard.php');
    exit();
}

$message = '';
$user_id_to_edit = null;
$user_data = [];

// --- Menampilkan Pesan Setelah Redirect (GET) ---
if (isset($_GET['msg'])) {
    if ($_GET['msg'] == 'add_success') {
        $message = '<div class="alert alert-success">Pengguna baru berhasil ditambahkan.</div>';
    } elseif ($_GET['msg'] == 'edit_success') {
        $message = '<div class="alert alert-success">Pengguna berhasil diperbarui.</div>';
    } elseif ($_GET['msg'] == 'delete_success') {
        $message = '<div class="alert alert-success">Pengguna berhasil dihapus.</div>';
    } elseif ($_GET['msg'] == 'delete_fail') {
        $error_detail = $_GET['err'] ?? 'Terjadi kesalahan tidak diketahui.';
        $message = '<div class="alert alert-danger">Gagal menghapus pengguna: ' . htmlspecialchars($error_detail) . '</div>';
    }
}


// --- Logika Hapus User ---
if (isset($_GET['action']) && $_GET['action'] == 'delete' && isset($_GET['id'])) {
    $id_user_to_delete = $koneksi->real_escape_string($_GET['id']);
    
    // Jangan izinkan superadmin menghapus dirinya sendiri
    if ($id_user_to_delete == $_SESSION['user_id']) {
        $message = '<div class="alert alert-danger">Anda tidak bisa menghapus akun Anda sendiri.</div>';
    } else {
        $stmt = $koneksi->prepare("DELETE FROM users WHERE id = ?");
        $stmt->bind_param("i", $id_user_to_delete);
        if ($stmt->execute()) {
            $message = '<div class="alert alert-success">Pengguna berhasil dihapus.</div>';
            header('Location: user_settings.php?msg=delete_success');
            exit();
        } else {
            $message = '<div class="alert alert-danger">Gagal menghapus pengguna: ' . $stmt->error . '</div>';
            header('Location: user_settings.php?msg=delete_fail&err=' . urlencode($stmt->error));
            exit();
        }
        $stmt->close();
    }
}

// --- Logika Tambah/Edit User ---
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $username = $koneksi->real_escape_string($_POST['username']);
    $role = $koneksi->real_escape_string($_POST['role']);
    $user_id = $koneksi->real_escape_string($_POST['user_id'] ?? '');

    // Validasi dasar
    if (empty($username) || empty($role)) {
        $message = '<div class="alert alert-danger">Username dan Role tidak boleh kosong.</div>';
    } else {
        if (empty($user_id)) { // Tambah User Baru
            $password = $_POST['password'];
            if (empty($password)) {
                $message = '<div class="alert alert-danger">Password harus diisi untuk pengguna baru.</div>';
            } else {
                // Cek apakah username sudah ada saat menambah baru
                $stmt_check_username = $koneksi->prepare("SELECT id FROM users WHERE username = ?");
                $stmt_check_username->bind_param("s", $username);
                $stmt_check_username->execute();
                $result_check_username = $stmt_check_username->get_result();
                if ($result_check_username->num_rows > 0) {
                    $message = '<div class="alert alert-danger">Username sudah ada. Pilih username lain.</div>';
                } else {
                    $hashed_password = password_hash($password, PASSWORD_DEFAULT);
                    $stmt = $koneksi->prepare("INSERT INTO users (username, password, role) VALUES (?, ?, ?)");
                    $stmt->bind_param("sss", $username, $hashed_password, $role);
                    if ($stmt->execute()) {
                        $message = '<div class="alert alert-success">Pengguna berhasil ditambahkan.</div>';
                        header('Location: user_settings.php?msg=add_success');
                        exit();
                    } else {
                        $message = '<div class="alert alert-danger">Gagal menambahkan pengguna: ' . $stmt->error . '</div>';
                    }
                }
                $stmt_check_username->close();
            }
        } else { // Edit User
            $password_field = $_POST['password'] ?? '';
            
            $stmt_check_username_edit = $koneksi->prepare("SELECT id FROM users WHERE username = ? AND id != ?");
            $stmt_check_username_edit->bind_param("si", $username, $user_id);
            $stmt_check_username_edit->execute();
            $result_check_username_edit = $stmt_check_username_edit->get_result();
            if ($result_check_username_edit->num_rows > 0) {
                $message = '<div class="alert alert-danger">Username sudah ada untuk pengguna lain. Pilih username lain.</div>';
            } else {
                if (!empty($password_field)) {
                    $hashed_password = password_hash($password_field, PASSWORD_DEFAULT);
                    $stmt = $koneksi->prepare("UPDATE users SET username = ?, password = ?, role = ? WHERE id = ?");
                    $stmt->bind_param("sssi", $username, $hashed_password, $role, $user_id);
                } else {
                    $stmt = $koneksi->prepare("UPDATE users SET username = ?, role = ? WHERE id = ?");
                    $stmt->bind_param("ssi", $username, $role, $user_id);
                }

                if ($stmt->execute()) {
                    $message = '<div class="alert alert-success">Pengguna berhasil diperbarui.</div>';
                    if ($user_id == $_SESSION['user_id']) {
                        $_SESSION['username'] = $username;
                        $_SESSION['role'] = $role;
                    }
                    header('Location: user_settings.php?msg=edit_success');
                    exit();
                } else {
                    $message = '<div class="alert alert-danger">Gagal memperbarui pengguna: ' . $stmt->error . '</div>';
                }
            }
            $stmt_check_username_edit->close();
        }
        if (isset($stmt) && $stmt instanceof mysqli_stmt) { 
            $stmt->close();
        }
    }
}

// --- Logika Ambil Data Untuk Form Edit (dari GET request) ---
if (isset($_GET['action']) && $_GET['action'] == 'edit' && isset($_GET['id'])) {
    $user_id_to_edit = $koneksi->real_escape_string($_GET['id']);
    $query_edit = $koneksi->query("SELECT id, username, role FROM users WHERE id = '$user_id_to_edit'");
    if ($query_edit->num_rows > 0) {
        $user_data = $query_edit->fetch_assoc();
    } else {
        $message = '<div class="alert alert-danger">Data pengguna tidak ditemukan.</div>';
        $user_id_to_edit = null;
    }
    $form_should_be_visible = true; // Langsung tampilkan form jika mode edit
} else {
    $form_should_be_visible = false; // Sembunyikan form secara default
}


// Ambil semua data user untuk ditampilkan
$query_user_list = "SELECT id, username, role, created_at FROM users ORDER BY username ASC";
$result_user_list = $koneksi->query($query_user_list);
?>

<div class="main-content">
    <div class="top-header">
        <div class="alert-message">
            Pemberitahuan: Hanya Superadmin yang dapat mengelola pengguna sistem.
        </div>
        <div class="welcome-message">
            <span>Selamat datang, <?php echo htmlspecialchars($_SESSION['username'] ?? 'User'); ?>!</span>
            <a href="../logout.php" class="btn-logout">Logout</a> 
        </div>
    </div>

    <div class="container">
        <h2>Pengaturan User</h2>

        <?php echo htmlspecialchars($message, ENT_QUOTES, "UTF-8"); ?>

        <button id="toggleFormBtn" class="btn btn-primary" style="margin-bottom: 20px;">
            <?php echo ($user_id_to_edit ? 'Kembali ke Form Edit' : 'Tambah Pengguna Baru'); ?>
        </button>

        <div id="formUserCard" class="card <?php echo $form_should_be_visible ? '' : 'hide-form'; ?>" style="margin-bottom: 20px;">
            <div class="card-header">
                <h3><?php echo ($user_id_to_edit ? 'Edit' : 'Tambah'); ?> Pengguna Sistem</h3>
            </div>
            <div class="card-body">
                <form method="POST"><?php if (!isset($_SESSION['csrf_token'])) { $_SESSION['csrf_token'] = bin2hex(random_bytes(32)); } ?><input type='hidden' name='csrf_token' value='<?php echo $_SESSION['csrf_token']; ?>'>
                    <?php if ($user_id_to_edit): ?>
                        <input type="hidden" name="user_id" value="<?php echo htmlspecialchars($user_data['id']); ?>">
                    <?php endif; ?>
                    <div class="form-group">
                        <label for="username">Username:</label>
                        <input type="text" id="username" name="username" value="<?php echo htmlspecialchars($user_data['username'] ?? ''); ?>" required>
                    </div>
                    <div class="form-group">
                        <label for="password">Password <?php echo ($user_id_to_edit ? '(Kosongkan jika tidak diubah)' : '*'); ?>:</label>
                        <input type="password" id="password" name="password" <?php echo ($user_id_to_edit ? '' : 'required'); ?>>
                    </div>
                    <div class="form-group">
                        <label for="role">Role:</label>
                        <select id="role" name="role" required>
                            <option value="admin" <?php echo (isset($user_data['role']) && $user_data['role'] == 'admin') ? 'selected' : ''; ?>>Admin</option>
                            <option value="superadmin" <?php echo (isset($user_data['role']) && $user_data['role'] == 'superadmin') ? 'selected' : ''; ?>>Superadmin</option>
                            </select>
                    </div>
                    <button type="submit" class="btn btn-primary"><?php echo ($user_id_to_edit ? 'Update' : 'Tambah'); ?> Pengguna</button>
                    <?php if ($user_id_to_edit): ?>
                        <a href="user_settings.php" class="btn btn-secondary">Batal Edit</a>
                    <?php endif; ?>
                </form>
            </div>
        </div>

        <div class="card">
            <div class="card-header">
                <h3>Daftar Pengguna Sistem</h3>
            </div>
            <div class="card-body">
                <table class="data-table">
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>Username</th>
                            <th>Role</th>
                            <th>Created At</th>
                            <th>Aksi</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if ($result_user_list->num_rows > 0): ?>
                            <?php while($row = $result_user_list->fetch_assoc()): ?>
                                <tr>
                                    <td><?php echo htmlspecialchars($row['id']); ?></td>
                                    <td><?php echo htmlspecialchars($row['username']); ?></td>
                                    <td><span class="status-badge status-<?php echo strtolower(str_replace(' ', '-', $row['role'])); ?>"><?php echo htmlspecialchars($row['role']); ?></span></td>
                                    <td><?php echo htmlspecialchars(date('d-m-Y H:i', strtotime($row['created_at']))); ?></td>
                                    <td>
                                        <a href="user_settings.php?action=edit&id=<?php echo $row['id']; ?>" class="btn-action btn-edit"><i class="fas fa-edit"></i> Edit</a>
                                        <a href="user_settings.php?action=delete&id=<?php echo $row['id']; ?>" class="btn-action btn-delete" 
                                           onclick="return confirm('Apakah Anda yakin ingin menghapus pengguna ini? Menghapus pengguna yang sedang login bisa menyebabkan masalah.');">
                                           <i class="fas fa-trash-alt"></i> Hapus
                                        </a>
                                    </td>
                                </tr>
                            <?php endwhile; ?>
                        <?php else: ?>
                            <tr><td colspan="5" style="text-align: center;">Belum ada pengguna sistem.</td></tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>

    </div>
</div>

<script>
document.addEventListener('DOMContentLoaded', function() {
    var formCard = document.getElementById('formUserCard');
    var toggleBtn = document.getElementById('toggleFormBtn');
    
    // Safety check: ensure both elements exist
    if (!formCard || !toggleBtn) {
        console.error("Error: formUserCard or toggleFormBtn not found. Script cannot proceed.");
        return; // Stop script execution if elements are missing
    }

    var urlParams = new URLSearchParams(window.location.search);
    var isEditMode = urlParams.get('action') === 'edit';

    // Set teks tombol default
    // Visibilitas awal form diatur oleh PHP melalui kelas 'hide-form'
    if (formCard.classList.contains('hide-form')) {
        toggleBtn.textContent = 'Tambah Pengguna Baru';
    } else {
        toggleBtn.textContent = 'Sembunyikan Form';
    }

    // Add event listener only once
    if (!toggleBtn._hasClickListener) { 
        toggleBtn.addEventListener('click', function() {
            console.log("Toggle button clicked. Current classes:", formCard.classList); // Debugging
            if (formCard.classList.contains('hide-form')) {
                formCard.classList.remove('hide-form'); // Tampilkan form
                toggleBtn.textContent = 'Sembunyikan Form';
                formCard.scrollIntoView({ behavior: 'smooth', block: 'start' });
            } else {
                formCard.classList.add('hide-form'); // Sembunyikan form
                toggleBtn.textContent = 'Tambah Pengguna Baru';
                if (!isEditMode) { // Hanya reset form jika bukan mode edit
                    var form = formCard.querySelector('form');
                    if (form) {
                        form.reset();
                        var roleSelect = form.querySelector('#role');
                        if (roleSelect) {
                            roleSelect.value = 'admin'; // Reset ke 'admin'
                        }
                    }
                }
                if (isEditMode) {
                    window.location.href = 'user_settings.php'; 
                }
            }
        });
        toggleBtn._hasClickListener = true; 
    }

    // JavaScript untuk menampilkan pesan setelah redirect
    <?php if (isset($_GET['msg'])): ?>
        console.log("Message from GET param:", "<?php echo htmlspecialchars($_GET['msg']); ?>"); 
        window.scrollTo({ top: 0, behavior: 'smooth' });
    <?php endif; ?>

});
</script>

<?php include '../includes/footer.php'; ?>