<?php
// C:\xampp\htdocs\billing_isp_app\pages\manajemen_hotspot_profile.php

ini_set('session.use_strict_mode', 1);
ini_set('session.cookie_httponly', 1);
ini_set('session.cookie_samesite', 'Lax');
if (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on') {
    ini_set('session.cookie_secure', 1);
}
session_start();
include '../config/koneksi.php';
include '../includes/header.php'; // Pastikan header.php meng-include Bootstrap CSS/JS dan Font Awesome

// Fungsi hasRole() diasumsikan didefinisikan di suatu tempat (misal: config/koneksi.php atau includes/functions.php)
if (!function_exists('hasRole')) {
    function hasRole($roles) {
        return isset($_SESSION['role']) && in_array($_SESSION['role'], $roles);
    }
}

// Pastikan user memiliki role yang sesuai (misal: superadmin atau teknisi)
if (!hasRole(['superadmin', 'teknisi'])) {
    echo "<script>
            alert('Anda tidak memiliki akses ke halaman ini.');
            window.location.href = '../pages/dashboard.php';
          </script>";
    exit();
}
?>

<div class="main-content">
    <div class="page-header">
        <h1>Manajemen Hotspot Profile</h1>
        <p>Kelola profil hotspot Mikrotik Anda.</p>
    </div>

    <div class="container">
        <div class="card mb-4">
            <div class="card-header">
                <ul class="nav nav-tabs card-header-tabs" id="myTab" role="tablist">
                    <li class="nav-item">
                        <a class="nav-link active" id="list-profiles-tab" data-bs-toggle="tab" href="#list-profiles" role="tab" aria-controls="list-profiles" aria-selected="true">Daftar Profil</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" id="add-profile-tab" data-bs-toggle="tab" href="#add-profile" role="tab" aria-controls="add-profile" aria-selected="false">Tambah Profil</a>
                    </li>
                </ul>
            </div>
            <div class="card-body">
                <div class="tab-content" id="myTabContent">
                    <div class="tab-pane fade show active" id="list-profiles" role="tabpanel" aria-labelledby="list-profiles-tab">
                        <h3><i class="fas fa-list-ul"></i> Daftar Profil Hotspot</h3>
                        <button id="refreshProfilesBtn" class="btn btn-info mb-3"><i class="fas fa-sync-alt"></i> Refresh Daftar Profil</button>
                        <div class="table-responsive">
                            <table class="table table-bordered table-striped data-table" id="hotspotProfilesTable">
                                <thead>
                                    <tr>
                                        <th>No</th>
                                        <th>Nama</th>
                                        <th>Shared Users</th>
                                        <th>Rate Limit</th>
                                        <th>Mode Kadaluarsa</th>
                                        <th>Masa Berlaku</th>
                                        <th>Harga (Rp)</th>
                                        <th>Harga Jual (Rp)</th>
                                        <th>Kunci Pengguna</th>
                                        <th>Grace Period</th>
                                        <th>Aksi</th>
                                    </tr>
                                </thead>
                                <tbody id="hotspotProfilesTableBody">
                                    <tr><td colspan="11" class="text-center"><i class="fas fa-spinner fa-spin"></i> Memuat profil hotspot...</td></tr>
                                </tbody>
                            </table>
                        </div>
                    </div>

                    <div class="tab-pane fade" id="add-profile" role="tabpanel" aria-labelledby="add-profile-tab">
                        <h3><i class="fas fa-plus-circle"></i> Tambah Profil Hotspot Baru</h3>
                        <form id="addHotspotProfileForm">
                            <div class="form-actions-top mb-3 d-flex justify-content-end">
                                <button type="button" class="btn btn-warning me-2" id="cancelAddProfileBtn"><i class="fas fa-times-circle"></i> Tutup</button>
                                <button type="submit" class="btn btn-primary" id="addProfileSubmitBtn"><i class="fas fa-save"></i> Simpan</button>
                            </div>

                            <div class="form-group mb-3">
                                <label for="profile_name">Nama Profil:</label>
                                <input class="form-control" type="text" id="profile_name" name="name" onchange="remSpace(this);" required>
                                <small class="form-text text-muted">Nama profil tidak boleh berisi spasi. Spasi akan diganti dengan '-'.</small>
                            </div>
                            <div class="form-group mb-3">
                                <label for="address_pool">Address Pool:</label>
                                <select class="form-control" id="address_pool" name="address-pool">
                                    <option value="none">none</option>
                                </select>
                                <small class="form-text text-muted">Pool alamat IP yang akan dialokasikan ke pengguna.</small>
                            </div>
                            <div class="form-group mb-3">
                                <label for="shared_users">Shared Users:</label>
                                <input class="form-control" type="number" id="shared_users" name="shared-users" value="1" min="1">
                                <small class="form-text text-muted">Jumlah pengguna yang dapat login bersamaan dengan profil ini.</small>
                            </div>
                            <div class="form-group mb-3">
                                <label for="rate_limit">Rate Limit (misal: 1M/1M):</label>
                                <input class="form-control" type="text" id="rate_limit" name="rate-limit" placeholder="misal: 1M/1M, 256k/512k">
                                <small class="form-text text-muted">Format: TxRate/RxRate (upload/download). Contoh: 1M/5M, 256k/512k.</small>
                            </div>
                            <div class="form-group mb-3">
                                <label for="status_mode_kadaluarsa">Mode Kadaluarsa:</label>
                                <select class="form-control" onchange="toggleValidityGraceperiod();" id="status_mode_kadaluarsa" name="status-mode-kadaluarsa" required>
                                    <option value="">Pilih...</option>
                                    <option value="0">None</option>
                                    <option value="rem">Remove</option>
                                    <option value="ntf">Notice</option>
                                    <option value="remc">Remove & Record</option>
                                    <option value="ntfc">Notice & Record</option>
                                </select>
                                <small class="form-text text-muted">Ini adalah indikasi untuk aplikasi. Logika sebenarnya perlu diimplementasikan via script on-login/scheduler Mikrotik.</small>
                            </div>
                             <div class="form-group mb-3" id="validity_group" style="display:none;">
                                <label for="masa_berlaku">Masa Berlaku (misal: 1d, 1w):</label>
                                <input class="form-control" type="text" id="masa_berlaku" name="validity" placeholder="misal: 1d, 1w, 30d">
                                <small class="form-text text-muted">Masa berlaku voucher setelah aktivasi pertama. Contoh: 1d (1 hari), 1w (1 minggu), 30d (30 hari). Ini juga indikasi.</small>
                            </div>
                             <div class="form-group mb-3" id="graceperiod_group" style="display:none;">
                                <label for="grace_period">Grace Period (misal: 5m):</label>
                                <input class="form-control" type="text" id="grace_period" name="graceperiod" placeholder="misal: 5m" value="5m">
                                <small class="form-text text-muted">Waktu tambahan sebelum user benar-benar kadaluarsa.</small>
                            </div>
                             <div class="form-group mb-3">
                                <label for="harga_jual">Harga (Rp):</label>
                                <input class="form-control" type="number" id="harga_jual" name="price" placeholder="misal: 5000" min="0">
                                <small class="form-text text-muted">Harga voucher (informasi untuk aplikasi billing Anda).</small>
                            </div>
                            <div class="form-group mb-3">
                                <label for="selling_price">Harga Jual (Rp):</label>
                                <input class="form-control" type="number" id="selling_price" name="sprice" placeholder="misal: 7000" min="0">
                                <small class="form-text text-muted">Harga jual final ke pengguna (informasi untuk aplikasi billing Anda).</small>
                            </div>
                            <div class="form-group mb-3">
                                <label for="kunci_pengguna">Kunci Pengguna:</label>
                                <select class="form-control" id="kunci_pengguna" name="user-key">
                                    <option value="Disable">Disable</option>
                                    <option value="Enable">Enable</option>
                                </select>
                                <small class="form-text text-muted">Mengunci profil ke pengguna tertentu atau mengatur status (Enable/Disable). Logika di script on-login.</small>
                            </div>
                             <div class="form-group mb-3">
                                <label for="parent_queue">Parent Queue (Opsional):</label>
                                <select class="form-control" id="parent_queue" name="parent-queue">
                                    <option value="none">none</option>
                                </select>
                                <small class="form-text text-muted">Parent queue untuk trafik dari profil ini.</small>
                            </div>
                             <div class="form-group mb-3">
                                <label for="on_login">Script On Login (Opsional):</label>
                                <textarea class="form-control" id="on_login" name="on-login" rows="3" placeholder="Misal: /system script add name=test_script policy=read,write source=&quot;some code&quot;"></textarea>
                                <small class="form-text text-muted">Script RouterOS yang dijalankan saat pengguna login. Gunakan hanya jika Anda tahu apa yang Anda lakukan.</small>
                            </div>
                            <div class="form-group mb-3">
                                <label for="on_logout">Script On Logout (Opsional):</label>
                                <textarea class="form-control" id="on_logout" name="on-logout" rows="3" placeholder="Misal: /system script add name=logout_script policy=read,write source=&quot;some code&quot;"></textarea>
                                <small class="form-text text-muted">Script RouterOS yang dijalankan saat pengguna logout. Gunakan hanya jika Anda tahu apa yang Anda lakukan.</small>
                            </div>
                            <div class="form-group mb-3">
                                <label for="session_timeout">Session Timeout (misal: 1h):</label>
                                <input class="form-control" type="text" id="session_timeout" name="session-timeout" placeholder="misal: 1h, 30m, 1d">
                                <small class="form-text text-muted">Waktu sesi aktif pengguna. Biarkan kosong untuk tidak terbatas.</small>
                            </div>
                            <div class="form-group mb-3">
                                <label for="idle_timeout">Idle Timeout (misal: 5m):</label>
                                <input class="form-control" type="text" id="idle_timeout" name="idle-timeout" placeholder="misal: 5m, 1h">
                                <small class="form-text text-muted">Waktu maksimal tidak ada aktivitas sebelum diputus. Biarkan kosong untuk tidak terbatas.</small>
                            </div>
                            <div class="form-group mb-3">
                                <label for="keepalive_timeout">Keepalive Timeout (misal: 2m):</label>
                                <input class="form-control" type="text" id="keepalive_timeout" name="keepalive-timeout" placeholder="misal: 2m">
                                <small class="form-text text-muted">Waktu untuk menjaga koneksi tetap hidup.</small>
                            </div>
                            <div class="form-group mb-3">
                                <label for="comment">Komentar (Opsional):</label>
                                <textarea class="form-control" id="comment" name="comment" rows="2" placeholder="Catatan untuk profil ini"></textarea>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<script>
document.addEventListener('DOMContentLoaded', function() {
    const listProfilesTab = document.getElementById('list-profiles-tab');
    const addProfileTab = document.getElementById('add-profile-tab');
    const listProfilesPane = document.getElementById('list-profiles');
    const addProfilePane = document.getElementById('add-profile');

    const addHotspotProfileForm = document.getElementById('addHotspotProfileForm');
    const hotspotProfilesTableBody = document.getElementById('hotspotProfilesTableBody');
    const refreshProfilesBtn = document.getElementById('refreshProfilesBtn');
    const addProfileSubmitBtn = document.getElementById('addProfileSubmitBtn'); // Tombol Simpan
    const cancelAddProfileBtn = document.getElementById('cancelAddProfileBtn'); // Tombol Tutup

    const addressPoolSelect = document.getElementById('address_pool');
    const parentQueueSelect = document.getElementById('parent_queue');
    const statusModeKadaluarsaSelect = document.getElementById('status_mode_kadaluarsa'); // Select untuk Mode Kadaluarsa
    const validityGroup = document.getElementById('validity_group'); // Group untuk Masa Berlaku
    const graceperiodGroup = document.getElementById('graceperiod_group'); // Group untuk Grace Period
    const masaBerlakuInput = document.getElementById('masa_berlaku'); // Input Masa Berlaku
    const gracePeriodInput = document.getElementById('grace_period'); // Input Grace Period

    // Asumsi: showNotification, showLoadingOverlay, hideLoadingOverlay, showCustomConfirm sudah ada secara global
    // Fallback jika fungsi-fungsi ini belum didefinisikan (untuk menghindari error JavaScript)
    if (typeof showNotification !== 'function') {
        console.warn("showNotification function is not defined. Please ensure it's included in header.php or a global JS file.");
        window.showNotification = function(message, type = 'info') {
            alert(type.toUpperCase() + ': ' + message);
        };
    }
    if (typeof showLoadingOverlay !== 'function') {
        console.warn("showLoadingOverlay function is not defined. Using a placeholder.");
        window.showLoadingOverlay = function() {
            document.body.style.cursor = 'wait';
            console.log('Loading...');
        };
        window.hideLoadingOverlay = function() {
            document.body.style.cursor = 'default';
            console.log('Loading Finished.');
        };
    }
    if (typeof showCustomConfirm !== 'function') {
        console.warn("showCustomConfirm function is not defined. Using a placeholder.");
        window.showCustomConfirm = function(title, message, callback) {
            if (confirm(title + '\n' + message)) {
                callback(true);
            } else {
                callback(false);
            }
        };
    }

    // Fungsi untuk menampilkan/menyembunyikan Validity dan Grace Period berdasarkan Expire Mode
    window.toggleValidityGraceperiod = function() {
        const expMode = statusModeKadaluarsaSelect.value;
        if (expMode === '0' || expMode === '') { // None
            validityGroup.style.display = 'none';
            graceperiodGroup.style.display = 'none';
            masaBerlakuInput.removeAttribute('required'); // Hapus required
            gracePeriodInput.removeAttribute('required'); // Hapus required
        } else { // rem, ntf, remc, ntfc
            validityGroup.style.display = 'block';
            graceperiodGroup.style.display = 'block';
            masaBerlakuInput.setAttribute('required', 'required'); // Tambahkan required
            gracePeriodInput.setAttribute('required', 'required'); // Tambahkan required
        }
    };

    // Panggil saat DOMContentLoaded dan saat select berubah
    statusModeKadaluarsaSelect.addEventListener('change', toggleValidityGraceperiod);


    // Fungsi untuk menampilkan tab yang dipilih
    function showTab(tabId) {
        document.querySelectorAll('.tab-pane').forEach(pane => {
            pane.classList.remove('show', 'active');
        });
        document.querySelectorAll('.nav-link').forEach(link => {
            link.classList.remove('active');
        });

        document.getElementById(tabId).classList.add('show', 'active');
        document.getElementById(tabId + '-tab').classList.add('active');
    }

    // Event listener untuk klik tab
    listProfilesTab.addEventListener('click', function(e) {
        e.preventDefault();
        showTab('list-profiles');
        loadHotspotProfilesTable(); // Muat ulang data ketika tab daftar profil diaktifkan
    });

    addProfileTab.addEventListener('click', function(e) {
        e.preventDefault();
        showTab('add-profile');
        loadAddressPools(); // Muat address pools saat tab tambah profil diaktifkan
        loadParentQueues(); // Muat parent queues saat tab tambah profil diaktifkan
        toggleValidityGraceperiod(); // Panggil untuk inisialisasi display validity/graceperiod
    });

    // Event listener untuk tombol "Tutup"
    cancelAddProfileBtn.addEventListener('click', function() {
        showTab('list-profiles'); // Kembali ke tab Daftar Profil
        addHotspotProfileForm.reset(); // Reset form jika ada data yang belum disimpan
        toggleValidityGraceperiod(); // Reset display validity/graceperiod
    });

    // Fungsi untuk memuat daftar profil hotspot dari Mikrotik
    function loadHotspotProfilesTable() {
        hotspotProfilesTableBody.innerHTML = '<tr><td colspan="11" class="text-center"><i class="fas fa-spinner fa-spin"></i> Memuat profil hotspot...</td></tr>';
        showLoadingOverlay();

        fetch('mikrotik_api.php?action=get_hotspot_user_profiles')
            .then(response => {
                if (!response.ok) {
                    throw new Error(`HTTP error! Status: ${response.status}`);
                }
                return response.json();
            })
            .then(data => {
                hideLoadingOverlay();
                hotspotProfilesTableBody.innerHTML = ''; // Kosongkan baris yang ada

                if (data.status === 'success' && data.profiles.length > 0) {
                    data.profiles.forEach((profile, index) => {
                        const row = document.createElement('tr');
                        const sharedUsers = profile['shared-users'] || '1'; // Default 1
                        const rateLimit = profile['rate-limit'] || 'N/A';
                        
                        // Data tambahan yang diparse dari Mikrotik 'comment' field
                        const modeKadaluarsa = profile['expire-mode'] || 'Tidak Ada'; // Perhatikan perubahan nama field
                        const validity = profile['validity'] || 'Tidak Terbatas';
                        const price = parseFloat(profile['price'] || 0).toLocaleString('id-ID');
                        const sPrice = parseFloat(profile['selling-price'] || 0).toLocaleString('id-ID'); // Perhatikan perubahan nama field
                        const userKey = profile['user-key'] || 'Disable';
                        const gracePeriod = profile['grace-period'] || 'Tidak Ada'; // Perhatikan perubahan nama field


                        // Untuk icon warna, asumsikan 'default' adalah abu-abu, lainnya kuning/hijau
                        const profileIconColor = profile.name === 'default' ? 'grey' : 'yellowgreen';

                        row.innerHTML = `
                            <td>${index + 1}</td>
                            <td><i class="fas fa-dot-circle" style="color: ${profileIconColor}; margin-right: 5px;"></i>${profile.name || 'N/A'}</td>
                            <td>${sharedUsers}</td>
                            <td>${rateLimit}</td>
                            <td>${modeKadaluarsa}</td>
                            <td>${validity}</td>
                            <td>Rp ${price}</td>
                            <td>Rp ${sPrice}</td>
                            <td>${userKey}</td>
                            <td>${gracePeriod}</td>
                            <td>
                                <button class="btn btn-danger btn-sm delete-profile-btn" data-id="${profile['.id']}" data-name="${profile.name}"><i class="fas fa-trash"></i> Hapus</button>
                            </td>
                        `;
                        hotspotProfilesTableBody.appendChild(row);
                    });
                    attachDeleteProfileListeners();
                } else {
                    hotspotProfilesTableBody.innerHTML = '<tr><td colspan="11" class="text-center">Tidak ada profil hotspot ditemukan.</td></tr>';
                }
            })
            .catch(error => {
                hideLoadingOverlay();
                console.error('Error loading hotspot profiles:', error);
                hotspotProfilesTableBody.innerHTML = `<tr><td colspan="11" class="text-center text-danger">Gagal memuat profil hotspot: ${error.message}. Cek koneksi Mikrotik dan log server.</td></tr>`;
                showNotification('Terjadi kesalahan saat memuat profil hotspot. ' + error.message, 'error');
            });
    }

    // Fungsi untuk memuat Address Pools
    function loadAddressPools() {
        addressPoolSelect.innerHTML = '<option value="none">Memuat...</option>'; // Tambahkan indikator loading
        fetch('mikrotik_api.php?action=get_ip_pools')
            .then(response => {
                if (!response.ok) throw new Error(`HTTP error! Status: ${response.status}`);
                return response.json();
            })
            .then(data => {
                if (data.status === 'success') {
                    addressPoolSelect.innerHTML = '<option value="none">none</option>'; // Reset sebelum mengisi
                    data.pools.forEach(pool => {
                        const option = document.createElement('option');
                        option.value = pool.name;
                        option.textContent = pool.name;
                        addressPoolSelect.appendChild(option);
                    });
                } else {
                    showNotification('Gagal memuat Address Pools: ' + data.message, 'error');
                    addressPoolSelect.innerHTML = '<option value="none">Error memuat</option>';
                }
            })
            .catch(error => {
                console.error('Error loading address pools:', error);
                showNotification('Terjadi kesalahan saat memuat Address Pools.', 'error');
                addressPoolSelect.innerHTML = '<option value="none">Error memuat</option>';
            });
    }

    // Fungsi untuk memuat Parent Queues
    function loadParentQueues() {
        parentQueueSelect.innerHTML = '<option value="none">Memuat...</option>'; // Tambahkan indikator loading
        fetch('mikrotik_api.php?action=get_simple_queues')
            .then(response => {
                if (!response.ok) throw new Error(`HTTP error! Status: ${response.status}`);
                return response.json();
            })
            .then(data => {
                if (data.status === 'success') {
                    parentQueueSelect.innerHTML = '<option value="none">none</option>'; // Reset sebelum mengisi
                    data.queues.forEach(queue => {
                        const option = document.createElement('option');
                        option.value = queue.name;
                        option.textContent = queue.name;
                        parentQueueSelect.appendChild(option);
                    });
                } else {
                    showNotification('Gagal memuat Parent Queues: ' + data.message, 'error');
                    parentQueueSelect.innerHTML = '<option value="none">Error memuat</option>';
                }
            })
            .catch(error => {
                console.error('Error loading parent queues:', error);
                showNotification('Terjadi kesalahan saat memuat Parent Queues.', 'error');
                parentQueueSelect.innerHTML = '<option value="none">Error memuat</option>';
            });
    }

    // Event listener untuk tombol refresh daftar profil
    refreshProfilesBtn.addEventListener('click', loadHotspotProfilesTable);

    // Fungsi untuk melampirkan event listener delete
    function attachDeleteProfileListeners() {
        document.querySelectorAll('.delete-profile-btn').forEach(button => {
            button.addEventListener('click', function() {
                const profileId = this.dataset.id;
                const profileName = this.dataset.name;
                showCustomConfirm('Konfirmasi Hapus', `Apakah Anda yakin ingin menghapus profil hotspot "${profileName}"? Ini akan memengaruhi voucher yang menggunakan profil ini.`, (result) => {
                    if (result) {
                        showLoadingOverlay();
                        fetch('mikrotik_api.php?action=remove_hotspot_user_profile', {
                            method: 'POST',
                            headers: {
                                'Content-Type': 'application/json'
                            },
                            body: JSON.stringify({ id: profileId })
                        })
                        .then(response => {
                            if (!response.ok) throw new Error(`HTTP error! Status: ${response.status}`);
                            return response.json();
                        })
                        .then(data => {
                            hideLoadingOverlay();
                            if (data.status === 'success') {
                                showNotification(data.message, 'success');
                                loadHotspotProfilesTable(); // Muat ulang daftar
                            } else {
                                showNotification('Gagal menghapus profil: ' + data.message, 'error');
                            }
                        })
                        .catch(error => {
                            hideLoadingOverlay();
                            console.error('Error deleting profile:', error);
                            showNotification('Terjadi kesalahan jaringan atau server saat menghapus profil: ' + error.message, 'error');
                        });
                    }
                });
            });
        });
    }

    // Fungsi untuk mengganti spasi dengan '-'
    window.remSpace = function(inputElement) {
        inputElement.value = inputElement.value.replace(/\s+/g, "-");
    };

    // Fungsi untuk menghasilkan string acak (digunakan untuk start-time scheduler)
    function generateRandomTime() {
        const randHour = Math.floor(Math.random() * 6); // 0-5
        const randMin = Math.floor(Math.random() * 50) + 10; // 10-59
        const randSec = Math.floor(Math.random() * 50) + 10; // 10-59
        return `0${randHour}:${randMin}:${randSec}`;
    }

    // Event listener untuk form tambah profil
    addHotspotProfileForm.addEventListener('submit', function(e) {
        e.preventDefault();
        
        // Disable tombol submit dan tampilkan loading
        addProfileSubmitBtn.disabled = true;
        addProfileSubmitBtn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Menyimpan...'; // Mengubah teks
        showLoadingOverlay();

        const formData = new FormData(this);
        const jsonData = {};
        formData.forEach((value, key) => {
            // Trim whitespace dari input string
            if (typeof value === 'string') {
                jsonData[key] = value.trim();
            } else {
                jsonData[key] = value;
            }
        });

        // Validasi minimal nama profil
        if (!jsonData.name || jsonData.name === '') {
            showNotification('Nama Profil tidak boleh kosong.', 'error');
            hideLoadingOverlay();
            addProfileSubmitBtn.disabled = false;
            addProfileSubmitBtn.innerHTML = '<i class="fas fa-save"></i> Simpan'; // Mengembalikan teks
            return;
        }

        // Hapus spasi dari nama profil (sudah ditangani oleh remSpace tapi jaga-jaga)
        jsonData.name = jsonData.name.replace(/\s+/g, "-");

        // --- Logika Pembuatan Script On-Login dan Scheduler (Mikhmon Style) ---
        const profileName = jsonData.name;
        const expMode = jsonData['status-mode-kadaluarsa'];
        const validity = jsonData.validity || '';
        const price = jsonData.price || '0';
        const sPrice = jsonData.sprice || '0';
        const userKey = jsonData['user-key'];
        const originalComment = jsonData.comment || '';
        const gracePeriod = jsonData.graceperiod || '5m'; // Default 5m

        let onLoginScript = "";
        let schedulerMode = ""; // Untuk background service

        // Logika untuk on-login
        if (expMode !== '0' && expMode !== '') {
            let lockScript = '';
            if (userKey === "Enable") {
                lockScript = '; [:local mac $"mac-address"; /ip hotspot user set mac-address=$mac [find where name=$user]]';
            }
            
            // Perhatikan bahwa on-login Mikhmon cukup kompleks, ini adalah interpretasi dari script PHP Anda
            // Script ini menambahkan scheduler, mengatur comment user dengan waktu expired
            // Pastikan Anda memahami dan menyesuaikan script ini dengan kebutuhan Mikrotik Anda
            onLoginScript = `:put (",${expMode},${price},${validity},${sPrice},,${userKey},"); {:local comment [ /ip hotspot user get [/ip hotspot user find where name="$user"] comment]; :local ucode [:pic $comment 0 2]; :if ($ucode = "vc" or $ucode = "up" or $comment = "") do={ :local date [ /system clock get date ];:local year [ :pic $date 0 4 ];:local month [ :pic $date 5 7 ]; /sys sch add name="$user" disable=no start-date=$date interval="${validity}"; :delay 5s; :local exp [ /sys sch get [ /sys sch find where name="$user" ] next-run]; :local getxp [len $exp]; :if ($getxp = 15) do={ :local d [:pic $exp 0 6]; :local t [:pic $exp 7 16]; :local s ("/"); :local exp ("$d$s$year $t"); /ip hotspot user set comment="$exp" [find where name="$user"];}; :if ($getxp = 8) do={ /ip hotspot user set comment="$date $exp" [find where name="$user"];}; :if ($getxp > 15) do={ /ip hotspot user set comment="$exp" [find where name="$user"];};:delay 5s; /sys sch remove [find where name="$user"]`;
            
            // Tambahkan lockScript dan penutup curly braces
            onLoginScript += lockScript + "}}";

            // Tentukan mode untuk scheduler background service
            if (expMode === "rem" || expMode === "remc") {
                schedulerMode = "remove";
            } else if (expMode === "ntf" || expMode === "ntfc") {
                // Untuk mode notice, Anda mungkin ingin melakukan sesuatu yang berbeda,
                // seperti mengubah rate limit atau memindahkan ke profil lain.
                // Untuk contoh ini, saya biarkan kosong atau Anda bisa definisikan aksi lain.
                schedulerMode = "set limit-uptime=1s"; // Contoh: batasi uptime jadi 1 detik
            }

        } else if (price !== '0') { // Jika tidak ada Expire Mode tapi ada harga
            onLoginScript = `:put (",,${price},,,noexp,${userKey},")`;
            if (userKey === "Enable") {
                onLoginScript += '; [:local mac $"mac-address"; /ip hotspot user set mac-address=$mac [find where name=$user]]';
            }
        }

        // Logika untuk background service (scheduler)
        // Ini adalah script yang akan ditambahkan ke /system scheduler
        let bgServiceScript = '';
        if (expMode !== '0' && expMode !== '') {
            // Script ini perlu dijalankan secara berkala di Mikrotik oleh scheduler
            // agar bisa memproses user yang kadaluarsa berdasarkan comment mereka
            // Ini adalah bagian kritis yang 'adduserprofile.php' tangani di sisi RouterOS
            // Kita harus kirim ini sebagai bagian dari data profil, dan mikrotik_api.php harus bisa membuat/mengupdate scheduler
            // **PENTING**: Mikrotik API untuk profile /ip/hotspot/user/profile/add TIDAK memiliki parameter untuk menambahkan scheduler.
            // Scheduler harus ditambahkan secara terpisah melalui API call ke /system/scheduler.
            // Mikrotik_api.php Anda saat ini TIDAK memiliki endpoint untuk mengelola scheduler.
            // Ini adalah Kesenjangan Fitur antara adduserprofile.php dan mikrotik_api.php yang Anda miliki.
            // Untuk sementara, saya akan menyertakan skripnya sebagai parameter ke mikrotik_api.php,
            // tetapi API itu sendiri HARUS diubah untuk MENAMBAH/MENGURUS SCHEDULER.
            
            bgServiceScript = `:local dateint do={:local montharray ( "01","02","03","04","05","06","07","08","09","10","11","12" );:local days [ :pic $d 8 10 ];:local month [ :pic $d 5 7 ];:local year [ :pic $d 0 4 ];:local monthint ([ :find $montharray $month]);:local month ($monthint + 1);:if ( [len $month] = 1) do={:local zero ("0");:return [:tonum ("$year$zero$month$days")];} else={:return [:tonum ("$year$month$days")];}}; :local timeint do={ :local hours [ :pic $t 0 2 ]; :local minutes [ :pic $t 3 5 ]; :return ($hours * 60 + $minutes) ; }; :local date [ /system clock get date ]; :local time [ /system clock get time ]; :local today [$dateint d=$date] ; :local curtime [$timeint t=$time] ; :foreach i in [ /ip hotspot user find where profile="${profileName}" ] do={ :local comment [ /ip hotspot user get $i comment]; :local name [ /ip hotspot user get $i name]; :local gettime [:pic $comment 11 19]; :if ([:pic $comment 4] = "-" and [:pic $comment 7] = "-") do={:local expd [$dateint d=$comment] ; :local expt [$timeint t=$gettime] ; :if (($expd < $today and $expt < $curtime) or ($expd < $today and $expt > $curtime) or ($expd = $today and $expt < $curtime)) do={ [ /ip hotspot user ${schedulerMode} $i ]; [ /ip hotspot active remove [find where user=$name] ];}}}`;
        }


        // Data yang akan dikirim ke Mikrotik API
        const apiParams = {
            name: profileName,
            'shared-users': jsonData['shared-users'],
            'rate-limit': jsonData['rate-limit'],
            'session-timeout': jsonData['session-timeout'],
            'idle-timeout': jsonData['idle-timeout'],
            'keepalive-timeout': jsonData['keepalive-timeout'],
            'on-login': onLoginScript, // Script on-login yang sudah dibuat
            'on-logout': jsonData['on-logout'],
            'address-pool': jsonData['address-pool'] === 'none' ? '' : jsonData['address-pool'],
            'parent-queue': jsonData['parent-queue'] === 'none' ? '' : jsonData['parent-queue'],
            // Comment akan dibangun di bawah
        };

        // Mikhmon style comment parts
        let additionalCommentParts = [];
        if (expMode && expMode !== '') {
            additionalCommentParts.push(`Expire Mode: ${expMode}`);
        }
        if (validity && validity !== '') {
            additionalCommentParts.push(`Validity: ${validity}`);
        }
        if (price !== '0') { // Gunakan string '0' karena price bisa jadi string
            additionalCommentParts.push(`Price: ${price}`);
        }
        if (sPrice !== '0') { // Gunakan string '0' karena sprice bisa jadi string
            additionalCommentParts.push(`Selling Price: ${sPrice}`);
        }
        if (userKey && userKey !== '') {
            additionalCommentParts.push(`User Key: ${userKey}`);
        }
        if (gracePeriod && gracePeriod !== '') {
            additionalCommentParts.push(`Grace Period: ${gracePeriod}`); // Tambahkan grace period ke comment
        }
        
        // Gabungkan komentar tambahan ke dalam field 'comment' yang akan dikirim ke Mikrotik
        if (additionalCommentParts.length > 0) {
            apiParams.comment = (originalComment ? originalComment + ' | ' : '') + additionalCommentParts.join(' | ');
        } else if (originalComment) {
            apiParams.comment = originalComment;
        } else {
            apiParams.comment = ''; // Pastikan tidak undefined
        }

        // Hapus field yang kosong dari params yang dikirim ke Mikrotik (kecuali comment jika ingin dikirim kosong)
        for (const key in apiParams) {
            if (apiParams[key] === '' && key !== 'comment' && key !== 'on-login' && key !== 'on-logout') {
                delete apiParams[key];
            }
        }
        // Pastikan on-login/on-logout kosong jika tidak ada script
        if (apiParams['on-login'] === '') delete apiParams['on-login'];
        if (apiParams['on-logout'] === '') delete apiParams['on-logout'];


        fetch('mikrotik_api.php?action=add_hotspot_user_profile', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify(apiParams) // Kirim apiParams
        })
        .then(response => {
            if (!response.ok) throw new Error(`HTTP error! Status: ${response.status}`);
            return response.json();
        })
        .then(data => {
            hideLoadingOverlay();
            addProfileSubmitBtn.disabled = false;
            addProfileSubmitBtn.innerHTML = '<i class="fas fa-save"></i> Simpan';

            if (data.status === 'success') {
                showNotification(data.message, 'success');
                addHotspotProfileForm.reset(); // Reset form
                toggleValidityGraceperiod(); // Reset display validity/graceperiod
                showTab('list-profiles'); // Kembali ke tab daftar
                loadHotspotProfilesTable(); // Muat ulang daftar profil

                // --- BAGIAN UNTUK MENAMBAHKAN SCHEDULER (JIKA EXPMODE AKTIF) ---
                // Ini adalah area di mana Anda perlu memanggil API ke /system/scheduler
                // Mikrotik_api.php Anda saat ini belum memiliki endpoint untuk ini.
                // Jika ingin fitur scheduler otomatis seperti Mikhmon, mikrotik_api.php perlu diperbarui.
                if (expMode !== '0' && expMode !== '') {
                    const randStartTime = generateRandomTime(); // Fungsi random time
                    const randInterval = '00:02:10'; // Contoh, bisa di random juga
                    // Panggil API baru untuk menambahkan scheduler
                    // Contoh: fetch('mikrotik_api.php?action=add_scheduler', { ... })
                    // untuk saat ini, ini hanya log di konsol
                    console.warn(`[PENTING] Anda perlu menambahkan logika di mikrotik_api.php untuk membuat scheduler di Mikrotik dengan nama "${profileName}", start-time "${randStartTime}", interval "${randInterval}" dan on-event script: \n${bgServiceScript}`);
                    showNotification('Penting: Fitur Scheduler (Mode Kadaluarsa Otomatis) memerlukan update Mikrotik API Anda untuk menambahkan scheduler di RouterOS. Lihat konsol untuk detail.', 'warning', 10000);
                }

            } else {
                showNotification('Gagal menambah profil: ' + data.message, 'error');
            }
        })
        .catch(error => {
            hideLoadingOverlay();
            addProfileSubmitBtn.disabled = false;
            addProfileSubmitBtn.innerHTML = '<i class="fas fa-save"></i> Simpan';
            console.error('Error adding profile:', error);
            showNotification('Terjadi kesalahan jaringan atau server saat menambah profil: ' + error.message, 'error');
        });
    });

    // Inisialisasi: Muat daftar profil saat halaman pertama kali dimuat
    loadHotspotProfilesTable();
    // PENTING: Muat address pools dan parent queues saat halaman dimuat,
    // agar dropdown terisi ketika tab "Tambah Profil" dibuka.
    loadAddressPools();
    loadParentQueues();

    // Pastikan tab "Daftar Profil" aktif secara default saat load
    showTab('list-profiles'); // Ini memastikan tab yang benar aktif secara visual
});
</script>

<?php include '../includes/footer.php'; ?>