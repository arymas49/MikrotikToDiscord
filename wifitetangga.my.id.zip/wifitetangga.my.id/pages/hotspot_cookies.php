<?php
// C:\xampp\htdocs\billing_isp_app\pages\hotspot_cookies.php

ini_set('session.use_strict_mode', 1);
ini_set('session.cookie_httponly', 1);
ini_set('session.cookie_samesite', 'Lax');
if (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on') {
    ini_set('session.cookie_secure', 1);
}
session_start();
include '../config/koneksi.php';
include '../includes/header.php';

// Pastikan user memiliki role yang sesuai (misal: superadmin atau teknisi)
if (!hasRole(['superadmin', 'teknisi'])) {
    echo "<script>
            alert('Anda tidak memiliki akses ke halaman ini.');
            window.location.href = '../pages/dashboard.php';
          </script>";
    exit();
}
?>

<div class="main-content">
    <div class="page-header">
        <h1>Hotspot Cookies</h1>
        <p>Kelola daftar cookies hotspot.</p>
    </div>

    <div class="container">
        <div class="card mb-4">
            <div class="card-header">
                <h3><i class="fas fa-cookie-bite"></i> Hotspot Cookies</h3>
                <div class="search-form-group">
                    <input type="text" id="filterCookies" class="form-control" placeholder="Cari User/MAC/Domain...">
                    <div class="form-group mb-0" style="max-width: 250px;">
                        <label for="mikrotikConfigSelect" class="sr-only">Pilih MikroTik:</label>
                        <select id="mikrotikConfigSelect" class="form-control form-control-sm">
                            <option value="">Memuat konfigurasi...</option>
                        </select>
                    </div>
                    <button id="refreshCookiesBtn" class="btn btn-info"><i class="fas fa-sync-alt"></i> Refresh</button>
                </div>
            </div>
            <div class="card-body">
                <div class="table-responsive">
                    <table class="table data-table table-bordered table-striped" id="hotspotCookiesTable">
                        <thead>
                            <tr>
                                <th>No</th>
                                <th>Server</th> <!-- New column for MikroTik Server -->
                                <th>User</th>
                                <th>MAC Address</th>
                                <th>Domain</th>
                                <th>Expires In</th>
                                <th>Aksi</th>
                            </tr>
                        </thead>
                        <tbody id="hotspotCookiesTableBody">
                            <tr><td colspan="7" class="text-center">Memuat cookies...</td></tr> <!-- Adjusted colspan -->
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>

<script>
document.addEventListener('DOMContentLoaded', function() {
    const hotspotCookiesTableBody = document.getElementById('hotspotCookiesTableBody');
    const filterCookiesInput = document.getElementById('filterCookies');
    const refreshCookiesBtn = document.getElementById('refreshCookiesBtn');
    const mikrotikConfigSelect = document.getElementById('mikrotikConfigSelect');

    // Variabel untuk menyimpan ID konfigurasi MikroTik yang saat ini dipilih
    let selectedMikrotikConfigId = localStorage.getItem('selectedMikrotikConfigId') || null;
    // Cache konfigurasi MikroTik yang dimuat (untuk mendapatkan nama dari ID)
    window.cachedMikrotikConfigs = [];

    // Helper function to show notifications (assuming it's defined elsewhere or in header.php)
    function showNotification(message, type = 'info') {
        const notificationArea = document.getElementById('notificationArea') || document.createElement('div');
        notificationArea.id = 'notificationArea';
        notificationArea.innerHTML = `<div class="alert alert-${type} alert-dismissible fade show" role="alert">
                                        ${message}
                                        <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                                            <span aria-hidden="true">&times;</span>
                                        </button>
                                    </div>`;
        document.body.prepend(notificationArea);
        setTimeout(() => {
            const alert = notificationArea.querySelector('.alert');
            if (alert) {
                $(alert).alert('close');
            }
        }, 5000);
    }

    // Helper function to format RouterOS time duration
    function formatRouterOSTime(time_str) {
        if (!time_str || time_str === '0s' || time_str === 'N/A') {
            return '0 Detik';
        }

        let seconds = 0;
        const weeksMatch = time_str.match(/(\d+)w/);
        if (weeksMatch) {
            seconds += parseInt(weeksMatch[1]) * 7 * 24 * 3600;
            time_str = time_str.replace(/(\d+)w/, '');
        }
        const daysMatch = time_str.match(/(\d+)d/);
        if (daysMatch) {
            seconds += parseInt(daysMatch[1]) * 24 * 3600;
            time_str = time_str.replace(/(\d+)d/, '');
        }
        const hoursMatch = time_str.match(/(\d+)h/);
        if (hoursMatch) {
            seconds += parseInt(hoursMatch[1]) * 3600;
            time_str = time_str.replace(/(\d+)h/, '');
        }
        const minutesMatch = time_str.match(/(\d+)m/);
        if (minutesMatch) {
            seconds += parseInt(minutesMatch[1]) * 60;
            time_str = time_str.replace(/(\d+)m/, '');
        }
        const secondsMatch = time_str.match(/(\d+)s/);
        if (secondsMatch) {
            seconds += parseInt(secondsMatch[1]);
        }
        
        const years = Math.floor(seconds / (365 * 24 * 3600));
        seconds %= (365 * 24 * 3600);
        const months = Math.floor(seconds / (30 * 24 * 3600)); // Approx month
        seconds %= (30 * 24 * 3600);
        const days = Math.floor(seconds / (24 * 3600));
        seconds %= (24 * 3600);
        const hours = Math.floor(seconds / 3600);
        seconds %= 3600;
        const minutes = Math.floor(seconds / 60);
        const secs = seconds % 60;

        const parts = [];
        if (years > 0) parts.push(years + ' Tahun');
        if (months > 0) parts.push(months + ' Bulan');
        if (days > 0) parts.push(days + ' Hari');
        if (hours > 0) parts.push(hours + ' Jam');
        if (minutes > 0) parts.push(minutes + ' Menit');
        if (secs > 0) parts.push(secs + ' Detik');
        else if (parts.length === 0) parts.push('0 Detik'); // If all units are zero, display "0 Detik"

        return parts.join(' ');
    }

    // Fungsi untuk memuat daftar konfigurasi MikroTik
    async function loadMikrotikConfigs() {
        try {
            const response = await fetch('mikrotik_api.php?action=get_mikrotik_configs');
            const data = await response.json();

            mikrotikConfigSelect.innerHTML = ''; // Clear existing options

            // Tambahkan opsi "Tampilkan Semua"
            const allOption = document.createElement('option');
            allOption.value = 'all';
            allOption.textContent = 'Tampilkan Semua';
            mikrotikConfigSelect.appendChild(allOption);

            if (data.status === 'success' && data.configs && Array.isArray(data.configs) && data.configs.length > 0) {
                window.cachedMikrotikConfigs = data.configs; // Cache konfigurasi
                
                data.configs.forEach(config => {
                    const option = document.createElement('option');
                    option.value = config.id;
                    option.textContent = `${config.name} (${config.ip_address})`;
                    mikrotikConfigSelect.appendChild(option);
                });

                // Set pilihan yang tersimpan di localStorage atau "all" sebagai default
                if (selectedMikrotikConfigId && data.configs.some(c => c.id == selectedMikrotikConfigId || selectedMikrotikConfigId === 'all')) {
                    mikrotikConfigSelect.value = selectedMikrotikConfigId;
                } else {
                    mikrotikConfigSelect.value = 'all'; // Default ke "all"
                    selectedMikrotikConfigId = 'all'; // Perbarui selected ID
                    localStorage.setItem('selectedMikrotikConfigId', selectedMikrotikConfigId);
                }
            } else {
                mikrotikConfigSelect.innerHTML = '';
                const noConfigOption = document.createElement('option');
                noConfigOption.value = '';
                noConfigOption.textContent = 'Tidak ada konfigurasi MikroTik';
                mikrotikConfigSelect.appendChild(noConfigOption);
                mikrotikConfigSelect.disabled = true;
                selectedMikrotikConfigId = null; // Reset selected ID jika tidak ada konfigurasi
                localStorage.removeItem('selectedMikrotikConfigId');
                showNotification('Tidak ada konfigurasi MikroTik yang tersimpan. Silakan tambahkan di Pengaturan API MikroTik.', 'warning');
            }
            // Setelah konfigurasi dimuat dan dipilih, muat cookies
            loadHotspotCookies();

        } catch (error) {
            console.error('Error loading MikroTik configs:', error);
            mikrotikConfigSelect.innerHTML = '';
            const errorOption = document.createElement('option');
            errorOption.value = '';
            errorOption.textContent = 'Gagal memuat konfigurasi';
            mikrotikConfigSelect.appendChild(errorOption);
            mikrotikConfigSelect.disabled = true;
            selectedMikrotikConfigId = null;
            localStorage.removeItem('selectedMikrotikConfigId');
            showNotification('Terjadi kesalahan saat memuat daftar konfigurasi MikroTik.', 'error');
            // Tetap coba muat cookies
            loadHotspotCookies();
        }
    }


    // Fungsi untuk memuat daftar cookies
    async function loadHotspotCookies(search_term = '') { // Changed to async
        if (!selectedMikrotikConfigId) {
            hotspotCookiesTableBody.innerHTML = '<tr><td colspan="7" class="text-center">Tidak ada konfigurasi MikroTik yang dipilih.</td></tr>';
            return;
        }

        hotspotCookiesTableBody.innerHTML = '<tr><td colspan="7" class="text-center"><i class="fas fa-spinner fa-spin"></i> Memuat cookies...</td></tr>';
        showLoadingOverlay();

        let allCookies = [];

        try {
            if (selectedMikrotikConfigId === 'all') {
                if (window.cachedMikrotikConfigs.length === 0) {
                    showNotification('Tidak ada konfigurasi MikroTik yang tersedia untuk ditampilkan.', 'info');
                    hotspotCookiesTableBody.innerHTML = '<tr><td colspan="7" class="text-center">Tidak ada cookies untuk ditampilkan.</td></tr>';
                    hideLoadingOverlay();
                    return;
                }
                const fetchPromises = window.cachedMikrotikConfigs.map(async (config) => {
                    let url = `mikrotik_api.php?action=get_hotspot_cookies&config_id=${config.id}`;
                    if (search_term) url += `&search=${encodeURIComponent(search_term)}`; // Pass search term
                    const response = await fetch(url);
                    const data = await response.json();
                    if (data.status === 'success' && data.cookies && Array.isArray(data.cookies)) {
                        return data.cookies.map(cookie => ({ ...cookie, mikrotik_name: config.name, mikrotik_config_id: config.id }));
                    } else {
                        console.warn(`Gagal memuat cookies dari MikroTik ${config.name}: ${data.message || 'Unknown error'}`);
                        return [];
                    }
                });
                const results = await Promise.all(fetchPromises);
                allCookies = results.flat();
            } else {
                // Fetch from a single selected MikroTik
                const selectedConfig = window.cachedMikrotikConfigs.find(config => config.id == selectedMikrotikConfigId);
                const selectedMikrotikName = selectedConfig ? selectedConfig.name : 'N/A';

                let url = `mikrotik_api.php?action=get_hotspot_cookies&config_id=${selectedMikrotikConfigId}`;
                if (search_term) url += `&search=${encodeURIComponent(search_term)}`;
                const response = await fetch(url);
                const data = await response.json();

                if (data.status === 'success' && data.cookies && Array.isArray(data.cookies)) {
                    allCookies = data.cookies.map(cookie => ({ ...cookie, mikrotik_name: selectedMikrotikName, mikrotik_config_id: selectedMikrotikConfigId }));
                } else {
                    showNotification('Gagal memuat cookies: ' + data.message, 'error');
                }
            }

            hideLoadingOverlay();
            hotspotCookiesTableBody.innerHTML = ''; // Clear existing rows

            if (allCookies.length > 0) {
                allCookies.forEach((cookie, index) => {
                    const row = document.createElement('tr');
                    row.innerHTML = `
                        <td>${index + 1}</td>
                        <td>${cookie.mikrotik_name || 'N/A'}</td> <!-- Display MikroTik Server -->
                        <td>${cookie.user || 'N/A'}</td>
                        <td>${cookie['mac-address'] || 'N/A'}</td>
                        <td>${cookie.domain || 'N/A'}</td>
                        <td>${formatRouterOSTime(cookie['expires-in'] || 'N/A')}</td>
                        <td>
                            <button class="btn btn-danger btn-sm remove-cookie-btn" 
                                    data-id="${cookie['.id']}" 
                                    data-user="${cookie.user || 'N/A'}"
                                    data-mikrotik-config-id="${cookie.mikrotik_config_id}"> <!-- Add config ID here -->
                                <i class="fas fa-trash"></i> Hapus
                            </button>
                        </td>
                    `;
                    hotspotCookiesTableBody.appendChild(row);
                });
                attachRemoveCookieListeners();
            } else {
                hotspotCookiesTableBody.innerHTML = '<tr><td colspan="7" class="text-center">Tidak ada hotspot cookies.</td></tr>';
            }
        } catch (error) {
            hideLoadingOverlay();
            console.error('Error loading hotspot cookies:', error);
            hotspotCookiesTableBody.innerHTML = `<tr><td colspan="7" class="text-center text-danger">Terjadi kesalahan saat memuat cookies: ${error.message}</td></tr>`;
            showNotification('Terjadi kesalahan saat memuat hotspot cookies.', 'error');
        }
    }

    // Event listener for filter input
    filterCookiesInput.addEventListener('keyup', function() {
        clearTimeout(this.debounceTimeout);
        this.debounceTimeout = setTimeout(() => {
            loadHotspotCookies(this.value);
        }, 500);
    });

    // Event listener for refresh button
    refreshCookiesBtn.addEventListener('click', function() {
        loadHotspotCookies(filterCookiesInput.value);
    });

    // Event listener for MikroTik selection change
    mikrotikConfigSelect.addEventListener('change', function() {
        selectedMikrotikConfigId = this.value;
        localStorage.setItem('selectedMikrotikConfigId', selectedMikrotikConfigId);
        loadHotspotCookies(filterCookiesInput.value); // Reload cookies with new MikroTik
    });


    // Fungsi untuk melampirkan event listener "Hapus"
    function attachRemoveCookieListeners() {
        document.querySelectorAll('.remove-cookie-btn').forEach(button => {
            button.addEventListener('click', function() {
                const cookieId = this.dataset.id;
                const userName = this.dataset.user;
                const mikrotikConfigIdToRemove = this.dataset.mikrotikConfigId; // Get config ID from button

                showCustomConfirm('Konfirmasi Hapus', `Apakah Anda yakin ingin menghapus cookie untuk user "${userName}" dari MikroTik ini?`, (result) => {
                    if (result) {
                        removeCookie(cookieId, mikrotikConfigIdToRemove); // Pass config ID to remove function
                    }
                });
            });
        });
    }

    // Fungsi untuk menghapus cookie
    function removeCookie(id, mikrotikConfigIdToRemove) { // Accepts mikrotikConfigIdToRemove
        if (!mikrotikConfigIdToRemove || mikrotikConfigIdToRemove === 'all') {
            showNotification('Tidak dapat menghapus cookie di mode "Tampilkan Semua". Silakan pilih MikroTik spesifik.', 'warning');
            return;
        }

        showLoadingOverlay();
        fetch(`mikrotik_api.php?action=remove_hotspot_cookie&config_id=${mikrotikConfigIdToRemove}`, { // Pass config_id to API
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ id: id })
        })
        .then(response => response.json())
        .then(data => {
            hideLoadingOverlay();
            if (data.status === 'success') {
                showNotification(data.message, 'success');
                loadHotspotCookies(filterCookiesInput.value); // Refresh list
            } else {
                showNotification('Gagal menghapus cookie: ' + data.message, 'error');
            }
        })
        .catch(error => {
            hideLoadingOverlay();
            console.error('Error removing cookie:', error);
            showNotification('Terjadi kesalahan jaringan atau server saat menghapus cookie: ' + error.message, 'error');
        });
    }

    // Initial load
    loadMikrotikConfigs(); // This will trigger loadHotspotCookies
});
</script>