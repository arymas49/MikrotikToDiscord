<?php
include '../../config/koneksi.php';

if (isset($_GET['id'])) {
    $id = (int)$_GET['id'];

    if ($id === 0) {
        $_SESSION['message'] = "ID Pembayaran tidak valid.";
        $_SESSION['message_type'] = "danger";
        header('Location: index.php');
        exit;
    }

    $query = "DELETE FROM pembayaran WHERE id = ?";
    $stmt = $koneksi->prepare($query);
    $stmt->bind_param("i", $id);

    if ($stmt->execute()) {
        $_SESSION['message'] = "Catatan pembayaran berhasil dihapus!";
        $_SESSION['message_type'] = "success";
    } else {
        $_SESSION['message'] = "Gagal menghapus catatan pembayaran: " . $stmt->error;
        $_SESSION['message_type'] = "danger";
    }
} else {
    $_SESSION['message'] = "Permintaan hapus tidak valid.";
    $_SESSION['message_type'] = "danger";
}

header('Location: index.php');
exit;
?>