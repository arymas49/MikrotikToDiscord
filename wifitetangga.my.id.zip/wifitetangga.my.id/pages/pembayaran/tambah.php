<?php
include '../../config/koneksi.php';
include '../../includes/header.php';

// Ambil data pelanggan untuk dropdown
$query_pelanggan = "SELECT p.id, p.nama, pk.nama_paket, pk.harga
                    FROM pelanggan p
                    LEFT JOIN paket pk ON p.id_paket = pk.id
                    ORDER BY p.nama ASC";
$result_pelanggan = $koneksi->query($query_pelanggan);

if (isset($_POST['submit'])) {
    $id_pelanggan = $koneksi->real_escape_string($_POST['id_pelanggan']);
    $jumlah_bayar = $koneksi->real_escape_string($_POST['jumlah_bayar']);
    $bulan_bayar = $koneksi->real_escape_string($_POST['bulan_bayar']); // Format: YYYY-MM
    $tanggal_bayar = date('Y-m-d H:i:s'); // Waktu saat ini

    // Untuk bulan_bayar di database, kita ubah format YYYY-MM menjadi nama bulan dan tahun
    // Contoh: '2025-06' menjadi 'Juni 2025'
    $timestamp_bulan = strtotime($bulan_bayar . '-01'); // Ambil tanggal 1 di bulan tersebut
    $bulan_bayar_formatted = strftime('%B %Y', $timestamp_bulan); // Format ke nama bulan dan tahun (misal: "Juni 2025")

    // Validasi sederhana
    if (empty($id_pelanggan) || empty($jumlah_bayar) || empty($bulan_bayar)) {
        $_SESSION['message'] = "Semua field harus diisi!";
        $_SESSION['message_type'] = "danger";
    } else {
        $query = "INSERT INTO pembayaran (id_pelanggan, jumlah_bayar, tanggal_bayar, bulan_bayar) VALUES (?, ?, ?, ?)";
        $stmt = $koneksi->prepare($query);
        // "ids" = integer, double, string (untuk tanggal_bayar), string (untuk bulan_bayar_formatted)
        $stmt->bind_param("idss", $id_pelanggan, $jumlah_bayar, $tanggal_bayar, $bulan_bayar_formatted);

        if ($stmt->execute()) {
            $_SESSION['message'] = "Pembayaran berhasil dicatat!";
            $_SESSION['message_type'] = "success";
            header('Location: index.php');
            exit;
        } else {
            $_SESSION['message'] = "Gagal mencatat pembayaran: " . $stmt->error;
            $_SESSION['message_type'] = "danger";
        }
    }
}
?>

<div class="container form-container">
    <h2>Catat Pembayaran Baru</h2>
    <?php if (isset($_SESSION['message'])): ?>
        <div class="alert alert-<?php echo $_SESSION['message_type']; ?>">
            <?php echo $_SESSION['message']; unset($_SESSION['message']); unset($_SESSION['message_type']); ?>
        </div>
    <?php endif; ?>

    <form action="" method="POST"><?php if (!isset($_SESSION['csrf_token'])) { $_SESSION['csrf_token'] = bin2hex(random_bytes(32)); } ?><input type='hidden' name='csrf_token' value='<?php echo $_SESSION['csrf_token']; ?>'>
        <div class="form-group">
            <label for="id_pelanggan">Pilih Pelanggan:</label>
            <select id="id_pelanggan" name="id_pelanggan" required onchange="getPaketHarga()">
                <option value="">-- Pilih Pelanggan --</option>
                <?php while ($pelanggan = $result_pelanggan->fetch_assoc()): ?>
                    <option value="<?php echo htmlspecialchars($pelanggan['id']); ?>" data-harga="<?php echo htmlspecialchars($pelanggan['harga']); ?>">
                        <?php echo htmlspecialchars($pelanggan['nama'] . ' (Paket: ' . ($pelanggan['nama_paket'] ?? 'N/A') . ')'); ?>
                    </option>
                <?php endwhile; ?>
            </select>
        </div>
        <div class="form-group">
            <label for="bulan_bayar">Untuk Bulan:</label>
            <input type="month" id="bulan_bayar" name="bulan_bayar" value="<?php echo date('Y-m'); ?>" required>
        </div>
        <div class="form-group">
            <label for="jumlah_bayar">Jumlah Bayar (Rp):</label>
            <input type="number" id="jumlah_bayar" name="jumlah_bayar" step="0.01" min="0" required>
            <small style="display: block; margin-top: 5px; color: #555;">Harga paket pelanggan akan otomatis terisi jika ada.</small>
        </div>
        <button type="submit" name="submit">Catat Pembayaran</button>
        <a href="index.php" class="btn btn-danger">Batal</a>
    </form>
</div>

<script>
function getPaketHarga() {
    var selectPelanggan = document.getElementById('id_pelanggan');
    var selectedOption = selectPelanggan.options[selectPelanggan.selectedIndex];
    var hargaPaket = selectedOption.getAttribute('data-harga');
    var jumlahBayarInput = document.getElementById('jumlah_bayar');

    if (hargaPaket) {
        jumlahBayarInput.value = parseFloat(hargaPaket).toFixed(2); // Menampilkan 2 desimal
    } else {
        jumlahBayarInput.value = '';
    }
}
</script>

<?php include '../../includes/footer.php'; ?>