<?php
include '../../config/koneksi.php';
include '../../includes/header.php';

// Gabungkan tabel pembayaran dan pelanggan
$query = "SELECT pb.*, p.nama AS nama_pelanggan, p.telepon AS telepon_pelanggan, pk.nama_paket FROM pembayaran pb JOIN pelanggan p ON pb.id_pelanggan = p.id LEFT JOIN paket pk ON p.id_paket = pk.id ORDER BY pb.tanggal_bayar DESC";
$result = $koneksi->query($query);
?>

<div class="container">
    <h2>Daftar Pembayaran</h2>
    <?php if (isset($_SESSION['message'])): ?>
        <div class="alert alert-<?php echo $_SESSION['message_type']; ?>">
            <?php echo $_SESSION['message']; unset($_SESSION['message']); unset($_SESSION['message_type']); ?>
        </div>
    <?php endif; ?>

    <div class="add-button-container">
        <a href="tambah.php" class="btn">Catat Pembayaran Baru</a>
    </div>

    <table>
        <thead>
            <tr>
                <th>ID Pembayaran</th>
                <th>Nama Pelanggan</th>
                <th>Telepon</th>
                <th>Paket</th>
                <th>Bulan Bayar</th>
                <th>Jumlah Bayar</th>
                <th>Tanggal Bayar</th>
                <th>Aksi</th>
            </tr>
        </thead>
        <tbody>
            <?php if ($result->num_rows > 0): ?>
                <?php while ($row = $result->fetch_assoc()): ?>
                    <tr>
                        <td><?php echo htmlspecialchars($row['id']); ?></td>
                        <td><?php echo htmlspecialchars($row['nama_pelanggan']); ?></td>
                        <td><?php echo htmlspecialchars($row['telepon_pelanggan']); ?></td>
                        <td><?php echo htmlspecialchars($row['nama_paket'] ?? 'N/A'); ?></td>
                        <td><?php echo htmlspecialchars($row['bulan_bayar']); ?></td>
                        <td>Rp <?php echo number_format($row['jumlah_bayar'], 0, ',', '.'); ?></td>
                        <td><?php echo date('d-m-Y H:i', strtotime($row['tanggal_bayar'])); ?></td>
                        <td class="action-buttons">
                            <a href="hapus.php?id=<?php echo $row['id']; ?>" class="btn btn-danger btn-delete" onclick="return confirm('Yakin ingin menghapus catatan pembayaran ini?');">Hapus</a>
                        </td>
                    </tr>
                <?php endwhile; ?>
            <?php else: ?>
                <tr>
                    <td colspan="8" class="text-center">Belum ada catatan pembayaran.</td>
                </tr>
            <?php endif; ?>
        </tbody>
    </table>
</div>

<?php include '../../includes/footer.php'; ?>