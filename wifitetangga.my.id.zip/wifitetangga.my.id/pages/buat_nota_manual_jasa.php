<?php
// C:\xampp\htdocs\billing_isp_app\pages\buat_nota_manual_jasa.php
ob_start();
ini_set('session.use_strict_mode', 1);
ini_set('session.cookie_httponly', 1);
ini_set('session.cookie_samesite', 'Lax');
if (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on') {
    ini_set('session.cookie_secure', 1);
}
session_start();
include '../config/koneksi.php';
include '../includes/header.php'; // Header akan meng-include sidebar dan fungsi hasRole()

// Batasi akses ke halaman ini: hanya superadmin dan admin
if (!hasRole(['superadmin', 'admin'])) {
    header('Location: dashboard.php'); // Redirect ke dashboard atau halaman akses ditolak
    exit();
}

$message = ''; // Untuk pesan sukses/error

// --- Logika Buat Nota Manual Jasa Baru ---
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['action']) && $_POST['action'] == 'create_manual_invoice_jasa') {
    $nama_pelanggan_manual = $koneksi->real_escape_string($_POST['nama_pelanggan_manual']);
    $alamat_manual = $koneksi->real_escape_string($_POST['alamat_manual']);
    $telepon_manual = $koneksi->real_escape_string($_POST['telepon_manual']);
    $email_manual = $koneksi->real_escape_string($_POST['email_manual']);
    $jenis_jasa = $koneksi->real_escape_string($_POST['jenis_jasa']);
    $deskripsi_jasa = $koneksi->real_escape_string($_POST['deskripsi_jasa']);
    $jumlah_tagihan_jasa = $koneksi->real_escape_string($_POST['jumlah_tagihan_jasa']);
    $tanggal_terbit = $koneksi->real_escape_string($_POST['tanggal_terbit']);
    $tanggal_jatuh_tempo = $koneksi->real_escape_string($_POST['tanggal_jatuh_tempo']);
    $status_tagihan = 'Belum Lunas'; // Default status

    $stmt = $koneksi->prepare("INSERT INTO tagihan_manual (nama_pelanggan_manual, alamat_manual, telepon_manual, email_manual, nama_paket_manual, deskripsi_tagihan_manual, jumlah_tagihan, tanggal_terbit, tanggal_jatuh_tempo, status_tagihan) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
    $stmt->bind_param("ssssssisss", $nama_pelanggan_manual, $alamat_manual, $telepon_manual, $email_manual, $jenis_jasa, $deskripsi_jasa, $jumlah_tagihan_jasa, $tanggal_terbit, $tanggal_jatuh_tempo, $status_tagihan);

    if ($stmt->execute()) {
        $last_id_tagihan_manual = $koneksi->insert_id;
        $_SESSION['form_message'] = '<div class="alert alert-success">Nota manual jasa berhasil dibuat! <a href="print_invoice.php?source_table=tagihan_manual&id=' . $last_id_tagihan_manual . '" target="_blank" class="btn btn-sm btn-info"><i class="fas fa-print"></i> Cetak Nota</a></div>';
        header('Location: buat_nota_manual_jasa.php'); // Redirect untuk menghindari resubmission form
        exit();
    } else {
        $message = '<div class="alert alert-danger">Gagal membuat nota manual jasa: ' . $stmt->error . '</div>';
    }
    $stmt->close();
}

// --- Logika Catat Pembayaran Nota Manual ---
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['action']) && $_POST['action'] == 'catat_pembayaran_manual_jasa') {
    $id_tagihan_manual_to_pay = $koneksi->real_escape_string($_POST['id_tagihan_manual_to_pay']);
    $jumlah_bayar_manual = $koneksi->real_escape_string($_POST['jumlah_bayar_manual']);
    $metode_pembayaran_manual = $koneksi->real_escape_string($_POST['metode_pembayaran_manual']);
    $tanggal_bayar_manual = $koneksi->real_escape_string($_POST['tanggal_bayar_manual']);

    // Ambil jumlah tagihan seharusnya untuk validasi
    $stmt_get_tagihan = $koneksi->prepare("SELECT jumlah_tagihan FROM tagihan_manual WHERE id_tagihan_manual = ?");
    $stmt_get_tagihan->bind_param("i", $id_tagihan_manual_to_pay);
    $stmt_get_tagihan->execute();
    $result_get_tagihan = $stmt_get_tagihan->get_result();
    $tagihan_data = $result_get_tagihan->fetch_assoc();
    $harga_seharusnya = $tagihan_data['jumlah_tagihan'] ?? 0;
    $stmt_get_tagihan->close();

    if ($jumlah_bayar_manual < $harga_seharusnya) {
        $message = '<div class="alert alert-warning">Jumlah bayar kurang dari harga nota seharusnya (Rp ' . number_format($harga_seharusnya, 0, ',', '.') . '). Pembayaran tidak dicatat.</div>';
    } else {
        $stmt = $koneksi->prepare("UPDATE tagihan_manual SET status_tagihan = 'Lunas', tanggal_bayar_manual = ?, jumlah_bayar_manual = ?, metode_pembayaran_manual = ?, updated_at = CURRENT_TIMESTAMP WHERE id_tagihan_manual = ?");
        $stmt->bind_param("sdsi", $tanggal_bayar_manual, $jumlah_bayar_manual, $metode_pembayaran_manual, $id_tagihan_manual_to_pay);

        if ($stmt->execute()) {
            $_SESSION['form_message'] = '<div class="alert alert-success">Pembayaran nota manual berhasil dicatat! <a href="print_invoice.php?source_table=tagihan_manual&id=' . $id_tagihan_manual_to_pay . '" target="_blank" class="btn btn-sm btn-info"><i class="fas fa-print"></i> Cetak Bukti Bayar</a></div>';
            header('Location: buat_nota_manual_jasa.php?filter_status_manual=Lunas'); // Redirect ke halaman dengan filter lunas
            exit();
        } else {
            $message = '<div class="alert alert-danger">Gagal mencatat pembayaran nota manual: ' . $stmt->error . '</div>';
        }
        $stmt->close();
    }
}


// --- Logika Hapus Tagihan Manual ---
if (isset($_GET['action']) && $_GET['action'] == 'delete_manual_invoice' && isset($_GET['id'])) {
    if (!hasRole('superadmin')) {
        $message = '<div class="alert alert-danger">Anda tidak memiliki izin untuk menghapus nota manual. Hanya Superadmin yang dapat melakukan aksi ini.</div>';
    } else {
        $id_to_delete = $koneksi->real_escape_string($_GET['id']);
        // Pastikan hanya tagihan manual yang belum lunas yang bisa dihapus, atau yang tidak terkait dengan pembayaran
        $stmt = $koneksi->prepare("DELETE FROM tagihan_manual WHERE id_tagihan_manual = ? AND status_tagihan != 'Lunas'"); // Only delete if not Lunas
        $stmt->bind_param("i", $id_to_delete);
        if ($stmt->execute()) {
            if ($stmt->affected_rows > 0) {
                $_SESSION['form_message'] = '<div class="alert alert-success">Nota manual jasa berhasil dihapus.</div>';
                header('Location: buat_nota_manual_jasa.php'); // Redirect
                exit();
            } else {
                $message = '<div class="alert alert-warning">Nota manual jasa tidak ditemukan atau sudah lunas dan tidak dapat dihapus.</div>';
            }
        } else {
            $message = '<div class="alert alert-danger">Gagal menghapus nota manual jasa: ' . $stmt->error . '</div>';
        }
        $stmt->close();
    }
}

// --- Logika Ubah Status Lunas ke Belum Lunas (Unpay) ---
if (isset($_GET['action']) && $_GET['action'] == 'unpay_manual_invoice' && isset($_GET['id'])) {
    if (!hasRole('superadmin')) {
        $message = '<div class="alert alert-danger">Anda tidak memiliki izin untuk mengubah status nota manual. Hanya Superadmin yang dapat melakukan aksi ini.</div>';
    } else {
        $id_to_unpay = $koneksi->real_escape_string($_GET['id']);
        
        // Update status_tagihan menjadi 'Belum Lunas' dan kosongkan data pembayaran
        $stmt = $koneksi->prepare("UPDATE tagihan_manual SET status_tagihan = 'Belum Lunas', tanggal_bayar_manual = NULL, jumlah_bayar_manual = NULL, metode_pembayaran_manual = NULL, id_pembayaran_terkait = NULL, updated_at = CURRENT_TIMESTAMP WHERE id_tagihan_manual = ? AND status_tagihan = 'Lunas'");
        $stmt->bind_param("i", $id_to_unpay);
        
        if ($stmt->execute()) {
            if ($stmt->affected_rows > 0) {
                $_SESSION['form_message'] = '<div class="alert alert-success">Status nota manual berhasil diubah menjadi "Belum Lunas".</div>';
                header('Location: buat_nota_manual_jasa.php?filter_status_manual=Belum Lunas'); // Redirect ke halaman dengan filter belum lunas
                exit();
            } else {
                $message = '<div class="alert alert-warning">Nota manual tidak ditemukan atau statusnya sudah "Belum Lunas".</div>';
            }
        } else {
            $message = '<div class="alert alert-danger">Gagal mengubah status nota manual: ' . $stmt->error . '</div>';
        }
        $stmt->close();
    }
}


// --- Ambil semua tagihan manual (filter default Belum Lunas) ---
$tagihan_manual_list = [];
$filter_status_manual = $_GET['filter_status_manual'] ?? 'Belum Lunas'; // Default filter

$query_tagihan_manual = "SELECT * FROM tagihan_manual";
$where_clauses_manual = [];
$params_manual = [];
$param_types_manual = "";

if ($filter_status_manual !== 'Semua') {
    $where_clauses_manual[] = "status_tagihan = ?";
    $params_manual[] = $filter_status_manual;
    $param_types_manual .= "s";
}

if (!empty($where_clauses_manual)) {
    $query_tagihan_manual .= " WHERE " . implode(" AND ", $where_clauses_manual);
}
$query_tagihan_manual .= " ORDER BY tanggal_terbit DESC, status_tagihan ASC";

$stmt_manual = $koneksi->prepare($query_tagihan_manual);
if (!empty($params_manual)) {
    $stmt_manual->bind_param($param_types_manual, ...$params_manual);
}
$stmt_manual->execute();
$result_tagihan_manual = $stmt_manual->get_result();

if ($result_tagihan_manual && $result_tagihan_manual->num_rows > 0) {
    while ($row = $result_tagihan_manual->fetch_assoc()) {
        $tagihan_manual_list[] = $row;
    }
}
$stmt_manual->close();

// Tampilkan pesan dari sesi jika ada
if (isset($_SESSION['form_message'])) {
    $message = $_SESSION['form_message'];
    unset($_SESSION['form_message']); // Hapus pesan setelah ditampilkan
}

?>

<div class="main-content">
    <div class="top-header">
        <div class="alert-message">
            Pemberitahuan: Gunakan fitur ini untuk mencatat nota manual untuk jasa selain layanan ISP.
        </div>
        <div class="welcome-message">
            <span>Selamat datang, <?php echo htmlspecialchars($_SESSION['username'] ?? 'User'); ?>!</span>
            <a href="../logout.php" class="btn-logout">Logout</a> 
        </div>
    </div>

    <div class="container"> 
        <h2>Manajemen Nota Manual Jasa Lainnya</h2>

        <?php echo htmlspecialchars($message, ENT_QUOTES, "UTF-8"); ?>

        <div class="card" style="margin-bottom: 20px;">
            <div class="card-header">
                <h3>Formulir Nota Manual Jasa Baru</h3>
            </div>
            <div class="card-body">
                <form method="POST"><?php if (!isset($_SESSION['csrf_token'])) { $_SESSION['csrf_token'] = bin2hex(random_bytes(32)); } ?><input type='hidden' name='csrf_token' value='<?php echo $_SESSION['csrf_token']; ?>'>
                    <input type="hidden" name="action" value="create_manual_invoice_jasa">
                    
                    <h4>Data Pelanggan (Jasa)</h4>
                    <div class="form-group">
                        <label for="nama_pelanggan_manual">Nama Pelanggan:</label>
                        <input type="text" id="nama_pelanggan_manual" name="nama_pelanggan_manual" required>
                    </div>
                    <div class="form-group">
                        <label for="alamat_manual">Alamat:</label>
                        <textarea id="alamat_manual" name="alamat_manual" rows="3"></textarea>
                    </div>
                    <div class="form-group">
                        <label for="telepon_manual">Telepon:</label>
                        <input type="text" id="telepon_manual" name="telepon_manual">
                    </div>
                    <div class="form-group">
                        <label for="email_manual">Email (Opsional):</label>
                        <input type="email" id="email_manual" name="email_manual">
                    </div>

                    <h4>Detail Jasa</h4>
                    <div class="form-group">
                        <label for="jenis_jasa">Jenis Jasa:</label>
                        <input type="text" id="jenis_jasa" name="jenis_jasa" placeholder="Contoh: Perbaikan Komputer, Pemasangan CCTV" required>
                    </div>
                    <div class="form-group">
                        <label for="deskripsi_jasa">Deskripsi Jasa (Opsional):</label>
                        <textarea id="deskripsi_jasa" name="deskripsi_jasa" rows="3" placeholder="Detail pekerjaan atau barang yang disertakan"></textarea>
                    </div>
                    <div class="form-group">
                        <label for="jumlah_tagihan_jasa">Jumlah Tagihan (Rp):</label>
                        <input type="number" id="jumlah_tagihan_jasa" name="jumlah_tagihan_jasa" step="0.01" required>
                    </div>
                    <div class="form-group">
                        <label for="tanggal_terbit">Tanggal Terbit Nota:</label>
                        <input type="date" id="tanggal_terbit" name="tanggal_terbit" value="<?php echo date('Y-m-d'); ?>" required>
                    </div>
                    <div class="form-group">
                        <label for="tanggal_jatuh_tempo">Tanggal Jatuh Tempo:</label>
                        <input type="date" id="tanggal_jatuh_tempo" name="tanggal_jatuh_tempo" value="<?php echo date('Y-m-d', strtotime('+7 days')); ?>" required>
                    </div>
                    
                    <button type="submit" class="btn btn-primary">Buat Nota Manual</button>
                </form>
            </div>
        </div>

        <div class="card">
            <div class="card-header">
                <h3>Daftar Nota Manual Jasa</h3>
                <div class="filter-form">
                    <form method="GET" action="buat_nota_manual_jasa.php">
                        <select name="filter_status_manual" onchange="this.form.submit()">
                            <option value="Belum Lunas" <?php echo ($filter_status_manual == 'Belum Lunas') ? 'selected' : ''; ?>>Belum Lunas</option>
                            <option value="Lunas" <?php echo ($filter_status_manual == 'Lunas') ? 'selected' : ''; ?>>Lunas</option>
                            <option value="Semua" <?php echo ($filter_status_manual == 'Semua') ? 'selected' : ''; ?>>Semua</option>
                        </select>
                        <a href="buat_nota_manual_jasa.php" class="btn btn-secondary btn-sm"><i class="fas fa-redo"></i> Reset Filter</a>
                    </form>
                </div>
            </div>
            <div class="card-body">
                <table class="data-table">
                    <thead>
                        <tr>
                            <th>ID Nota</th>
                            <th>Nama Pelanggan</th>
                            <th>Jenis Jasa</th>
                            <th>Jumlah</th>
                            <th>Tgl Terbit</th>
                            <th>Tgl Jatuh Tempo</th>
                            <th>Status</th>
                            <th>Aksi</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if (!empty($tagihan_manual_list)): ?>
                            <?php foreach ($tagihan_manual_list as $nota): ?>
                                <tr>
                                    <td><?php echo htmlspecialchars($nota['id_tagihan_manual']); ?></td>
                                    <td><?php echo htmlspecialchars($nota['nama_pelanggan_manual']); ?></td>
                                    <td><?php echo htmlspecialchars($nota['nama_paket_manual']); ?></td>
                                    <td>Rp <?php echo number_format($nota['jumlah_tagihan'], 0, ',', '.'); ?></td>
                                    <td><?php echo htmlspecialchars(date('d-m-Y', strtotime($nota['tanggal_terbit']))); ?></td>
                                    <td><?php echo htmlspecialchars(date('d-m-Y', strtotime($nota['tanggal_jatuh_tempo']))); ?></td>
                                    <td><span class="status-badge status-<?php echo strtolower(str_replace(' ', '-', $nota['status_tagihan'])); ?>"><?php echo htmlspecialchars($nota['status_tagihan']); ?></span></td>
                                    <td>
                                        <?php if ($nota['status_tagihan'] == 'Belum Lunas'): ?>
                                            <button class="btn-action btn-primary" onclick="showPaymentModal(<?php echo $nota['id_tagihan_manual']; ?>, '<?php echo htmlspecialchars($nota['nama_pelanggan_manual']); ?>', '<?php echo htmlspecialchars($nota['nama_paket_manual']); ?>', <?php echo $nota['jumlah_tagihan']; ?>)">
                                                <i class="fas fa-money-bill-wave"></i> Bayar
                                            </button>
                                        <?php elseif ($nota['status_tagihan'] == 'Lunas'): ?>
                                            <?php if (hasRole('superadmin')): ?>
                                                <a href="buat_nota_manual_jasa.php?action=unpay_manual_invoice&id=<?php echo htmlspecialchars($nota['id_tagihan_manual']); ?>" class="btn-action btn-warning" onclick="return confirm('Apakah Anda yakin ingin mengubah status nota ini menjadi BELUM LUNAS? Ini akan menghapus data pembayaran.');">
                                                    <i class="fas fa-undo"></i> Belum Lunas
                                                </a>
                                            <?php endif; ?>
                                        <?php endif; ?>
                                        <a href="print_invoice.php?source_table=tagihan_manual&id=<?php echo htmlspecialchars($nota['id_tagihan_manual']); ?>" target="_blank" class="btn-action btn-secondary"><i class="fas fa-print"></i> Cetak</a>
                                        <?php if (hasRole('superadmin') && $nota['status_tagihan'] != 'Lunas'): // Hanya superadmin bisa hapus, dan hanya jika belum lunas ?>
                                        <a href="buat_nota_manual_jasa.php?action=delete_manual_invoice&id=<?php echo htmlspecialchars($nota['id_tagihan_manual']); ?>" class="btn-action btn-delete" onclick="return confirm('Apakah Anda yakin ingin menghapus nota manual ini? Ini tidak dapat dikembalikan.');"><i class="fas fa-trash-alt"></i> Hapus</a>
                                        <?php endif; ?>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        <?php else: ?>
                            <tr><td colspan="8" style="text-align: center;">Tidak ada nota manual jasa yang ditemukan.</td></tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>

        <!-- Payment Modal for Manual Invoice -->
        <div id="paymentModal" class="modal">
            <div class="modal-content">
                <span class="close-button" onclick="closePaymentModal()">&times;</span>
                <h3>Catat Pembayaran Nota Manual</h3>
                <form method="POST"><?php if (!isset($_SESSION['csrf_token'])) { $_SESSION['csrf_token'] = bin2hex(random_bytes(32)); } ?><input type='hidden' name='csrf_token' value='<?php echo $_SESSION['csrf_token']; ?>'>
                    <input type="hidden" name="action" value="catat_pembayaran_manual_jasa">
                    <input type="hidden" id="modal_id_tagihan_manual" name="id_tagihan_manual_to_pay">
                    
                    <div class="form-group">
                        <label>Pelanggan:</label>
                        <input type="text" id="modal_nama_pelanggan" readonly>
                    </div>
                    <div class="form-group">
                        <label>Jenis Jasa:</label>
                        <input type="text" id="modal_jenis_jasa" readonly>
                    </div>
                    <div class="form-group">
                        <label>Jumlah Tagihan:</label>
                        <input type="text" id="modal_jumlah_tagihan" readonly>
                    </div>
                    <div class="form-group">
                        <label for="tanggal_bayar_manual">Tanggal Bayar:</label>
                        <input type="date" id="tanggal_bayar_manual" name="tanggal_bayar_manual" value="<?php echo date('Y-m-d'); ?>" required>
                    </div>
                    <div class="form-group">
                        <label for="jumlah_bayar_manual">Jumlah Bayar (Rp):</label>
                        <input type="number" id="jumlah_bayar_manual" name="jumlah_bayar_manual" step="0.01" required>
                    </div>
                    <div class="form-group">
                        <label for="metode_pembayaran_manual">Metode Pembayaran:</label>
                        <input type="text" id="metode_pembayaran_manual" name="metode_pembayaran_manual" placeholder="Contoh: Tunai, Transfer Bank" required>
                    </div>
                    <button type="submit" class="btn btn-primary">Catat Pembayaran</button>
                </form>
            </div>
        </div>

        <script>
        // Get the modal
        var paymentModal = document.getElementById('paymentModal');

        // Get the <span> element that closes the modal
        var span = document.getElementsByClassName("close-button")[0];

        // Function to open the modal and pre-fill form
        function showPaymentModal(id_tagihan, nama_pelanggan, jenis_jasa, jumlah_tagihan) {
            document.getElementById('modal_id_tagihan_manual').value = id_tagihan;
            document.getElementById('modal_nama_pelanggan').value = nama_pelanggan;
            document.getElementById('modal_jenis_jasa').value = jenis_jasa;
            document.getElementById('modal_jumlah_tagihan').value = 'Rp ' + parseFloat(jumlah_tagihan).toLocaleString('id-ID');
            document.getElementById('jumlah_bayar_manual').value = parseFloat(jumlah_tagihan); // Pre-fill jumlah bayar
            paymentModal.style.display = "block";
        }

        // Function to close the modal
        function closePaymentModal() {
            paymentModal.style.display = "none";
        }

        // When the user clicks anywhere outside of the modal, close it
        window.onclick = function(event) {
            if (event.target == paymentModal) {
                paymentModal.style.display = "none";
            }
        }
        </script>

        <style>
            /* Modal Styles */
            .modal {
                display: none; /* Hidden by default */
                position: fixed; /* Stay in place */
                z-index: 1000; /* Sit on top */
                left: 0;
                top: 0;
                width: 100%; /* Full width */
                height: 100%; /* Full height */
                overflow: auto; /* Enable scroll if needed */
                background-color: rgba(0,0,0,0.4); /* Black w/ opacity */
                padding-top: 60px;
            }

            .modal-content {
                background-color: #fefefe;
                margin: 5% auto; /* 5% from the top and centered */
                padding: 30px;
                border: 1px solid #888;
                width: 80%; /* Could be more or less, depending on screen size */
                max-width: 600px;
                border-radius: 8px;
                box-shadow: 0 4px 8px rgba(0,0,0,0.2);
                position: relative;
            }

            .close-button {
                color: #aaa;
                position: absolute;
                right: 20px;
                top: 10px;
                font-size: 28px;
                font-weight: bold;
                cursor: pointer;
            }

            .close-button:hover,
            .close-button:focus {
                color: black;
                text-decoration: none;
                cursor: pointer;
            }

            .modal .form-group {
                margin-bottom: 15px;
            }

            .modal .form-group label {
                display: block;
                margin-bottom: 5px;
                font-weight: bold;
            }

            .modal .form-group input[type="text"],
            .modal .form-group input[type="number"],
            .modal .form-group input[type="date"],
            .modal .form-group input[type="email"],
            .modal .form-group textarea {
                width: calc(100% - 20px);
                padding: 10px;
                border: 1px solid #ddd;
                border-radius: 4px;
                box-sizing: border-box;
            }

            .modal .btn {
                padding: 10px 20px;
                border-radius: 5px;
                cursor: pointer;
                font-size: 16px;
                margin-top: 10px;
            }
        </style>

    </div>
</div>

<?php include '../includes/footer.php'; ?>