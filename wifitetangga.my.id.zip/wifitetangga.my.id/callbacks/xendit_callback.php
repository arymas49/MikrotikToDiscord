<?php
// C:\xampp\htdocs\billing_isp_app\callbacks\xendit_callback.php
// Endpoint ini akan menerima notifikasi webhook dari Xendit

// Pastikan pelaporan error diaktifkan untuk debugging
ini_set('display_errors', 1); // Hanya untuk debugging, nonaktifkan di production
ini_set('display_startup_errors', 1); // Hanya untuk debugging, nonaktifkan di production
error_reporting(E_ALL);

// Tentukan path ke autoload.php secara dinamis
// __DIR__ adalah direktori dari file saat ini (callbacks)
// dirname(__DIR__, 2) akan naik dua level ke direktori root aplikasi (billing.tzn.my.id)
$autoloadPath = dirname(__DIR__, 2) . '/vendor/autoload.php';

// Verifikasi apakah file autoload.php ada sebelum mencoba memuatnya
if (!file_exists($autoloadPath)) {
    // Log error dan keluar jika file autoload tidak ditemukan
    file_put_contents(__DIR__ . '/xendit_callback_log.txt', "\n--- " . date('Y-m-d H:i:s') . " - AUTOLOAD ERROR ---\n", FILE_APPEND);
    file_put_contents(__DIR__ . '/xendit_callback_log.txt', "Fatal error: Composer autoload file not found at " . htmlspecialchars($autoloadPath) . ". Please run 'composer install' in your application root directory.\n", FILE_APPEND);
    http_response_code(500); // Internal Server Error
    echo json_encode(['status' => 'error', 'message' => 'Composer autoload file not found.']);
    exit();
}

// Memuat Composer Autoloader untuk memastikan semua kelas library tersedia.
require_once $autoloadPath;

// Sertakan file koneksi database dan konfigurasi Xendit
// Pastikan path ini benar relatif terhadap lokasi file callback ini
include_once __DIR__ . '/../config/koneksi.php'; 
$xenditConfig = include __DIR__ . '/../config/xendit_config.php';

// --- Logging untuk Debugging (sangat direkomendasikan saat pengembangan) ---
// Pastikan folder log bisa ditulis oleh web server (izin 777 atau sesuai)
$logFilePath = __DIR__ . '/xendit_callback_log.txt';
file_put_contents($logFilePath, "\n--- " . date('Y-m-d H:i:s') . " - NEW CALLBACK ---\n", FILE_APPEND);
file_put_contents($logFilePath, "HTTP Method: " . $_SERVER['REQUEST_METHOD'] . "\n", FILE_APPEND);
file_put_contents($logFilePath, "Headers:\n" . json_encode(getallheaders(), JSON_PRETTY_PRINT) . "\n", FILE_APPEND);
$requestBody = file_get_contents('php://input');
file_put_contents($logFilePath, "Raw Body:\n" . $requestBody . "\n", FILE_APPEND);
// --- Akhir Logging ---

// Set header response agar Xendit tahu bahwa responsnya adalah JSON
header('Content-Type: application/json');

// --- 1. Verifikasi Callback Token (Penting untuk Keamanan) ---
// Ambil X-Callback-Token dari header HTTP
$xCallbackToken = $_SERVER['HTTP_X_CALLBACK_TOKEN'] ?? '';
$configuredCallbackToken = $xenditConfig['xendit_callback_token'] ?? '';

// Periksa apakah token ada dan cocok dengan yang dikonfigurasi
if (empty($configuredCallbackToken) || $xCallbackToken !== $configuredCallbackToken) {
    http_response_code(401); // Unauthorized
    echo json_encode(['status' => 'error', 'message' => 'Unauthorized callback token.']);
    file_put_contents($logFilePath, "Unauthorized callback token: " . $xCallbackToken . "\n", FILE_APPEND);
    exit();
}

// --- 2. Decode Payload JSON ---
$data = json_decode($requestBody, true);

// Periksa apakah decoding JSON berhasil
if (json_last_error() !== JSON_ERROR_NONE) {
    http_response_code(400); // Bad Request
    echo json_encode(['status' => 'error', 'message' => 'Invalid JSON payload.']);
    file_put_contents($logFilePath, "Invalid JSON payload.\n", FILE_APPEND);
    exit();
}

// Log payload yang sudah didecode
file_put_contents($logFilePath, "Decoded Payload:\n" . json_encode($data, JSON_PRETTY_PRINT) . "\n", FILE_APPEND);

// --- 3. Validasi Data yang Dibutuhkan ---
// Pastikan data penting seperti external_id dan status ada dalam payload
if (!isset($data['external_id']) || !isset($data['status'])) {
    http_response_code(400); // Bad Request
    echo json_encode(['status' => 'error', 'message' => 'Missing external_id or status in payload.']);
    file_put_contents($logFilePath, "Missing external_id or status.\n", FILE_APPEND);
    exit();
}

$xendit_external_id = $data['external_id'];
$xendit_status = $data['status']; // PAID, EXPIRED, SETTLED, CANCELLED, etc.
$xendit_id = $data['id'] ?? null; // ID unik invoice dari Xendit
$amount = $data['amount'] ?? 0; // Jumlah yang diminta Xendit untuk invoice
$paid_amount = $data['paid_amount'] ?? 0; // Jumlah aktual yang dibayar pelanggan
$payment_channel = $data['payment_channel'] ?? 'Unknown';
$payment_method = $data['payment_method'] ?? 'Unknown';
$paid_at = $data['paid_at'] ?? null; // Timestamp pembayaran dari Xendit

// Ekstrak ID tagihan lokal dari external_id
// Asumsi format: 'billing-isp-{id_tagihan_lokal}'
$local_tagihan_id = str_replace('billing-isp-', '', $xendit_external_id);

// Validasi apakah ID tagihan lokal adalah angka
if (!is_numeric($local_tagihan_id)) {
    http_response_code(400); // Bad Request
    echo json_encode(['status' => 'error', 'message' => 'Invalid local tagihan ID extracted: ' . $local_tagihan_id]);
    file_put_contents($logFilePath, "Invalid local tagihan ID extracted: " . $local_tagihan_id . "\n", FILE_APPEND);
    exit();
}

// --- 4. Mulai Transaksi Database ---
// Menggunakan transaksi untuk memastikan integritas data
$koneksi->begin_transaction();

try {
    // Ambil status tagihan saat ini dari database lokal
    $current_status_query = "SELECT status_tagihan, total_tagihan FROM tagihan WHERE id_tagihan = ?";
    $stmt_current_status = $koneksi->prepare($current_status_query);
    $stmt_current_status->bind_param("i", $local_tagihan_id);
    $stmt_current_status->execute();
    $result_current_status = $stmt_current_status->get_result();
    $current_tagihan_data = $result_current_status->fetch_assoc();
    $stmt_current_status->close();

    // Jika tagihan lokal tidak ditemukan
    if (!$current_tagihan_data) {
        http_response_code(404); // Not Found
        echo json_encode(['status' => 'error', 'message' => 'Local tagihan not found for external ID: ' . $xendit_external_id]);
        file_put_contents($logFilePath, "Local tagihan ID not found: " . $local_tagihan_id . "\n", FILE_APPEND);
        $koneksi->rollback(); // Batalkan transaksi
        exit();
    }

    $current_local_status = $current_tagihan_data['status_tagihan'];
    $total_tagihan_expected = $current_tagihan_data['total_tagihan'];

    // --- 5. Proses Berdasarkan Status Xendit ---

    // Jika Xendit status adalah PAID atau SETTLED dan tagihan lokal belum Lunas
    if (($xendit_status === 'PAID' || $xendit_status === 'SETTLED') && $current_local_status !== 'Lunas') {
        
        // Verifikasi jumlah pembayaran (opsional tapi direkomendasikan)
        // Beri toleransi jika ada perbedaan sangat kecil (misal 1-2 rupiah)
        if (abs($paid_amount - $total_tagihan_expected) > 5) { 
            error_log("Payment amount mismatch for tagihan ID " . $local_tagihan_id . ". Expected: " . $total_tagihan_expected . ", Paid: " . $paid_amount);
            
            // Tandai sebagai 'Menunggu Verifikasi' atau 'Partial' jika ada ketidakcocokan jumlah
            $update_status = 'Menunggu Verifikasi'; 
            $update_query = "UPDATE tagihan SET status_tagihan = ?, sisa_tagihan = ?, xendit_invoice_id = ?, tanggal_lunas = NULL WHERE id_tagihan = ?";
            $stmt = $koneksi->prepare($update_query);
            // Gunakan paid_amount sebagai sisa_tagihan sementara untuk review
            $stmt->bind_param("sisi", $update_status, $paid_amount, $xendit_id, $local_tagihan_id);
            $stmt->execute();
            $stmt->close();
            
            // Masukkan/Update data pembayaran ke tabel pembayaran
            $tanggal_bayar_format = $paid_at ? date('Y-m-d H:i:s', strtotime($paid_at)) : date('Y-m-d H:i:s');
            $status_pembayaran_histori = 'Pending Review'; // Status untuk histori pembayaran

            // Asumsi tabel pembayaran memiliki kolom `id_tagihan` dan `id_xendit_pembayaran`
            $check_pembayaran_exist = $koneksi->prepare("SELECT id_pembayaran FROM pembayaran WHERE pelanggan_id = (SELECT pelanggan_id FROM tagihan WHERE id_tagihan = ?) AND bulan_tagihan = (SELECT bulan_tagihan FROM tagihan WHERE id_tagihan = ?)");
            $check_pembayaran_exist->bind_param("ii", $local_tagihan_id, $local_tagihan_id);
            $check_pembayaran_exist->execute();
            $check_pembayaran_exist->store_result();

            if ($check_pembayaran_exist->num_rows === 0) {
                // Ambil pelanggan_id dan paket_id dari tabel tagihan
                $get_tagihan_info = $koneksi->prepare("SELECT pelanggan_id, paket_id, bulan_tagihan FROM tagihan WHERE id_tagihan = ?");
                $get_tagihan_info->bind_param("i", $local_tagihan_id);
                $get_tagihan_info->execute();
                $tagihan_info_result = $get_tagihan_info->get_result();
                $tagihan_info = $tagihan_info_result->fetch_assoc();
                $get_tagihan_info->close();

                if ($tagihan_info) {
                    $insert_pembayaran_query = "INSERT INTO pembayaran (pelanggan_id, paket_id, bulan_tagihan, tanggal_bayar, jumlah_bayar, metode_pembayaran, status_pembayaran, id_tagihan) VALUES (?, ?, ?, ?, ?, ?, ?, ?)";
                    $stmt_pembayaran = $koneksi->prepare($insert_pembayaran_query);
                    $stmt_pembayaran->bind_param("iissdsss", $tagihan_info['pelanggan_id'], $tagihan_info['paket_id'], $tagihan_info['bulan_tagihan'], $tanggal_bayar_format, $paid_amount, $payment_channel, $status_pembayaran_histori, $local_tagihan_id);
                    $stmt_pembayaran->execute();
                    $stmt_pembayaran->close();
                } else {
                    file_put_contents($logFilePath, "Error: Could not retrieve pelanggan_id/paket_id for tagihan ID " . $local_tagihan_id . "\n", FILE_APPEND);
                }
            } else {
                // Update pembayaran yang sudah ada jika ditemukan
                $update_pembayaran_query = "UPDATE pembayaran SET tanggal_bayar = ?, jumlah_bayar = ?, metode_pembayaran = ?, status_pembayaran = ? WHERE pelanggan_id = (SELECT pelanggan_id FROM tagihan WHERE id_tagihan = ?) AND bulan_tagihan = (SELECT bulan_tagihan FROM tagihan WHERE id_tagihan = ?)";
                $stmt_pembayaran = $koneksi->prepare($update_pembayaran_query);
                $stmt_pembayaran->bind_param("sdssii", $tanggal_bayar_format, $paid_amount, $payment_channel, $status_pembayaran_histori, $local_tagihan_id, $local_tagihan_id);
                $stmt_pembayaran->execute();
                $stmt_pembayaran->close();
            }
            $check_pembayaran_exist->close();


            $koneksi->commit();
            http_response_code(200);
            echo json_encode(['status' => 'success', 'message' => 'Tagihan ID ' . $local_tagihan_id . ' diperbarui sebagai ' . $update_status . ' (amount mismatch).']);
            file_put_contents($logFilePath, "Tagihan ID " . $local_tagihan_id . " diperbarui sebagai " . $update_status . " (amount mismatch).\n", FILE_APPEND);
            exit();
        }

        // Jika jumlah cocok, update status tagihan menjadi Lunas
        $update_query = "UPDATE tagihan SET status_tagihan = 'Lunas', sisa_tagihan = 0, xendit_invoice_id = ?, tanggal_lunas = NOW() WHERE id_tagihan = ?";
        $stmt = $koneksi->prepare($update_query);
        $stmt->bind_param("si", $xendit_id, $local_tagihan_id); 
        $stmt->execute();
        $stmt->close();

        // Masukkan atau perbarui data pembayaran di tabel 'pembayaran'
        $tanggal_bayar_format = $paid_at ? date('Y-m-d H:i:s', strtotime($paid_at)) : date('Y-m-d H:i:s');
        $status_pembayaran_histori = 'Lunas'; // Status aktual di tabel pembayaran

        // Asumsi tabel pembayaran memiliki kolom `id_tagihan` atau dapat diidentifikasi unik dengan pelanggan_id dan bulan_tagihan
        $check_pembayaran_exist = $koneksi->prepare("SELECT id_pembayaran FROM pembayaran WHERE pelanggan_id = (SELECT pelanggan_id FROM tagihan WHERE id_tagihan = ?) AND bulan_tagihan = (SELECT bulan_tagihan FROM tagihan WHERE id_tagihan = ?)");
        $check_pembayaran_exist->bind_param("ii", $local_tagihan_id, $local_tagihan_id);
        $check_pembayaran_exist->execute();
        $check_pembayaran_exist->store_result();
        
        if ($check_pembayaran_exist->num_rows === 0) {
            // Ambil pelanggan_id dan paket_id dari tabel tagihan
            $get_tagihan_info = $koneksi->prepare("SELECT pelanggan_id, paket_id, bulan_tagihan FROM tagihan WHERE id_tagihan = ?");
            $get_tagihan_info->bind_param("i", $local_tagihan_id);
            $get_tagihan_info->execute();
            $tagihan_info_result = $get_tagihan_info->get_result();
            $tagihan_info = $tagihan_info_result->fetch_assoc();
            $get_tagihan_info->close();

            if ($tagihan_info) {
                $insert_pembayaran_query = "INSERT INTO pembayaran (pelanggan_id, paket_id, bulan_tagihan, tanggal_bayar, jumlah_bayar, metode_pembayaran, status_pembayaran, id_tagihan) VALUES (?, ?, ?, ?, ?, ?, ?, ?)";
                $stmt_pembayaran = $koneksi->prepare($insert_pembayaran_query);
                $stmt_pembayaran->bind_param("iissdsss", $tagihan_info['pelanggan_id'], $tagihan_info['paket_id'], $tagihan_info['bulan_tagihan'], $tanggal_bayar_format, $paid_amount, $payment_channel, $status_pembayaran_histori, $local_tagihan_id);
                $stmt_pembayaran->execute();
                $stmt_pembayaran->close();
            } else {
                file_put_contents($logFilePath, "Error: Could not retrieve pelanggan_id/paket_id for tagihan ID " . $local_tagihan_id . "\n", FILE_APPEND);
            }
        } else {
            // Update pembayaran yang sudah ada jika ditemukan
            $update_pembayaran_query = "UPDATE pembayaran SET tanggal_bayar = ?, jumlah_bayar = ?, metode_pembayaran = ?, status_pembayaran = ? WHERE pelanggan_id = (SELECT pelanggan_id FROM tagihan WHERE id_tagihan = ?) AND bulan_tagihan = (SELECT bulan_tagihan FROM tagihan WHERE id_tagihan = ?)";
            $stmt_pembayaran = $koneksi->prepare($update_pembayaran_query);
            $stmt_pembayaran->bind_param("sdssii", $tanggal_bayar_format, $paid_amount, $payment_channel, $status_pembayaran_histori, $local_tagihan_id, $local_tagihan_id);
            $stmt_pembayaran->execute();
            $stmt_pembayaran->close();
        }
        $check_pembayaran_exist->close();

        $koneksi->commit(); // Commit transaksi jika semua berhasil
        http_response_code(200); // Penting: Selalu kembalikan 200 OK ke Xendit
        echo json_encode(['status' => 'success', 'message' => 'Tagihan ID ' . $local_tagihan_id . ' berhasil dilunasi.']);
        file_put_contents($logFilePath, "Tagihan ID " . $local_tagihan_id . " berhasil dilunasi.\n", FILE_APPEND);

    } elseif ($xendit_status === 'EXPIRED' && $current_local_status !== 'Lunas') {
        // Jika Xendit invoice expired dan status lokal masih 'Belum Lunas'
        $update_query = "UPDATE tagihan SET status_tagihan = 'Jatuh Tempo', tanggal_lunas = NULL WHERE id_tagihan = ?";
        $stmt = $koneksi->prepare($update_query);
        $stmt->bind_param("i", $local_tagihan_id);
        $stmt->execute();
        $stmt->close();
        $koneksi->commit();
        http_response_code(200);
        echo json_encode(['status' => 'success', 'message' => 'Tagihan ID ' . $local_tagihan_id . ' diatur ke Jatuh Tempo karena Xendit invoice expired.']);
        file_put_contents($logFilePath, "Tagihan ID " . $local_tagihan_id . " diatur ke Jatuh Tempo (Xendit expired).\n", FILE_APPEND);

    } else {
        // Untuk status Xendit lainnya atau jika status lokal sudah 'Lunas' (tidak perlu update lagi)
        http_response_code(200); 
        echo json_encode(['status' => 'success', 'message' => 'Callback received, no action taken or already processed. Status: ' . $xendit_status . ', Local Status: ' . $current_local_status]);
        file_put_contents($logFilePath, "Callback received, no action taken or already processed. Tagihan ID " . $local_tagihan_id . ", Xendit Status: " . $xendit_status . ", Local Status: " . $current_local_status . "\n", FILE_APPEND);
    }

} catch (Exception $e) {
    // Jika ada kesalahan di dalam blok try, rollback transaksi
    $koneksi->rollback();
    http_response_code(500); // Internal Server Error
    echo json_encode(['status' => 'error', 'message' => 'Database transaction failed: ' . $e->getMessage()]);
    file_put_contents($logFilePath, "Database transaction failed for Tagihan ID " . $local_tagihan_id . ": " . $e->getMessage() . "\n", FILE_APPEND);
}

// Tutup koneksi database
if (isset($koneksi)) {
    $koneksi->close();
}
?>