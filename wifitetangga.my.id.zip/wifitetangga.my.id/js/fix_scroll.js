// C:\xampp\htdocs\billing_isp_app\js\fix_scroll.js

document.addEventListener('DOMContentLoaded', function() {
    // --- PENTING SANGAT PENTING: SESUAIKAN SELECTOR ELEMEN YANG DAPAT DISCROLL DI SINI ---
    // Ini adalah BAGIAN KRITIS dari seluruh 'fix' ini. Anda HARUS mengidentifikasi
    // elemen HTML mana di halaman Anda yang secara visual memiliki scrollbar vertikal
    // dan yang nilai 'scrollTop'-nya berubah ketika Anda menggulir halaman.
    // Jika ini tidak tepat, pemulihan scroll TIDAK AKAN PERNAH BERHASIL.

    // CARA MENGIDENTIFIKASI ELEMEN YANG BENAR (WAJIB DILAKUKAN):
    // 1. Buka halaman web Anda di browser (misal Chrome, Firefox).
    // 2. Tekan F12 untuk membuka Developer Tools.
    // 3. Pergi ke tab "Elements".
    // 4. Gulir halaman Anda ke bawah. Sambil menggulir, perhatikan di panel "Elements":
    //    - Elemen mana yang memiliki scrollbar di sampingnya?
    //    - Elemen mana yang saat Anda pilih (klik) di Developer Tools,
    //      kemudian Anda ketik di tab "Console" (misalnya `document.querySelector('.nama-kelas-anda').scrollTop;`),
    //      nilai `scrollTop`-nya berubah (bukan 0) saat Anda menggulir halaman?
    // 5. Elemen yang nilai `scrollTop`-nya berubah itulah yang HARUS Anda gunakan di bawah.

    // UNKOMENTARI HANYA SATU (1) BARIS di bawah ini yang paling cocok dengan elemen scrollable di halaman Anda:
    // SETELAH ANDA YAKIN DENGAN PILIHAN ANDA, HAPUS KOMENTAR (//) PADA BARIS TERSEBUT
    // DAN PASTIKAN OPSI LAINNYA TETAP DIKOMENTARI.

    // Opsi 1: Paling Umum untuk layout dashboard modern (biasanya ada div utama yang berisi konten)
    //         Coba ini terlebih dahulu jika Anda memiliki div dengan kelas seperti 'main-content', 'app-content', dll.
    //         Berdasarkan dashboard.php Anda, konten utama dibungkus dalam <div class="main-content">.
    const scrollableElement = document.querySelector('.main-content'); // <-- Kembali menggunakan .main-content

    // Opsi 2: Jika scrollbar ada di seluruh elemen body (sering terjadi di situs web sederhana atau jika main-content tidak penuh)
    //         Unkomentari baris ini jika Opsi 1 tidak berhasil dan 'body' adalah elemen yang digulir.
    // const scrollableElement = document.body;

    // Opsi 3: Jika scrollbar ada di seluruh dokumen HTML (tag <html>) - SANGAT UMUM untuk scroll seluruh halaman.
    //         Unkomentari baris ini jika Opsi 1 & 2 tidak berhasil. Ini sering terjadi jika body memiliki tinggi 100%.
    // const scrollableElement = document.documentElement; 

    if (!scrollableElement) {
        // Pesan error ini akan muncul jika selector yang Anda gunakan tidak ditemukan di DOM.
        // Pastikan selector Anda benar-benar ada di HTML.
        console.error("FIX SCROLL: Elemen yang dapat discroll tidak ditemukan! Pemulihan scroll tidak akan berfungsi. Pastikan selector di fix_scroll.js benar.");
        return; // Hentikan eksekusi skrip jika elemen tidak ditemukan
    }

    let lastScrollPosition = 0; // Variabel untuk menyimpan posisi scroll

    // Fungsi untuk menyimpan posisi scroll saat ini dari elemen yang diidentifikasi
    function saveScrollPosition() {
        lastScrollPosition = scrollableElement.scrollTop;
        // Pastikan kita hanya menyimpan jika posisi scroll lebih dari 0
        // Ini mencegah penyimpanan posisi '0' yang tidak perlu dan membingungkan logika pemulihan.
        if (lastScrollPosition > 0) {
            sessionStorage.setItem('savedScrollPosition', lastScrollPosition);
            console.log('FIX SCROLL: Saved scroll position:', lastScrollPosition);
        } else {
            console.log('FIX SCROLL: Not saving scroll position (currently 0).');
            sessionStorage.removeItem('savedScrollPosition'); // Hapus jika sebelumnya ada
        }
    }

    // Fungsi untuk memulihkan posisi scroll ke elemen yang diidentifikasi
    function restoreScrollPosition() {
        const storedPos = parseInt(sessionStorage.getItem('savedScrollPosition'));

        // Hanya pulihkan jika ada posisi tersimpan yang valid (bukan NaN dan lebih besar dari 0)
        if (!isNaN(storedPos) && storedPos > 0) {
            // Gunakan requestAnimationFrame untuk memastikan operasi DOM berjalan setelah browser siap,
            // dan setTimeout untuk memberikan jeda ekstra setelah animasi loading.
            requestAnimationFrame(() => {
                // Memberikan sedikit waktu setelah DOM dirender dan kemungkinan animasi loading selesai
                setTimeout(() => {
                    scrollableElement.scrollTop = storedPos;
                    sessionStorage.removeItem('savedScrollPosition'); // Hapus setelah dipulihkan agar tidak mengganggu navigasi lain
                    console.log('FIX SCROLL: Restored scroll position to:', storedPos);
                }, 100); // Jeda 100ms. Pastikan jeda ini lebih lama dari jeda di hideLoading (yang 50ms)
            });
        } else {
            // Pesan ini muncul jika tidak ada posisi tersimpan atau posisi tersimpan adalah 0.
            // Ini biasanya karena elemen yang digulir tidak pernah mencapai posisi > 0,
            // atau elemen yang diidentifikasi di atas salah.
            console.log('FIX SCROLL: No valid scroll position to restore or position is 0. Current element scroll:', scrollableElement.scrollTop);
        }
    }

    // Event listener untuk klik link navigasi (seperti di sidebar)
    // Ini penting agar posisi scroll disimpan SEBELUM halaman berpindah
    const navLinks = document.querySelectorAll('.sidebar-nav ul li a');
    navLinks.forEach(link => {
        link.addEventListener('click', function(event) {
            const currentPathname = window.location.pathname;
            const linkHref = this.getAttribute('href');
            const currentPageFile = currentPathname.split('/').pop();
            const linkPageFile = linkHref ? linkHref.split('/').pop() : '';

            // Hanya simpan posisi scroll jika ini adalah navigasi ke halaman lain
            // (bukan ke halaman yang sama atau link yang hanya '#' yang biasanya untuk toggle submenu)
            if (linkHref && linkHref !== '#' && linkPageFile !== currentPageFile) {
                saveScrollPosition();
                // Fungsi window.showLoading() dari loading_scripts.js sudah dipanggil pada klik ini
                // Tidak perlu preventDefault() di sini, biarkan browser menavigasi setelah menyimpan posisi
            }
        });
    });

    // Event listener untuk memulihkan scroll saat halaman BARU selesai dimuat
    // Menggunakan 'load' untuk memastikan semua konten sudah dirender dan loading overlay sudah disembunyikan
    window.addEventListener('load', function() {
        console.log('FIX SCROLL: Window load event fired.');
        // Beri sedikit jeda setelah hideLoading() selesai agar tidak bentrok
        // Jeda ini harus lebih lama dari jeda di hideLoading (50ms) dan juga penundaan internal restoreScrollPosition
        setTimeout(() => {
            restoreScrollPosition();
        }, 150);
    });

    // Pastikan browser tidak otomatis memulihkan scroll.
    // Ini memberi kendali penuh pada JavaScript kita.
    if ('scrollRestoration' in history) {
        history.scrollRestoration = 'manual';
        console.log('FIX SCROLL: history.scrollRestoration set to manual.');
    }
});
