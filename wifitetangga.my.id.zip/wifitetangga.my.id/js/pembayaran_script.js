// C:\xampp\htdocs\billing_isp_app\js\pembayaran_script.js

document.addEventListener('DOMContentLoaded', function() {
    // ====================================================================================================
    // *** VARIABEL GLOBAL DARI PHP (Sudah didefinisikan di `pembayaran.php` sebelum script ini dimuat) ***
    // window.APP_BASE_URL_FOR_PRINT
    // window.API_ACCESS_TOKEN_FOR_PRINT
    // window.DEFAULT_REMINDER_MESSAGE_TEMPLATE
    // window.pelanggan_belum_lunas_list_data (jika di-JSON-encode dari PHP)
    // window.INITIAL_PELANGGAN_ID, dll.
    // ====================================================================================================

    // Variabel elemen dari HTML
    const paymentForm = document.getElementById('paymentForm');
    const pelangganIdSelect = document.getElementById('pelanggan_id');
    const bulanTagihanInput = document.getElementById('bulan_tagihan');
    const jumlahBayarInput = document.getElementById('jumlah_bayar');
    const hargaSeharusnyaSpan = document.getElementById('harga_seharusnya');
    const paketIdFromPelangganInput = document.getElementById('paket_id_from_pelanggan');
    const metodeCashCheckbox = document.getElementById('metode_cash');
    const metodeTransferCheckbox = document.getElementById('metode_transfer');
    const metodePembayaranHiddenInput = document.getElementById('metode_pembayaran_hidden');
    const metodePembayaranErrorDiv = document.getElementById('metodePembayaranError');

    const btnCatatPembayaran = document.getElementById('btnCatatPembayaran');
    const btnRiwayatPembayaran = document.getElementById('btnRiwayatPembayaran');
    const btnBelumLunas = document.getElementById('btnBelumLunas');
    const tabCatatPembayaran = document.getElementById('catatPembayaran');
    const tabRiwayatPembayaran = document.getElementById('riwayatPembayaran');
    const tabBelumLunas = document.getElementById('belumLunas');

    const reminderMessageTextArea = document.getElementById('reminderMessage'); 

    // Action Menu Modal Elements (spesifik untuk halaman ini)
    const actionMenuModal = document.getElementById('actionMenuModal');
    const closeActionMenuModalBtn = document.getElementById('closeActionMenuModal');
    const actionCustomerNameSpan = document.getElementById('actionCustomerName');
    const actionMenuButtonsDiv = document.getElementById('actionMenuButtons');


    // ====================================================================================================
    // *** FUNGSI-FUNGSI KHUSUS PEMBAYARAN.PHP ***
    // ====================================================================================================
    
    // Fungsi untuk mengupdate info paket dan harga (termasuk AJAX get_sisa_tagihan.php)
    function updatePaketInfo() {
        var selectPelanggan = pelangganIdSelect;
        if (selectPelanggan && selectPelanggan.selectedIndex !== -1 && selectPelanggan.value !== "") {
            var selectedOption = selectPelanggan.options[selectPelanggan.selectedIndex];
            var hargaPaketDasar = parseFloat(selectedOption.dataset.hargaPaket || '0');
            var usesPpn = parseInt(selectedOption.dataset.usesPpn || '0');
            var paketId = selectedOption.dataset.paketId || '';
            var pelangganId = selectedOption.value;

            let finalHarga = hargaPaketDasar;
            if (usesPpn === 1) {
                finalHarga += (hargaPaketDasar * 0.11);
            }

            const bulanTagihan = bulanTagihanInput.value;

            if (pelangganId && bulanTagihan) {
                window.showNotification('Memuat sisa tagihan...', 'info', 1500); 
                fetch(`get_sisa_tagihan.php?pelanggan_id=${pelangganId}&bulan_tagihan=${bulanTagihan}`) 
                    .then(response => {
                        if (!response.ok) {
                            throw new Error('Network response was not ok');
                        }
                        return response.json();
                    })
                    .then(data => {
                        if (data.sisa_tagihan !== undefined && data.sisa_tagihan !== null) {
                            jumlahBayarInput.value = parseFloat(data.sisa_tagihan).toFixed(0);
                            hargaSeharusnyaSpan.innerText = 'Rp ' + parseFloat(data.sisa_tagihan).toLocaleString('id-ID', {
                                minimumFractionDigits: 0,
                                maximumFractionDigits: 0
                            });
                        } else {
                            jumlahBayarInput.value = finalHarga.toFixed(0);
                            hargaSeharusnyaSpan.innerText = 'Rp ' + finalHarga.toLocaleString('id-ID', {
                                minimumFractionDigits: 0,
                                maximumFractionDigits: 0
                            });
                        }
                        window.hideNotification(); 
                    })
                    .catch(error => {
                        console.error('Error fetching sisa tagihan:', error);
                        window.showNotification('Gagal memuat sisa tagihan. Coba lagi.', 'error', 3000); 
                        jumlahBayarInput.value = finalHarga.toFixed(0);
                        hargaSeharusnyaSpan.innerText = 'Rp ' + finalHarga.toLocaleString('id-ID', {
                            minimumFractionDigits: 0,
                            maximumFractionDigits: 0
                        });
                    });
            } else {
                jumlahBayarInput.value = finalHarga.toFixed(0);
                hargaSeharusnyaSpan.innerText = 'Rp ' + finalHarga.toLocaleString('id-ID', {
                    minimumFractionDigits: 0,
                    maximumFractionDigits: 0
                });
            }

            paketIdFromPelangganInput.value = paketId;
        } else {
            jumlahBayarInput.value = '0';
            hargaSeharusnyaSpan.innerText = 'Rp 0';
            paketIdFromPelangganInput.value = '';
        }
    }

    // Fungsi untuk menggabungkan nilai checkbox dan mengaturnya ke input hidden (Dibuat global)
    window.updateMetodePembayaranInput = function() { 
        let selectedMethods = [];
        if (metodeCashCheckbox.checked) {
            selectedMethods.push(metodeCashCheckbox.value);
        }
        if (metodeTransferCheckbox.checked) {
            selectedMethods.push(metodeTransferCheckbox.value);
        }

        metodePembayaranHiddenInput.value = selectedMethods.join(', ') || '';

        if (selectedMethods.length === 0) {
            metodePembayaranErrorDiv.style.display = 'block';
        } else {
            metodePembayaranErrorDiv.style.display = 'none';
        }
    }

    // Fungsi untuk menampilkan tab
    function showTab(tabId) {
        var tabs = document.getElementsByClassName('tab-content');
        for (var i = 0; i < tabs.length; i++) {
            tabs[i].classList.remove('active-tab'); 
        }
        document.getElementById(tabId).classList.add('active-tab');

        var buttons = document.querySelectorAll('.tabs .btn');
        buttons.forEach(function(button) {
            button.classList.remove('btn-primary');
            button.classList.add('btn-secondary');
        });
        
        var activeBtn = document.getElementById('btn' + tabId.charAt(0).toUpperCase() + tabId.slice(1));
        if (activeBtn) {
            activeBtn.classList.remove('btn-secondary');
            activeBtn.classList.add('btn-primary');
        }
    }

    // Fungsi untuk prefill form pembayaran (Dibuat global)
    window.prefillPaymentForm = function(pelangganId, hargaTotalYangAkanDibayar, paketId, bulanTagihan) {
        showTab('catatPembayaran');

        pelangganIdSelect.value = pelangganId;
        bulanTagihanInput.value = bulanTagihan;
        
        jumlahBayarInput.value = parseFloat(hargaTotalYangAkanDibayar).toFixed(0);
        hargaSeharusnyaSpan.innerText = 'Rp ' + parseFloat(hargaTotalYangAkanDibayar).toLocaleString('id-ID', {
            minimumFractionDigits: 0,
            maximumFractionDigits: 0
        });
        paketIdFromPelangganInput.value = paketId;

        document.getElementById('tanggal_bayar').value = '<?php echo date('Y-m-d'); ?>';

        window.updateMetodePembayaranInput(); // Panggil fungsi global

        tabCatatPembayaran.scrollIntoView({
            behavior: 'smooth',
            block: 'start' // FIX: Menggunakan nilai valid 'start'
        });
    }

    // Fungsi untuk menyimpan pesan pengingat kustom
    function saveCustomReminderMessage() {
        const message = reminderMessageTextArea.value;
        try {
            localStorage.setItem('customReminderMessage', message);
            window.showNotification('Pesan pengingat berhasil disimpan ke browser Anda!', 'success');
        } catch (e) {
            window.showNotification('Gagal menyimpan pesan pengingat. Mungkin browser Anda tidak mendukung penyimpanan lokal atau ruang penyimpanan penuh.', 'error');
            console.error('Failed to save reminder message:', e);
        }
    }

    // Fungsi untuk konfirmasi pengiriman pengingat massal
    async function sendReminderToAllUnpaidConfirmation() {
        const customMessage = reminderMessageTextArea.value;

        if (!customMessage.trim()) {
            window.showNotification('Pesan pengingat tidak boleh kosong! Silakan isi pesan di bagian atas tabel.', 'warning');
            return;
        }

        window.showCustomConfirm( // Panggil fungsi global
            'Konfirmasi Kirim Pengingat Massal',
            'Apakah Anda yakin ingin mengirim pesan pengingat tagihan ke SEMUA pelanggan yang belum lunas? Pesan yang akan dikirim: \n\n"' + customMessage + '"',
            { type: 'callback', func: sendReminderToAllUnpaid }
        );
    }

    // Fungsi untuk mengirim pengingat massal
    async function sendReminderToAllUnpaid() {
        console.log("sendReminderToAllUnpaid function started.");
        const kirimPengingatBtn = document.getElementById('kirimPengingatBtn');
        const originalButtonHtml = kirimPengingatBtn.innerHTML;
        const customMessage = reminderMessageTextArea.value;

        kirimPengingatBtn.disabled = true;
        kirimPengingatBtn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Mengirim...';

        window.showNotification('Mengirim pengingat ke semua pelanggan menunggak... Harap tunggu.<br>Terkirim: 0, Gagal: 0', 'info', 0);

        const attachInvoice = false;

        try {
            const response = await fetch('send_whatsapp_message.php', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify({
                    action: 'send_reminder',
                    message_content: customMessage,
                    customer_ids: [],
                    attach_invoice: attachInvoice
                }),
            });

            const responseText = await response.text();
            console.log("Raw Response Text from send_whatsapp_message.php (All Unpaid):", responseText);

            if (!response.ok) {
                console.error(`HTTP Error (All Unpaid):`, response.status, responseText);
                let errorData = {};
                try {
                    errorData = JSON.parse(responseText);
                } catch (e) {
                    errorData.message = responseText;
                }
                window.showNotification(`Gagal mengirim pengingat (HTTP ${response.status}): ${errorData.message || 'Error tidak diketahui dari server.'}`, 'error');
                return;
            }

            let data;
            try {
                data = JSON.parse(responseText);
            } catch (jsonError) {
                console.error("JSON parsing error (All Unpaid):", jsonError);
                window.showNotification('Gagal memproses respons dari server. Respons tidak valid JSON.', 'error');
                return;
            }
            
            console.log(`Parsed Data from send_whatsapp_message.php (All Unpaid):`, data);

            const isSuccess = (data.status === 'sent' || (typeof data.status === 'boolean' && data.status === true) || (typeof data.message === 'string' && (data.message.includes('berhasil dikirim') || data.message.includes('success'))));

            if (isSuccess) {
                let sentCount = 0;
                let failedCount = 0;

                if (data.detailed_results && Array.isArray(data.detailed_results)) {
                    sentCount = data.detailed_results.filter(r => r.status === 'sent').length;
                    failedCount = data.detailed_results.filter(r => r.status === 'failed').length;
                } else {
                    console.warn("data.detailed_results is missing or not an array for All Unpaid. Attempting to parse from message.");
                    const match = data.message.match(/Berhasil: (\d+), Gagal: (\d+)/);
                    if (match) {
                        sentCount = parseInt(match[1]);
                        failedCount = parseInt(match[2]);
                    }
                }

                window.showNotification(`<strong>Pengingat Selesai!</strong> ${data.message} <br>Total terkirim: ${sentCount} <br>Total gagal: ${failedCount}`, 'success', 5000);
            } else {
                window.showNotification('Gagal mengirim pengingat: ' + (data.message || 'Error tidak diketahui dari API Fonnte.'), 'error');
            }
        } catch (error) {
            console.error(`Catch Error (All Unpaid):`, error);
            window.showNotification('Terjadi kesalahan jaringan atau server saat mengirim pengingat: ' + error.message, 'error');
        } finally {
            console.log("Finally block executed (All Unpaid).");
            if (kirimPengingatBtn) {
                kirimPengingatBtn.disabled = false;
                kirimPengingatBtn.innerHTML = originalButtonHtml;
            }
            
            // Reload halaman setelah notifikasi selesai ditampilkan
            setTimeout(() => {
                console.log("Reloading page...");
                // FIX: Menggunakan variabel global yang sudah didefinisikan oleh PHP di halaman utama
                window.location.href = window.location.pathname + '?tab=belumLunas' +
                    (typeof window.INITIAL_PELANGGAN_ID !== 'undefined' && window.INITIAL_PELANGGAN_ID ? '&pelanggan_id=' + window.INITIAL_PELANGGAN_ID : '') +
                    (typeof window.FILTER_TGL_TERBIT_MULAI_BL !== 'undefined' && window.FILTER_TGL_TERBIT_MULAI_BL ? '&filter_tgl_terbit_mulai_bl=' + window.FILTER_TGL_TERBIT_MULAI_BL : '') +
                    (typeof window.FILTER_TGL_TERBIT_AKHIR_BL !== 'undefined' && window.FILTER_TGL_TERBIT_AKHIR_BL ? '&filter_tgl_terbit_akhir_bl=' + window.FILTER_TGL_TERBIT_AKHIR_BL : '');
            }, 2000); 
        }
    }

    // Fungsi untuk konfirmasi pengiriman pengingat individu
    async function sendSingleReminderConfirmation(buttonElement) {
        const customerName = buttonElement.dataset.customerName;
        const invoiceMonth = buttonElement.dataset.invoiceMonth;
        
        const baseMessageContent = reminderMessageTextArea.value;

        if (!baseMessageContent.trim()) {
            window.showNotification('Pesan pengingat tidak boleh kosong! Silakan isi pesan di bagian atas tabel.', 'warning');
            return;
        }

        const personalizedMessagePreview = baseMessageContent
            .replace(/\[nama_pelanggan\]/g, customerName)
            .replace(/\[bulan\]/g, invoiceMonth)
            .replace(/\[jumlah\]/g, buttonElement.dataset.invoiceAmount)
            .replace(/\[jatuh_tempo\]/g, buttonElement.dataset.dueDate)
            .replace(/\[invoice_link\]/g, `[link_invoice_untuk_${customerName}]`);

        window.showCustomConfirm( // Panggil fungsi global
            'Konfirmasi Kirim Pengingat',
            `Apakah Anda yakin ingin mengirim pengingat ke ${customerName} (Tagihan ${invoiceMonth})?\n\nPesan:\n"${personalizedMessagePreview}"`,
            { type: 'callback', func: sendSingleReminder, args: [buttonElement] } // Pass the button element itself
        );
    }

    // Fungsi untuk mengirim pengingat individu
    async function sendSingleReminder(buttonElement) {
        console.log("sendSingleReminder function started for:", buttonElement.dataset.customerName);
        const customerId = buttonElement.dataset.customerId;
        const customerName = buttonElement.dataset.customerName;
        const invoiceId = buttonElement.dataset.invoiceId;
        const invoiceMonth = buttonElement.dataset.invoiceMonth;
        const invoiceAmount = buttonElement.dataset.invoiceAmount;
        const dueDate = buttonElement.dataset.dueDate;
        const phoneNumber = buttonElement.dataset.phoneNumber;

        const originalButtonHtml = buttonElement.innerHTML;

        const baseMessageContent = reminderMessageTextArea.value;

        const personalizedMessage = baseMessageContent
            .replace(/\[nama_pelanggan\]/g, customerName)
            .replace(/\[bulan\]/g, invoiceMonth)
            .replace(/\[jumlah\]/g, invoiceAmount)
            .replace(/\[jatuh_tempo\]/g, dueDate)
            .replace(/\[invoice_link\]/g, `${window.APP_BASE_URL_FOR_PRINT}/pages/print_invoice.php?source_table=tagihan&id=${invoiceId}&api_access_token=${window.API_ACCESS_TOKEN_FOR_PRINT}`); // FIX: Menggunakan variabel global
        
        buttonElement.disabled = true;
        buttonElement.innerHTML = '<i class="fas fa-spinner fa-spin"></i>';
        
        window.showNotification(`Mengirim pesan ke ${customerName}...`, 'info', 0);

        try {
            const response = await fetch('send_whatsapp_message.php', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify({
                    action: 'test_message',
                    phoneNumber: phoneNumber,
                    message_content: personalizedMessage,
                    customer_ids: [],
                    attach_invoice: false
                }),
            });

            const responseText = await response.text();
            console.log(`Raw Response Text for ${customerName} (ID: ${customerId}):`, responseText);

            if (!response.ok) {
                console.error(`HTTP Error for ${customerName} (ID: ${customerId}):`, response.status, responseText);
                let errorData = {};
                try {
                    errorData = JSON.parse(responseText);
                } catch (e) {
                    errorData.message = responseText;
                }
                window.showNotification(`Gagal mengirim pesan ke ${customerName}: ${errorData.message || 'Error tidak diketahui.'}`, 'error');
                return;
            }

            let data;
            try {
                data = JSON.parse(responseText);
            } catch (jsonError) {
                console.error(`JSON parsing error for ${customerName} (ID: ${customerId}):`, jsonError);
                window.showNotification(`Gagal memproses respons untuk ${customerName}: Respons tidak valid JSON.`, 'error');
                return;
            }
            
            console.log(`Parsed Data for ${customerName} (ID: ${customerId}):`, data);

            const isSuccess = (data.status === 'sent' || (typeof data.status === 'boolean' && data.status === true) || (typeof data.message === 'string' && (data.message.includes('berhasil dikirim') || data.message.includes('success'))));

            if (isSuccess) {
                window.showNotification(`Pesan ke ${customerName} berhasil terkirim!`, 'success');
            } else {
                window.showNotification(`Gagal mengirim pesan ke ${customerName}: ${data.message || 'Error tidak diketahui dari API.'}`, 'error');
            }
        } catch (error) {
            console.error(`Catch Error for ${customerName} (ID: ${customerId}):`, error);
            window.showNotification(`Terjadi kesalahan jaringan atau server saat mengirim pesan ke ${customerName}: ${error.message}`, 'error');
        } finally {
            buttonElement.disabled = false;
            buttonElement.innerHTML = originalButtonHtml;
        }
    }


    document.addEventListener('DOMContentLoaded', function() {
        const pelangganIdSelect = document.getElementById('pelanggan_id');
        const bulanTagihanInput = document.getElementById('bulan_tagihan');
        const metodeCashCheckbox = document.getElementById('metode_cash');
        const metodeTransferCheckbox = document.getElementById('metode_transfer');
        const metodePembayaranErrorDiv = document.getElementById('metodePembayaranError');
        const paymentForm = document.getElementById('paymentForm');

        const btnCatatPembayaran = document.getElementById('btnCatatPembayaran');
        const btnRiwayatPembayaran = document.getElementById('btnRiwayatPembayaran');
        const btnBelumLunas = document.getElementById('btnBelumLunas');
        
        // Event Listener Tabs
        if (btnCatatPembayaran) {
            btnCatatPembayaran.addEventListener('click', function() { showTab('catatPembayaran'); });
        }
        if (btnRiwayatPembayaran) {
            btnRiwayatPembayaran.addEventListener('click', function() { showTab('riwayatPembayaran'); });
        }
        if (btnBelumLunas) {
            btnBelumLunas.addEventListener('click', function() { showTab('belumLunas'); });
        }

        const kirimPengingatBtn = document.getElementById('kirimPengingatBtn');
        if (kirimPengingatBtn) {
            kirimPengingatBtn.addEventListener('click', sendReminderToAllUnpaidConfirmation);
            kirimPengingatBtn.removeAttribute('onclick'); 
        }

        const saveReminderMessageBtn = document.getElementById('saveReminderMessageBtn');
        if (saveReminderMessageBtn) {
            saveReminderMessageBtn.addEventListener('click', saveCustomReminderMessage);
            saveReminderMessageBtn.removeAttribute('onclick');
        }

        // Delegasi event untuk tombol pengingat tunggal
        document.querySelector('table.data-table tbody').addEventListener('click', function(event) {
            const targetButton = event.target.closest('.send-single-reminder-btn');
            if (targetButton) {
                event.preventDefault(); 
                event.stopPropagation();
                sendSingleReminderConfirmation(targetButton);
            }
        });

        const savedCustomReminderMessage = localStorage.getItem('customReminderMessage');
        // Pastikan reminderMessageTextArea didefinisikan jika ingin menggunakan nilai default
        if (reminderMessageTextArea) {
            if (savedCustomReminderMessage) {
                reminderMessageTextArea.value = savedCustomReminderMessage;
            } else {
                reminderMessageTextArea.value = window.DEFAULT_REMINDER_MESSAGE_TEMPLATE; // FIX: Menggunakan variabel global
            }
        }

        var defaultTabId = 'catatPembayaran';
        var urlParams = new URLSearchParams(window.location.search);
        var statusFilter = urlParams.get('status');
        var initialPelangganId = urlParams.get('pelanggan_id');
        var initialTagihanId = urlParams.get('tagihan_id');
        var initialTabFromUrl = urlParams.get('tab');
        var filterTglMulaiRiwayat = urlParams.get('filter_tgl_mulai_riwayat');
        var filterTglAkhirRiwayat = urlParams.get('filter_tgl_akhir_riwayat');
        var filterTglTerbitMulaiBl = urlParams.get('filter_tgl_terbit_mulai_bl');
        var filterTglTerbitAkhirBl = urlParams.get('filter_tgl_terbit_akhir_bl');


        if (initialTabFromUrl) {
            defaultTabId = initialTabFromUrl;
        } else if (filterTglMulaiRiwayat || filterTglAkhirRiwayat || urlParams.has('filter_penagih_id_riwayat')) {
            defaultTabId = 'riwayatPembayaran';
        } else if (filterTglTerbitMulaiBl || filterTglTerbitAkhirBl || urlParams.has('filter_penagih_id_bl')) {
            defaultTabId = 'belumLunas';
        } else if (initialTagihanId) {
            defaultTabId = 'catatPembayaran';
        } else if (initialPelangganId) {
            defaultTabId = 'riwayatPembayaran';
        } else if (statusFilter === 'lunas') {
            defaultTabId = 'riwayatPembayaran';
        } else if (statusFilter === 'belum_lunas') {
            defaultTabId = 'belumLunas';
        }
        
        showTab(defaultTabId);

        // Jika pelanggan list sudah di-encode di PHP dan tersedia secara global
        // window.pelanggan_belum_lunas_list = <?php echo json_encode($pelanggan_belum_lunas_list, JSON_HEX_TAG | JSON_HEX_APOS | JSON_HEX_AMP | JSON_HEX_QUOT); ?>;

        if (initialPelangganId && initialTagihanId) {
            let pelangganBelumLunasList = [];
            // Karena `pelanggan_belum_lunas_list` didefinisikan dalam PHP, kita perlu menyuntiknya ke JavaScript
            // atau memastikan ia sudah di-JSON-encode dan tersedia di sini.
            // Untuk memastikan ini berfungsi dengan baik, kita akan langsung menyuntikkan data ke sini.
            try {
                // Asumsi: data $pelanggan_belum_lunas_list sudah di-JSON-encode di suatu tempat di HTML.
                // Jika tidak, Anda perlu menambahkan:
                // <script> window.pelanggan_belum_lunas_list_data = <?php echo json_encode($pelanggan_belum_lunas_list, JSON_HEX_TAG | JSON_HEX_APOS | JSON_HEX_AMP | JSON_HEX_QUOT); ?>; </script>
                // di pembayaran.php sebelum pembayaran_script.js dimuat.
                if (typeof window.pelanggan_belum_lunas_list_data !== 'undefined') {
                    pelangganBelumLunasList = window.pelanggan_belum_lunas_list_data;
                } else {
                    console.warn("window.pelanggan_belum_lunas_list_data not found. Prefilling might fail.");
                }
            } catch (e) {
                console.error("Error accessing window.pelanggan_belum_lunas_list_data:", e);
                pelangganBelumLunasList = [];
            }

            const tagihanData = pelangganBelumLunasList.find(
                t => t.pelanggan_id == initialPelangganId && t.id_tagihan == initialTagihanId
            );
            if (tagihanData) {
                window.prefillPaymentForm( // FIX: Panggil fungsi global
                    parseInt(tagihanData.pelanggan_id),
                    parseFloat(tagihanData.jumlah_tagihan_display),
                    parseInt(tagihanData.paket_id),
                    tagihanData.bulan_tagihan
                );
            }
        } else if (pelangganIdSelect.value) { 
            if (defaultTabId === 'catatPembayaran') {
                updatePaketInfo();
            }
        }

        // Event listeners for payment form (existing)
        bulanTagihanInput.addEventListener('change', updatePaketInfo);
        pelangganIdSelect.addEventListener('change', updatePaketInfo);

        window.updateMetodePembayaranInput(); // Initial call for global function

        // Event listener for payment form submission
        paymentForm.addEventListener('submit', function(event) {
            window.updateMetodePembayaranInput(); // Panggil fungsi global
            if (!metodeCashCheckbox.checked && !metodeTransferCheckbox.checked) {
                event.preventDefault();
                metodePembayaranErrorDiv.style.display = 'block';
                // metodePembayaranErrorDiv.scrollIntoView({ behavior: 'smooth', block: 'center' }); // Removed for now due to block type error
                window.showNotification('Pilih setidaknya satu metode pembayaran.', 'error');
            } else {
                metodePembayaranErrorDiv.style.display = 'none';
            }
        });

        // Column Resizing Logic (existing)
        const table = document.querySelector('.data-table');
        if (table) { 
            let thElements = table.querySelectorAll('th.resizable-column');
            let isResizing = false;
            let currentResizer;
            let startX;
            let startWidth;
            let currentTh;
            let currentTdIndex;

            thElements.forEach((th, index) => {
                const resizer = document.createElement('div');
                resizer.classList.add('resizer');
                th.appendChild(resizer);

                resizer.addEventListener('mousedown', function(e) {
                    e.preventDefault();
                    currentResizer = this;
                    isResizing = true;
                    startX = e.clientX;
                    currentTh = currentResizer.parentElement;
                    startWidth = currentTh.offsetWidth;
                    currentTdIndex = Array.from(currentTh.parentNode.children).indexOf(currentTh);

                    table.classList.add('resizing');
                });
            });

            document.addEventListener('mousemove', function(e) {
                if (!isResizing) return;
                const width = startWidth + (e.clientX - startX);
                const newWidth = Math.max(5, width);

                currentTh.style.width = `${newWidth}px`;
                table.querySelectorAll('tr').forEach(row => {
                    if (row.children[currentTdIndex]) {
                        row.children[currentTdIndex].style.width = `${newWidth}px`;
                    }
                });
            });

            document.addEventListener('mouseup', function() {
                if (isResizing) {
                    isResizing = false;
                    table.classList.remove('resizing');
                }
            });
        }
    });
</script>