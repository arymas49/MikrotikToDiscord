// C:\xampp\htdocs\billing_isp_app\js\loading_scripts.js

document.addEventListener('DOMContentLoaded', function() {
    const loadingOverlay = document.getElementById('loadingOverlay');
    // lastScrollPosition tidak lagi diperlukan di sini karena fix_scroll.js yang menanganinya
    // let lastScrollPosition = 0; 

    // Fungsi untuk menampilkan loading overlay
    window.showLoading = function() {
        if (loadingOverlay) {
            // Tidak perlu lagi menyimpan posisi scroll di sini
            // lastScrollPosition = window.scrollY;
            loadingOverlay.classList.add('show');
        }
    };

    // Fungsi untuk menyembunyikan loading overlay
    window.hideLoading = function() {
        if (loadingOverlay) {
            loadingOverlay.classList.remove('show');
            // Hapus logika pemulihan scroll di sini, karena fix_scroll.js yang akan menanganinya
            // setTimeout(() => {
            //     window.scrollTo(0, lastScrollPosition);
            // }, 50); 
        }
    };

    // LOGIKA KLIK LINK MENU UNTUK MENAMPILKAN LOADING OVERLAY
    const allNavLinks = document.querySelectorAll('.sidebar-nav ul li a');

    allNavLinks.forEach(link => {
        link.addEventListener('click', function(event) {
            const currentPathname = window.location.pathname;
            const linkHref = this.getAttribute('href');

            // Tambahkan pengecekan untuk javascript:void(0);
            const isJavascriptVoidLink = linkHref === 'javascript:void(0);';

            const currentPageFile = currentPathname.split('/').pop();
            const linkPageFile = linkHref ? linkHref.split('/').pop() : '';

            // Tampilkan loading jika:
            // 1. Link memiliki href (bukan null atau kosong)
            // 2. Link BUKAN hanya "href='#'"
            // 3. Link BUKAN "href='javascript:void(0);'" (ini yang baru!)
            // 4. Link tidak mengarah ke halaman yang sudah aktif saat ini
            if (linkHref && linkHref !== '#' && !isJavascriptVoidLink && linkPageFile !== currentPageFile) { //
                window.showLoading(); // Panggil fungsi global
                // Tidak perlu preventDefault() di sini, biarkan browser menavigasi
            }
            // Jika ini link dropdown toggle (href="#") atau (href="javascript:void(0);"), jangan lakukan apa-apa di sini
            // Logika ini sudah ada di header.php dan berfungsi untuk toggle submenu
        });
    });

    // Sembunyikan loading overlay saat seluruh halaman selesai dimuat
    window.addEventListener('load', function() {
        window.hideLoading(); // Panggil fungsi global
    });

    // Opsional: Atur scroll restoration ke manual (untuk tombol back/forward)
    // Ini juga ada di fix_scroll.js, tapi tidak masalah jika ada di keduanya
    if ('scrollRestoration' in history) {
        history.scrollRestoration = 'manual';
    }
});