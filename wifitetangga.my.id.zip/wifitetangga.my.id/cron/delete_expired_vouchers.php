<?php
// C:\xampp\htdocs\billing_isp_app\cron\delete_expired_vouchers.php

// Pastikan skrip ini hanya bisa diakses dari CLI atau melalui otorisasi yang ketat
// atau hanya bisa diakses dari localhost jika melalui web server (misal .htaccess)
// Untuk tujuan cron job, ini biasanya dipanggil langsung oleh PHP CLI.

// Error reporting untuk debugging
error_reporting(E_ALL);
ini_set('display_errors', 'Off'); // Nonaktifkan display errors di lingkungan produksi
ini_set('log_errors', 'On');
ini_set('error_log', __DIR__ . '/../logs/cron_error.log'); // Sesuaikan path log error

// Log proses
function log_message($message) {
    echo date('Y-m-d H:i:s') . " - " . $message . PHP_EOL;
    error_log(date('Y-m-d H:i:s') . " - " . $message, 3, __DIR__ . '/../logs/cron_activity.log'); // Log ke file aktivitas
}

log_message("Starting expired voucher deletion script...");

// Include koneksi database
include_once __DIR__ . '/../config/koneksi.php'; // Ini akan menyediakan $koneksi

// Include library RouterOS API
include_once __DIR__ . '/../vendor/routeros_api/routeros_api.class.php';

// Fungsi untuk mendapatkan pengaturan Mikrotik dari database
function getMikrotikSettings($koneksi) {
    $settings = [];
    $query = "SELECT ip_address, username, password, port_api FROM mikrotik_settings LIMIT 1";
    $result = $koneksi->query($query);
    if ($result && $result->num_rows > 0) {
        $settings = $result->fetch_assoc();
    }
    return $settings;
}

// Fungsi untuk menghubungkan ke Mikrotik
function connectToMikrotik($koneksi) {
    $settings = getMikrotikSettings($koneksi);
    if (empty($settings['ip_address']) || empty($settings['username'])) {
        return ['status' => 'error', 'message' => 'Pengaturan Mikrotik (IP, Username) belum lengkap di database.'];
    }

    $API = new RouterosAPI();
    $API->debug = false;
    $API->port = $settings['port_api'] ?? 8728;

    if ($API->connect($settings['ip_address'], $settings['username'], $settings['password'])) {
        return ['status' => 'success', 'API' => $API];
    } else {
        return ['status' => 'error', 'message' => 'Gagal terhubung ke Mikrotik: ' . ($API->error_str ?? 'Tidak ada pesan error spesifik.')];
    }
}

$mikrotik_api_connection = null;
try {
    $connection_result = connectToMikrotik($koneksi);
    if ($connection_result['status'] === 'success') {
        $mikrotik_api_connection = $connection_result['API'];
        log_message("Successfully connected to MikroTik.");
    } else {
        log_message("Failed to connect to MikroTik: " . $connection_result['message']);
        exit(); // Hentikan skrip jika gagal koneksi Mikrotik
    }

    $removed_from_mikrotik_count = 0;
    $removed_from_db_count = 0;

    // --- Langkah 1: Hapus pengguna kadaluarsa dari MikroTik ---
    // Kriteria: user dengan 'limit-uptime' = '1s' (Mikrotik menandai ini sebagai kadaluarsa)
    $expired_users_mikrotik = $mikrotik_api_connection->comm("/ip/hotspot/user/print", ["?limit-uptime" => "1s"]);

    $usernames_to_remove_from_db = [];

    if (!empty($expired_users_mikrotik)) {
        log_message("Found " . count($expired_users_mikrotik) . " expired users in MikroTik.");
        foreach ($expired_users_mikrotik as $user) {
            if (isset($user['.id']) && isset($user['name'])) {
                $remove_response = $mikrotik_api_connection->comm("/ip/hotspot/user/remove", [".id" => $user['.id']]);
                if (!isset($remove_response['!trap'])) {
                    $removed_from_mikrotik_count++;
                    $usernames_to_remove_from_db[] = $user['name']; // Kumpulkan username untuk dihapus dari DB
                    log_message("Removed user '" . $user['name'] . "' from MikroTik.");
                } else {
                    log_message("Failed to remove user '" . $user['name'] . "' from MikroTik: " . ($remove_response['!trap'][0]['message'] ?? 'Unknown error.'));
                }
            }
        }
        log_message("Finished removing users from MikroTik. Removed: " . $removed_from_mikrotik_count);
    } else {
        log_message("No expired users found in MikroTik with 'limit-uptime=1s'.");
    }

    // --- Langkah 2: Hapus voucher yang sesuai dari database lokal ---
    if (!empty($usernames_to_remove_from_db)) {
        // Buat placeholder untuk query IN (?, ?, ...)
        $placeholders = implode(',', array_fill(0, count($usernames_to_remove_from_db), '?'));
        $sql_delete_db = "DELETE FROM vouchers WHERE username IN ($placeholders)";

        $stmt = $koneksi->prepare($sql_delete_db);
        if ($stmt) {
            // Binding parameter (tipe 's' untuk string, sebanyak jumlah username)
            $types = str_repeat('s', count($usernames_to_remove_from_db));
            $stmt->bind_param($types, ...$usernames_to_remove_from_db);

            if ($stmt->execute()) {
                $removed_from_db_count = $stmt->affected_rows;
                log_message("Removed " . $removed_from_db_count . " vouchers from local database.");
            } else {
                log_message("Failed to delete vouchers from local database: " . $stmt->error);
            }
            $stmt->close();
        } else {
            log_message("Failed to prepare SQL statement for DB deletion: " . $koneksi->error);
        }
    } else {
        log_message("No usernames to remove from local database.");
    }

} catch (Exception $e) {
    log_message("An unexpected error occurred: " . $e->getMessage());
} finally {
    if ($mikrotik_api_connection && $mikrotik_api_connection->is_connected()) {
        $mikrotik_api_connection->disconnect();
        log_message("Disconnected from MikroTik.");
    }
    if (isset($koneksi) && $koneksi->ping()) {
        $koneksi->close();
        log_message("Database connection closed.");
    }
    log_message("Expired voucher deletion script finished.");
}
?>

0 * * * * /usr/bin/php /path/to/your/billing_isp_app/cron/delete_expired_vouchers.php >> /path/to/your/billing_isp_app/logs/cron.log 2>&1