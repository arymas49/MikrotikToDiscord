<?php
// C:\xampp\htdocs\billing_isp_app\index.php
ob_start();
ini_set('session.use_strict_mode', 1);
ini_set('session.cookie_httponly', 1);
ini_set('session.cookie_samesite', 'Lax');
if (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on') {
    ini_set('session.cookie_secure', 1);
}
session_start(); //
include 'config/koneksi.php'; //
include 'config/log_activity.php'; //

$error_message = '';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $username = $koneksi->real_escape_string($_POST['username']);
    $password = $_POST['password'];

    $query = "SELECT id, username, password, role FROM users WHERE username = ?";
    $stmt = $koneksi->prepare($query);
    $stmt->bind_param("s", $username);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows == 1) {
        $user = $result->fetch_assoc();
        if (password_verify($password, $user['password'])) {
            $_SESSION['user_id'] = $user['id'];
            $_SESSION['username'] = $user['username'];
            $_SESSION['role'] = $user['role'];
            // Log aktivitas login berhasil
            logActivity('Login', 'User ' . $username . ' berhasil login.');
            header('Location: pages/dashboard.php');
            exit();
        } else {
            $error_message = 'Username atau password salah.';
        }
    } else {
        $error_message = 'Username atau password salah.';
    }
    $stmt->close();
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login - TZN</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <link rel="icon" type="image/png" href="assets/images/Logo.png"> 
    <style>
         body {
            margin: 0;
            padding: 0;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            /* Hapus background-color: #f0f2f5; jika Anda ingin gambar mengisi seluruh background */

            /* Tambahkan properti background di sini */
            background-image: url('assets/images/background_login.jpg'); /* Ganti dengan path gambar Anda */
            background-size: cover; /* Menutupi seluruh area tanpa mengulang gambar */
            background-position: center center; /* Memposisikan gambar di tengah */
            background-repeat: no-repeat; /* Mencegah gambar berulang */
            background-attachment: fixed; /* Membuat gambar tetap saat discroll (opsional) */

            display: flex;
            justify-content: center;
            align-items: center;
            min-height: 100vh;
            color: #333;
        }

        .login-container {
            text-align: center;
            background-color: #fff; /* White background for the main container */
            padding: 30px;
            border-radius: 10px;
            box-shadow: 0 4px 15px rgba(0, 0, 0, 0.1); /* Soft shadow */
            max-width: 400px; /* Maximum width for the login box */
            width: 90%; /* Responsive width */
            box-sizing: border-box; /* Include padding in the width */
        }

        /* Logo styling */
        .logo img {
            width: 120px; /* Size of the logo */
            height: auto;
            margin-bottom: 15px;
        }

        /* System information (title and version) */
        .system-info h1 {
            font-size: 1.8em;
            margin-bottom: 5px;
            color: #333;
        }

        .system-info p {
            font-size: 1em;
            color: #666;
            margin-top: 0;
            margin-bottom: 25px;
        }

        /* Login form box (inner card) */
        .login-box {
            background-color: #fff;
            padding: 25px;
            border-radius: 8px;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.08); /* Slight shadow for the form box */
            margin-bottom: 20px; /* Space between login box and footer info */
        }

        .login-box h2 {
            font-size: 1.5em;
            color: #555;
            margin-top: 0;
            margin-bottom: 20px;
            border-bottom: 1px solid #eee; /* Separator line */
            padding-bottom: 15px;
        }

        /* Input field group with icon */
        .input-group {
            position: relative;
            margin-bottom: 18px;
        }

        .input-group input {
            width: calc(100% - 40px); /* Adjust width to make space for the icon */
            padding: 12px 15px 12px 40px; /* Left padding for the icon */
            border: 1px solid #ddd;
            border-radius: 5px;
            font-size: 1em;
            box-sizing: border-box; /* Include padding and border in the element's total width and height */
            transition: border-color 0.3s;
        }

        .input-group input:focus {
            border-color: #007bff; /* Highlight border on focus */
            outline: none;
        }

        .input-group i {
            position: absolute;
            left: 30px; /* Position of the icon */
            top: 50%;
            transform: translateY(-50%);
            color: #888;
        }

        /* General button styling */
        .btn {
            display: block; /* Make button take full width */
            width: 100%;
            padding: 12px;
            border: none;
            border-radius: 5px;
            font-size: 1.1em;
            cursor: pointer;
            transition: background-color 0.3s ease;
            margin-top: 10px; /* Space between buttons */
            font-weight: bold;
        }

        /* Primary button (for "Masuk") */
        .btn-primary {
            background-color: #ffc107; /* Yellow color */
            color: #333; /* Dark text for contrast */
        }

        .btn-primary:hover {
            background-color: #e0a800; /* Darker yellow on hover */
        }

        /* Secondary button (for "Lupa Password") */
        .btn-secondary {
            background-color: #007bff; /* Blue color */
            color: #fff;
            margin-top: 10px; /* Keep consistent margin */
        }

        .btn-secondary:hover {
            background-color: #0056b3; /* Darker blue on hover */
        }
        
        /* Footer information */
        .footer-info {
            margin-top: 20px;
            font-size: 0.85em;
            color: #777;
        }

        .footer-info a {
            color: #007bff;
            text-decoration: none;
        }

        .footer-info a:hover {
            text-decoration: underline;
        }

        /* Alert messages (for error display from PHP) */
        .alert {
            padding: 10px;
            margin-bottom: 15px;
            border: 1px solid transparent;
            border-radius: 5px;
            display: flex;
            align-items: center;
            gap: 8px;
            font-size: 0.9em;
            margin-top: 15px; /* Add margin top for messages */
        }

        .alert-danger {
            color: #842029;
            background-color: #f8d7da;
            border-color: #ebccce;
        }
        .alert-danger i {
            color: #dc3545;
        }
    </style>
</head>
<body>
    <div class="login-container">
        <div class="logo">
            <img src="assets/images/Logo.png" alt="Logo SLF"> </div>
        <div class="system-info">
            <h1>Billing Tetangga</h1>
        </div>

        <div class="login-box">
            <?php if ($error_message): ?>
                <div class="alert alert-danger"><i class="fas fa-exclamation-circle"></i> <?php echo htmlspecialchars($error_message, ENT_QUOTES, "UTF-8"); ?></div>
            <?php endif; ?>
            <form method="POST"><?php if (!isset($_SESSION['csrf_token'])) { $_SESSION['csrf_token'] = bin2hex(random_bytes(32)); } ?><input type='hidden' name='csrf_token' value='<?php echo $_SESSION['csrf_token']; ?>'>
                <div class="input-group">
                    <input type="text" id="username" name="username" placeholder="username" required>
                    <i class="fas fa-user"></i>
                </div>
                <div class="input-group">
                    <input type="password" id="password" name="password" placeholder="••••••••" required>
                    <i class="fas fa-lock"></i>
                </div>
                <button type="submit" class="btn btn-primary">Masuk</button>

        <div class="footer-info">
            <p>Copyright &copy; <a href="#">Kiukiu</a> Created 2025</p>
        </div>
    </div>
</body>
</html>
<?php
$koneksi->close();
ob_end_flush(); // Pastikan ob_end_flush() dipanggil di akhir
?>