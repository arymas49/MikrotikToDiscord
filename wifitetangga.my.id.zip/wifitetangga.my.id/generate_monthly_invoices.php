<?php
// C:\xampp\htdocs\billing_isp_app\generate_monthly_invoices.php
// Skrip ini dirancang untuk dijalankan via Cron Job setiap awal bulan.

// Pastikan skrip hanya bisa diakses dari CLI atau Cron Job (opsional, untuk keamanan)
if (php_sapi_name() !== 'cli' && !isset($_GET['run_manual'])) {
    die("Akses ditolak. Skrip ini hanya bisa dijalankan dari command line atau Cron Job.");
}

include 'config/koneksi.php'; // Koneksi database

echo "Memulai generasi invoice bulanan...\n";

// Tentukan bulan dan tahun untuk invoice yang akan dibuat
$invoice_month_year = date('Y-m'); // Contoh: '2025-06'
$tanggal_terbit = date('Y-m-d');   // Tanggal hari ini
$tanggal_jatuh_tempo = date('Y-m-t', strtotime($invoice_month_year . '-01')); // Akhir bulan ini

// Konfigurasi PPN
$ppn_percentage = 0.11; // 11%

echo "Generasi invoice untuk periode: " . $invoice_month_year . "\n";

// 1. Ambil semua pelanggan yang statusnya 'Aktif', BESERTA penagih_id dan uses_ppn
$query_active_pelanggan = "
    SELECT
        p.id_pelanggan,
        p.paket_id,
        pk.harga,
        p.penagih_id,   -- NEW: Ambil penagih_id dari pelanggan
        p.uses_ppn      -- NEW: Ambil uses_ppn dari pelanggan
    FROM pelanggan p
    JOIN paket_layanan pk ON p.paket_id = pk.id_paket
    WHERE p.status_aktif = 'Aktif'
";
$result_active_pelanggan = $koneksi->query($query_active_pelanggan);

$invoices_generated = 0;
$invoices_skipped_exist = 0;
$invoices_skipped_inactive = 0;

if ($result_active_pelanggan->num_rows > 0) {
    while ($pelanggan = $result_active_pelanggan->fetch_assoc()) {
        $pelanggan_id = $pelanggan['id_pelanggan'];
        $paket_id = $pelanggan['paket_id'];
        $harga_paket_bersih = $pelanggan['harga']; // Ini adalah harga paket tanpa PPN
        $penagih_id = $pelanggan['penagih_id']; // Ambil penagih_id
        $uses_ppn = $pelanggan['uses_ppn'];   // Ambil uses_ppn

        // Hitung total_tagihan (harga_paket + PPN jika berlaku)
        $total_tagihan_penuh = $harga_paket_bersih;
        if ($uses_ppn == 1) {
            $total_tagihan_penuh += ($harga_paket_bersih * $ppn_percentage);
        }

        // 2. Cek apakah invoice untuk pelanggan ini dan bulan ini sudah ada
        $stmt_check_invoice = $koneksi->prepare("SELECT id_tagihan FROM tagihan WHERE pelanggan_id = ? AND bulan_tagihan = ?");
        $stmt_check_invoice->bind_param("is", $pelanggan_id, $invoice_month_year);
        $stmt_check_invoice->execute();
        $check_result = $stmt_check_invoice->get_result();

        if ($check_result->num_rows == 0) {
            // Invoice belum ada, buat yang baru
            // NEW: Tambahkan penagih_id, total_tagihan, dan sisa_tagihan
            $stmt_insert_invoice = $koneksi->prepare("
                INSERT INTO tagihan (pelanggan_id, paket_id, bulan_tagihan, jumlah_tagihan, total_tagihan, sisa_tagihan, tanggal_terbit, tanggal_jatuh_tempo, status_tagihan, penagih_id)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, 'Belum Lunas', ?)
            ");
            // jumlah_tagihan (harga_paket_bersih) adalah harga sebelum PPN
            // total_tagihan adalah harga_paket_bersih + PPN
            // sisa_tagihan awal sama dengan total_tagihan
            // penagih_id bisa NULL di DB, jadi tipe bindingnya harus 's' jika $penagih_id is NULL
            // atau 'i' jika $penagih_id adalah integer.
            $penagih_id_type = is_null($penagih_id) ? 's' : 'i';

            // Parameter binding harus sesuai urutan dan tipe
            $bind_params = [
                $pelanggan_id,
                $paket_id,
                $invoice_month_year,
                $harga_paket_bersih,      // jumlah_tagihan (harga bersih)
                $total_tagihan_penuh,     // total_tagihan (harga_bersih + PPN)
                $total_tagihan_penuh,     // sisa_tagihan (awal sama dengan total_tagihan)
                $tanggal_terbit,
                $tanggal_jatuh_tempo,
                $penagih_id               // penagih_id (bisa NULL)
            ];

            // Tipe binding: iisddsss + (s/i)
            $types = "iisddsss" . $penagih_id_type;

            // Menggunakan call_user_func_array untuk bind_param dengan array dinamis dan referensi
            // Ini diperlukan karena bind_param membutuhkan argumen by reference.
            $refs = [];
            foreach($bind_params as $key => $value) {
                $refs[$key] = &$bind_params[$key];
            }
            // Tambahkan $types sebagai argumen pertama ke $refs
            array_unshift($refs, $types);

            if (call_user_func_array([$stmt_insert_invoice, 'bind_param'], $refs)) {
                if ($stmt_insert_invoice->execute()) {
                    echo "Invoice baru untuk pelanggan ID: " . $pelanggan_id . " bulan " . $invoice_month_year . " berhasil dibuat. (Total: Rp " . number_format($total_tagihan_penuh, 0, ',', '.') . ")\n";
                    $invoices_generated++;
                } else {
                    echo "Gagal membuat invoice untuk pelanggan ID: " . $pelanggan_id . ". Error execute: " . $stmt_insert_invoice->error . "\n";
                }
            } else {
                echo "Gagal bind_param untuk pelanggan ID: " . $pelanggan_id . ". Error bind_param: " . $stmt_insert_invoice->error . "\n";
            }
            $stmt_insert_invoice->close();
        } else {
            echo "Invoice untuk pelanggan ID: " . $pelanggan_id . " bulan " . $invoice_month_year . " sudah ada. Dilewati.\n";
            $invoices_skipped_exist++;
        }
        $stmt_check_invoice->close();
    }
} else {
    echo "Tidak ada pelanggan aktif ditemukan.\n";
}

echo "Proses generasi invoice selesai.\n";
echo "Total invoice dibuat: " . $invoices_generated . "\n";
echo "Total invoice dilewati (sudah ada): " . $invoices_skipped_exist . "\n";

$koneksi->close();

?>